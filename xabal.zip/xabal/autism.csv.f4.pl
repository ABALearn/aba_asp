% training data:
% no. positive ex.: 13
% no. negative ex.: 26
% query: 
train :- aba_asp('./xabal/autism.csv.f4.bk',[autism(434),autism(529),autism(124),autism(509),autism(660),autism(559),autism(521),autism(654),autism(203),autism(545),autism(494),autism(638),autism(449)],[autism(304),autism(608),autism(64),autism(294),autism(132),autism(600),autism(215),autism(633),autism(202),autism(113),autism(520),autism(160),autism(295),autism(133),autism(88),autism(205),autism(267),autism(321),autism(286),autism(157),autism(44),autism(131),autism(259),autism(470),autism(489),autism(9)]).
% test data:
% no. positive ex.: 4
% no. negative ex.: 7
% query: 
test :- test_abaf('./xabal/autism.csv.f4.bk.sol',[pos(autism(224),[a1(224),a3(224),a4(224),a6(224),a7(224),a8(224),a9(224),a10(224),age2(224),white(224),self(224)]),pos(autism(189),[a1(189),a2(189),a4(189),a5(189),a6(189),a8(189),a9(189),a10(189),age5(189),female(189),white(189),pdd(189),self(189)]),pos(autism(693),[a1(693),a2(693),a3(693),a5(693),a6(693),a7(693),a8(693),a10(693),age2(693),white(693),self(693)]),pos(autism(472),[a1(472),a2(472),a3(472),a4(472),a5(472),a7(472),a8(472),age2(472),latino(472),self(472)])],[neg(autism(527),[a4(527),a7(527),a8(527),a10(527),age3(527),asian(527),self(527)]),neg(autism(110),[a1(110),a6(110),a7(110),age1(110),female(110),asian(110),parent(110)]),neg(autism(342),[a1(342),a2(342),a3(342),a4(342),a5(342),a8(342),age1(342)]),neg(autism(306),[a1(306),a2(306),a4(306),a10(306),age3(306),female(306),white(306),self(306)]),neg(autism(581),[a3(581),a4(581),age4(581),black(581),self(581)]),neg(autism(617),[a1(617),a5(617),a7(617),age2(617),southasian(617),self(617)]),neg(autism(676),[a1(676),a2(676),a3(676),a4(676),a9(676),age2(676),female(676),white(676),jaundice(676),self(676)])]).
