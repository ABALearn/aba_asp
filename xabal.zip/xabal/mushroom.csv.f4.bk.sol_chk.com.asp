head(id(1),cap_shapef(6363)).
head(id(2),cap_surfaces(6363)).
head(id(3),cap_colore(6363)).
head(id(4),odorf(6363)).
head(id(5),gill_spacing(6363)).
head(id(6),gill_size(6363)).
head(id(7),gill_colorb(6363)).
head(id(8),stalk_surface_above_rings(6363)).
head(id(9),stalk_surface_below_ringk(6363)).
head(id(10),stalk_color_above_ringw(6363)).
head(id(11),stalk_color_below_ringp(6363)).
head(id(12),veil_colorw(6363)).
head(id(13),ring_numbero(6363)).
head(id(14),ring_typee(6363)).
head(id(15),spore_print_colorw(6363)).
head(id(16),populationv(6363)).
head(id(17),habitatl(6363)).
head(id(18),cap_surfaces(4107)).
head(id(19),cap_colorb(4107)).
head(id(20),bruises(4107)).
head(id(21),odorn(4107)).
head(id(22),gill_spacing(4107)).
head(id(23),gill_colorg(4107)).
head(id(24),stalk_rootb(4107)).
head(id(25),stalk_surface_above_rings(4107)).
head(id(26),stalk_surface_below_rings(4107)).
head(id(27),stalk_color_above_ringw(4107)).
head(id(28),stalk_color_below_ringw(4107)).
head(id(29),veil_colorw(4107)).
head(id(30),spore_print_colorr(4107)).
head(id(31),populationv(4107)).
head(id(32),habitatm(4107)).
head(id(33),cap_shapex(5522)).
head(id(34),cap_colorn(5522)).
head(id(35),odors(5522)).
head(id(36),gill_spacing(5522)).
head(id(37),gill_size(5522)).
head(id(38),gill_colorb(5522)).
head(id(39),stalk_surface_above_ringk(5522)).
head(id(40),stalk_surface_below_ringk(5522)).
head(id(41),stalk_color_above_ringw(5522)).
head(id(42),stalk_color_below_ringw(5522)).
head(id(43),veil_colorw(5522)).
head(id(44),ring_numbero(5522)).
head(id(45),ring_typee(5522)).
head(id(46),spore_print_colorw(5522)).
head(id(47),populationv(5522)).
head(id(48),habitatd(5522)).
head(id(49),cap_shapex(4271)).
head(id(50),cap_surfacef(4271)).
head(id(51),odorf(4271)).
head(id(52),gill_spacing(4271)).
head(id(53),gill_colorg(4271)).
head(id(54),stalk_rootb(4271)).
head(id(55),stalk_surface_above_ringk(4271)).
head(id(56),stalk_surface_below_ringk(4271)).
head(id(57),stalk_color_above_ringb(4271)).
head(id(58),stalk_color_below_ringp(4271)).
head(id(59),veil_colorw(4271)).
head(id(60),ring_numbero(4271)).
head(id(61),ring_typel(4271)).
head(id(62),spore_print_colorh(4271)).
head(id(63),populationv(4271)).
head(id(64),habitatp(4271)).
head(id(65),cap_shapex(4499)).
head(id(66),cap_colorn(4499)).
head(id(67),gill_spacing(4499)).
head(id(68),gill_size(4499)).
head(id(69),gill_colorb(4499)).
head(id(70),stalk_surface_above_rings(4499)).
head(id(71),stalk_surface_below_ringk(4499)).
head(id(72),stalk_color_above_ringp(4499)).
head(id(73),stalk_color_below_ringp(4499)).
head(id(74),veil_colorw(4499)).
head(id(75),ring_numbero(4499)).
head(id(76),ring_typee(4499)).
head(id(77),spore_print_colorw(4499)).
head(id(78),populationv(4499)).
head(id(79),habitatp(4499)).
head(id(80),cap_shapek(7794)).
head(id(81),cap_surfaces(7794)).
head(id(82),cap_colorn(7794)).
head(id(83),gill_spacing(7794)).
head(id(84),gill_size(7794)).
head(id(85),gill_colorb(7794)).
head(id(86),stalk_surface_above_ringk(7794)).
head(id(87),stalk_surface_below_rings(7794)).
head(id(88),stalk_color_above_ringw(7794)).
head(id(89),stalk_color_below_ringp(7794)).
head(id(90),veil_colorw(7794)).
head(id(91),ring_numbero(7794)).
head(id(92),ring_typee(7794)).
head(id(93),spore_print_colorw(7794)).
head(id(94),populationv(7794)).
head(id(95),habitatp(7794)).
head(id(96),cap_shapex(1100)).
head(id(97),cap_colorn(1100)).
head(id(98),bruises(1100)).
head(id(99),odorp(1100)).
head(id(100),gill_spacing(1100)).
head(id(101),gill_size(1100)).
head(id(102),gill_colorn(1100)).
head(id(103),stalk_roote(1100)).
head(id(104),stalk_surface_above_rings(1100)).
head(id(105),stalk_surface_below_rings(1100)).
head(id(106),stalk_color_above_ringw(1100)).
head(id(107),stalk_color_below_ringw(1100)).
head(id(108),veil_colorw(1100)).
head(id(109),ring_numbero(1100)).
head(id(110),spore_print_colorn(1100)).
head(id(111),populations(1100)).
head(id(112),habitatg(1100)).
head(id(113),cap_shapek(7102)).
head(id(114),cap_colore(7102)).
head(id(115),odors(7102)).
head(id(116),gill_spacing(7102)).
head(id(117),gill_size(7102)).
head(id(118),gill_colorb(7102)).
head(id(119),stalk_surface_above_ringk(7102)).
head(id(120),stalk_surface_below_ringk(7102)).
head(id(121),stalk_color_above_ringw(7102)).
head(id(122),stalk_color_below_ringp(7102)).
head(id(123),veil_colorw(7102)).
head(id(124),ring_numbero(7102)).
head(id(125),ring_typee(7102)).
head(id(126),spore_print_colorw(7102)).
head(id(127),populationv(7102)).
head(id(128),habitatp(7102)).
head(id(129),cap_shapex(3470)).
head(id(130),cap_surfaces(3470)).
head(id(131),cap_colorp(3470)).
head(id(132),odorc(3470)).
head(id(133),gill_spacing(3470)).
head(id(134),gill_size(3470)).
head(id(135),gill_colorn(3470)).
head(id(136),stalk_rootb(3470)).
head(id(137),stalk_surface_above_rings(3470)).
head(id(138),stalk_surface_below_rings(3470)).
head(id(139),stalk_color_above_ringw(3470)).
head(id(140),stalk_color_below_ringw(3470)).
head(id(141),veil_colorw(3470)).
head(id(142),ring_numbero(3470)).
head(id(143),spore_print_colorn(3470)).
head(id(144),populationv(3470)).
head(id(145),habitatd(3470)).
head(id(146),cap_shapex(5772)).
head(id(147),cap_colorn(5772)).
head(id(148),gill_spacing(5772)).
head(id(149),gill_size(5772)).
head(id(150),gill_colorb(5772)).
head(id(151),stalk_surface_above_ringk(5772)).
head(id(152),stalk_surface_below_ringk(5772)).
head(id(153),stalk_color_above_ringp(5772)).
head(id(154),stalk_color_below_ringp(5772)).
head(id(155),veil_colorw(5772)).
head(id(156),ring_numbero(5772)).
head(id(157),ring_typee(5772)).
head(id(158),spore_print_colorw(5772)).
head(id(159),populationv(5772)).
head(id(160),habitatl(5772)).
head(id(161),cap_shapec(5509)).
head(id(162),cap_colorw(5509)).
head(id(163),bruises(5509)).
head(id(164),odorn(5509)).
head(id(165),gill_size(5509)).
head(id(166),gill_colorw(5509)).
head(id(167),stalk_rootb(5509)).
head(id(168),stalk_surface_above_rings(5509)).
head(id(169),stalk_surface_below_rings(5509)).
head(id(170),stalk_color_above_ringw(5509)).
head(id(171),stalk_color_below_ringw(5509)).
head(id(172),veil_colorw(5509)).
head(id(173),ring_numbero(5509)).
head(id(174),spore_print_colorw(5509)).
head(id(175),populationc(5509)).
head(id(176),habitatl(5509)).
head(id(177),cap_shapef(6946)).
head(id(178),cap_colore(6946)).
head(id(179),odorm(6946)).
head(id(180),gill_attachment(6946)).
head(id(181),gill_spacing(6946)).
head(id(182),gill_colorw(6946)).
head(id(183),stalk_rootc(6946)).
head(id(184),stalk_surface_above_ringk(6946)).
head(id(185),stalk_color_above_ringc(6946)).
head(id(186),stalk_color_below_ringc(6946)).
head(id(187),veil_colorw(6946)).
head(id(188),ring_numbern(6946)).
head(id(189),ring_typen(6946)).
head(id(190),spore_print_colorw(6946)).
head(id(191),populationc(6946)).
head(id(192),habitatd(6946)).
head(id(193),cap_shapex(3338)).
head(id(194),cap_surfacef(3338)).
head(id(195),cap_colorw(3338)).
head(id(196),odorc(3338)).
head(id(197),gill_size(3338)).
head(id(198),gill_colorg(3338)).
head(id(199),stalk_rootb(3338)).
head(id(200),stalk_surface_above_rings(3338)).
head(id(201),stalk_surface_below_rings(3338)).
head(id(202),stalk_color_above_ringw(3338)).
head(id(203),stalk_color_below_ringw(3338)).
head(id(204),veil_colorw(3338)).
head(id(205),ring_numbero(3338)).
head(id(206),spore_print_colork(3338)).
head(id(207),populationv(3338)).
head(id(208),habitatd(3338)).
head(id(209),cap_shapef(6507)).
head(id(210),cap_colore(6507)).
head(id(211),odorf(6507)).
head(id(212),gill_spacing(6507)).
head(id(213),gill_size(6507)).
head(id(214),gill_colorb(6507)).
head(id(215),stalk_surface_above_rings(6507)).
head(id(216),stalk_surface_below_rings(6507)).
head(id(217),stalk_color_above_ringp(6507)).
head(id(218),stalk_color_below_ringp(6507)).
head(id(219),veil_colorw(6507)).
head(id(220),ring_numbero(6507)).
head(id(221),ring_typee(6507)).
head(id(222),spore_print_colorw(6507)).
head(id(223),populationv(6507)).
head(id(224),habitatp(6507)).
head(id(225),cap_shapef(6341)).
head(id(226),cap_colore(6341)).
head(id(227),odorf(6341)).
head(id(228),gill_spacing(6341)).
head(id(229),gill_size(6341)).
head(id(230),gill_colorb(6341)).
head(id(231),stalk_surface_above_rings(6341)).
head(id(232),stalk_surface_below_ringk(6341)).
head(id(233),stalk_color_above_ringp(6341)).
head(id(234),stalk_color_below_ringw(6341)).
head(id(235),veil_colorw(6341)).
head(id(236),ring_numbero(6341)).
head(id(237),ring_typee(6341)).
head(id(238),spore_print_colorw(6341)).
head(id(239),populationv(6341)).
head(id(240),habitatd(6341)).
head(id(241),cap_shapex(4725)).
head(id(242),cap_surfacef(4725)).
head(id(243),odorf(4725)).
head(id(244),gill_spacing(4725)).
head(id(245),gill_colorp(4725)).
head(id(246),stalk_rootb(4725)).
head(id(247),stalk_surface_above_ringk(4725)).
head(id(248),stalk_surface_below_ringk(4725)).
head(id(249),stalk_color_above_ringb(4725)).
head(id(250),stalk_color_below_ringp(4725)).
head(id(251),veil_colorw(4725)).
head(id(252),ring_numbero(4725)).
head(id(253),ring_typel(4725)).
head(id(254),spore_print_colorh(4725)).
head(id(255),habitatd(4725)).
head(id(256),cap_shapex(4341)).
head(id(257),cap_colorg(4341)).
head(id(258),odorf(4341)).
head(id(259),gill_spacing(4341)).
head(id(260),gill_colorg(4341)).
head(id(261),stalk_rootb(4341)).
head(id(262),stalk_surface_above_ringk(4341)).
head(id(263),stalk_surface_below_ringk(4341)).
head(id(264),stalk_color_above_ringp(4341)).
head(id(265),stalk_color_below_ringn(4341)).
head(id(266),veil_colorw(4341)).
head(id(267),ring_numbero(4341)).
head(id(268),ring_typel(4341)).
head(id(269),spore_print_colorh(4341)).
head(id(270),habitatg(4341)).
head(id(271),cap_shapef(4195)).
head(id(272),cap_surfaces(4195)).
head(id(273),cap_colorb(4195)).
head(id(274),bruises(4195)).
head(id(275),odorf(4195)).
head(id(276),gill_spacing(4195)).
head(id(277),gill_colorw(4195)).
head(id(278),stalk_rootb(4195)).
head(id(279),stalk_surface_above_ringf(4195)).
head(id(280),stalk_surface_below_ringf(4195)).
head(id(281),stalk_color_above_ringw(4195)).
head(id(282),stalk_color_below_ringw(4195)).
head(id(283),veil_colorw(4195)).
head(id(284),ring_numbero(4195)).
head(id(285),spore_print_colorh(4195)).
head(id(286),populations(4195)).
head(id(287),habitatu(4195)).
head(id(288),cap_shapex(4477)).
head(id(289),odorf(4477)).
head(id(290),gill_spacing(4477)).
head(id(291),gill_colorp(4477)).
head(id(292),stalk_rootb(4477)).
head(id(293),stalk_surface_above_ringk(4477)).
head(id(294),stalk_surface_below_ringk(4477)).
head(id(295),stalk_color_above_ringb(4477)).
head(id(296),stalk_color_below_ringn(4477)).
head(id(297),veil_colorw(4477)).
head(id(298),ring_numbero(4477)).
head(id(299),ring_typel(4477)).
head(id(300),spore_print_colorh(4477)).
head(id(301),populationv(4477)).
head(id(302),habitatp(4477)).
head(id(303),cap_shapex(5816)).
head(id(304),cap_colorn(5816)).
head(id(305),odors(5816)).
head(id(306),gill_spacing(5816)).
head(id(307),gill_size(5816)).
head(id(308),gill_colorb(5816)).
head(id(309),stalk_surface_above_ringk(5816)).
head(id(310),stalk_surface_below_ringk(5816)).
head(id(311),stalk_color_above_ringp(5816)).
head(id(312),stalk_color_below_ringp(5816)).
head(id(313),veil_colorw(5816)).
head(id(314),ring_numbero(5816)).
head(id(315),ring_typee(5816)).
head(id(316),spore_print_colorw(5816)).
head(id(317),populationv(5816)).
head(id(318),habitatl(5816)).
head(id(319),cap_shapex(6443)).
head(id(320),cap_surfaces(6443)).
head(id(321),cap_colorn(6443)).
head(id(322),gill_spacing(6443)).
head(id(323),gill_size(6443)).
head(id(324),gill_colorb(6443)).
head(id(325),stalk_surface_above_rings(6443)).
head(id(326),stalk_surface_below_rings(6443)).
head(id(327),stalk_color_above_ringw(6443)).
head(id(328),stalk_color_below_ringw(6443)).
head(id(329),veil_colorw(6443)).
head(id(330),ring_numbero(6443)).
head(id(331),ring_typee(6443)).
head(id(332),spore_print_colorw(6443)).
head(id(333),populationv(6443)).
head(id(334),habitatl(6443)).
head(id(335),cap_shapek(7047)).
head(id(336),cap_surfacef(7047)).
head(id(337),cap_colorg(7047)).
head(id(338),odorn(7047)).
head(id(339),gill_colorp(7047)).
head(id(340),stalk_surface_above_rings(7047)).
head(id(341),stalk_surface_below_ringk(7047)).
head(id(342),stalk_color_above_ringw(7047)).
head(id(343),stalk_color_below_ringw(7047)).
head(id(344),veil_colorw(7047)).
head(id(345),spore_print_colorw(7047)).
head(id(346),populationn(7047)).
head(id(347),habitatg(7047)).
head(id(348),cap_colorw(209)).
head(id(349),bruises(209)).
head(id(350),odorl(209)).
head(id(351),gill_spacing(209)).
head(id(352),gill_colorn(209)).
head(id(353),stalk_rootc(209)).
head(id(354),stalk_surface_above_rings(209)).
head(id(355),stalk_surface_below_rings(209)).
head(id(356),stalk_color_above_ringw(209)).
head(id(357),stalk_color_below_ringw(209)).
head(id(358),veil_colorw(209)).
head(id(359),ring_numbero(209)).
head(id(360),spore_print_colorn(209)).
head(id(361),populationn(209)).
head(id(362),habitatg(209)).
head(id(363),cap_shapek(8106)).
head(id(364),cap_surfaces(8106)).
head(id(365),cap_colorn(8106)).
head(id(366),odorn(8106)).
head(id(367),gill_attachment(8106)).
head(id(368),gill_spacing(8106)).
head(id(369),stalk_surface_above_rings(8106)).
head(id(370),stalk_surface_below_rings(8106)).
head(id(371),stalk_color_above_ringo(8106)).
head(id(372),stalk_color_below_ringo(8106)).
head(id(373),veil_colorn(8106)).
head(id(374),ring_numbero(8106)).
head(id(375),populationv(8106)).
head(id(376),habitatl(8106)).
head(id(377),cap_shapex(3047)).
head(id(378),cap_colore(3047)).
head(id(379),bruises(3047)).
head(id(380),odorn(3047)).
head(id(381),gill_spacing(3047)).
head(id(382),gill_colorn(3047)).
head(id(383),stalk_rootb(3047)).
head(id(384),stalk_surface_above_rings(3047)).
head(id(385),stalk_surface_below_rings(3047)).
head(id(386),stalk_color_above_ringp(3047)).
head(id(387),stalk_color_below_ringp(3047)).
head(id(388),veil_colorw(3047)).
head(id(389),ring_numbero(3047)).
head(id(390),spore_print_colork(3047)).
head(id(391),populationv(3047)).
head(id(392),habitatd(3047)).
head(id(393),cap_surfaces(170)).
head(id(394),cap_colorw(170)).
head(id(395),bruises(170)).
head(id(396),odora(170)).
head(id(397),gill_spacing(170)).
head(id(398),gill_colork(170)).
head(id(399),stalk_rootc(170)).
head(id(400),stalk_surface_above_rings(170)).
head(id(401),stalk_surface_below_rings(170)).
head(id(402),stalk_color_above_ringw(170)).
head(id(403),stalk_color_below_ringw(170)).
head(id(404),veil_colorw(170)).
head(id(405),ring_numbero(170)).
head(id(406),spore_print_colork(170)).
head(id(407),populations(170)).
head(id(408),habitatg(170)).
head(id(409),cap_shapex(646)).
head(id(410),cap_surfaces(646)).
head(id(411),bruises(646)).
head(id(412),odorl(646)).
head(id(413),gill_size(646)).
head(id(414),gill_colorn(646)).
head(id(415),stalk_rootb(646)).
head(id(416),stalk_surface_above_rings(646)).
head(id(417),stalk_surface_below_rings(646)).
head(id(418),stalk_color_above_ringw(646)).
head(id(419),stalk_color_below_ringw(646)).
head(id(420),veil_colorw(646)).
head(id(421),ring_numbero(646)).
head(id(422),spore_print_coloru(646)).
head(id(423),populationv(646)).
head(id(424),habitatd(646)).
head(id(425),cap_shapef(1757)).
head(id(426),cap_surfacef(1757)).
head(id(427),cap_colorg(1757)).
head(id(428),odorn(1757)).
head(id(429),gill_colork(1757)).
head(id(430),stalk_roote(1757)).
head(id(431),stalk_surface_above_rings(1757)).
head(id(432),stalk_surface_below_rings(1757)).
head(id(433),stalk_color_above_ringw(1757)).
head(id(434),stalk_color_below_ringw(1757)).
head(id(435),veil_colorw(1757)).
head(id(436),ring_numbero(1757)).
head(id(437),ring_typee(1757)).
head(id(438),spore_print_colorn(1757)).
head(id(439),populations(1757)).
head(id(440),habitatg(1757)).
head(id(441),cap_shapex(2418)).
head(id(442),cap_colorn(2418)).
head(id(443),bruises(2418)).
head(id(444),odorn(2418)).
head(id(445),gill_spacing(2418)).
head(id(446),gill_coloru(2418)).
head(id(447),stalk_rootb(2418)).
head(id(448),stalk_surface_above_rings(2418)).
head(id(449),stalk_surface_below_rings(2418)).
head(id(450),stalk_color_above_ringg(2418)).
head(id(451),stalk_color_below_ringw(2418)).
head(id(452),veil_colorw(2418)).
head(id(453),ring_numbero(2418)).
head(id(454),spore_print_colork(2418)).
head(id(455),habitatd(2418)).
head(id(456),cap_shapex(751)).
head(id(457),cap_colorn(751)).
head(id(458),bruises(751)).
head(id(459),odora(751)).
head(id(460),gill_spacing(751)).
head(id(461),gill_colorn(751)).
head(id(462),stalk_rootr(751)).
head(id(463),stalk_surface_above_rings(751)).
head(id(464),stalk_color_above_ringw(751)).
head(id(465),stalk_color_below_ringw(751)).
head(id(466),veil_colorw(751)).
head(id(467),ring_numbero(751)).
head(id(468),spore_print_colorn(751)).
head(id(469),populations(751)).
head(id(470),habitatp(751)).
head(id(471),cap_shapek(6763)).
head(id(472),cap_surfacef(6763)).
head(id(473),cap_colorg(6763)).
head(id(474),odorn(6763)).
head(id(475),gill_colorp(6763)).
head(id(476),stalk_surface_above_ringk(6763)).
head(id(477),stalk_surface_below_rings(6763)).
head(id(478),stalk_color_above_ringw(6763)).
head(id(479),stalk_color_below_ringw(6763)).
head(id(480),veil_colorw(6763)).
head(id(481),spore_print_colorw(6763)).
head(id(482),populations(6763)).
head(id(483),habitatg(6763)).
head(id(484),cap_shapex(2011)).
head(id(485),cap_surfaces(2011)).
head(id(486),cap_colorn(2011)).
head(id(487),odorn(2011)).
head(id(488),gill_colork(2011)).
head(id(489),stalk_roote(2011)).
head(id(490),stalk_surface_above_ringf(2011)).
head(id(491),stalk_surface_below_ringf(2011)).
head(id(492),stalk_color_above_ringw(2011)).
head(id(493),stalk_color_below_ringw(2011)).
head(id(494),veil_colorw(2011)).
head(id(495),ring_numbero(2011)).
head(id(496),ring_typee(2011)).
head(id(497),spore_print_colorn(2011)).
head(id(498),populationa(2011)).
head(id(499),habitatg(2011)).
head(id(500),cap_shapek(7571)).
head(id(501),cap_surfaces(7571)).
head(id(502),cap_colorn(7571)).
head(id(503),odorn(7571)).
head(id(504),gill_spacing(7571)).
head(id(505),gill_colorw(7571)).
head(id(506),stalk_rootb(7571)).
head(id(507),stalk_color_above_ringn(7571)).
head(id(508),stalk_color_below_ringn(7571)).
head(id(509),veil_colorw(7571)).
head(id(510),spore_print_colorw(7571)).
head(id(511),habitatp(7571)).
head(id(512),cap_shapef(1328)).
head(id(513),cap_surfaces(1328)).
head(id(514),cap_colorg(1328)).
head(id(515),odorn(1328)).
head(id(516),gill_colork(1328)).
head(id(517),stalk_roote(1328)).
head(id(518),stalk_surface_above_ringf(1328)).
head(id(519),stalk_surface_below_ringf(1328)).
head(id(520),stalk_color_above_ringw(1328)).
head(id(521),stalk_color_below_ringw(1328)).
head(id(522),veil_colorw(1328)).
head(id(523),ring_numbero(1328)).
head(id(524),ring_typee(1328)).
head(id(525),spore_print_colorn(1328)).
head(id(526),populationa(1328)).
head(id(527),habitatg(1328)).
head(id(528),cap_shapef(4912)).
head(id(529),cap_surfaces(4912)).
head(id(530),cap_colore(4912)).
head(id(531),bruises(4912)).
head(id(532),odorn(4912)).
head(id(533),gill_spacing(4912)).
head(id(534),gill_colorw(4912)).
head(id(535),stalk_surface_above_rings(4912)).
head(id(536),stalk_surface_below_rings(4912)).
head(id(537),stalk_color_above_ringw(4912)).
head(id(538),stalk_color_below_ringe(4912)).
head(id(539),veil_colorw(4912)).
head(id(540),ring_typee(4912)).
head(id(541),spore_print_colorw(4912)).
head(id(542),populationc(4912)).
head(id(543),cap_shapef(3143)).
head(id(544),cap_colorg(3143)).
head(id(545),bruises(3143)).
head(id(546),odorn(3143)).
head(id(547),gill_spacing(3143)).
head(id(548),gill_colorw(3143)).
head(id(549),stalk_rootb(3143)).
head(id(550),stalk_surface_above_rings(3143)).
head(id(551),stalk_surface_below_rings(3143)).
head(id(552),stalk_color_above_ringp(3143)).
head(id(553),stalk_color_below_ringp(3143)).
head(id(554),veil_colorw(3143)).
head(id(555),ring_numbero(3143)).
head(id(556),spore_print_colork(3143)).
head(id(557),habitatd(3143)).
head(id(558),cap_shapef(3635)).
head(id(559),cap_colorn(3635)).
head(id(560),bruises(3635)).
head(id(561),odorn(3635)).
head(id(562),gill_spacing(3635)).
head(id(563),gill_colorn(3635)).
head(id(564),stalk_rootb(3635)).
head(id(565),stalk_surface_above_rings(3635)).
head(id(566),stalk_surface_below_rings(3635)).
head(id(567),stalk_color_above_ringw(3635)).
head(id(568),stalk_color_below_ringp(3635)).
head(id(569),veil_colorw(3635)).
head(id(570),ring_numbero(3635)).
head(id(571),spore_print_colorn(3635)).
head(id(572),populationv(3635)).
head(id(573),habitatd(3635)).
head(id(574),cap_shapex(1530)).
head(id(575),cap_surfaces(1530)).
head(id(576),cap_colorw(1530)).
head(id(577),odorn(1530)).
head(id(578),gill_colorn(1530)).
head(id(579),stalk_roote(1530)).
head(id(580),stalk_surface_above_ringf(1530)).
head(id(581),stalk_surface_below_ringf(1530)).
head(id(582),stalk_color_above_ringw(1530)).
head(id(583),stalk_color_below_ringw(1530)).
head(id(584),veil_colorw(1530)).
head(id(585),ring_numbero(1530)).
head(id(586),ring_typee(1530)).
head(id(587),spore_print_colork(1530)).
head(id(588),populationa(1530)).
head(id(589),habitatg(1530)).
head(id(590),cap_shapex(7538)).
head(id(591),cap_surfaces(7538)).
head(id(592),cap_colorn(7538)).
head(id(593),odorn(7538)).
head(id(594),gill_attachment(7538)).
head(id(595),gill_spacing(7538)).
head(id(596),stalk_surface_above_rings(7538)).
head(id(597),stalk_surface_below_rings(7538)).
head(id(598),stalk_color_above_ringo(7538)).
head(id(599),stalk_color_below_ringo(7538)).
head(id(600),veil_coloro(7538)).
head(id(601),ring_numbero(7538)).
head(id(602),populationc(7538)).
head(id(603),habitatl(7538)).
head(id(604),cap_shapex(2575)).
head(id(605),cap_colorn(2575)).
head(id(606),bruises(2575)).
head(id(607),odorn(2575)).
head(id(608),gill_spacing(2575)).
head(id(609),gill_colorp(2575)).
head(id(610),stalk_rootb(2575)).
head(id(611),stalk_surface_above_rings(2575)).
head(id(612),stalk_surface_below_rings(2575)).
head(id(613),stalk_color_above_ringg(2575)).
head(id(614),stalk_color_below_ringw(2575)).
head(id(615),veil_colorw(2575)).
head(id(616),ring_numbero(2575)).
head(id(617),spore_print_colork(2575)).
head(id(618),populationv(2575)).
head(id(619),habitatd(2575)).
head(id(2544,A),poisoned(A)) :- dom(A).
body(id(2544,A),alpha_1(A)) :- dom(A).
body(id(2544,A),cap_shapef(A)) :- dom(A).
head(id(4496,A),poisoned(A)) :- dom(A).
body(id(4496,A),alpha_2(A)) :- dom(A).
body(id(4496,A),cap_surfaces(A)) :- dom(A).
head(id(6487,A),poisoned(A)) :- dom(A).
body(id(6487,A),alpha_3(A)) :- dom(A).
body(id(6487,A),cap_shapex(A)) :- dom(A).
head(id(11192,A),poisoned(A)) :- dom(A).
body(id(11192,A),alpha_4(A)) :- dom(A).
body(id(11192,A),cap_shapek(A)) :- dom(A).
head(id(13902,A),poisoned(A)) :- dom(A).
body(id(13902,A),cap_shapec(A)) :- dom(A).
head(id(23300,A),c_alpha_1(A)) :- dom(A).
body(id(23300,A),cap_surfaces(A)) :- dom(A).
head(id(25977,A),c_alpha_1(A)) :- dom(A).
body(id(25977,A),cap_surfacef(A)) :- dom(A).
head(id(28658,A),c_alpha_1(A)) :- dom(A).
body(id(28658,A),cap_colorg(A)) :- dom(A).
head(id(31343,A),c_alpha_1(A)) :- dom(A).
body(id(31343,A),cap_colorn(A)) :- dom(A).
head(id(34699,A),c_alpha_2(A)) :- dom(A).
body(id(34699,A),cap_colorw(A)) :- dom(A).
head(id(36041,A),c_alpha_2(A)) :- dom(A).
body(id(36041,A),cap_shapex(A)) :- dom(A).
head(id(40083,A),c_alpha_2(A)) :- dom(A).
body(id(40083,A),cap_colorg(A)) :- dom(A).
head(id(46137,A),c_alpha_2(A)) :- dom(A).
body(id(46137,A),alpha_5(A)) :- dom(A).
body(id(46137,A),cap_colore(A)) :- dom(A).
head(id(48166,A),c_alpha_2(A)) :- dom(A).
body(id(48166,A),cap_shapek(A)) :- dom(A).
head(id(53579,A),c_alpha_3(A)) :- dom(A).
body(id(53579,A),alpha_6(A)) :- dom(A).
body(id(53579,A),bruises(A)) :- dom(A).
head(id(59027,A),c_alpha_3(A)) :- dom(A).
body(id(59027,A),alpha_7(A)) :- dom(A).
body(id(59027,A),cap_colorw(A)) :- dom(A).
head(id(63830,A),c_alpha_3(A)) :- dom(A).
body(id(63830,A),alpha_8(A)) :- dom(A).
body(id(63830,A),cap_colorn(A)) :- dom(A).
head(id(69368,A),c_alpha_4(A)) :- dom(A).
body(id(69368,A),cap_surfacef(A)) :- dom(A).
head(id(75594,A),c_alpha_4(A)) :- dom(A).
body(id(75594,A),odorn(A)) :- dom(A).
head(id(79742,A),c_alpha_5(A)) :- dom(A).
body(id(79742,A),alpha_2(A)) :- dom(A).
body(id(79742,A),cap_surfaces(A)) :- dom(A).
head(id(81820,A),c_alpha_6(A)) :- dom(A).
body(id(81820,A),alpha_3(A)) :- dom(A).
body(id(81820,A),cap_shapex(A)) :- dom(A).
head(id(83904,A),c_alpha_7(A)) :- dom(A).
body(id(83904,A),alpha_3(A)) :- dom(A).
body(id(83904,A),cap_shapex(A)) :- dom(A).
head(id(85994,A),c_alpha_8(A)) :- dom(A).
body(id(85994,A),alpha_3(A)) :- dom(A).
body(id(85994,A),cap_shapex(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
assumption(alpha_4(A)) :- dom(A).
assumption(alpha_5(A)) :- dom(A).
assumption(alpha_6(A)) :- dom(A).
assumption(alpha_7(A)) :- dom(A).
assumption(alpha_8(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).
contrary(alpha_4(A),c_alpha_4(A)) :- assumption(alpha_4(A)).
contrary(alpha_5(A),c_alpha_5(A)) :- assumption(alpha_5(A)).
contrary(alpha_6(A),c_alpha_6(A)) :- assumption(alpha_6(A)).
contrary(alpha_7(A),c_alpha_7(A)) :- assumption(alpha_7(A)).
contrary(alpha_8(A),c_alpha_8(A)) :- assumption(alpha_8(A)).

dom(170).
dom(209).
dom(646).
dom(751).
dom(1100).
dom(1328).
dom(1530).
dom(1757).
dom(2011).
dom(2418).
dom(2575).
dom(3047).
dom(3143).
dom(3338).
dom(3470).
dom(3635).
dom(4107).
dom(4195).
dom(4271).
dom(4341).
dom(4477).
dom(4499).
dom(4725).
dom(4912).
dom(5509).
dom(5522).
dom(5772).
dom(5816).
dom(6341).
dom(6363).
dom(6443).
dom(6507).
dom(6763).
dom(6946).
dom(7047).
dom(7102).
dom(7538).
dom(7571).
dom(7794).
dom(8106).
 :- not supported(poisoned(6363)).
 :- not supported(poisoned(4107)).
 :- not supported(poisoned(5522)).
 :- not supported(poisoned(4271)).
 :- not supported(poisoned(4499)).
 :- not supported(poisoned(7794)).
 :- not supported(poisoned(1100)).
 :- not supported(poisoned(7102)).
 :- not supported(poisoned(3470)).
 :- not supported(poisoned(5772)).
 :- not supported(poisoned(5509)).
 :- not supported(poisoned(6946)).
 :- not supported(poisoned(3338)).
 :- not supported(poisoned(6507)).
 :- not supported(poisoned(6341)).
 :- not supported(poisoned(4725)).
 :- not supported(poisoned(4341)).
 :- not supported(poisoned(4195)).
 :- not supported(poisoned(4477)).
 :- not supported(poisoned(5816)).
 :- not supported(poisoned(6443)).
 :- supported(poisoned(7047)).
 :- supported(poisoned(209)).
 :- supported(poisoned(8106)).
 :- supported(poisoned(3047)).
 :- supported(poisoned(170)).
 :- supported(poisoned(646)).
 :- supported(poisoned(1757)).
 :- supported(poisoned(2418)).
 :- supported(poisoned(751)).
 :- supported(poisoned(6763)).
 :- supported(poisoned(2011)).
 :- supported(poisoned(7571)).
 :- supported(poisoned(1328)).
 :- supported(poisoned(4912)).
 :- supported(poisoned(3143)).
 :- supported(poisoned(3635)).
 :- supported(poisoned(1530)).
 :- supported(poisoned(7538)).
 :- supported(poisoned(2575)).
