head(id(1),handicapped_infants(38)).
head(id(2),water_project_cost_sharing(38)).
head(id(3),physician_fee_freeze(38)).
head(id(4),el_salvador_aid(38)).
head(id(5),religious_groups_in_schools(38)).
head(id(6),superfund_right_to_sue(38)).
head(id(7),crime(38)).
head(id(8),export_administration_act_south_africa(38)).
head(id(9),physician_fee_freeze(136)).
head(id(10),el_salvador_aid(136)).
head(id(11),religious_groups_in_schools(136)).
head(id(12),immigration(136)).
head(id(13),education_spending(136)).
head(id(14),superfund_right_to_sue(136)).
head(id(15),crime(136)).
head(id(16),physician_fee_freeze(87)).
head(id(17),el_salvador_aid(87)).
head(id(18),religious_groups_in_schools(87)).
head(id(19),immigration(87)).
head(id(20),education_spending(87)).
head(id(21),superfund_right_to_sue(87)).
head(id(22),crime(87)).
head(id(23),water_project_cost_sharing(9)).
head(id(24),physician_fee_freeze(9)).
head(id(25),el_salvador_aid(9)).
head(id(26),religious_groups_in_schools(9)).
head(id(27),education_spending(9)).
head(id(28),superfund_right_to_sue(9)).
head(id(29),crime(9)).
head(id(30),export_administration_act_south_africa(9)).
head(id(31),water_project_cost_sharing(39)).
head(id(32),physician_fee_freeze(39)).
head(id(33),el_salvador_aid(39)).
head(id(34),religious_groups_in_schools(39)).
head(id(35),immigration(39)).
head(id(36),education_spending(39)).
head(id(37),superfund_right_to_sue(39)).
head(id(38),crime(39)).
head(id(39),handicapped_infants(167)).
head(id(40),budget_resolution(167)).
head(id(41),physician_fee_freeze(167)).
head(id(42),el_salvador_aid(167)).
head(id(43),religious_groups_in_schools(167)).
head(id(44),anti_satellite_test_ban(167)).
head(id(45),aid_to_nicaraguan_contras(167)).
head(id(46),immigration(167)).
head(id(47),education_spending(167)).
head(id(48),crime(167)).
head(id(49),duty_free_exports(167)).
head(id(50),export_administration_act_south_africa(167)).
head(id(51),physician_fee_freeze(120)).
head(id(52),el_salvador_aid(120)).
head(id(53),religious_groups_in_schools(120)).
head(id(54),education_spending(120)).
head(id(55),superfund_right_to_sue(120)).
head(id(56),crime(120)).
head(id(57),water_project_cost_sharing(57)).
head(id(58),physician_fee_freeze(57)).
head(id(59),el_salvador_aid(57)).
head(id(60),religious_groups_in_schools(57)).
head(id(61),immigration(57)).
head(id(62),synfuels_corporation_cutback(57)).
head(id(63),education_spending(57)).
head(id(64),superfund_right_to_sue(57)).
head(id(65),crime(57)).
head(id(66),export_administration_act_south_africa(57)).
head(id(67),physician_fee_freeze(134)).
head(id(68),el_salvador_aid(134)).
head(id(69),religious_groups_in_schools(134)).
head(id(70),immigration(134)).
head(id(71),education_spending(134)).
head(id(72),superfund_right_to_sue(134)).
head(id(73),crime(134)).
head(id(74),export_administration_act_south_africa(134)).
head(id(75),handicapped_infants(74)).
head(id(76),budget_resolution(74)).
head(id(77),physician_fee_freeze(74)).
head(id(78),el_salvador_aid(74)).
head(id(79),anti_satellite_test_ban(74)).
head(id(80),mx_missile(74)).
head(id(81),immigration(74)).
head(id(82),superfund_right_to_sue(74)).
head(id(83),crime(74)).
head(id(84),export_administration_act_south_africa(74)).
head(id(85),water_project_cost_sharing(137)).
head(id(86),physician_fee_freeze(137)).
head(id(87),el_salvador_aid(137)).
head(id(88),religious_groups_in_schools(137)).
head(id(89),immigration(137)).
head(id(90),synfuels_corporation_cutback(137)).
head(id(91),education_spending(137)).
head(id(92),superfund_right_to_sue(137)).
head(id(93),export_administration_act_south_africa(137)).
head(id(94),water_project_cost_sharing(36)).
head(id(95),physician_fee_freeze(36)).
head(id(96),el_salvador_aid(36)).
head(id(97),religious_groups_in_schools(36)).
head(id(98),education_spending(36)).
head(id(99),superfund_right_to_sue(36)).
head(id(100),crime(36)).
head(id(101),water_project_cost_sharing(68)).
head(id(102),physician_fee_freeze(68)).
head(id(103),el_salvador_aid(68)).
head(id(104),religious_groups_in_schools(68)).
head(id(105),immigration(68)).
head(id(106),education_spending(68)).
head(id(107),superfund_right_to_sue(68)).
head(id(108),crime(68)).
head(id(109),water_project_cost_sharing(155)).
head(id(110),physician_fee_freeze(155)).
head(id(111),el_salvador_aid(155)).
head(id(112),religious_groups_in_schools(155)).
head(id(113),education_spending(155)).
head(id(114),superfund_right_to_sue(155)).
head(id(115),crime(155)).
head(id(116),water_project_cost_sharing(107)).
head(id(117),physician_fee_freeze(107)).
head(id(118),el_salvador_aid(107)).
head(id(119),religious_groups_in_schools(107)).
head(id(120),education_spending(107)).
head(id(121),superfund_right_to_sue(107)).
head(id(122),crime(107)).
head(id(123),export_administration_act_south_africa(107)).
head(id(124),physician_fee_freeze(123)).
head(id(125),el_salvador_aid(123)).
head(id(126),religious_groups_in_schools(123)).
head(id(127),immigration(123)).
head(id(128),education_spending(123)).
head(id(129),crime(123)).
head(id(130),export_administration_act_south_africa(123)).
head(id(131),water_project_cost_sharing(149)).
head(id(132),physician_fee_freeze(149)).
head(id(133),el_salvador_aid(149)).
head(id(134),religious_groups_in_schools(149)).
head(id(135),immigration(149)).
head(id(136),synfuels_corporation_cutback(149)).
head(id(137),education_spending(149)).
head(id(138),superfund_right_to_sue(149)).
head(id(139),crime(149)).
head(id(140),export_administration_act_south_africa(149)).
head(id(141),handicapped_infants(29)).
head(id(142),physician_fee_freeze(29)).
head(id(143),el_salvador_aid(29)).
head(id(144),anti_satellite_test_ban(29)).
head(id(145),aid_to_nicaraguan_contras(29)).
head(id(146),mx_missile(29)).
head(id(147),education_spending(29)).
head(id(148),superfund_right_to_sue(29)).
head(id(149),crime(29)).
head(id(150),export_administration_act_south_africa(29)).
head(id(151),physician_fee_freeze(141)).
head(id(152),anti_satellite_test_ban(141)).
head(id(153),aid_to_nicaraguan_contras(141)).
head(id(154),mx_missile(141)).
head(id(155),immigration(141)).
head(id(156),superfund_right_to_sue(141)).
head(id(157),crime(141)).
head(id(158),export_administration_act_south_africa(141)).
head(id(159),physician_fee_freeze(143)).
head(id(160),el_salvador_aid(143)).
head(id(161),religious_groups_in_schools(143)).
head(id(162),anti_satellite_test_ban(143)).
head(id(163),aid_to_nicaraguan_contras(143)).
head(id(164),mx_missile(143)).
head(id(165),immigration(143)).
head(id(166),education_spending(143)).
head(id(167),superfund_right_to_sue(143)).
head(id(168),crime(143)).
head(id(169),export_administration_act_south_africa(143)).
head(id(170),water_project_cost_sharing(59)).
head(id(171),physician_fee_freeze(59)).
head(id(172),el_salvador_aid(59)).
head(id(173),religious_groups_in_schools(59)).
head(id(174),immigration(59)).
head(id(175),education_spending(59)).
head(id(176),superfund_right_to_sue(59)).
head(id(177),crime(59)).
head(id(178),export_administration_act_south_africa(59)).
head(id(179),handicapped_infants(66)).
head(id(180),water_project_cost_sharing(66)).
head(id(181),physician_fee_freeze(66)).
head(id(182),el_salvador_aid(66)).
head(id(183),religious_groups_in_schools(66)).
head(id(184),anti_satellite_test_ban(66)).
head(id(185),education_spending(66)).
head(id(186),superfund_right_to_sue(66)).
head(id(187),crime(66)).
head(id(188),export_administration_act_south_africa(66)).
head(id(189),water_project_cost_sharing(62)).
head(id(190),physician_fee_freeze(62)).
head(id(191),el_salvador_aid(62)).
head(id(192),religious_groups_in_schools(62)).
head(id(193),education_spending(62)).
head(id(194),superfund_right_to_sue(62)).
head(id(195),crime(62)).
head(id(196),water_project_cost_sharing(31)).
head(id(197),physician_fee_freeze(31)).
head(id(198),el_salvador_aid(31)).
head(id(199),religious_groups_in_schools(31)).
head(id(200),education_spending(31)).
head(id(201),superfund_right_to_sue(31)).
head(id(202),crime(31)).
head(id(203),water_project_cost_sharing(58)).
head(id(204),physician_fee_freeze(58)).
head(id(205),el_salvador_aid(58)).
head(id(206),religious_groups_in_schools(58)).
head(id(207),immigration(58)).
head(id(208),education_spending(58)).
head(id(209),superfund_right_to_sue(58)).
head(id(210),crime(58)).
head(id(211),export_administration_act_south_africa(58)).
head(id(212),water_project_cost_sharing(159)).
head(id(213),physician_fee_freeze(159)).
head(id(214),el_salvador_aid(159)).
head(id(215),religious_groups_in_schools(159)).
head(id(216),immigration(159)).
head(id(217),education_spending(159)).
head(id(218),superfund_right_to_sue(159)).
head(id(219),crime(159)).
head(id(220),handicapped_infants(54)).
head(id(221),water_project_cost_sharing(54)).
head(id(222),physician_fee_freeze(54)).
head(id(223),el_salvador_aid(54)).
head(id(224),religious_groups_in_schools(54)).
head(id(225),immigration(54)).
head(id(226),education_spending(54)).
head(id(227),superfund_right_to_sue(54)).
head(id(228),crime(54)).
head(id(229),physician_fee_freeze(88)).
head(id(230),el_salvador_aid(88)).
head(id(231),religious_groups_in_schools(88)).
head(id(232),education_spending(88)).
head(id(233),superfund_right_to_sue(88)).
head(id(234),crime(88)).
head(id(235),physician_fee_freeze(84)).
head(id(236),el_salvador_aid(84)).
head(id(237),religious_groups_in_schools(84)).
head(id(238),education_spending(84)).
head(id(239),superfund_right_to_sue(84)).
head(id(240),crime(84)).
head(id(241),handicapped_infants(157)).
head(id(242),water_project_cost_sharing(157)).
head(id(243),physician_fee_freeze(157)).
head(id(244),el_salvador_aid(157)).
head(id(245),religious_groups_in_schools(157)).
head(id(246),anti_satellite_test_ban(157)).
head(id(247),education_spending(157)).
head(id(248),superfund_right_to_sue(157)).
head(id(249),crime(157)).
head(id(250),handicapped_infants(72)).
head(id(251),water_project_cost_sharing(72)).
head(id(252),budget_resolution(72)).
head(id(253),physician_fee_freeze(72)).
head(id(254),anti_satellite_test_ban(72)).
head(id(255),aid_to_nicaraguan_contras(72)).
head(id(256),mx_missile(72)).
head(id(257),immigration(72)).
head(id(258),synfuels_corporation_cutback(72)).
head(id(259),crime(72)).
head(id(260),export_administration_act_south_africa(72)).
head(id(261),budget_resolution(177)).
head(id(262),physician_fee_freeze(177)).
head(id(263),anti_satellite_test_ban(177)).
head(id(264),aid_to_nicaraguan_contras(177)).
head(id(265),mx_missile(177)).
head(id(266),immigration(177)).
head(id(267),crime(177)).
head(id(268),duty_free_exports(177)).
head(id(269),export_administration_act_south_africa(177)).
head(id(270),physician_fee_freeze(80)).
head(id(271),el_salvador_aid(80)).
head(id(272),immigration(80)).
head(id(273),education_spending(80)).
head(id(274),superfund_right_to_sue(80)).
head(id(275),crime(80)).
head(id(276),handicapped_infants(118)).
head(id(277),water_project_cost_sharing(118)).
head(id(278),budget_resolution(118)).
head(id(279),physician_fee_freeze(118)).
head(id(280),el_salvador_aid(118)).
head(id(281),anti_satellite_test_ban(118)).
head(id(282),education_spending(118)).
head(id(283),superfund_right_to_sue(118)).
head(id(284),crime(118)).
head(id(285),export_administration_act_south_africa(118)).
head(id(286),handicapped_infants(47)).
head(id(287),water_project_cost_sharing(47)).
head(id(288),budget_resolution(47)).
head(id(289),anti_satellite_test_ban(47)).
head(id(290),aid_to_nicaraguan_contras(47)).
head(id(291),mx_missile(47)).
head(id(292),export_administration_act_south_africa(47)).
head(id(293),handicapped_infants(64)).
head(id(294),water_project_cost_sharing(64)).
head(id(295),budget_resolution(64)).
head(id(296),anti_satellite_test_ban(64)).
head(id(297),aid_to_nicaraguan_contras(64)).
head(id(298),mx_missile(64)).
head(id(299),synfuels_corporation_cutback(64)).
head(id(300),export_administration_act_south_africa(64)).
head(id(301),handicapped_infants(35)).
head(id(302),water_project_cost_sharing(35)).
head(id(303),budget_resolution(35)).
head(id(304),anti_satellite_test_ban(35)).
head(id(305),aid_to_nicaraguan_contras(35)).
head(id(306),mx_missile(35)).
head(id(307),duty_free_exports(35)).
head(id(308),export_administration_act_south_africa(35)).
head(id(309),handicapped_infants(20)).
head(id(310),water_project_cost_sharing(20)).
head(id(311),budget_resolution(20)).
head(id(312),anti_satellite_test_ban(20)).
head(id(313),aid_to_nicaraguan_contras(20)).
head(id(314),mx_missile(20)).
head(id(315),synfuels_corporation_cutback(20)).
head(id(316),duty_free_exports(20)).
head(id(317),export_administration_act_south_africa(20)).
head(id(318),handicapped_infants(95)).
head(id(319),budget_resolution(95)).
head(id(320),el_salvador_aid(95)).
head(id(321),religious_groups_in_schools(95)).
head(id(322),export_administration_act_south_africa(95)).
head(id(323),water_project_cost_sharing(78)).
head(id(324),budget_resolution(78)).
head(id(325),physician_fee_freeze(78)).
head(id(326),el_salvador_aid(78)).
head(id(327),religious_groups_in_schools(78)).
head(id(328),aid_to_nicaraguan_contras(78)).
head(id(329),mx_missile(78)).
head(id(330),immigration(78)).
head(id(331),synfuels_corporation_cutback(78)).
head(id(332),education_spending(78)).
head(id(333),superfund_right_to_sue(78)).
head(id(334),crime(78)).
head(id(335),export_administration_act_south_africa(78)).
head(id(336),handicapped_infants(26)).
head(id(337),budget_resolution(26)).
head(id(338),anti_satellite_test_ban(26)).
head(id(339),aid_to_nicaraguan_contras(26)).
head(id(340),mx_missile(26)).
head(id(341),immigration(26)).
head(id(342),duty_free_exports(26)).
head(id(343),export_administration_act_south_africa(26)).
head(id(344),handicapped_infants(27)).
head(id(345),budget_resolution(27)).
head(id(346),anti_satellite_test_ban(27)).
head(id(347),aid_to_nicaraguan_contras(27)).
head(id(348),mx_missile(27)).
head(id(349),synfuels_corporation_cutback(27)).
head(id(350),duty_free_exports(27)).
head(id(351),export_administration_act_south_africa(27)).
head(id(352),handicapped_infants(101)).
head(id(353),el_salvador_aid(101)).
head(id(354),religious_groups_in_schools(101)).
head(id(355),synfuels_corporation_cutback(101)).
head(id(356),education_spending(101)).
head(id(357),crime(101)).
head(id(358),export_administration_act_south_africa(101)).
head(id(359),handicapped_infants(170)).
head(id(360),budget_resolution(170)).
head(id(361),anti_satellite_test_ban(170)).
head(id(362),aid_to_nicaraguan_contras(170)).
head(id(363),mx_missile(170)).
head(id(364),immigration(170)).
head(id(365),synfuels_corporation_cutback(170)).
head(id(366),crime(170)).
head(id(367),export_administration_act_south_africa(170)).
head(id(368),water_project_cost_sharing(187)).
head(id(369),budget_resolution(187)).
head(id(370),anti_satellite_test_ban(187)).
head(id(371),aid_to_nicaraguan_contras(187)).
head(id(372),mx_missile(187)).
head(id(373),immigration(187)).
head(id(374),synfuels_corporation_cutback(187)).
head(id(375),duty_free_exports(187)).
head(id(376),export_administration_act_south_africa(187)).
head(id(377),budget_resolution(154)).
head(id(378),religious_groups_in_schools(154)).
head(id(379),anti_satellite_test_ban(154)).
head(id(380),aid_to_nicaraguan_contras(154)).
head(id(381),mx_missile(154)).
head(id(382),immigration(154)).
head(id(383),synfuels_corporation_cutback(154)).
head(id(384),superfund_right_to_sue(154)).
head(id(385),crime(154)).
head(id(386),export_administration_act_south_africa(154)).
head(id(387),anti_satellite_test_ban(148)).
head(id(388),aid_to_nicaraguan_contras(148)).
head(id(389),mx_missile(148)).
head(id(390),immigration(148)).
head(id(391),education_spending(148)).
head(id(392),superfund_right_to_sue(148)).
head(id(393),crime(148)).
head(id(394),duty_free_exports(148)).
head(id(395),export_administration_act_south_africa(148)).
head(id(396),handicapped_infants(117)).
head(id(397),budget_resolution(117)).
head(id(398),anti_satellite_test_ban(117)).
head(id(399),aid_to_nicaraguan_contras(117)).
head(id(400),mx_missile(117)).
head(id(401),synfuels_corporation_cutback(117)).
head(id(402),duty_free_exports(117)).
head(id(403),export_administration_act_south_africa(117)).
head(id(404),handicapped_infants(33)).
head(id(405),water_project_cost_sharing(33)).
head(id(406),budget_resolution(33)).
head(id(407),anti_satellite_test_ban(33)).
head(id(408),aid_to_nicaraguan_contras(33)).
head(id(409),mx_missile(33)).
head(id(410),immigration(33)).
head(id(411),superfund_right_to_sue(33)).
head(id(412),duty_free_exports(33)).
head(id(413),export_administration_act_south_africa(33)).
head(id(414),handicapped_infants(180)).
head(id(415),budget_resolution(180)).
head(id(416),anti_satellite_test_ban(180)).
head(id(417),aid_to_nicaraguan_contras(180)).
head(id(418),mx_missile(180)).
head(id(419),immigration(180)).
head(id(420),duty_free_exports(180)).
head(id(421),export_administration_act_south_africa(180)).
head(id(422),water_project_cost_sharing(76)).
head(id(423),budget_resolution(76)).
head(id(424),physician_fee_freeze(76)).
head(id(425),el_salvador_aid(76)).
head(id(426),religious_groups_in_schools(76)).
head(id(427),immigration(76)).
head(id(428),synfuels_corporation_cutback(76)).
head(id(429),superfund_right_to_sue(76)).
head(id(430),crime(76)).
head(id(431),handicapped_infants(49)).
head(id(432),water_project_cost_sharing(49)).
head(id(433),budget_resolution(49)).
head(id(434),anti_satellite_test_ban(49)).
head(id(435),aid_to_nicaraguan_contras(49)).
head(id(436),crime(49)).
head(id(437),export_administration_act_south_africa(49)).
head(id(438),water_project_cost_sharing(163)).
head(id(439),budget_resolution(163)).
head(id(440),el_salvador_aid(163)).
head(id(441),religious_groups_in_schools(163)).
head(id(442),anti_satellite_test_ban(163)).
head(id(443),synfuels_corporation_cutback(163)).
head(id(444),education_spending(163)).
head(id(445),superfund_right_to_sue(163)).
head(id(446),crime(163)).
head(id(447),export_administration_act_south_africa(163)).
head(id(448),handicapped_infants(40)).
head(id(449),budget_resolution(40)).
head(id(450),anti_satellite_test_ban(40)).
head(id(451),aid_to_nicaraguan_contras(40)).
head(id(452),mx_missile(40)).
head(id(453),immigration(40)).
head(id(454),synfuels_corporation_cutback(40)).
head(id(455),superfund_right_to_sue(40)).
head(id(456),duty_free_exports(40)).
head(id(457),export_administration_act_south_africa(40)).
head(id(458),budget_resolution(182)).
head(id(459),anti_satellite_test_ban(182)).
head(id(460),aid_to_nicaraguan_contras(182)).
head(id(461),mx_missile(182)).
head(id(462),immigration(182)).
head(id(463),synfuels_corporation_cutback(182)).
head(id(464),duty_free_exports(182)).
head(id(465),export_administration_act_south_africa(182)).
head(id(466),water_project_cost_sharing(176)).
head(id(467),budget_resolution(176)).
head(id(468),anti_satellite_test_ban(176)).
head(id(469),aid_to_nicaraguan_contras(176)).
head(id(470),mx_missile(176)).
head(id(471),immigration(176)).
head(id(472),duty_free_exports(176)).
head(id(473),export_administration_act_south_africa(176)).
head(id(474),budget_resolution(150)).
head(id(475),anti_satellite_test_ban(150)).
head(id(476),aid_to_nicaraguan_contras(150)).
head(id(477),mx_missile(150)).
head(id(478),immigration(150)).
head(id(479),superfund_right_to_sue(150)).
head(id(480),duty_free_exports(150)).
head(id(481),export_administration_act_south_africa(150)).
head(id(482),budget_resolution(185)).
head(id(483),anti_satellite_test_ban(185)).
head(id(484),aid_to_nicaraguan_contras(185)).
head(id(485),mx_missile(185)).
head(id(486),immigration(185)).
head(id(487),synfuels_corporation_cutback(185)).
head(id(488),duty_free_exports(185)).
head(id(489),export_administration_act_south_africa(185)).
head(id(490),water_project_cost_sharing(153)).
head(id(491),budget_resolution(153)).
head(id(492),religious_groups_in_schools(153)).
head(id(493),aid_to_nicaraguan_contras(153)).
head(id(494),mx_missile(153)).
head(id(495),immigration(153)).
head(id(496),synfuels_corporation_cutback(153)).
head(id(497),superfund_right_to_sue(153)).
head(id(498),duty_free_exports(153)).
head(id(499),export_administration_act_south_africa(153)).
head(id(500),handicapped_infants(99)).
head(id(501),water_project_cost_sharing(99)).
head(id(502),budget_resolution(99)).
head(id(503),religious_groups_in_schools(99)).
head(id(504),anti_satellite_test_ban(99)).
head(id(505),aid_to_nicaraguan_contras(99)).
head(id(506),mx_missile(99)).
head(id(507),immigration(99)).
head(id(508),export_administration_act_south_africa(99)).
head(id(509),water_project_cost_sharing(89)).
head(id(510),budget_resolution(89)).
head(id(511),el_salvador_aid(89)).
head(id(512),religious_groups_in_schools(89)).
head(id(513),anti_satellite_test_ban(89)).
head(id(514),mx_missile(89)).
head(id(515),immigration(89)).
head(id(516),synfuels_corporation_cutback(89)).
head(id(517),superfund_right_to_sue(89)).
head(id(518),crime(89)).
head(id(519),export_administration_act_south_africa(89)).
head(id(520),handicapped_infants(75)).
head(id(521),budget_resolution(75)).
head(id(522),religious_groups_in_schools(75)).
head(id(523),anti_satellite_test_ban(75)).
head(id(524),aid_to_nicaraguan_contras(75)).
head(id(525),mx_missile(75)).
head(id(526),immigration(75)).
head(id(527),synfuels_corporation_cutback(75)).
head(id(528),crime(75)).
head(id(529),duty_free_exports(75)).
head(id(530),export_administration_act_south_africa(75)).
head(id(531),budget_resolution(111)).
head(id(532),anti_satellite_test_ban(111)).
head(id(533),aid_to_nicaraguan_contras(111)).
head(id(534),mx_missile(111)).
head(id(535),immigration(111)).
head(id(536),duty_free_exports(111)).
head(id(537),export_administration_act_south_africa(111)).
head(id(538),handicapped_infants(51)).
head(id(539),water_project_cost_sharing(51)).
head(id(540),budget_resolution(51)).
head(id(541),anti_satellite_test_ban(51)).
head(id(542),aid_to_nicaraguan_contras(51)).
head(id(543),mx_missile(51)).
head(id(544),synfuels_corporation_cutback(51)).
head(id(545),duty_free_exports(51)).
head(id(546),export_administration_act_south_africa(51)).
head(id(547),budget_resolution(132)).
head(id(548),religious_groups_in_schools(132)).
head(id(549),aid_to_nicaraguan_contras(132)).
head(id(550),mx_missile(132)).
head(id(551),immigration(132)).
head(id(552),crime(132)).
head(id(553),export_administration_act_south_africa(132)).
head(id(554),handicapped_infants(24)).
head(id(555),water_project_cost_sharing(24)).
head(id(556),budget_resolution(24)).
head(id(557),anti_satellite_test_ban(24)).
head(id(558),aid_to_nicaraguan_contras(24)).
head(id(559),mx_missile(24)).
head(id(560),duty_free_exports(24)).
head(id(561),export_administration_act_south_africa(24)).
head(id(562),handicapped_infants(140)).
head(id(563),budget_resolution(140)).
head(id(564),religious_groups_in_schools(140)).
head(id(565),anti_satellite_test_ban(140)).
head(id(566),aid_to_nicaraguan_contras(140)).
head(id(567),mx_missile(140)).
head(id(568),duty_free_exports(140)).
head(id(569),export_administration_act_south_africa(140)).
head(id(570),handicapped_infants(79)).
head(id(571),water_project_cost_sharing(79)).
head(id(572),budget_resolution(79)).
head(id(573),el_salvador_aid(79)).
head(id(574),religious_groups_in_schools(79)).
head(id(575),immigration(79)).
head(id(576),synfuels_corporation_cutback(79)).
head(id(577),superfund_right_to_sue(79)).
head(id(578),crime(79)).
head(id(579),export_administration_act_south_africa(79)).
head(id(580),el_salvador_aid(162)).
head(id(581),religious_groups_in_schools(162)).
head(id(582),anti_satellite_test_ban(162)).
head(id(583),education_spending(162)).
head(id(584),superfund_right_to_sue(162)).
head(id(585),crime(162)).
head(id(586),export_administration_act_south_africa(162)).
head(id(587),el_salvador_aid(174)).
head(id(588),religious_groups_in_schools(174)).
head(id(589),immigration(174)).
head(id(590),synfuels_corporation_cutback(174)).
head(id(591),education_spending(174)).
head(id(592),superfund_right_to_sue(174)).
head(id(593),crime(174)).
head(id(594),export_administration_act_south_africa(174)).
head(id(595),water_project_cost_sharing(6)).
head(id(596),budget_resolution(6)).
head(id(597),el_salvador_aid(6)).
head(id(598),religious_groups_in_schools(6)).
head(id(599),superfund_right_to_sue(6)).
head(id(600),crime(6)).
head(id(601),duty_free_exports(6)).
head(id(602),export_administration_act_south_africa(6)).
head(id(603),handicapped_infants(44)).
head(id(604),budget_resolution(44)).
head(id(605),anti_satellite_test_ban(44)).
head(id(606),aid_to_nicaraguan_contras(44)).
head(id(607),mx_missile(44)).
head(id(608),duty_free_exports(44)).
head(id(609),export_administration_act_south_africa(44)).
head(id(610),water_project_cost_sharing(161)).
head(id(611),el_salvador_aid(161)).
head(id(612),religious_groups_in_schools(161)).
head(id(613),education_spending(161)).
head(id(614),superfund_right_to_sue(161)).
head(id(615),crime(161)).
head(id(616),duty_free_exports(161)).
head(id(617),export_administration_act_south_africa(161)).
head(id(618),handicapped_infants(94)).
head(id(619),budget_resolution(94)).
head(id(620),anti_satellite_test_ban(94)).
head(id(621),mx_missile(94)).
head(id(622),immigration(94)).
head(id(623),synfuels_corporation_cutback(94)).
head(id(624),duty_free_exports(94)).
head(id(625),export_administration_act_south_africa(94)).
head(id(626),handicapped_infants(92)).
head(id(627),budget_resolution(92)).
head(id(628),anti_satellite_test_ban(92)).
head(id(629),aid_to_nicaraguan_contras(92)).
head(id(630),mx_missile(92)).
head(id(631),immigration(92)).
head(id(632),synfuels_corporation_cutback(92)).
head(id(633),duty_free_exports(92)).
head(id(634),export_administration_act_south_africa(92)).
head(id(635),handicapped_infants(106)).
head(id(636),water_project_cost_sharing(106)).
head(id(637),budget_resolution(106)).
head(id(638),aid_to_nicaraguan_contras(106)).
head(id(639),mx_missile(106)).
head(id(640),synfuels_corporation_cutback(106)).
head(id(641),duty_free_exports(106)).
head(id(642),export_administration_act_south_africa(106)).
head(id(2017,A),republican(A)) :- dom(A).
body(id(2017,A),alpha_1(A)) :- dom(A).
body(id(2017,A),crime(A)) :- dom(A).
body(id(2017,A),education_spending(A)) :- dom(A).
body(id(2017,A),el_salvador_aid(A)) :- dom(A).
body(id(2017,A),physician_fee_freeze(A)) :- dom(A).
body(id(2017,A),religious_groups_in_schools(A)) :- dom(A).
body(id(2017,A),superfund_right_to_sue(A)) :- dom(A).
head(id(3357,A),republican(A)) :- dom(A).
body(id(3357,A),alpha_2(A)) :- dom(A).
body(id(3357,A),crime(A)) :- dom(A).
body(id(3357,A),education_spending(A)) :- dom(A).
body(id(3357,A),el_salvador_aid(A)) :- dom(A).
body(id(3357,A),immigration(A)) :- dom(A).
body(id(3357,A),physician_fee_freeze(A)) :- dom(A).
body(id(3357,A),superfund_right_to_sue(A)) :- dom(A).
head(id(4717,A),republican(A)) :- dom(A).
body(id(4717,A),alpha_3(A)) :- dom(A).
body(id(4717,A),crime(A)) :- dom(A).
body(id(4717,A),education_spending(A)) :- dom(A).
body(id(4717,A),el_salvador_aid(A)) :- dom(A).
body(id(4717,A),export_administration_act_south_africa(A)) :- dom(A).
body(id(4717,A),immigration(A)) :- dom(A).
body(id(4717,A),physician_fee_freeze(A)) :- dom(A).
body(id(4717,A),religious_groups_in_schools(A)) :- dom(A).
head(id(5406,A),republican(A)) :- dom(A).
body(id(5406,A),crime(A)) :- dom(A).
body(id(5406,A),el_salvador_aid(A)) :- dom(A).
body(id(5406,A),export_administration_act_south_africa(A)) :- dom(A).
body(id(5406,A),handicapped_infants(A)) :- dom(A).
body(id(5406,A),physician_fee_freeze(A)) :- dom(A).
body(id(5406,A),religious_groups_in_schools(A)) :- dom(A).
body(id(5406,A),superfund_right_to_sue(A)) :- dom(A).
body(id(5406,A),water_project_cost_sharing(A)) :- dom(A).
head(id(6099,A),republican(A)) :- dom(A).
body(id(6099,A),aid_to_nicaraguan_contras(A)) :- dom(A).
body(id(6099,A),anti_satellite_test_ban(A)) :- dom(A).
body(id(6099,A),crime(A)) :- dom(A).
body(id(6099,A),export_administration_act_south_africa(A)) :- dom(A).
body(id(6099,A),immigration(A)) :- dom(A).
body(id(6099,A),mx_missile(A)) :- dom(A).
body(id(6099,A),physician_fee_freeze(A)) :- dom(A).
body(id(6099,A),superfund_right_to_sue(A)) :- dom(A).
head(id(7510,A),republican(A)) :- dom(A).
body(id(7510,A),alpha_4(A)) :- dom(A).
body(id(7510,A),education_spending(A)) :- dom(A).
body(id(7510,A),el_salvador_aid(A)) :- dom(A).
body(id(7510,A),export_administration_act_south_africa(A)) :- dom(A).
body(id(7510,A),immigration(A)) :- dom(A).
body(id(7510,A),physician_fee_freeze(A)) :- dom(A).
body(id(7510,A),religious_groups_in_schools(A)) :- dom(A).
body(id(7510,A),superfund_right_to_sue(A)) :- dom(A).
body(id(7510,A),synfuels_corporation_cutback(A)) :- dom(A).
body(id(7510,A),water_project_cost_sharing(A)) :- dom(A).
head(id(8228,A),republican(A)) :- dom(A).
body(id(8228,A),aid_to_nicaraguan_contras(A)) :- dom(A).
body(id(8228,A),anti_satellite_test_ban(A)) :- dom(A).
body(id(8228,A),budget_resolution(A)) :- dom(A).
body(id(8228,A),crime(A)) :- dom(A).
body(id(8228,A),duty_free_exports(A)) :- dom(A).
body(id(8228,A),export_administration_act_south_africa(A)) :- dom(A).
body(id(8228,A),immigration(A)) :- dom(A).
body(id(8228,A),mx_missile(A)) :- dom(A).
body(id(8228,A),physician_fee_freeze(A)) :- dom(A).
head(id(8951,A),republican(A)) :- dom(A).
body(id(8951,A),anti_satellite_test_ban(A)) :- dom(A).
body(id(8951,A),budget_resolution(A)) :- dom(A).
body(id(8951,A),crime(A)) :- dom(A).
body(id(8951,A),el_salvador_aid(A)) :- dom(A).
body(id(8951,A),export_administration_act_south_africa(A)) :- dom(A).
body(id(8951,A),handicapped_infants(A)) :- dom(A).
body(id(8951,A),immigration(A)) :- dom(A).
body(id(8951,A),mx_missile(A)) :- dom(A).
body(id(8951,A),physician_fee_freeze(A)) :- dom(A).
body(id(8951,A),superfund_right_to_sue(A)) :- dom(A).
head(id(9684,A),republican(A)) :- dom(A).
body(id(9684,A),aid_to_nicaraguan_contras(A)) :- dom(A).
body(id(9684,A),anti_satellite_test_ban(A)) :- dom(A).
body(id(9684,A),crime(A)) :- dom(A).
body(id(9684,A),education_spending(A)) :- dom(A).
body(id(9684,A),el_salvador_aid(A)) :- dom(A).
body(id(9684,A),export_administration_act_south_africa(A)) :- dom(A).
body(id(9684,A),handicapped_infants(A)) :- dom(A).
body(id(9684,A),mx_missile(A)) :- dom(A).
body(id(9684,A),physician_fee_freeze(A)) :- dom(A).
body(id(9684,A),superfund_right_to_sue(A)) :- dom(A).
head(id(10427,A),republican(A)) :- dom(A).
body(id(10427,A),anti_satellite_test_ban(A)) :- dom(A).
body(id(10427,A),budget_resolution(A)) :- dom(A).
body(id(10427,A),crime(A)) :- dom(A).
body(id(10427,A),education_spending(A)) :- dom(A).
body(id(10427,A),el_salvador_aid(A)) :- dom(A).
body(id(10427,A),export_administration_act_south_africa(A)) :- dom(A).
body(id(10427,A),handicapped_infants(A)) :- dom(A).
body(id(10427,A),physician_fee_freeze(A)) :- dom(A).
body(id(10427,A),superfund_right_to_sue(A)) :- dom(A).
body(id(10427,A),water_project_cost_sharing(A)) :- dom(A).
head(id(11180,A),republican(A)) :- dom(A).
body(id(11180,A),aid_to_nicaraguan_contras(A)) :- dom(A).
body(id(11180,A),anti_satellite_test_ban(A)) :- dom(A).
body(id(11180,A),budget_resolution(A)) :- dom(A).
body(id(11180,A),crime(A)) :- dom(A).
body(id(11180,A),export_administration_act_south_africa(A)) :- dom(A).
body(id(11180,A),handicapped_infants(A)) :- dom(A).
body(id(11180,A),immigration(A)) :- dom(A).
body(id(11180,A),mx_missile(A)) :- dom(A).
body(id(11180,A),physician_fee_freeze(A)) :- dom(A).
body(id(11180,A),synfuels_corporation_cutback(A)) :- dom(A).
body(id(11180,A),water_project_cost_sharing(A)) :- dom(A).
head(id(11944,A),c_alpha_1(A)) :- dom(A).
body(id(11944,A),aid_to_nicaraguan_contras(A)) :- dom(A).
body(id(11944,A),budget_resolution(A)) :- dom(A).
body(id(11944,A),crime(A)) :- dom(A).
body(id(11944,A),education_spending(A)) :- dom(A).
body(id(11944,A),el_salvador_aid(A)) :- dom(A).
body(id(11944,A),export_administration_act_south_africa(A)) :- dom(A).
body(id(11944,A),immigration(A)) :- dom(A).
body(id(11944,A),mx_missile(A)) :- dom(A).
body(id(11944,A),physician_fee_freeze(A)) :- dom(A).
body(id(11944,A),religious_groups_in_schools(A)) :- dom(A).
body(id(11944,A),superfund_right_to_sue(A)) :- dom(A).
body(id(11944,A),synfuels_corporation_cutback(A)) :- dom(A).
body(id(11944,A),water_project_cost_sharing(A)) :- dom(A).
head(id(12721,A),c_alpha_2(A)) :- dom(A).
body(id(12721,A),aid_to_nicaraguan_contras(A)) :- dom(A).
body(id(12721,A),budget_resolution(A)) :- dom(A).
body(id(12721,A),crime(A)) :- dom(A).
body(id(12721,A),education_spending(A)) :- dom(A).
body(id(12721,A),el_salvador_aid(A)) :- dom(A).
body(id(12721,A),export_administration_act_south_africa(A)) :- dom(A).
body(id(12721,A),immigration(A)) :- dom(A).
body(id(12721,A),mx_missile(A)) :- dom(A).
body(id(12721,A),physician_fee_freeze(A)) :- dom(A).
body(id(12721,A),religious_groups_in_schools(A)) :- dom(A).
body(id(12721,A),superfund_right_to_sue(A)) :- dom(A).
body(id(12721,A),synfuels_corporation_cutback(A)) :- dom(A).
body(id(12721,A),water_project_cost_sharing(A)) :- dom(A).
head(id(13511,A),c_alpha_3(A)) :- dom(A).
body(id(13511,A),aid_to_nicaraguan_contras(A)) :- dom(A).
body(id(13511,A),budget_resolution(A)) :- dom(A).
body(id(13511,A),crime(A)) :- dom(A).
body(id(13511,A),education_spending(A)) :- dom(A).
body(id(13511,A),el_salvador_aid(A)) :- dom(A).
body(id(13511,A),export_administration_act_south_africa(A)) :- dom(A).
body(id(13511,A),immigration(A)) :- dom(A).
body(id(13511,A),mx_missile(A)) :- dom(A).
body(id(13511,A),physician_fee_freeze(A)) :- dom(A).
body(id(13511,A),religious_groups_in_schools(A)) :- dom(A).
body(id(13511,A),superfund_right_to_sue(A)) :- dom(A).
body(id(13511,A),synfuels_corporation_cutback(A)) :- dom(A).
body(id(13511,A),water_project_cost_sharing(A)) :- dom(A).
head(id(14314,A),c_alpha_4(A)) :- dom(A).
body(id(14314,A),aid_to_nicaraguan_contras(A)) :- dom(A).
body(id(14314,A),budget_resolution(A)) :- dom(A).
body(id(14314,A),crime(A)) :- dom(A).
body(id(14314,A),education_spending(A)) :- dom(A).
body(id(14314,A),el_salvador_aid(A)) :- dom(A).
body(id(14314,A),export_administration_act_south_africa(A)) :- dom(A).
body(id(14314,A),immigration(A)) :- dom(A).
body(id(14314,A),mx_missile(A)) :- dom(A).
body(id(14314,A),physician_fee_freeze(A)) :- dom(A).
body(id(14314,A),religious_groups_in_schools(A)) :- dom(A).
body(id(14314,A),superfund_right_to_sue(A)) :- dom(A).
body(id(14314,A),synfuels_corporation_cutback(A)) :- dom(A).
body(id(14314,A),water_project_cost_sharing(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
assumption(alpha_4(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).
contrary(alpha_4(A),c_alpha_4(A)) :- assumption(alpha_4(A)).

dom(6).
dom(9).
dom(20).
dom(24).
dom(26).
dom(27).
dom(29).
dom(31).
dom(33).
dom(35).
dom(36).
dom(38).
dom(39).
dom(40).
dom(44).
dom(47).
dom(49).
dom(51).
dom(54).
dom(57).
dom(58).
dom(59).
dom(62).
dom(64).
dom(66).
dom(68).
dom(72).
dom(74).
dom(75).
dom(76).
dom(78).
dom(79).
dom(80).
dom(84).
dom(87).
dom(88).
dom(89).
dom(92).
dom(94).
dom(95).
dom(99).
dom(101).
dom(106).
dom(107).
dom(111).
dom(117).
dom(118).
dom(120).
dom(123).
dom(132).
dom(134).
dom(136).
dom(137).
dom(140).
dom(141).
dom(143).
dom(148).
dom(149).
dom(150).
dom(153).
dom(154).
dom(155).
dom(157).
dom(159).
dom(161).
dom(162).
dom(163).
dom(167).
dom(170).
dom(174).
dom(176).
dom(177).
dom(180).
dom(182).
dom(185).
dom(187).
