% training data:
% no. positive ex.: 14
% no. negative ex.: 26
% query: 
train :- aba_asp('./xabal/autism.csv.f3.bk',[autism(434),autism(529),autism(124),autism(509),autism(660),autism(559),autism(224),autism(189),autism(693),autism(472),autism(545),autism(494),autism(638),autism(449)],[autism(304),autism(608),autism(64),autism(294),autism(132),autism(600),autism(215),autism(633),autism(202),autism(113),autism(520),autism(160),autism(527),autism(110),autism(342),autism(306),autism(581),autism(617),autism(676),autism(157),autism(44),autism(131),autism(259),autism(470),autism(489),autism(9)]).
% test data:
% no. positive ex.: 3
% no. negative ex.: 7
% query: 
test :- test_abaf('./xabal/autism.csv.f3.bk.sol',[pos(autism(521),[a1(521),a2(521),a3(521),a4(521),a5(521),a8(521),a9(521),a10(521),age2(521),female(521),white(521),pdd(521),self(521)]),pos(autism(654),[a1(654),a2(654),a3(654),a4(654),a5(654),a6(654),a7(654),a8(654),a9(654),a10(654),age3(654),female(654),white(654),pdd(654),self(654)]),pos(autism(203),[a1(203),a2(203),a4(203),a5(203),a8(203),a9(203),a10(203),age2(203),female(203),white(203),self(203)])],[neg(autism(295),[age4(295),female(295),middleeastern(295),parent(295)]),neg(autism(133),[a1(133),a2(133),a8(133),age2(133),southasian(133),self(133)]),neg(autism(88),[a1(88),age3(88),white(88),self(88)]),neg(autism(205),[a1(205),a3(205),a4(205),age3(205),white(205),pdd(205),self(205)]),neg(autism(267),[a1(267),a4(267),a9(267),age2(267),asian(267),self(267)]),neg(autism(321),[a1(321),a2(321),age1(321),female(321),middleeastern(321),self(321)]),neg(autism(286),[a4(286),a5(286),a6(286),a7(286),a9(286),a10(286),age3(286),female(286)])]).
