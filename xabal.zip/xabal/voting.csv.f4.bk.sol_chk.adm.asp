head(id(1),physician_fee_freeze(301)).
head(id(2),el_salvador_aid(301)).
head(id(3),anti_satellite_test_ban(301)).
head(id(4),aid_to_nicaraguan_contras(301)).
head(id(5),mx_missile(301)).
head(id(6),immigration(301)).
head(id(7),education_spending(301)).
head(id(8),superfund_right_to_sue(301)).
head(id(9),crime(301)).
head(id(10),export_administration_act_south_africa(301)).
head(id(11),handicapped_infants(405)).
head(id(12),water_project_cost_sharing(405)).
head(id(13),physician_fee_freeze(405)).
head(id(14),el_salvador_aid(405)).
head(id(15),religious_groups_in_schools(405)).
head(id(16),immigration(405)).
head(id(17),education_spending(405)).
head(id(18),superfund_right_to_sue(405)).
head(id(19),crime(405)).
head(id(20),export_administration_act_south_africa(405)).
head(id(21),physician_fee_freeze(143)).
head(id(22),el_salvador_aid(143)).
head(id(23),religious_groups_in_schools(143)).
head(id(24),anti_satellite_test_ban(143)).
head(id(25),aid_to_nicaraguan_contras(143)).
head(id(26),mx_missile(143)).
head(id(27),immigration(143)).
head(id(28),education_spending(143)).
head(id(29),superfund_right_to_sue(143)).
head(id(30),crime(143)).
head(id(31),export_administration_act_south_africa(143)).
head(id(32),physician_fee_freeze(357)).
head(id(33),el_salvador_aid(357)).
head(id(34),religious_groups_in_schools(357)).
head(id(35),education_spending(357)).
head(id(36),superfund_right_to_sue(357)).
head(id(37),crime(357)).
head(id(38),physician_fee_freeze(240)).
head(id(39),el_salvador_aid(240)).
head(id(40),religious_groups_in_schools(240)).
head(id(41),anti_satellite_test_ban(240)).
head(id(42),immigration(240)).
head(id(43),crime(240)).
head(id(44),duty_free_exports(240)).
head(id(45),export_administration_act_south_africa(240)).
head(id(46),physician_fee_freeze(406)).
head(id(47),el_salvador_aid(406)).
head(id(48),religious_groups_in_schools(406)).
head(id(49),education_spending(406)).
head(id(50),superfund_right_to_sue(406)).
head(id(51),crime(406)).
head(id(52),export_administration_act_south_africa(406)).
head(id(53),water_project_cost_sharing(62)).
head(id(54),physician_fee_freeze(62)).
head(id(55),el_salvador_aid(62)).
head(id(56),religious_groups_in_schools(62)).
head(id(57),education_spending(62)).
head(id(58),superfund_right_to_sue(62)).
head(id(59),crime(62)).
head(id(60),water_project_cost_sharing(59)).
head(id(61),physician_fee_freeze(59)).
head(id(62),el_salvador_aid(59)).
head(id(63),religious_groups_in_schools(59)).
head(id(64),immigration(59)).
head(id(65),education_spending(59)).
head(id(66),superfund_right_to_sue(59)).
head(id(67),crime(59)).
head(id(68),export_administration_act_south_africa(59)).
head(id(69),water_project_cost_sharing(34)).
head(id(70),physician_fee_freeze(34)).
head(id(71),el_salvador_aid(34)).
head(id(72),religious_groups_in_schools(34)).
head(id(73),education_spending(34)).
head(id(74),superfund_right_to_sue(34)).
head(id(75),crime(34)).
head(id(76),export_administration_act_south_africa(34)).
head(id(77),water_project_cost_sharing(164)).
head(id(78),physician_fee_freeze(164)).
head(id(79),el_salvador_aid(164)).
head(id(80),religious_groups_in_schools(164)).
head(id(81),anti_satellite_test_ban(164)).
head(id(82),education_spending(164)).
head(id(83),superfund_right_to_sue(164)).
head(id(84),crime(164)).
head(id(85),export_administration_act_south_africa(164)).
head(id(86),physician_fee_freeze(84)).
head(id(87),el_salvador_aid(84)).
head(id(88),religious_groups_in_schools(84)).
head(id(89),education_spending(84)).
head(id(90),superfund_right_to_sue(84)).
head(id(91),crime(84)).
head(id(92),physician_fee_freeze(83)).
head(id(93),el_salvador_aid(83)).
head(id(94),religious_groups_in_schools(83)).
head(id(95),immigration(83)).
head(id(96),education_spending(83)).
head(id(97),superfund_right_to_sue(83)).
head(id(98),crime(83)).
head(id(99),export_administration_act_south_africa(83)).
head(id(100),handicapped_infants(74)).
head(id(101),budget_resolution(74)).
head(id(102),physician_fee_freeze(74)).
head(id(103),el_salvador_aid(74)).
head(id(104),anti_satellite_test_ban(74)).
head(id(105),mx_missile(74)).
head(id(106),immigration(74)).
head(id(107),superfund_right_to_sue(74)).
head(id(108),crime(74)).
head(id(109),export_administration_act_south_africa(74)).
head(id(110),physician_fee_freeze(88)).
head(id(111),el_salvador_aid(88)).
head(id(112),religious_groups_in_schools(88)).
head(id(113),education_spending(88)).
head(id(114),superfund_right_to_sue(88)).
head(id(115),crime(88)).
head(id(116),physician_fee_freeze(341)).
head(id(117),el_salvador_aid(341)).
head(id(118),religious_groups_in_schools(341)).
head(id(119),immigration(341)).
head(id(120),synfuels_corporation_cutback(341)).
head(id(121),education_spending(341)).
head(id(122),crime(341)).
head(id(123),export_administration_act_south_africa(341)).
head(id(124),physician_fee_freeze(303)).
head(id(125),el_salvador_aid(303)).
head(id(126),religious_groups_in_schools(303)).
head(id(127),anti_satellite_test_ban(303)).
head(id(128),immigration(303)).
head(id(129),education_spending(303)).
head(id(130),superfund_right_to_sue(303)).
head(id(131),crime(303)).
head(id(132),export_administration_act_south_africa(303)).
head(id(133),water_project_cost_sharing(147)).
head(id(134),physician_fee_freeze(147)).
head(id(135),el_salvador_aid(147)).
head(id(136),religious_groups_in_schools(147)).
head(id(137),education_spending(147)).
head(id(138),superfund_right_to_sue(147)).
head(id(139),crime(147)).
head(id(140),export_administration_act_south_africa(147)).
head(id(141),handicapped_infants(365)).
head(id(142),water_project_cost_sharing(365)).
head(id(143),physician_fee_freeze(365)).
head(id(144),el_salvador_aid(365)).
head(id(145),religious_groups_in_schools(365)).
head(id(146),synfuels_corporation_cutback(365)).
head(id(147),superfund_right_to_sue(365)).
head(id(148),crime(365)).
head(id(149),export_administration_act_south_africa(365)).
head(id(150),handicapped_infants(393)).
head(id(151),water_project_cost_sharing(393)).
head(id(152),physician_fee_freeze(393)).
head(id(153),el_salvador_aid(393)).
head(id(154),religious_groups_in_schools(393)).
head(id(155),synfuels_corporation_cutback(393)).
head(id(156),education_spending(393)).
head(id(157),superfund_right_to_sue(393)).
head(id(158),crime(393)).
head(id(159),export_administration_act_south_africa(393)).
head(id(160),handicapped_infants(348)).
head(id(161),physician_fee_freeze(348)).
head(id(162),el_salvador_aid(348)).
head(id(163),religious_groups_in_schools(348)).
head(id(164),immigration(348)).
head(id(165),education_spending(348)).
head(id(166),superfund_right_to_sue(348)).
head(id(167),crime(348)).
head(id(168),handicapped_infants(151)).
head(id(169),water_project_cost_sharing(151)).
head(id(170),physician_fee_freeze(151)).
head(id(171),el_salvador_aid(151)).
head(id(172),religious_groups_in_schools(151)).
head(id(173),immigration(151)).
head(id(174),education_spending(151)).
head(id(175),superfund_right_to_sue(151)).
head(id(176),crime(151)).
head(id(177),export_administration_act_south_africa(151)).
head(id(178),physician_fee_freeze(267)).
head(id(179),el_salvador_aid(267)).
head(id(180),religious_groups_in_schools(267)).
head(id(181),immigration(267)).
head(id(182),education_spending(267)).
head(id(183),crime(267)).
head(id(184),export_administration_act_south_africa(267)).
head(id(185),physician_fee_freeze(347)).
head(id(186),el_salvador_aid(347)).
head(id(187),religious_groups_in_schools(347)).
head(id(188),immigration(347)).
head(id(189),education_spending(347)).
head(id(190),superfund_right_to_sue(347)).
head(id(191),crime(347)).
head(id(192),export_administration_act_south_africa(347)).
head(id(193),physician_fee_freeze(134)).
head(id(194),el_salvador_aid(134)).
head(id(195),religious_groups_in_schools(134)).
head(id(196),immigration(134)).
head(id(197),education_spending(134)).
head(id(198),superfund_right_to_sue(134)).
head(id(199),crime(134)).
head(id(200),export_administration_act_south_africa(134)).
head(id(201),budget_resolution(201)).
head(id(202),anti_satellite_test_ban(201)).
head(id(203),aid_to_nicaraguan_contras(201)).
head(id(204),mx_missile(201)).
head(id(205),crime(201)).
head(id(206),duty_free_exports(201)).
head(id(207),export_administration_act_south_africa(201)).
head(id(208),handicapped_infants(420)).
head(id(209),water_project_cost_sharing(420)).
head(id(210),budget_resolution(420)).
head(id(211),anti_satellite_test_ban(420)).
head(id(212),aid_to_nicaraguan_contras(420)).
head(id(213),mx_missile(420)).
head(id(214),export_administration_act_south_africa(420)).
head(id(215),water_project_cost_sharing(153)).
head(id(216),budget_resolution(153)).
head(id(217),religious_groups_in_schools(153)).
head(id(218),aid_to_nicaraguan_contras(153)).
head(id(219),mx_missile(153)).
head(id(220),immigration(153)).
head(id(221),synfuels_corporation_cutback(153)).
head(id(222),superfund_right_to_sue(153)).
head(id(223),duty_free_exports(153)).
head(id(224),export_administration_act_south_africa(153)).
head(id(225),water_project_cost_sharing(366)).
head(id(226),el_salvador_aid(366)).
head(id(227),religious_groups_in_schools(366)).
head(id(228),immigration(366)).
head(id(229),synfuels_corporation_cutback(366)).
head(id(230),superfund_right_to_sue(366)).
head(id(231),crime(366)).
head(id(232),water_project_cost_sharing(89)).
head(id(233),budget_resolution(89)).
head(id(234),el_salvador_aid(89)).
head(id(235),religious_groups_in_schools(89)).
head(id(236),anti_satellite_test_ban(89)).
head(id(237),mx_missile(89)).
head(id(238),immigration(89)).
head(id(239),synfuels_corporation_cutback(89)).
head(id(240),superfund_right_to_sue(89)).
head(id(241),crime(89)).
head(id(242),export_administration_act_south_africa(89)).
head(id(243),budget_resolution(154)).
head(id(244),religious_groups_in_schools(154)).
head(id(245),anti_satellite_test_ban(154)).
head(id(246),aid_to_nicaraguan_contras(154)).
head(id(247),mx_missile(154)).
head(id(248),immigration(154)).
head(id(249),synfuels_corporation_cutback(154)).
head(id(250),superfund_right_to_sue(154)).
head(id(251),crime(154)).
head(id(252),export_administration_act_south_africa(154)).
head(id(253),religious_groups_in_schools(317)).
head(id(254),aid_to_nicaraguan_contras(317)).
head(id(255),mx_missile(317)).
head(id(256),synfuels_corporation_cutback(317)).
head(id(257),education_spending(317)).
head(id(258),superfund_right_to_sue(317)).
head(id(259),crime(317)).
head(id(260),duty_free_exports(317)).
head(id(261),handicapped_infants(203)).
head(id(262),budget_resolution(203)).
head(id(263),religious_groups_in_schools(203)).
head(id(264),anti_satellite_test_ban(203)).
head(id(265),aid_to_nicaraguan_contras(203)).
head(id(266),mx_missile(203)).
head(id(267),immigration(203)).
head(id(268),synfuels_corporation_cutback(203)).
head(id(269),duty_free_exports(203)).
head(id(270),export_administration_act_south_africa(203)).
head(id(271),handicapped_infants(386)).
head(id(272),water_project_cost_sharing(386)).
head(id(273),el_salvador_aid(386)).
head(id(274),religious_groups_in_schools(386)).
head(id(275),synfuels_corporation_cutback(386)).
head(id(276),education_spending(386)).
head(id(277),superfund_right_to_sue(386)).
head(id(278),crime(386)).
head(id(279),duty_free_exports(386)).
head(id(280),handicapped_infants(261)).
head(id(281),budget_resolution(261)).
head(id(282),anti_satellite_test_ban(261)).
head(id(283),aid_to_nicaraguan_contras(261)).
head(id(284),mx_missile(261)).
head(id(285),immigration(261)).
head(id(286),export_administration_act_south_africa(261)).
head(id(287),handicapped_infants(140)).
head(id(288),budget_resolution(140)).
head(id(289),religious_groups_in_schools(140)).
head(id(290),anti_satellite_test_ban(140)).
head(id(291),aid_to_nicaraguan_contras(140)).
head(id(292),mx_missile(140)).
head(id(293),duty_free_exports(140)).
head(id(294),export_administration_act_south_africa(140)).
head(id(295),handicapped_infants(412)).
head(id(296),budget_resolution(412)).
head(id(297),religious_groups_in_schools(412)).
head(id(298),anti_satellite_test_ban(412)).
head(id(299),aid_to_nicaraguan_contras(412)).
head(id(300),mx_missile(412)).
head(id(301),immigration(412)).
head(id(302),synfuels_corporation_cutback(412)).
head(id(303),export_administration_act_south_africa(412)).
head(id(304),water_project_cost_sharing(176)).
head(id(305),budget_resolution(176)).
head(id(306),anti_satellite_test_ban(176)).
head(id(307),aid_to_nicaraguan_contras(176)).
head(id(308),mx_missile(176)).
head(id(309),immigration(176)).
head(id(310),duty_free_exports(176)).
head(id(311),export_administration_act_south_africa(176)).
head(id(312),water_project_cost_sharing(220)).
head(id(313),budget_resolution(220)).
head(id(314),aid_to_nicaraguan_contras(220)).
head(id(315),mx_missile(220)).
head(id(316),synfuels_corporation_cutback(220)).
head(id(317),crime(220)).
head(id(318),duty_free_exports(220)).
head(id(319),export_administration_act_south_africa(220)).
head(id(320),handicapped_infants(384)).
head(id(321),water_project_cost_sharing(384)).
head(id(322),budget_resolution(384)).
head(id(323),el_salvador_aid(384)).
head(id(324),religious_groups_in_schools(384)).
head(id(325),aid_to_nicaraguan_contras(384)).
head(id(326),mx_missile(384)).
head(id(327),immigration(384)).
head(id(328),synfuels_corporation_cutback(384)).
head(id(329),export_administration_act_south_africa(384)).
head(id(330),handicapped_infants(40)).
head(id(331),budget_resolution(40)).
head(id(332),anti_satellite_test_ban(40)).
head(id(333),aid_to_nicaraguan_contras(40)).
head(id(334),mx_missile(40)).
head(id(335),immigration(40)).
head(id(336),synfuels_corporation_cutback(40)).
head(id(337),superfund_right_to_sue(40)).
head(id(338),duty_free_exports(40)).
head(id(339),export_administration_act_south_africa(40)).
head(id(340),budget_resolution(227)).
head(id(341),religious_groups_in_schools(227)).
head(id(342),anti_satellite_test_ban(227)).
head(id(343),aid_to_nicaraguan_contras(227)).
head(id(344),mx_missile(227)).
head(id(345),synfuels_corporation_cutback(227)).
head(id(346),crime(227)).
head(id(347),duty_free_exports(227)).
head(id(348),export_administration_act_south_africa(227)).
head(id(349),water_project_cost_sharing(369)).
head(id(350),budget_resolution(369)).
head(id(351),religious_groups_in_schools(369)).
head(id(352),anti_satellite_test_ban(369)).
head(id(353),aid_to_nicaraguan_contras(369)).
head(id(354),immigration(369)).
head(id(355),duty_free_exports(369)).
head(id(356),export_administration_act_south_africa(369)).
head(id(357),water_project_cost_sharing(163)).
head(id(358),budget_resolution(163)).
head(id(359),el_salvador_aid(163)).
head(id(360),religious_groups_in_schools(163)).
head(id(361),anti_satellite_test_ban(163)).
head(id(362),synfuels_corporation_cutback(163)).
head(id(363),education_spending(163)).
head(id(364),superfund_right_to_sue(163)).
head(id(365),crime(163)).
head(id(366),export_administration_act_south_africa(163)).
head(id(367),water_project_cost_sharing(424)).
head(id(368),budget_resolution(424)).
head(id(369),religious_groups_in_schools(424)).
head(id(370),anti_satellite_test_ban(424)).
head(id(371),aid_to_nicaraguan_contras(424)).
head(id(372),mx_missile(424)).
head(id(373),synfuels_corporation_cutback(424)).
head(id(374),crime(424)).
head(id(375),duty_free_exports(424)).
head(id(376),export_administration_act_south_africa(424)).
head(id(377),handicapped_infants(407)).
head(id(378),budget_resolution(407)).
head(id(379),el_salvador_aid(407)).
head(id(380),religious_groups_in_schools(407)).
head(id(381),mx_missile(407)).
head(id(382),immigration(407)).
head(id(383),superfund_right_to_sue(407)).
head(id(384),crime(407)).
head(id(385),export_administration_act_south_africa(407)).
head(id(386),handicapped_infants(392)).
head(id(387),water_project_cost_sharing(392)).
head(id(388),aid_to_nicaraguan_contras(392)).
head(id(389),mx_missile(392)).
head(id(390),synfuels_corporation_cutback(392)).
head(id(391),duty_free_exports(392)).
head(id(392),handicapped_infants(338)).
head(id(393),budget_resolution(338)).
head(id(394),anti_satellite_test_ban(338)).
head(id(395),aid_to_nicaraguan_contras(338)).
head(id(396),mx_missile(338)).
head(id(397),duty_free_exports(338)).
head(id(398),export_administration_act_south_africa(338)).
head(id(399),handicapped_infants(30)).
head(id(400),water_project_cost_sharing(30)).
head(id(401),budget_resolution(30)).
head(id(402),anti_satellite_test_ban(30)).
head(id(403),aid_to_nicaraguan_contras(30)).
head(id(404),mx_missile(30)).
head(id(405),synfuels_corporation_cutback(30)).
head(id(406),duty_free_exports(30)).
head(id(407),export_administration_act_south_africa(30)).
head(id(1272,A),republican(A)) :- dom(A).
body(id(1272,A),physician_fee_freeze(A)) :- dom(A).

dom(30).
dom(34).
dom(40).
dom(59).
dom(62).
dom(74).
dom(83).
dom(84).
dom(88).
dom(89).
dom(134).
dom(140).
dom(143).
dom(147).
dom(151).
dom(153).
dom(154).
dom(163).
dom(164).
dom(176).
dom(201).
dom(203).
dom(220).
dom(227).
dom(240).
dom(261).
dom(267).
dom(301).
dom(303).
dom(317).
dom(338).
dom(341).
dom(347).
dom(348).
dom(357).
dom(365).
dom(366).
dom(369).
dom(384).
dom(386).
dom(392).
dom(393).
dom(405).
dom(406).
dom(407).
dom(412).
dom(420).
dom(424).
 :- not supported(republican(301)).
 :- not supported(republican(405)).
 :- not supported(republican(143)).
 :- not supported(republican(357)).
 :- not supported(republican(240)).
 :- not supported(republican(406)).
 :- not supported(republican(62)).
 :- not supported(republican(59)).
 :- not supported(republican(34)).
 :- not supported(republican(164)).
 :- not supported(republican(84)).
 :- not supported(republican(83)).
 :- not supported(republican(74)).
 :- not supported(republican(88)).
 :- not supported(republican(341)).
 :- not supported(republican(303)).
 :- not supported(republican(147)).
 :- not supported(republican(365)).
 :- not supported(republican(393)).
 :- not supported(republican(348)).
 :- not supported(republican(151)).
 :- not supported(republican(267)).
 :- not supported(republican(347)).
 :- not supported(republican(134)).
 :- supported(republican(201)).
 :- supported(republican(420)).
 :- supported(republican(153)).
 :- supported(republican(366)).
 :- supported(republican(89)).
 :- supported(republican(154)).
 :- supported(republican(317)).
 :- supported(republican(203)).
 :- supported(republican(386)).
 :- supported(republican(261)).
 :- supported(republican(140)).
 :- supported(republican(412)).
 :- supported(republican(176)).
 :- supported(republican(220)).
 :- supported(republican(384)).
 :- supported(republican(40)).
 :- supported(republican(227)).
 :- supported(republican(369)).
 :- supported(republican(163)).
 :- supported(republican(424)).
 :- supported(republican(407)).
 :- supported(republican(392)).
 :- supported(republican(338)).
 :- supported(republican(30)).
