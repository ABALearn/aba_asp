head(id(1),a6(2221)).
head(id(2),a9(2221)).
head(id(3),a11(2221)).
head(id(4),a13(2221)).
head(id(5),n(2221)).
head(id(6),a18(2221)).
head(id(7),a20(2221)).
head(id(8),a21(2221)).
head(id(9),a22(2221)).
head(id(10),a26(2221)).
head(id(11),a31(2221)).
head(id(12),a33(2221)).
head(id(13),a34(2221)).
head(id(14),a6(420)).
head(id(15),a9(420)).
head(id(16),a11(420)).
head(id(17),n(420)).
head(id(18),a18(420)).
head(id(19),a22(420)).
head(id(20),a26(420)).
head(id(21),a34(420)).
head(id(22),a35(420)).
head(id(23),a5(296)).
head(id(24),a7(296)).
head(id(25),a8(296)).
head(id(26),a9(296)).
head(id(27),a13(296)).
head(id(28),n(296)).
head(id(29),a18(296)).
head(id(30),a24(296)).
head(id(31),a34(296)).
head(id(32),a35(296)).
head(id(33),a5(2181)).
head(id(34),a11(2181)).
head(id(35),a13(2181)).
head(id(36),w(2181)).
head(id(37),a21(2181)).
head(id(38),a26(2181)).
head(id(39),a31(2181)).
head(id(40),a2(2266)).
head(id(41),a5(2266)).
head(id(42),a9(2266)).
head(id(43),a13(2266)).
head(id(44),n(2266)).
head(id(45),a21(2266)).
head(id(46),a22(2266)).
head(id(47),a35(2266)).
head(id(48),a1(200)).
head(id(49),a6(200)).
head(id(50),a7(200)).
head(id(51),a11(200)).
head(id(52),a13(200)).
head(id(53),b(200)).
head(id(54),a18(200)).
head(id(55),a24(200)).
head(id(56),a26(200)).
head(id(57),a34(200)).
head(id(58),a35(200)).
head(id(59),a2(1702)).
head(id(60),a11(1702)).
head(id(61),a13(1702)).
head(id(62),w(1702)).
head(id(63),a20(1702)).
head(id(64),a26(1702)).
head(id(65),a31(1702)).
head(id(66),a5(68)).
head(id(67),a7(68)).
head(id(68),a13(68)).
head(id(69),n(68)).
head(id(70),a24(68)).
head(id(71),a26(68)).
head(id(72),a34(68)).
head(id(73),a35(68)).
head(id(74),a10(2011)).
head(id(75),a11(2011)).
head(id(76),a13(2011)).
head(id(77),w(2011)).
head(id(78),a18(2011)).
head(id(79),a20(2011)).
head(id(80),a21(2011)).
head(id(81),a24(2011)).
head(id(82),a26(2011)).
head(id(83),a31(2011)).
head(id(84),a33(2011)).
head(id(85),a34(2011)).
head(id(86),a35(2011)).
head(id(87),a1(49)).
head(id(88),a11(49)).
head(id(89),a13(49)).
head(id(90),n(49)).
head(id(91),a18(49)).
head(id(92),a24(49)).
head(id(93),a26(49)).
head(id(94),a31(49)).
head(id(95),a34(49)).
head(id(96),a1(2258)).
head(id(97),a4(2258)).
head(id(98),a6(2258)).
head(id(99),a11(2258)).
head(id(100),a13(2258)).
head(id(101),w(2258)).
head(id(102),a21(2258)).
head(id(103),a24(2258)).
head(id(104),a26(2258)).
head(id(105),a27(2258)).
head(id(106),a31(2258)).
head(id(107),a33(2258)).
head(id(108),a35(2258)).
head(id(109),a13(611)).
head(id(110),n(611)).
head(id(111),a24(611)).
head(id(112),a34(611)).
head(id(113),a35(611)).
head(id(114),a36(611)).
head(id(115),a2(2324)).
head(id(116),a5(2324)).
head(id(117),a9(2324)).
head(id(118),a13(2324)).
head(id(119),n(2324)).
head(id(120),a21(2324)).
head(id(121),a22(2324)).
head(id(122),a30(2324)).
head(id(123),a33(2324)).
head(id(124),a35(2324)).
head(id(125),a36(2324)).
head(id(126),a13(703)).
head(id(127),n(703)).
head(id(128),a18(703)).
head(id(129),a21(703)).
head(id(130),a26(703)).
head(id(131),a34(703)).
head(id(132),a35(703)).
head(id(133),a2(2308)).
head(id(134),a9(2308)).
head(id(135),a13(2308)).
head(id(136),n(2308)).
head(id(137),a21(2308)).
head(id(138),a22(2308)).
head(id(139),a24(2308)).
head(id(140),a33(2308)).
head(id(141),a35(2308)).
head(id(142),a36(2308)).
head(id(143),a5(594)).
head(id(144),a6(594)).
head(id(145),a7(594)).
head(id(146),a8(594)).
head(id(147),a9(594)).
head(id(148),a13(594)).
head(id(149),n(594)).
head(id(150),a18(594)).
head(id(151),a26(594)).
head(id(152),a35(594)).
head(id(153),a36(594)).
head(id(154),a6(259)).
head(id(155),a7(259)).
head(id(156),a8(259)).
head(id(157),a9(259)).
head(id(158),a11(259)).
head(id(159),a13(259)).
head(id(160),w(259)).
head(id(161),a18(259)).
head(id(162),a22(259)).
head(id(163),a26(259)).
head(id(164),a34(259)).
head(id(165),a35(259)).
head(id(166),a7(107)).
head(id(167),a8(107)).
head(id(168),a9(107)).
head(id(169),a11(107)).
head(id(170),a13(107)).
head(id(171),w(107)).
head(id(172),a18(107)).
head(id(173),a20(107)).
head(id(174),a26(107)).
head(id(175),a34(107)).
head(id(176),a35(107)).
head(id(177),a6(339)).
head(id(178),a9(339)).
head(id(179),a13(339)).
head(id(180),n(339)).
head(id(181),a22(339)).
head(id(182),a24(339)).
head(id(183),a35(339)).
head(id(184),a9(671)).
head(id(185),n(671)).
head(id(186),a18(671)).
head(id(187),a22(671)).
head(id(188),a34(671)).
head(id(189),a35(671)).
head(id(190),a36(671)).
head(id(191),a6(591)).
head(id(192),a13(591)).
head(id(193),n(591)).
head(id(194),a24(591)).
head(id(195),a26(591)).
head(id(196),a33(591)).
head(id(197),a35(591)).
head(id(198),a36(591)).
head(id(199),a1(2912)).
head(id(200),a4(2912)).
head(id(201),a6(2912)).
head(id(202),a11(2912)).
head(id(203),a13(2912)).
head(id(204),n(2912)).
head(id(205),a18(2912)).
head(id(206),a24(2912)).
head(id(207),a26(2912)).
head(id(208),a27(2912)).
head(id(209),a31(2912)).
head(id(210),a33(2912)).
head(id(211),a35(2912)).
head(id(212),w(3154)).
head(id(213),a18(3154)).
head(id(214),a20(3154)).
head(id(215),a24(3154)).
head(id(216),a26(3154)).
head(id(217),a29(3154)).
head(id(218),a32(3154)).
head(id(219),a34(3154)).
head(id(220),a6(3121)).
head(id(221),a9(3121)).
head(id(222),a13(3121)).
head(id(223),n(3121)).
head(id(224),a16(3121)).
head(id(225),a22(3121)).
head(id(226),a24(3121)).
head(id(227),a33(3121)).
head(id(228),a35(3121)).
head(id(229),a36(3121)).
head(id(230),a6(1452)).
head(id(231),a7(1452)).
head(id(232),a10(1452)).
head(id(233),a11(1452)).
head(id(234),n(1452)).
head(id(235),a18(1452)).
head(id(236),a26(1452)).
head(id(237),a34(1452)).
head(id(238),a35(1452)).
head(id(239),a6(2576)).
head(id(240),a7(2576)).
head(id(241),a10(2576)).
head(id(242),a11(2576)).
head(id(243),a13(2576)).
head(id(244),w(2576)).
head(id(245),a18(2576)).
head(id(246),a20(2576)).
head(id(247),a26(2576)).
head(id(248),a31(2576)).
head(id(249),a33(2576)).
head(id(250),a34(2576)).
head(id(251),a11(2821)).
head(id(252),a13(2821)).
head(id(253),n(2821)).
head(id(254),a18(2821)).
head(id(255),a20(2821)).
head(id(256),a26(2821)).
head(id(257),a27(2821)).
head(id(258),a31(2821)).
head(id(259),a33(2821)).
head(id(260),a34(2821)).
head(id(261),a5(1045)).
head(id(262),a6(1045)).
head(id(263),a7(1045)).
head(id(264),a8(1045)).
head(id(265),a9(1045)).
head(id(266),a13(1045)).
head(id(267),n(1045)).
head(id(268),a18(1045)).
head(id(269),a33(1045)).
head(id(270),a35(1045)).
head(id(271),a10(1494)).
head(id(272),n(1494)).
head(id(273),a18(1494)).
head(id(274),a24(1494)).
head(id(275),a33(1494)).
head(id(276),a34(1494)).
head(id(277),a35(1494)).
head(id(278),a5(2868)).
head(id(279),a9(2868)).
head(id(280),a13(2868)).
head(id(281),n(2868)).
head(id(282),a20(2868)).
head(id(283),a22(2868)).
head(id(284),a26(2868)).
head(id(285),a32(2868)).
head(id(286),a34(2868)).
head(id(287),a1(2494)).
head(id(288),a3(2494)).
head(id(289),a7(2494)).
head(id(290),a8(2494)).
head(id(291),a9(2494)).
head(id(292),a10(2494)).
head(id(293),a11(2494)).
head(id(294),a13(2494)).
head(id(295),b(2494)).
head(id(296),a18(2494)).
head(id(297),a24(2494)).
head(id(298),a26(2494)).
head(id(299),a35(2494)).
head(id(300),a1(2833)).
head(id(301),a2(2833)).
head(id(302),a13(2833)).
head(id(303),b(2833)).
head(id(304),a18(2833)).
head(id(305),a26(2833)).
head(id(306),a32(2833)).
head(id(307),a11(925)).
head(id(308),a13(925)).
head(id(309),n(925)).
head(id(310),a18(925)).
head(id(311),a20(925)).
head(id(312),a26(925)).
head(id(313),a31(925)).
head(id(314),a33(925)).
head(id(315),a34(925)).
head(id(316),a2(1285)).
head(id(317),a10(1285)).
head(id(318),a13(1285)).
head(id(319),n(1285)).
head(id(320),a26(1285)).
head(id(321),a33(1285)).
head(id(322),a34(1285)).
head(id(323),a35(1285)).
head(id(324),a5(1144)).
head(id(325),a6(1144)).
head(id(326),a7(1144)).
head(id(327),n(1144)).
head(id(328),a18(1144)).
head(id(329),a24(1144)).
head(id(330),a33(1144)).
head(id(331),a34(1144)).
head(id(332),a35(1144)).
head(id(333),a7(1305)).
head(id(334),a8(1305)).
head(id(335),a9(1305)).
head(id(336),a10(1305)).
head(id(337),a11(1305)).
head(id(338),a13(1305)).
head(id(339),n(1305)).
head(id(340),a26(1305)).
head(id(341),a33(1305)).
head(id(342),a34(1305)).
head(id(343),a35(1305)).
head(id(344),a5(2855)).
head(id(345),a7(2855)).
head(id(346),a11(2855)).
head(id(347),a13(2855)).
head(id(348),n(2855)).
head(id(349),a20(2855)).
head(id(350),a26(2855)).
head(id(351),a31(2855)).
head(id(352),a33(2855)).
head(id(353),a1(3159)).
head(id(354),a7(3159)).
head(id(355),b(3159)).
head(id(356),a18(3159)).
head(id(357),a23(3159)).
head(id(358),a26(3159)).
head(id(359),a29(3159)).
head(id(360),a32(3159)).
head(id(361),a34(3159)).
head(id(362),a2(2616)).
head(id(363),a6(2616)).
head(id(364),a10(2616)).
head(id(365),a13(2616)).
head(id(366),n(2616)).
head(id(367),a16(2616)).
head(id(368),a18(2616)).
head(id(369),a24(2616)).
head(id(370),a33(2616)).
head(id(371),a34(2616)).
head(id(372),a35(2616)).
head(id(373),a13(3094)).
head(id(374),n(3094)).
head(id(375),a27(3094)).
head(id(376),a30(3094)).
head(id(377),a33(3094)).
head(id(378),a35(3094)).
head(id(379),a36(3094)).
head(id(1584,A),krkp(A)) :- dom(A).
body(id(1584,A),alpha_1(A)) :- dom(A).
body(id(1584,A),a6(A)) :- dom(A).
head(id(3230,A),krkp(A)) :- dom(A).
body(id(3230,A),alpha_2(A)) :- dom(A).
body(id(3230,A),a5(A)) :- dom(A).
head(id(5731,A),krkp(A)) :- dom(A).
body(id(5731,A),alpha_3(A)) :- dom(A).
body(id(5731,A),a2(A)) :- dom(A).
head(id(7421,A),krkp(A)) :- dom(A).
body(id(7421,A),alpha_4(A)) :- dom(A).
body(id(7421,A),a10(A)) :- dom(A).
head(id(8722,A),krkp(A)) :- dom(A).
body(id(8722,A),alpha_5(A)) :- dom(A).
body(id(8722,A),a1(A)) :- dom(A).
head(id(10484,A),krkp(A)) :- dom(A).
body(id(10484,A),alpha_6(A)) :- dom(A).
body(id(10484,A),a13(A)) :- dom(A).
head(id(15017,A),krkp(A)) :- dom(A).
body(id(15017,A),alpha_7(A)) :- dom(A).
body(id(15017,A),a9(A)) :- dom(A).
head(id(16395,A),c_alpha_1(A)) :- dom(A).
body(id(16395,A),a5(A)) :- dom(A).
head(id(17770,A),c_alpha_1(A)) :- dom(A).
body(id(17770,A),a6(A)) :- dom(A).
head(id(20510,A),c_alpha_2(A)) :- dom(A).
body(id(20510,A),a5(A)) :- dom(A).
head(id(22781,A),c_alpha_3(A)) :- dom(A).
body(id(22781,A),a2(A)) :- dom(A).
head(id(24592,A),c_alpha_4(A)) :- dom(A).
body(id(24592,A),a2(A)) :- dom(A).
head(id(25498,A),c_alpha_4(A)) :- dom(A).
body(id(25498,A),a7(A)) :- dom(A).
head(id(26858,A),c_alpha_4(A)) :- dom(A).
body(id(26858,A),a10(A)) :- dom(A).
head(id(29119,A),c_alpha_5(A)) :- dom(A).
body(id(29119,A),a1(A)) :- dom(A).
head(id(31821,A),c_alpha_6(A)) :- dom(A).
body(id(31821,A),alpha_8(A)) :- dom(A).
body(id(31821,A),a11(A)) :- dom(A).
head(id(35049,A),c_alpha_6(A)) :- dom(A).
body(id(35049,A),alpha_9(A)) :- dom(A).
body(id(35049,A),a7(A)) :- dom(A).
head(id(39254,A),c_alpha_6(A)) :- dom(A).
body(id(39254,A),alpha_10(A)) :- dom(A).
body(id(39254,A),n(A)) :- dom(A).
head(id(45855,A),c_alpha_6(A)) :- dom(A).
body(id(45855,A),alpha_11(A)) :- dom(A).
body(id(45855,A),b(A)) :- dom(A).
head(id(52456,A),c_alpha_7(A)) :- dom(A).
body(id(52456,A),alpha_12(A)) :- dom(A).
body(id(52456,A),a8(A)) :- dom(A).
head(id(58659,A),c_alpha_7(A)) :- dom(A).
body(id(58659,A),alpha_13(A)) :- dom(A).
body(id(58659,A),a20(A)) :- dom(A).
head(id(63492,A),c_alpha_7(A)) :- dom(A).
body(id(63492,A),a16(A)) :- dom(A).
head(id(64456,A),c_alpha_8(A)) :- dom(A).
body(id(64456,A),a1(A)) :- dom(A).
head(id(65903,A),c_alpha_8(A)) :- dom(A).
body(id(65903,A),a2(A)) :- dom(A).
head(id(66869,A),c_alpha_8(A)) :- dom(A).
body(id(66869,A),a10(A)) :- dom(A).
head(id(67837,A),c_alpha_8(A)) :- dom(A).
body(id(67837,A),a5(A)) :- dom(A).
head(id(69290,A),c_alpha_9(A)) :- dom(A).
body(id(69290,A),a5(A)) :- dom(A).
head(id(70260,A),c_alpha_9(A)) :- dom(A).
body(id(70260,A),a1(A)) :- dom(A).
head(id(73674,A),c_alpha_10(A)) :- dom(A).
body(id(73674,A),alpha_6(A)) :- dom(A).
body(id(73674,A),a13(A)) :- dom(A).
head(id(77561,A),c_alpha_11(A)) :- dom(A).
body(id(77561,A),a6(A)) :- dom(A).
head(id(80968,A),c_alpha_12(A)) :- dom(A).
body(id(80968,A),alpha_7(A)) :- dom(A).
body(id(80968,A),a9(A)) :- dom(A).
head(id(83394,A),c_alpha_13(A)) :- dom(A).
body(id(83394,A),a7(A)) :- dom(A).
head(id(84364,A),c_alpha_13(A)) :- dom(A).
body(id(84364,A),a6(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
assumption(alpha_4(A)) :- dom(A).
assumption(alpha_5(A)) :- dom(A).
assumption(alpha_6(A)) :- dom(A).
assumption(alpha_7(A)) :- dom(A).
assumption(alpha_8(A)) :- dom(A).
assumption(alpha_9(A)) :- dom(A).
assumption(alpha_10(A)) :- dom(A).
assumption(alpha_11(A)) :- dom(A).
assumption(alpha_12(A)) :- dom(A).
assumption(alpha_13(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).
contrary(alpha_4(A),c_alpha_4(A)) :- assumption(alpha_4(A)).
contrary(alpha_5(A),c_alpha_5(A)) :- assumption(alpha_5(A)).
contrary(alpha_6(A),c_alpha_6(A)) :- assumption(alpha_6(A)).
contrary(alpha_7(A),c_alpha_7(A)) :- assumption(alpha_7(A)).
contrary(alpha_8(A),c_alpha_8(A)) :- assumption(alpha_8(A)).
contrary(alpha_9(A),c_alpha_9(A)) :- assumption(alpha_9(A)).
contrary(alpha_10(A),c_alpha_10(A)) :- assumption(alpha_10(A)).
contrary(alpha_11(A),c_alpha_11(A)) :- assumption(alpha_11(A)).
contrary(alpha_12(A),c_alpha_12(A)) :- assumption(alpha_12(A)).
contrary(alpha_13(A),c_alpha_13(A)) :- assumption(alpha_13(A)).

dom(49).
dom(68).
dom(107).
dom(200).
dom(259).
dom(296).
dom(339).
dom(420).
dom(591).
dom(594).
dom(611).
dom(671).
dom(703).
dom(925).
dom(1045).
dom(1144).
dom(1285).
dom(1305).
dom(1452).
dom(1494).
dom(1702).
dom(2011).
dom(2181).
dom(2221).
dom(2258).
dom(2266).
dom(2308).
dom(2324).
dom(2494).
dom(2576).
dom(2616).
dom(2821).
dom(2833).
dom(2855).
dom(2868).
dom(2912).
dom(3094).
dom(3121).
dom(3154).
dom(3159).
