% training data:
% no. positive ex.: 23
% no. negative ex.: 25
% query: 
train :- aba_asp('./xabal/acute.csv.f2.bk',[acute(11),acute(54),acute(37),acute(84),acute(80),acute(14),acute(89),acute(21),acute(100),acute(71),acute(9),acute(85),acute(22),acute(26),acute(30),acute(57),acute(17),acute(50),acute(99),acute(90),acute(49),acute(44),acute(40)],[acute(66),acute(64),acute(82),acute(78),acute(96),acute(110),acute(95),acute(113),acute(88),acute(53),acute(23),acute(16),acute(3),acute(68),acute(5),acute(87),acute(75),acute(114),acute(1),acute(38),acute(76),acute(8),acute(97),acute(35),acute(103)]).
% test data:
% no. positive ex.: 6
% no. negative ex.: 6
% query: 
test :- test_abaf('./xabal/acute.csv.f2.bk.sol',[acute(11),acute(54),acute(37),acute(84),acute(80),acute(14),acute(89),acute(21),acute(100),acute(71),acute(9),acute(85),acute(22),acute(26),acute(30),acute(57),acute(17),acute(50),acute(99),acute(90),acute(49),acute(44),acute(40)],[acute(66),acute(64),acute(82),acute(78),acute(96),acute(110),acute(95),acute(113),acute(88),acute(53),acute(23),acute(16),acute(3),acute(68),acute(5),acute(87),acute(75),acute(114),acute(1),acute(38),acute(76),acute(8),acute(97),acute(35),acute(103)],[pos(acute(47),[lo(47),a4(47),a5(47)]),pos(acute(7),[a4(7),a5(7),a6(7)]),pos(acute(48),[lo(48),a4(48),a5(48),a6(48)]),pos(acute(59),[lo(59),a4(59),a5(59),a6(59)]),pos(acute(52),[lo(52),a4(52)]),pos(acute(19),[a4(19),a5(19),a6(19)])],[neg(acute(58),[lo(58),a3(58)]),neg(acute(69),[hi(69),a3(69),a4(69),a6(69)]),neg(acute(33),[a3(33)]),neg(acute(74),[hi(74)]),neg(acute(51),[lo(51),a3(51)]),neg(acute(20),[a3(20)])]).
