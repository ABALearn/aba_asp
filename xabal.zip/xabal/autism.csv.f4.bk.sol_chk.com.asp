head(id(1),a1(434)).
head(id(2),a2(434)).
head(id(3),a3(434)).
head(id(4),a4(434)).
head(id(5),a5(434)).
head(id(6),a6(434)).
head(id(7),a8(434)).
head(id(8),a9(434)).
head(id(9),age3(434)).
head(id(10),female(434)).
head(id(11),white(434)).
head(id(12),self(434)).
head(id(13),a1(529)).
head(id(14),a2(529)).
head(id(15),a3(529)).
head(id(16),a4(529)).
head(id(17),a5(529)).
head(id(18),a6(529)).
head(id(19),a7(529)).
head(id(20),a8(529)).
head(id(21),a9(529)).
head(id(22),a10(529)).
head(id(23),age4(529)).
head(id(24),female(529)).
head(id(25),white(529)).
head(id(26),jaundice(529)).
head(id(27),pdd(529)).
head(id(28),self(529)).
head(id(29),a1(124)).
head(id(30),a4(124)).
head(id(31),a5(124)).
head(id(32),a6(124)).
head(id(33),a7(124)).
head(id(34),a8(124)).
head(id(35),a10(124)).
head(id(36),age3(124)).
head(id(37),asian(124)).
head(id(38),jaundice(124)).
head(id(39),self(124)).
head(id(40),a1(509)).
head(id(41),a2(509)).
head(id(42),a3(509)).
head(id(43),a4(509)).
head(id(44),a5(509)).
head(id(45),a6(509)).
head(id(46),a7(509)).
head(id(47),a8(509)).
head(id(48),a9(509)).
head(id(49),a10(509)).
head(id(50),age4(509)).
head(id(51),female(509)).
head(id(52),white(509)).
head(id(53),jaundice(509)).
head(id(54),pdd(509)).
head(id(55),self(509)).
head(id(56),a1(660)).
head(id(57),a2(660)).
head(id(58),a3(660)).
head(id(59),a4(660)).
head(id(60),a5(660)).
head(id(61),a6(660)).
head(id(62),a9(660)).
head(id(63),a10(660)).
head(id(64),age4(660)).
head(id(65),a1(559)).
head(id(66),a2(559)).
head(id(67),a3(559)).
head(id(68),a4(559)).
head(id(69),a5(559)).
head(id(70),a6(559)).
head(id(71),a7(559)).
head(id(72),a8(559)).
head(id(73),a10(559)).
head(id(74),age2(559)).
head(id(75),female(559)).
head(id(76),white(559)).
head(id(77),self(559)).
head(id(78),a1(521)).
head(id(79),a2(521)).
head(id(80),a3(521)).
head(id(81),a4(521)).
head(id(82),a5(521)).
head(id(83),a8(521)).
head(id(84),a9(521)).
head(id(85),a10(521)).
head(id(86),age2(521)).
head(id(87),female(521)).
head(id(88),white(521)).
head(id(89),pdd(521)).
head(id(90),self(521)).
head(id(91),a1(654)).
head(id(92),a2(654)).
head(id(93),a3(654)).
head(id(94),a4(654)).
head(id(95),a5(654)).
head(id(96),a6(654)).
head(id(97),a7(654)).
head(id(98),a8(654)).
head(id(99),a9(654)).
head(id(100),a10(654)).
head(id(101),age3(654)).
head(id(102),female(654)).
head(id(103),white(654)).
head(id(104),pdd(654)).
head(id(105),self(654)).
head(id(106),a1(203)).
head(id(107),a2(203)).
head(id(108),a4(203)).
head(id(109),a5(203)).
head(id(110),a8(203)).
head(id(111),a9(203)).
head(id(112),a10(203)).
head(id(113),age2(203)).
head(id(114),female(203)).
head(id(115),white(203)).
head(id(116),self(203)).
head(id(117),a1(545)).
head(id(118),a3(545)).
head(id(119),a4(545)).
head(id(120),a5(545)).
head(id(121),a6(545)).
head(id(122),a7(545)).
head(id(123),a8(545)).
head(id(124),a9(545)).
head(id(125),a10(545)).
head(id(126),age3(545)).
head(id(127),female(545)).
head(id(128),white(545)).
head(id(129),jaundice(545)).
head(id(130),self(545)).
head(id(131),a1(494)).
head(id(132),a2(494)).
head(id(133),a3(494)).
head(id(134),a4(494)).
head(id(135),a5(494)).
head(id(136),a6(494)).
head(id(137),a7(494)).
head(id(138),a8(494)).
head(id(139),a9(494)).
head(id(140),a10(494)).
head(id(141),age3(494)).
head(id(142),latino(494)).
head(id(143),self(494)).
head(id(144),a1(638)).
head(id(145),a2(638)).
head(id(146),a3(638)).
head(id(147),a4(638)).
head(id(148),a5(638)).
head(id(149),a6(638)).
head(id(150),a7(638)).
head(id(151),a8(638)).
head(id(152),a9(638)).
head(id(153),a10(638)).
head(id(154),age2(638)).
head(id(155),female(638)).
head(id(156),white(638)).
head(id(157),self(638)).
head(id(158),a1(449)).
head(id(159),a2(449)).
head(id(160),a3(449)).
head(id(161),a4(449)).
head(id(162),a5(449)).
head(id(163),a6(449)).
head(id(164),a7(449)).
head(id(165),a9(449)).
head(id(166),a10(449)).
head(id(167),age5(449)).
head(id(168),white(449)).
head(id(169),self(449)).
head(id(170),a8(304)).
head(id(171),a9(304)).
head(id(172),age3(304)).
head(id(173),female(304)).
head(id(174),others(304)).
head(id(175),self(304)).
head(id(176),a8(608)).
head(id(177),age2(608)).
head(id(178),female(608)).
head(id(179),asian(608)).
head(id(180),jaundice(608)).
head(id(181),self(608)).
head(id(182),a1(64)).
head(id(183),a4(64)).
head(id(184),a5(64)).
head(id(185),a8(64)).
head(id(186),a9(64)).
head(id(187),age1(64)).
head(id(188),white(64)).
head(id(189),parent(64)).
head(id(190),a1(294)).
head(id(191),a5(294)).
head(id(192),a7(294)).
head(id(193),a10(294)).
head(id(194),age2(294)).
head(id(195),female(294)).
head(id(196),white(294)).
head(id(197),pdd(294)).
head(id(198),self(294)).
head(id(199),a1(132)).
head(id(200),a8(132)).
head(id(201),a10(132)).
head(id(202),age2(132)).
head(id(203),black(132)).
head(id(204),self(132)).
head(id(205),a1(600)).
head(id(206),a3(600)).
head(id(207),a4(600)).
head(id(208),a8(600)).
head(id(209),a9(600)).
head(id(210),a10(600)).
head(id(211),age3(600)).
head(id(212),female(600)).
head(id(213),asian(600)).
head(id(214),parent(600)).
head(id(215),a1(215)).
head(id(216),a2(215)).
head(id(217),a3(215)).
head(id(218),a4(215)).
head(id(219),a10(215)).
head(id(220),age4(215)).
head(id(221),white(215)).
head(id(222),self(215)).
head(id(223),a3(633)).
head(id(224),a8(633)).
head(id(225),age2(633)).
head(id(226),female(633)).
head(id(227),asian(633)).
head(id(228),parent(633)).
head(id(229),a1(202)).
head(id(230),a2(202)).
head(id(231),a4(202)).
head(id(232),a5(202)).
head(id(233),a9(202)).
head(id(234),a10(202)).
head(id(235),age2(202)).
head(id(236),female(202)).
head(id(237),white(202)).
head(id(238),self(202)).
head(id(239),a1(113)).
head(id(240),a5(113)).
head(id(241),a10(113)).
head(id(242),age3(113)).
head(id(243),asian(113)).
head(id(244),parent(113)).
head(id(245),a3(520)).
head(id(246),a4(520)).
head(id(247),a10(520)).
head(id(248),age3(520)).
head(id(249),middleeastern(520)).
head(id(250),self(520)).
head(id(251),a1(160)).
head(id(252),a7(160)).
head(id(253),a8(160)).
head(id(254),age3(160)).
head(id(255),asian(160)).
head(id(256),self(160)).
head(id(257),age4(295)).
head(id(258),female(295)).
head(id(259),middleeastern(295)).
head(id(260),parent(295)).
head(id(261),a1(133)).
head(id(262),a2(133)).
head(id(263),a8(133)).
head(id(264),age2(133)).
head(id(265),southasian(133)).
head(id(266),self(133)).
head(id(267),a1(88)).
head(id(268),age3(88)).
head(id(269),white(88)).
head(id(270),self(88)).
head(id(271),a1(205)).
head(id(272),a3(205)).
head(id(273),a4(205)).
head(id(274),age3(205)).
head(id(275),white(205)).
head(id(276),pdd(205)).
head(id(277),self(205)).
head(id(278),a1(267)).
head(id(279),a4(267)).
head(id(280),a9(267)).
head(id(281),age2(267)).
head(id(282),asian(267)).
head(id(283),self(267)).
head(id(284),a1(321)).
head(id(285),a2(321)).
head(id(286),age1(321)).
head(id(287),female(321)).
head(id(288),middleeastern(321)).
head(id(289),self(321)).
head(id(290),a4(286)).
head(id(291),a5(286)).
head(id(292),a6(286)).
head(id(293),a7(286)).
head(id(294),a9(286)).
head(id(295),a10(286)).
head(id(296),age3(286)).
head(id(297),female(286)).
head(id(298),a1(157)).
head(id(299),a6(157)).
head(id(300),a8(157)).
head(id(301),a10(157)).
head(id(302),age2(157)).
head(id(303),female(157)).
head(id(304),asian(157)).
head(id(305),self(157)).
head(id(306),a2(44)).
head(id(307),a3(44)).
head(id(308),a4(44)).
head(id(309),a10(44)).
head(id(310),age3(44)).
head(id(311),female(44)).
head(id(312),white(44)).
head(id(313),jaundice(44)).
head(id(314),pdd(44)).
head(id(315),self(44)).
head(id(316),a1(131)).
head(id(317),a2(131)).
head(id(318),a8(131)).
head(id(319),age1(131)).
head(id(320),female(131)).
head(id(321),white(131)).
head(id(322),self(131)).
head(id(323),a1(259)).
head(id(324),a5(259)).
head(id(325),a6(259)).
head(id(326),a8(259)).
head(id(327),a10(259)).
head(id(328),age2(259)).
head(id(329),asian(259)).
head(id(330),self(259)).
head(id(331),a8(470)).
head(id(332),age2(470)).
head(id(333),female(470)).
head(id(334),asian(470)).
head(id(335),jaundice(470)).
head(id(336),self(470)).
head(id(337),a2(489)).
head(id(338),a3(489)).
head(id(339),a7(489)).
head(id(340),a10(489)).
head(id(341),age1(489)).
head(id(342),black(489)).
head(id(343),self(489)).
head(id(344),a1(9)).
head(id(345),a2(9)).
head(id(346),a5(9)).
head(id(347),a8(9)).
head(id(348),a9(9)).
head(id(349),a10(9)).
head(id(350),age2(9)).
head(id(351),white(9)).
head(id(352),self(9)).
head(id(1452,A),autism(A)) :- dom(A).
body(id(1452,A),alpha_1(A)) :- dom(A).
body(id(1452,A),a1(A)) :- dom(A).
head(id(7898,A),c_alpha_1(A)) :- dom(A).
body(id(7898,A),alpha_2(A)) :- dom(A).
body(id(7898,A),a2(A)) :- dom(A).
head(id(9853,A),c_alpha_1(A)) :- dom(A).
body(id(9853,A),alpha_3(A)) :- dom(A).
body(id(9853,A),a4(A)) :- dom(A).
head(id(11893,A),c_alpha_1(A)) :- dom(A).
body(id(11893,A),alpha_4(A)) :- dom(A).
body(id(11893,A),age3(A)) :- dom(A).
head(id(14797,A),c_alpha_1(A)) :- dom(A).
body(id(14797,A),alpha_5(A)) :- dom(A).
body(id(14797,A),a8(A)) :- dom(A).
head(id(20303,A),c_alpha_1(A)) :- dom(A).
body(id(20303,A),alpha_6(A)) :- dom(A).
body(id(20303,A),a5(A)) :- dom(A).
head(id(22486,A),c_alpha_2(A)) :- dom(A).
body(id(22486,A),alpha_1(A)) :- dom(A).
body(id(22486,A),a1(A)) :- dom(A).
head(id(28094,A),c_alpha_3(A)) :- dom(A).
body(id(28094,A),alpha_1(A)) :- dom(A).
body(id(28094,A),a1(A)) :- dom(A).
head(id(34429,A),c_alpha_4(A)) :- dom(A).
body(id(34429,A),alpha_1(A)) :- dom(A).
body(id(34429,A),a1(A)) :- dom(A).
head(id(37346,A),c_alpha_5(A)) :- dom(A).
body(id(37346,A),alpha_1(A)) :- dom(A).
body(id(37346,A),a1(A)) :- dom(A).
head(id(42694,A),c_alpha_6(A)) :- dom(A).
body(id(42694,A),alpha_1(A)) :- dom(A).
body(id(42694,A),a1(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
assumption(alpha_4(A)) :- dom(A).
assumption(alpha_5(A)) :- dom(A).
assumption(alpha_6(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).
contrary(alpha_4(A),c_alpha_4(A)) :- assumption(alpha_4(A)).
contrary(alpha_5(A),c_alpha_5(A)) :- assumption(alpha_5(A)).
contrary(alpha_6(A),c_alpha_6(A)) :- assumption(alpha_6(A)).

dom(9).
dom(44).
dom(64).
dom(88).
dom(113).
dom(124).
dom(131).
dom(132).
dom(133).
dom(157).
dom(160).
dom(202).
dom(203).
dom(205).
dom(215).
dom(259).
dom(267).
dom(286).
dom(294).
dom(295).
dom(304).
dom(321).
dom(434).
dom(449).
dom(470).
dom(489).
dom(494).
dom(509).
dom(520).
dom(521).
dom(529).
dom(545).
dom(559).
dom(600).
dom(608).
dom(633).
dom(638).
dom(654).
dom(660).
 :- not supported(autism(434)).
 :- not supported(autism(529)).
 :- not supported(autism(124)).
 :- not supported(autism(509)).
 :- not supported(autism(660)).
 :- not supported(autism(559)).
 :- not supported(autism(521)).
 :- not supported(autism(654)).
 :- not supported(autism(203)).
 :- not supported(autism(545)).
 :- not supported(autism(494)).
 :- not supported(autism(638)).
 :- not supported(autism(449)).
 :- supported(autism(304)).
 :- supported(autism(608)).
 :- supported(autism(64)).
 :- supported(autism(294)).
 :- supported(autism(132)).
 :- supported(autism(600)).
 :- supported(autism(215)).
 :- supported(autism(633)).
 :- supported(autism(202)).
 :- supported(autism(113)).
 :- supported(autism(520)).
 :- supported(autism(160)).
 :- supported(autism(295)).
 :- supported(autism(133)).
 :- supported(autism(88)).
 :- supported(autism(205)).
 :- supported(autism(267)).
 :- supported(autism(321)).
 :- supported(autism(286)).
 :- supported(autism(157)).
 :- supported(autism(44)).
 :- supported(autism(131)).
 :- supported(autism(259)).
 :- supported(autism(470)).
 :- supported(autism(489)).
 :- supported(autism(9)).
