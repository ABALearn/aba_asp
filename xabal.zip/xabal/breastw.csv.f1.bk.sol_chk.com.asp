head(id(1),clump_thickness__5(54)).
head(id(2),cell_size_uniformity__5(54)).
head(id(3),cell_shape_uniformity__5(54)).
head(id(4),marginal_adhesion__8(54)).
head(id(5),bare_nuclei__8(54)).
head(id(6),bland_chromatin__7(54)).
head(id(7),normal_nucleoli__3(54)).
head(id(8),mitoses__7(54)).
head(id(9),clump_thickness__9(426)).
head(id(10),mitoses__1(426)).
head(id(11),cell_size_uniformity__8(168)).
head(id(12),single_epi_cell_size__6(168)).
head(id(13),bare_nuclei__1(168)).
head(id(14),bland_chromatin__3(168)).
head(id(15),normal_nucleoli__1(168)).
head(id(16),clump_thickness__6(110)).
head(id(17),cell_size_uniformity__5(110)).
head(id(18),cell_shape_uniformity__4(110)).
head(id(19),marginal_adhesion__4(110)).
head(id(20),single_epi_cell_size__3(110)).
head(id(21),bare_nuclei__9(110)).
head(id(22),bland_chromatin__7(110)).
head(id(23),normal_nucleoli__8(110)).
head(id(24),mitoses__3(110)).
head(id(25),clump_thickness__7(152)).
head(id(26),cell_size_uniformity__2(152)).
head(id(27),cell_shape_uniformity__4(152)).
head(id(28),marginal_adhesion__1(152)).
head(id(29),single_epi_cell_size__6(152)).
head(id(30),bland_chromatin__5(152)).
head(id(31),normal_nucleoli__4(152)).
head(id(32),mitoses__3(152)).
head(id(33),cell_size_uniformity__8(202)).
head(id(34),cell_shape_uniformity__8(202)).
head(id(35),marginal_adhesion__4(202)).
head(id(36),bland_chromatin__8(202)).
head(id(37),normal_nucleoli__1(202)).
head(id(38),mitoses__1(202)).
head(id(39),clump_thickness__8(335)).
head(id(40),cell_size_uniformity__6(335)).
head(id(41),cell_shape_uniformity__7(335)).
head(id(42),marginal_adhesion__3(335)).
head(id(43),single_epi_cell_size__3(335)).
head(id(44),bland_chromatin__3(335)).
head(id(45),normal_nucleoli__4(335)).
head(id(46),mitoses__2(335)).
head(id(47),clump_thickness__7(265)).
head(id(48),cell_size_uniformity__9(265)).
head(id(49),cell_shape_uniformity__4(265)).
head(id(50),bare_nuclei__3(265)).
head(id(51),bland_chromatin__5(265)).
head(id(52),normal_nucleoli__3(265)).
head(id(53),mitoses__3(265)).
head(id(54),clump_thickness__7(321)).
head(id(55),cell_size_uniformity__6(321)).
head(id(56),cell_shape_uniformity__3(321)).
head(id(57),marginal_adhesion__2(321)).
head(id(58),single_epi_cell_size__5(321)).
head(id(59),bland_chromatin__7(321)).
head(id(60),normal_nucleoli__4(321)).
head(id(61),mitoses__6(321)).
head(id(62),cell_size_uniformity__6(467)).
head(id(63),cell_shape_uniformity__6(467)).
head(id(64),marginal_adhesion__2(467)).
head(id(65),single_epi_cell_size__4(467)).
head(id(66),bland_chromatin__9(467)).
head(id(67),normal_nucleoli__7(467)).
head(id(68),mitoses__1(467)).
head(id(69),clump_thickness__8(150)).
head(id(70),cell_size_uniformity__8(150)).
head(id(71),cell_shape_uniformity__7(150)).
head(id(72),marginal_adhesion__4(150)).
head(id(73),bland_chromatin__7(150)).
head(id(74),normal_nucleoli__8(150)).
head(id(75),mitoses__7(150)).
head(id(76),cell_size_uniformity__6(382)).
head(id(77),cell_shape_uniformity__3(382)).
head(id(78),marginal_adhesion__6(382)).
head(id(79),single_epi_cell_size__4(382)).
head(id(80),bland_chromatin__7(382)).
head(id(81),normal_nucleoli__8(382)).
head(id(82),mitoses__4(382)).
head(id(83),cell_size_uniformity__5(280)).
head(id(84),cell_shape_uniformity__7(280)).
head(id(85),marginal_adhesion__3(280)).
head(id(86),single_epi_cell_size__3(280)).
head(id(87),bare_nuclei__7(280)).
head(id(88),bland_chromatin__3(280)).
head(id(89),normal_nucleoli__3(280)).
head(id(90),mitoses__8(280)).
head(id(91),clump_thickness__5(290)).
head(id(92),cell_size_uniformity__6(290)).
head(id(93),cell_shape_uniformity__6(290)).
head(id(94),marginal_adhesion__8(290)).
head(id(95),single_epi_cell_size__6(290)).
head(id(96),bland_chromatin__4(290)).
head(id(97),mitoses__4(290)).
head(id(98),clump_thickness__5(670)).
head(id(99),marginal_adhesion__8(670)).
head(id(100),single_epi_cell_size__5(670)).
head(id(101),bare_nuclei__5(670)).
head(id(102),bland_chromatin__7(670)).
head(id(103),mitoses__1(670)).
head(id(104),clump_thickness__5(189)).
head(id(105),cell_size_uniformity__8(189)).
head(id(106),cell_shape_uniformity__4(189)).
head(id(107),single_epi_cell_size__5(189)).
head(id(108),bare_nuclei__8(189)).
head(id(109),bland_chromatin__9(189)).
head(id(110),mitoses__1(189)).
head(id(111),clump_thickness__3(476)).
head(id(112),cell_size_uniformity__1(476)).
head(id(113),cell_shape_uniformity__1(476)).
head(id(114),marginal_adhesion__1(476)).
head(id(115),single_epi_cell_size__2(476)).
head(id(116),bare_nuclei__1(476)).
head(id(117),bland_chromatin__1(476)).
head(id(118),normal_nucleoli__1(476)).
head(id(119),mitoses__1(476)).
head(id(120),clump_thickness__5(561)).
head(id(121),cell_size_uniformity__1(561)).
head(id(122),cell_shape_uniformity__1(561)).
head(id(123),marginal_adhesion__1(561)).
head(id(124),single_epi_cell_size__2(561)).
head(id(125),bare_nuclei__1(561)).
head(id(126),bland_chromatin__3(561)).
head(id(127),normal_nucleoli__1(561)).
head(id(128),mitoses__1(561)).
head(id(129),clump_thickness__2(409)).
head(id(130),cell_size_uniformity__3(409)).
head(id(131),cell_shape_uniformity__2(409)).
head(id(132),marginal_adhesion__2(409)).
head(id(133),single_epi_cell_size__2(409)).
head(id(134),bare_nuclei__2(409)).
head(id(135),bland_chromatin__3(409)).
head(id(136),normal_nucleoli__1(409)).
head(id(137),mitoses__1(409)).
head(id(138),clump_thickness__4(423)).
head(id(139),cell_size_uniformity__3(423)).
head(id(140),cell_shape_uniformity__3(423)).
head(id(141),marginal_adhesion__1(423)).
head(id(142),single_epi_cell_size__2(423)).
head(id(143),bare_nuclei__1(423)).
head(id(144),bland_chromatin__3(423)).
head(id(145),normal_nucleoli__3(423)).
head(id(146),mitoses__1(423)).
head(id(147),clump_thickness__5(333)).
head(id(148),cell_size_uniformity__2(333)).
head(id(149),cell_shape_uniformity__2(333)).
head(id(150),marginal_adhesion__2(333)).
head(id(151),single_epi_cell_size__2(333)).
head(id(152),bare_nuclei__1(333)).
head(id(153),bland_chromatin__2(333)).
head(id(154),normal_nucleoli__2(333)).
head(id(155),mitoses__1(333)).
head(id(156),clump_thickness__4(249)).
head(id(157),cell_size_uniformity__1(249)).
head(id(158),cell_shape_uniformity__1(249)).
head(id(159),marginal_adhesion__1(249)).
head(id(160),single_epi_cell_size__2(249)).
head(id(161),bare_nuclei__1(249)).
head(id(162),bland_chromatin__3(249)).
head(id(163),normal_nucleoli__6(249)).
head(id(164),mitoses__1(249)).
head(id(165),clump_thickness__1(486)).
head(id(166),cell_size_uniformity__1(486)).
head(id(167),cell_shape_uniformity__1(486)).
head(id(168),marginal_adhesion__3(486)).
head(id(169),single_epi_cell_size__1(486)).
head(id(170),bare_nuclei__3(486)).
head(id(171),bland_chromatin__1(486)).
head(id(172),normal_nucleoli__1(486)).
head(id(173),mitoses__1(486)).
head(id(174),clump_thickness__5(83)).
head(id(175),cell_size_uniformity__2(83)).
head(id(176),cell_shape_uniformity__1(83)).
head(id(177),marginal_adhesion__1(83)).
head(id(178),single_epi_cell_size__2(83)).
head(id(179),bare_nuclei__1(83)).
head(id(180),bland_chromatin__3(83)).
head(id(181),normal_nucleoli__1(83)).
head(id(182),mitoses__1(83)).
head(id(183),clump_thickness__3(396)).
head(id(184),cell_size_uniformity__1(396)).
head(id(185),cell_shape_uniformity__1(396)).
head(id(186),marginal_adhesion__1(396)).
head(id(187),single_epi_cell_size__2(396)).
head(id(188),bare_nuclei__1(396)).
head(id(189),bland_chromatin__2(396)).
head(id(190),normal_nucleoli__1(396)).
head(id(191),mitoses__1(396)).
head(id(192),clump_thickness__2(80)).
head(id(193),cell_size_uniformity__1(80)).
head(id(194),cell_shape_uniformity__1(80)).
head(id(195),marginal_adhesion__1(80)).
head(id(196),single_epi_cell_size__3(80)).
head(id(197),bare_nuclei__1(80)).
head(id(198),bland_chromatin__2(80)).
head(id(199),normal_nucleoli__1(80)).
head(id(200),mitoses__1(80)).
head(id(201),clump_thickness__1(190)).
head(id(202),cell_size_uniformity__2(190)).
head(id(203),cell_shape_uniformity__3(190)).
head(id(204),marginal_adhesion__1(190)).
head(id(205),single_epi_cell_size__2(190)).
head(id(206),bare_nuclei__1(190)).
head(id(207),bland_chromatin__3(190)).
head(id(208),normal_nucleoli__1(190)).
head(id(209),mitoses__1(190)).
head(id(210),clump_thickness__4(532)).
head(id(211),cell_size_uniformity__2(532)).
head(id(212),cell_shape_uniformity__2(532)).
head(id(213),marginal_adhesion__1(532)).
head(id(214),single_epi_cell_size__2(532)).
head(id(215),bare_nuclei__1(532)).
head(id(216),bland_chromatin__2(532)).
head(id(217),normal_nucleoli__1(532)).
head(id(218),mitoses__1(532)).
head(id(219),clump_thickness__1(431)).
head(id(220),cell_size_uniformity__3(431)).
head(id(221),cell_shape_uniformity__1(431)).
head(id(222),marginal_adhesion__1(431)).
head(id(223),single_epi_cell_size__2(431)).
head(id(224),bare_nuclei__1(431)).
head(id(225),bland_chromatin__2(431)).
head(id(226),normal_nucleoli__2(431)).
head(id(227),mitoses__1(431)).
head(id(228),clump_thickness__5(596)).
head(id(229),cell_size_uniformity__1(596)).
head(id(230),cell_shape_uniformity__1(596)).
head(id(231),marginal_adhesion__1(596)).
head(id(232),single_epi_cell_size__2(596)).
head(id(233),bare_nuclei__1(596)).
head(id(234),bland_chromatin__2(596)).
head(id(235),normal_nucleoli__1(596)).
head(id(236),mitoses__1(596)).
head(id(237),clump_thickness__5(414)).
head(id(238),cell_size_uniformity__1(414)).
head(id(239),cell_shape_uniformity__2(414)).
head(id(240),marginal_adhesion__1(414)).
head(id(241),single_epi_cell_size__2(414)).
head(id(242),bare_nuclei__1(414)).
head(id(243),bland_chromatin__3(414)).
head(id(244),normal_nucleoli__1(414)).
head(id(245),mitoses__1(414)).
head(id(246),clump_thickness__1(552)).
head(id(247),cell_size_uniformity__1(552)).
head(id(248),cell_shape_uniformity__1(552)).
head(id(249),marginal_adhesion__1(552)).
head(id(250),single_epi_cell_size__2(552)).
head(id(251),bare_nuclei__1(552)).
head(id(252),bland_chromatin__3(552)).
head(id(253),normal_nucleoli__1(552)).
head(id(254),mitoses__1(552)).
head(id(255),clump_thickness__3(23)).
head(id(256),cell_size_uniformity__1(23)).
head(id(257),cell_shape_uniformity__1(23)).
head(id(258),marginal_adhesion__1(23)).
head(id(259),single_epi_cell_size__2(23)).
head(id(260),bare_nuclei__1(23)).
head(id(261),bland_chromatin__2(23)).
head(id(262),normal_nucleoli__1(23)).
head(id(263),mitoses__1(23)).
head(id(264),clump_thickness__2(95)).
head(id(265),cell_size_uniformity__1(95)).
head(id(266),cell_shape_uniformity__1(95)).
head(id(267),marginal_adhesion__1(95)).
head(id(268),single_epi_cell_size__2(95)).
head(id(269),bare_nuclei__1(95)).
head(id(270),bland_chromatin__3(95)).
head(id(271),normal_nucleoli__1(95)).
head(id(272),mitoses__1(95)).
head(id(273),clump_thickness__6(38)).
head(id(274),cell_size_uniformity__2(38)).
head(id(275),cell_shape_uniformity__1(38)).
head(id(276),marginal_adhesion__1(38)).
head(id(277),single_epi_cell_size__1(38)).
head(id(278),bare_nuclei__1(38)).
head(id(279),bland_chromatin__7(38)).
head(id(280),normal_nucleoli__1(38)).
head(id(281),mitoses__1(38)).
head(id(282),clump_thickness__1(65)).
head(id(283),cell_size_uniformity__1(65)).
head(id(284),cell_shape_uniformity__1(65)).
head(id(285),marginal_adhesion__1(65)).
head(id(286),single_epi_cell_size__2(65)).
head(id(287),bare_nuclei__1(65)).
head(id(288),bland_chromatin__2(65)).
head(id(289),normal_nucleoli__1(65)).
head(id(290),mitoses__1(65)).
head(id(291),clump_thickness__4(67)).
head(id(292),cell_size_uniformity__1(67)).
head(id(293),cell_shape_uniformity__1(67)).
head(id(294),marginal_adhesion__1(67)).
head(id(295),single_epi_cell_size__2(67)).
head(id(296),bare_nuclei__1(67)).
head(id(297),bland_chromatin__3(67)).
head(id(298),normal_nucleoli__1(67)).
head(id(299),mitoses__1(67)).
head(id(300),clump_thickness__5(475)).
head(id(301),cell_size_uniformity__1(475)).
head(id(302),cell_shape_uniformity__1(475)).
head(id(303),marginal_adhesion__1(475)).
head(id(304),single_epi_cell_size__2(475)).
head(id(305),bare_nuclei__1(475)).
head(id(306),bland_chromatin__1(475)).
head(id(307),normal_nucleoli__1(475)).
head(id(308),mitoses__1(475)).
head(id(309),clump_thickness__1(96)).
head(id(310),cell_size_uniformity__1(96)).
head(id(311),cell_shape_uniformity__1(96)).
head(id(312),marginal_adhesion__1(96)).
head(id(313),single_epi_cell_size__2(96)).
head(id(314),bare_nuclei__1(96)).
head(id(315),bland_chromatin__3(96)).
head(id(316),normal_nucleoli__1(96)).
head(id(317),mitoses__1(96)).
head(id(318),clump_thickness__4(18)).
head(id(319),cell_size_uniformity__1(18)).
head(id(320),cell_shape_uniformity__1(18)).
head(id(321),marginal_adhesion__1(18)).
head(id(322),single_epi_cell_size__2(18)).
head(id(323),bare_nuclei__1(18)).
head(id(324),bland_chromatin__3(18)).
head(id(325),normal_nucleoli__1(18)).
head(id(326),mitoses__1(18)).
head(id(327),clump_thickness__1(687)).
head(id(328),cell_size_uniformity__1(687)).
head(id(329),cell_shape_uniformity__1(687)).
head(id(330),marginal_adhesion__1(687)).
head(id(331),single_epi_cell_size__2(687)).
head(id(332),bare_nuclei__1(687)).
head(id(333),bland_chromatin__1(687)).
head(id(334),normal_nucleoli__1(687)).
head(id(335),mitoses__1(687)).
head(id(1393,A),malignant(A)) :- dom(A).
body(id(1393,A),alpha_1(A)) :- dom(A).
body(id(1393,A),clump_thickness__5(A)) :- dom(A).
head(id(2118,A),malignant(A)) :- dom(A).
body(id(2118,A),clump_thickness__9(A)) :- dom(A).
head(id(2842,A),malignant(A)) :- dom(A).
body(id(2842,A),cell_size_uniformity__8(A)) :- dom(A).
head(id(3933,A),malignant(A)) :- dom(A).
body(id(3933,A),alpha_2(A)) :- dom(A).
body(id(3933,A),clump_thickness__6(A)) :- dom(A).
head(id(4672,A),malignant(A)) :- dom(A).
body(id(4672,A),clump_thickness__7(A)) :- dom(A).
head(id(5777,A),malignant(A)) :- dom(A).
body(id(5777,A),clump_thickness__8(A)) :- dom(A).
head(id(7248,A),malignant(A)) :- dom(A).
body(id(7248,A),cell_size_uniformity__6(A)) :- dom(A).
head(id(8715,A),malignant(A)) :- dom(A).
body(id(8715,A),cell_size_uniformity__5(A)) :- dom(A).
head(id(11274,A),c_alpha_1(A)) :- dom(A).
body(id(11274,A),cell_size_uniformity__2(A)) :- dom(A).
head(id(13100,A),c_alpha_1(A)) :- dom(A).
body(id(13100,A),cell_size_uniformity__1(A)) :- dom(A).
head(id(14916,A),c_alpha_2(A)) :- dom(A).
body(id(14916,A),clump_thickness__6(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).

dom(18).
dom(23).
dom(38).
dom(54).
dom(65).
dom(67).
dom(80).
dom(83).
dom(95).
dom(96).
dom(110).
dom(150).
dom(152).
dom(168).
dom(189).
dom(190).
dom(202).
dom(249).
dom(265).
dom(280).
dom(290).
dom(321).
dom(333).
dom(335).
dom(382).
dom(396).
dom(409).
dom(414).
dom(423).
dom(426).
dom(431).
dom(467).
dom(475).
dom(476).
dom(486).
dom(532).
dom(552).
dom(561).
dom(596).
dom(670).
dom(687).
 :- not supported(malignant(54)).
 :- not supported(malignant(426)).
 :- not supported(malignant(168)).
 :- not supported(malignant(110)).
 :- not supported(malignant(152)).
 :- not supported(malignant(202)).
 :- not supported(malignant(335)).
 :- not supported(malignant(265)).
 :- not supported(malignant(321)).
 :- not supported(malignant(467)).
 :- not supported(malignant(150)).
 :- not supported(malignant(382)).
 :- not supported(malignant(280)).
 :- not supported(malignant(290)).
 :- not supported(malignant(670)).
 :- not supported(malignant(189)).
 :- supported(malignant(476)).
 :- supported(malignant(561)).
 :- supported(malignant(409)).
 :- supported(malignant(423)).
 :- supported(malignant(333)).
 :- supported(malignant(249)).
 :- supported(malignant(486)).
 :- supported(malignant(83)).
 :- supported(malignant(396)).
 :- supported(malignant(80)).
 :- supported(malignant(190)).
 :- supported(malignant(532)).
 :- supported(malignant(431)).
 :- supported(malignant(596)).
 :- supported(malignant(414)).
 :- supported(malignant(552)).
 :- supported(malignant(23)).
 :- supported(malignant(95)).
 :- supported(malignant(38)).
 :- supported(malignant(65)).
 :- supported(malignant(67)).
 :- supported(malignant(475)).
 :- supported(malignant(96)).
 :- supported(malignant(18)).
 :- supported(malignant(687)).
