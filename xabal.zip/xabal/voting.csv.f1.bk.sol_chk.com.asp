head(id(1),water_project_cost_sharing(62)).
head(id(2),physician_fee_freeze(62)).
head(id(3),el_salvador_aid(62)).
head(id(4),religious_groups_in_schools(62)).
head(id(5),education_spending(62)).
head(id(6),superfund_right_to_sue(62)).
head(id(7),crime(62)).
head(id(8),water_project_cost_sharing(59)).
head(id(9),physician_fee_freeze(59)).
head(id(10),el_salvador_aid(59)).
head(id(11),religious_groups_in_schools(59)).
head(id(12),immigration(59)).
head(id(13),education_spending(59)).
head(id(14),superfund_right_to_sue(59)).
head(id(15),crime(59)).
head(id(16),export_administration_act_south_africa(59)).
head(id(17),water_project_cost_sharing(34)).
head(id(18),physician_fee_freeze(34)).
head(id(19),el_salvador_aid(34)).
head(id(20),religious_groups_in_schools(34)).
head(id(21),education_spending(34)).
head(id(22),superfund_right_to_sue(34)).
head(id(23),crime(34)).
head(id(24),export_administration_act_south_africa(34)).
head(id(25),water_project_cost_sharing(164)).
head(id(26),physician_fee_freeze(164)).
head(id(27),el_salvador_aid(164)).
head(id(28),religious_groups_in_schools(164)).
head(id(29),anti_satellite_test_ban(164)).
head(id(30),education_spending(164)).
head(id(31),superfund_right_to_sue(164)).
head(id(32),crime(164)).
head(id(33),export_administration_act_south_africa(164)).
head(id(34),physician_fee_freeze(84)).
head(id(35),el_salvador_aid(84)).
head(id(36),religious_groups_in_schools(84)).
head(id(37),education_spending(84)).
head(id(38),superfund_right_to_sue(84)).
head(id(39),crime(84)).
head(id(40),physician_fee_freeze(83)).
head(id(41),el_salvador_aid(83)).
head(id(42),religious_groups_in_schools(83)).
head(id(43),immigration(83)).
head(id(44),education_spending(83)).
head(id(45),superfund_right_to_sue(83)).
head(id(46),crime(83)).
head(id(47),export_administration_act_south_africa(83)).
head(id(48),handicapped_infants(74)).
head(id(49),budget_resolution(74)).
head(id(50),physician_fee_freeze(74)).
head(id(51),el_salvador_aid(74)).
head(id(52),anti_satellite_test_ban(74)).
head(id(53),mx_missile(74)).
head(id(54),immigration(74)).
head(id(55),superfund_right_to_sue(74)).
head(id(56),crime(74)).
head(id(57),export_administration_act_south_africa(74)).
head(id(58),physician_fee_freeze(88)).
head(id(59),el_salvador_aid(88)).
head(id(60),religious_groups_in_schools(88)).
head(id(61),education_spending(88)).
head(id(62),superfund_right_to_sue(88)).
head(id(63),crime(88)).
head(id(64),physician_fee_freeze(341)).
head(id(65),el_salvador_aid(341)).
head(id(66),religious_groups_in_schools(341)).
head(id(67),immigration(341)).
head(id(68),synfuels_corporation_cutback(341)).
head(id(69),education_spending(341)).
head(id(70),crime(341)).
head(id(71),export_administration_act_south_africa(341)).
head(id(72),physician_fee_freeze(303)).
head(id(73),el_salvador_aid(303)).
head(id(74),religious_groups_in_schools(303)).
head(id(75),anti_satellite_test_ban(303)).
head(id(76),immigration(303)).
head(id(77),education_spending(303)).
head(id(78),superfund_right_to_sue(303)).
head(id(79),crime(303)).
head(id(80),export_administration_act_south_africa(303)).
head(id(81),water_project_cost_sharing(147)).
head(id(82),physician_fee_freeze(147)).
head(id(83),el_salvador_aid(147)).
head(id(84),religious_groups_in_schools(147)).
head(id(85),education_spending(147)).
head(id(86),superfund_right_to_sue(147)).
head(id(87),crime(147)).
head(id(88),export_administration_act_south_africa(147)).
head(id(89),handicapped_infants(365)).
head(id(90),water_project_cost_sharing(365)).
head(id(91),physician_fee_freeze(365)).
head(id(92),el_salvador_aid(365)).
head(id(93),religious_groups_in_schools(365)).
head(id(94),synfuels_corporation_cutback(365)).
head(id(95),superfund_right_to_sue(365)).
head(id(96),crime(365)).
head(id(97),export_administration_act_south_africa(365)).
head(id(98),handicapped_infants(38)).
head(id(99),water_project_cost_sharing(38)).
head(id(100),physician_fee_freeze(38)).
head(id(101),el_salvador_aid(38)).
head(id(102),religious_groups_in_schools(38)).
head(id(103),superfund_right_to_sue(38)).
head(id(104),crime(38)).
head(id(105),export_administration_act_south_africa(38)).
head(id(106),water_project_cost_sharing(57)).
head(id(107),physician_fee_freeze(57)).
head(id(108),el_salvador_aid(57)).
head(id(109),religious_groups_in_schools(57)).
head(id(110),immigration(57)).
head(id(111),synfuels_corporation_cutback(57)).
head(id(112),education_spending(57)).
head(id(113),superfund_right_to_sue(57)).
head(id(114),crime(57)).
head(id(115),export_administration_act_south_africa(57)).
head(id(116),handicapped_infants(118)).
head(id(117),water_project_cost_sharing(118)).
head(id(118),budget_resolution(118)).
head(id(119),physician_fee_freeze(118)).
head(id(120),el_salvador_aid(118)).
head(id(121),anti_satellite_test_ban(118)).
head(id(122),education_spending(118)).
head(id(123),superfund_right_to_sue(118)).
head(id(124),crime(118)).
head(id(125),export_administration_act_south_africa(118)).
head(id(126),handicapped_infants(29)).
head(id(127),physician_fee_freeze(29)).
head(id(128),el_salvador_aid(29)).
head(id(129),anti_satellite_test_ban(29)).
head(id(130),aid_to_nicaraguan_contras(29)).
head(id(131),mx_missile(29)).
head(id(132),education_spending(29)).
head(id(133),superfund_right_to_sue(29)).
head(id(134),crime(29)).
head(id(135),export_administration_act_south_africa(29)).
head(id(136),water_project_cost_sharing(231)).
head(id(137),physician_fee_freeze(231)).
head(id(138),el_salvador_aid(231)).
head(id(139),religious_groups_in_schools(231)).
head(id(140),education_spending(231)).
head(id(141),superfund_right_to_sue(231)).
head(id(142),crime(231)).
head(id(143),export_administration_act_south_africa(231)).
head(id(144),physician_fee_freeze(306)).
head(id(145),el_salvador_aid(306)).
head(id(146),religious_groups_in_schools(306)).
head(id(147),immigration(306)).
head(id(148),education_spending(306)).
head(id(149),superfund_right_to_sue(306)).
head(id(150),crime(306)).
head(id(151),handicapped_infants(393)).
head(id(152),water_project_cost_sharing(393)).
head(id(153),physician_fee_freeze(393)).
head(id(154),el_salvador_aid(393)).
head(id(155),religious_groups_in_schools(393)).
head(id(156),synfuels_corporation_cutback(393)).
head(id(157),education_spending(393)).
head(id(158),superfund_right_to_sue(393)).
head(id(159),crime(393)).
head(id(160),export_administration_act_south_africa(393)).
head(id(161),handicapped_infants(348)).
head(id(162),physician_fee_freeze(348)).
head(id(163),el_salvador_aid(348)).
head(id(164),religious_groups_in_schools(348)).
head(id(165),immigration(348)).
head(id(166),education_spending(348)).
head(id(167),superfund_right_to_sue(348)).
head(id(168),crime(348)).
head(id(169),handicapped_infants(151)).
head(id(170),water_project_cost_sharing(151)).
head(id(171),physician_fee_freeze(151)).
head(id(172),el_salvador_aid(151)).
head(id(173),religious_groups_in_schools(151)).
head(id(174),immigration(151)).
head(id(175),education_spending(151)).
head(id(176),superfund_right_to_sue(151)).
head(id(177),crime(151)).
head(id(178),export_administration_act_south_africa(151)).
head(id(179),physician_fee_freeze(267)).
head(id(180),el_salvador_aid(267)).
head(id(181),religious_groups_in_schools(267)).
head(id(182),immigration(267)).
head(id(183),education_spending(267)).
head(id(184),crime(267)).
head(id(185),export_administration_act_south_africa(267)).
head(id(186),physician_fee_freeze(347)).
head(id(187),el_salvador_aid(347)).
head(id(188),religious_groups_in_schools(347)).
head(id(189),immigration(347)).
head(id(190),education_spending(347)).
head(id(191),superfund_right_to_sue(347)).
head(id(192),crime(347)).
head(id(193),export_administration_act_south_africa(347)).
head(id(194),physician_fee_freeze(134)).
head(id(195),el_salvador_aid(134)).
head(id(196),religious_groups_in_schools(134)).
head(id(197),immigration(134)).
head(id(198),education_spending(134)).
head(id(199),superfund_right_to_sue(134)).
head(id(200),crime(134)).
head(id(201),export_administration_act_south_africa(134)).
head(id(202),religious_groups_in_schools(317)).
head(id(203),aid_to_nicaraguan_contras(317)).
head(id(204),mx_missile(317)).
head(id(205),synfuels_corporation_cutback(317)).
head(id(206),education_spending(317)).
head(id(207),superfund_right_to_sue(317)).
head(id(208),crime(317)).
head(id(209),duty_free_exports(317)).
head(id(210),handicapped_infants(203)).
head(id(211),budget_resolution(203)).
head(id(212),religious_groups_in_schools(203)).
head(id(213),anti_satellite_test_ban(203)).
head(id(214),aid_to_nicaraguan_contras(203)).
head(id(215),mx_missile(203)).
head(id(216),immigration(203)).
head(id(217),synfuels_corporation_cutback(203)).
head(id(218),duty_free_exports(203)).
head(id(219),export_administration_act_south_africa(203)).
head(id(220),handicapped_infants(386)).
head(id(221),water_project_cost_sharing(386)).
head(id(222),el_salvador_aid(386)).
head(id(223),religious_groups_in_schools(386)).
head(id(224),synfuels_corporation_cutback(386)).
head(id(225),education_spending(386)).
head(id(226),superfund_right_to_sue(386)).
head(id(227),crime(386)).
head(id(228),duty_free_exports(386)).
head(id(229),handicapped_infants(261)).
head(id(230),budget_resolution(261)).
head(id(231),anti_satellite_test_ban(261)).
head(id(232),aid_to_nicaraguan_contras(261)).
head(id(233),mx_missile(261)).
head(id(234),immigration(261)).
head(id(235),export_administration_act_south_africa(261)).
head(id(236),handicapped_infants(140)).
head(id(237),budget_resolution(140)).
head(id(238),religious_groups_in_schools(140)).
head(id(239),anti_satellite_test_ban(140)).
head(id(240),aid_to_nicaraguan_contras(140)).
head(id(241),mx_missile(140)).
head(id(242),duty_free_exports(140)).
head(id(243),export_administration_act_south_africa(140)).
head(id(244),handicapped_infants(412)).
head(id(245),budget_resolution(412)).
head(id(246),religious_groups_in_schools(412)).
head(id(247),anti_satellite_test_ban(412)).
head(id(248),aid_to_nicaraguan_contras(412)).
head(id(249),mx_missile(412)).
head(id(250),immigration(412)).
head(id(251),synfuels_corporation_cutback(412)).
head(id(252),export_administration_act_south_africa(412)).
head(id(253),water_project_cost_sharing(176)).
head(id(254),budget_resolution(176)).
head(id(255),anti_satellite_test_ban(176)).
head(id(256),aid_to_nicaraguan_contras(176)).
head(id(257),mx_missile(176)).
head(id(258),immigration(176)).
head(id(259),duty_free_exports(176)).
head(id(260),export_administration_act_south_africa(176)).
head(id(261),water_project_cost_sharing(220)).
head(id(262),budget_resolution(220)).
head(id(263),aid_to_nicaraguan_contras(220)).
head(id(264),mx_missile(220)).
head(id(265),synfuels_corporation_cutback(220)).
head(id(266),crime(220)).
head(id(267),duty_free_exports(220)).
head(id(268),export_administration_act_south_africa(220)).
head(id(269),handicapped_infants(384)).
head(id(270),water_project_cost_sharing(384)).
head(id(271),budget_resolution(384)).
head(id(272),el_salvador_aid(384)).
head(id(273),religious_groups_in_schools(384)).
head(id(274),aid_to_nicaraguan_contras(384)).
head(id(275),mx_missile(384)).
head(id(276),immigration(384)).
head(id(277),synfuels_corporation_cutback(384)).
head(id(278),export_administration_act_south_africa(384)).
head(id(279),handicapped_infants(40)).
head(id(280),budget_resolution(40)).
head(id(281),anti_satellite_test_ban(40)).
head(id(282),aid_to_nicaraguan_contras(40)).
head(id(283),mx_missile(40)).
head(id(284),immigration(40)).
head(id(285),synfuels_corporation_cutback(40)).
head(id(286),superfund_right_to_sue(40)).
head(id(287),duty_free_exports(40)).
head(id(288),export_administration_act_south_africa(40)).
head(id(289),budget_resolution(227)).
head(id(290),religious_groups_in_schools(227)).
head(id(291),anti_satellite_test_ban(227)).
head(id(292),aid_to_nicaraguan_contras(227)).
head(id(293),mx_missile(227)).
head(id(294),synfuels_corporation_cutback(227)).
head(id(295),crime(227)).
head(id(296),duty_free_exports(227)).
head(id(297),export_administration_act_south_africa(227)).
head(id(298),water_project_cost_sharing(369)).
head(id(299),budget_resolution(369)).
head(id(300),religious_groups_in_schools(369)).
head(id(301),anti_satellite_test_ban(369)).
head(id(302),aid_to_nicaraguan_contras(369)).
head(id(303),immigration(369)).
head(id(304),duty_free_exports(369)).
head(id(305),export_administration_act_south_africa(369)).
head(id(306),water_project_cost_sharing(78)).
head(id(307),budget_resolution(78)).
head(id(308),physician_fee_freeze(78)).
head(id(309),el_salvador_aid(78)).
head(id(310),religious_groups_in_schools(78)).
head(id(311),aid_to_nicaraguan_contras(78)).
head(id(312),mx_missile(78)).
head(id(313),immigration(78)).
head(id(314),synfuels_corporation_cutback(78)).
head(id(315),education_spending(78)).
head(id(316),superfund_right_to_sue(78)).
head(id(317),crime(78)).
head(id(318),export_administration_act_south_africa(78)).
head(id(319),handicapped_infants(190)).
head(id(320),budget_resolution(190)).
head(id(321),anti_satellite_test_ban(190)).
head(id(322),aid_to_nicaraguan_contras(190)).
head(id(323),mx_missile(190)).
head(id(324),duty_free_exports(190)).
head(id(325),export_administration_act_south_africa(190)).
head(id(326),handicapped_infants(242)).
head(id(327),budget_resolution(242)).
head(id(328),anti_satellite_test_ban(242)).
head(id(329),aid_to_nicaraguan_contras(242)).
head(id(330),mx_missile(242)).
head(id(331),immigration(242)).
head(id(332),synfuels_corporation_cutback(242)).
head(id(333),crime(242)).
head(id(334),duty_free_exports(242)).
head(id(335),export_administration_act_south_africa(242)).
head(id(336),handicapped_infants(170)).
head(id(337),budget_resolution(170)).
head(id(338),anti_satellite_test_ban(170)).
head(id(339),aid_to_nicaraguan_contras(170)).
head(id(340),mx_missile(170)).
head(id(341),immigration(170)).
head(id(342),synfuels_corporation_cutback(170)).
head(id(343),crime(170)).
head(id(344),export_administration_act_south_africa(170)).
head(id(345),handicapped_infants(415)).
head(id(346),water_project_cost_sharing(415)).
head(id(347),budget_resolution(415)).
head(id(348),anti_satellite_test_ban(415)).
head(id(349),aid_to_nicaraguan_contras(415)).
head(id(350),mx_missile(415)).
head(id(351),export_administration_act_south_africa(415)).
head(id(352),water_project_cost_sharing(6)).
head(id(353),budget_resolution(6)).
head(id(354),el_salvador_aid(6)).
head(id(355),religious_groups_in_schools(6)).
head(id(356),superfund_right_to_sue(6)).
head(id(357),crime(6)).
head(id(358),duty_free_exports(6)).
head(id(359),export_administration_act_south_africa(6)).
head(id(360),water_project_cost_sharing(163)).
head(id(361),budget_resolution(163)).
head(id(362),el_salvador_aid(163)).
head(id(363),religious_groups_in_schools(163)).
head(id(364),anti_satellite_test_ban(163)).
head(id(365),synfuels_corporation_cutback(163)).
head(id(366),education_spending(163)).
head(id(367),superfund_right_to_sue(163)).
head(id(368),crime(163)).
head(id(369),export_administration_act_south_africa(163)).
head(id(370),water_project_cost_sharing(424)).
head(id(371),budget_resolution(424)).
head(id(372),religious_groups_in_schools(424)).
head(id(373),anti_satellite_test_ban(424)).
head(id(374),aid_to_nicaraguan_contras(424)).
head(id(375),mx_missile(424)).
head(id(376),synfuels_corporation_cutback(424)).
head(id(377),crime(424)).
head(id(378),duty_free_exports(424)).
head(id(379),export_administration_act_south_africa(424)).
head(id(380),handicapped_infants(407)).
head(id(381),budget_resolution(407)).
head(id(382),el_salvador_aid(407)).
head(id(383),religious_groups_in_schools(407)).
head(id(384),mx_missile(407)).
head(id(385),immigration(407)).
head(id(386),superfund_right_to_sue(407)).
head(id(387),crime(407)).
head(id(388),export_administration_act_south_africa(407)).
head(id(389),handicapped_infants(392)).
head(id(390),water_project_cost_sharing(392)).
head(id(391),aid_to_nicaraguan_contras(392)).
head(id(392),mx_missile(392)).
head(id(393),synfuels_corporation_cutback(392)).
head(id(394),duty_free_exports(392)).
head(id(395),handicapped_infants(338)).
head(id(396),budget_resolution(338)).
head(id(397),anti_satellite_test_ban(338)).
head(id(398),aid_to_nicaraguan_contras(338)).
head(id(399),mx_missile(338)).
head(id(400),duty_free_exports(338)).
head(id(401),export_administration_act_south_africa(338)).
head(id(402),handicapped_infants(30)).
head(id(403),water_project_cost_sharing(30)).
head(id(404),budget_resolution(30)).
head(id(405),anti_satellite_test_ban(30)).
head(id(406),aid_to_nicaraguan_contras(30)).
head(id(407),mx_missile(30)).
head(id(408),synfuels_corporation_cutback(30)).
head(id(409),duty_free_exports(30)).
head(id(410),export_administration_act_south_africa(30)).
head(id(1717,A),republican(A)) :- dom(A).
body(id(1717,A),alpha_1(A)) :- dom(A).
body(id(1717,A),water_project_cost_sharing(A)) :- dom(A).
head(id(4410,A),republican(A)) :- dom(A).
body(id(4410,A),alpha_2(A)) :- dom(A).
body(id(4410,A),physician_fee_freeze(A)) :- dom(A).
head(id(13696,A),c_alpha_1(A)) :- dom(A).
body(id(13696,A),water_project_cost_sharing(A)) :- dom(A).
head(id(20537,A),c_alpha_2(A)) :- dom(A).
body(id(20537,A),alpha_3(A)) :- dom(A).
body(id(20537,A),budget_resolution(A)) :- dom(A).
head(id(21398,A),c_alpha_3(A)) :- dom(A).
body(id(21398,A),handicapped_infants(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).

dom(6).
dom(29).
dom(30).
dom(34).
dom(38).
dom(40).
dom(57).
dom(59).
dom(62).
dom(74).
dom(78).
dom(83).
dom(84).
dom(88).
dom(118).
dom(134).
dom(140).
dom(147).
dom(151).
dom(163).
dom(164).
dom(170).
dom(176).
dom(190).
dom(203).
dom(220).
dom(227).
dom(231).
dom(242).
dom(261).
dom(267).
dom(303).
dom(306).
dom(317).
dom(338).
dom(341).
dom(347).
dom(348).
dom(365).
dom(369).
dom(384).
dom(386).
dom(392).
dom(393).
dom(407).
dom(412).
dom(415).
dom(424).
 :- not supported(republican(62)).
 :- not supported(republican(59)).
 :- not supported(republican(34)).
 :- not supported(republican(164)).
 :- not supported(republican(84)).
 :- not supported(republican(83)).
 :- not supported(republican(74)).
 :- not supported(republican(88)).
 :- not supported(republican(341)).
 :- not supported(republican(303)).
 :- not supported(republican(147)).
 :- not supported(republican(365)).
 :- not supported(republican(38)).
 :- not supported(republican(57)).
 :- not supported(republican(118)).
 :- not supported(republican(29)).
 :- not supported(republican(231)).
 :- not supported(republican(306)).
 :- not supported(republican(393)).
 :- not supported(republican(348)).
 :- not supported(republican(151)).
 :- not supported(republican(267)).
 :- not supported(republican(347)).
 :- not supported(republican(134)).
 :- supported(republican(317)).
 :- supported(republican(203)).
 :- supported(republican(386)).
 :- supported(republican(261)).
 :- supported(republican(140)).
 :- supported(republican(412)).
 :- supported(republican(176)).
 :- supported(republican(220)).
 :- supported(republican(384)).
 :- supported(republican(40)).
 :- supported(republican(227)).
 :- supported(republican(369)).
 :- supported(republican(78)).
 :- supported(republican(190)).
 :- supported(republican(242)).
 :- supported(republican(170)).
 :- supported(republican(415)).
 :- supported(republican(6)).
 :- supported(republican(163)).
 :- supported(republican(424)).
 :- supported(republican(407)).
 :- supported(republican(392)).
 :- supported(republican(338)).
 :- supported(republican(30)).
