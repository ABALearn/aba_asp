head(id(1),a4(11)).
head(id(2),a5(11)).
head(id(3),a6(11)).
head(id(4),lo(54)).
head(id(5),a4(54)).
head(id(6),a5(54)).
head(id(7),a6(54)).
head(id(8),lo(37)).
head(id(9),a4(37)).
head(id(10),hi(84)).
head(id(11),a2(84)).
head(id(12),a3(84)).
head(id(13),a4(84)).
head(id(14),a5(84)).
head(id(15),a6(84)).
head(id(16),hi(80)).
head(id(17),a2(80)).
head(id(18),a3(80)).
head(id(19),a4(80)).
head(id(20),a5(80)).
head(id(21),a6(80)).
head(id(22),lo(47)).
head(id(23),a4(47)).
head(id(24),a5(47)).
head(id(25),a4(7)).
head(id(26),a5(7)).
head(id(27),a6(7)).
head(id(28),lo(48)).
head(id(29),a4(48)).
head(id(30),a5(48)).
head(id(31),a6(48)).
head(id(32),lo(59)).
head(id(33),a4(59)).
head(id(34),a5(59)).
head(id(35),a6(59)).
head(id(36),lo(52)).
head(id(37),a4(52)).
head(id(38),a4(19)).
head(id(39),a5(19)).
head(id(40),a6(19)).
head(id(41),a4(14)).
head(id(42),a5(14)).
head(id(43),a6(14)).
head(id(44),hi(89)).
head(id(45),a2(89)).
head(id(46),a3(89)).
head(id(47),a4(89)).
head(id(48),a5(89)).
head(id(49),a4(21)).
head(id(50),a5(21)).
head(id(51),hi(100)).
head(id(52),a2(100)).
head(id(53),a3(100)).
head(id(54),a4(100)).
head(id(55),a5(100)).
head(id(56),hi(71)).
head(id(57),a2(71)).
head(id(58),a3(71)).
head(id(59),a4(71)).
head(id(60),a5(71)).
head(id(61),a6(71)).
head(id(62),a4(9)).
head(id(63),a5(9)).
head(id(64),a6(9)).
head(id(65),hi(85)).
head(id(66),a2(85)).
head(id(67),a3(85)).
head(id(68),a4(85)).
head(id(69),a5(85)).
head(id(70),a4(22)).
head(id(71),a5(22)).
head(id(72),a4(26)).
head(id(73),a5(26)).
head(id(74),a6(26)).
head(id(75),a4(30)).
head(id(76),a5(30)).
head(id(77),a6(30)).
head(id(78),lo(57)).
head(id(79),a4(57)).
head(id(80),a5(57)).
head(id(81),a4(17)).
head(id(82),a5(17)).
head(id(83),a6(17)).
head(id(84),mo(66)).
head(id(85),a3(66)).
head(id(86),a4(66)).
head(id(87),a6(66)).
head(id(88),mo(64)).
head(id(89),a3(64)).
head(id(90),a4(64)).
head(id(91),a6(64)).
head(id(92),hi(82)).
head(id(93),a2(82)).
head(id(94),a3(82)).
head(id(95),a5(82)).
head(id(96),hi(78)).
head(id(97),a3(78)).
head(id(98),a4(78)).
head(id(99),a6(78)).
head(id(100),hi(96)).
head(id(101),a2(96)).
head(id(102),a3(96)).
head(id(103),a5(96)).
head(id(104),vh(110)).
head(id(105),a3(110)).
head(id(106),a4(110)).
head(id(107),a6(110)).
head(id(108),lo(58)).
head(id(109),a3(58)).
head(id(110),hi(69)).
head(id(111),a3(69)).
head(id(112),a4(69)).
head(id(113),a6(69)).
head(id(114),a3(33)).
head(id(115),hi(74)).
head(id(116),lo(51)).
head(id(117),a3(51)).
head(id(118),a3(20)).
head(id(119),hi(95)).
head(id(120),vh(113)).
head(id(121),a2(113)).
head(id(122),a3(113)).
head(id(123),a5(113)).
head(id(124),hi(88)).
head(id(125),a2(88)).
head(id(126),a3(88)).
head(id(127),a5(88)).
head(id(128),lo(53)).
head(id(129),a3(53)).
head(id(130),a3(23)).
head(id(131),a3(16)).
head(id(132),a3(3)).
head(id(133),mo(68)).
head(id(134),a3(68)).
head(id(135),a4(68)).
head(id(136),a6(68)).
head(id(137),a3(5)).
head(id(138),hi(87)).
head(id(139),hi(75)).
head(id(140),vh(114)).
head(id(141),a3(114)).
head(id(142),a4(114)).
head(id(143),a6(114)).
head(id(646,A),acute(A)) :- dom(A).
body(id(646,A),alpha_1(A)) :- dom(A).
body(id(646,A),a4(A)) :- dom(A).
head(id(4622,A),c_alpha_1(A)) :- dom(A).
body(id(4622,A),mo(A)) :- dom(A).
head(id(5397,A),c_alpha_1(A)) :- dom(A).
body(id(5397,A),alpha_2(A)) :- dom(A).
body(id(5397,A),hi(A)) :- dom(A).
head(id(5890,A),c_alpha_1(A)) :- dom(A).
body(id(5890,A),vh(A)) :- dom(A).
head(id(6711,A),c_alpha_2(A)) :- dom(A).
body(id(6711,A),a2(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).

dom(3).
dom(5).
dom(7).
dom(9).
dom(11).
dom(14).
dom(16).
dom(17).
dom(19).
dom(20).
dom(21).
dom(22).
dom(23).
dom(26).
dom(30).
dom(33).
dom(37).
dom(47).
dom(48).
dom(51).
dom(52).
dom(53).
dom(54).
dom(57).
dom(58).
dom(59).
dom(64).
dom(66).
dom(68).
dom(69).
dom(71).
dom(74).
dom(75).
dom(78).
dom(80).
dom(82).
dom(84).
dom(85).
dom(87).
dom(88).
dom(89).
dom(95).
dom(96).
dom(100).
dom(110).
dom(113).
dom(114).
 :- not supported(acute(11)).
 :- not supported(acute(54)).
 :- not supported(acute(37)).
 :- not supported(acute(84)).
 :- not supported(acute(80)).
 :- not supported(acute(47)).
 :- not supported(acute(7)).
 :- not supported(acute(48)).
 :- not supported(acute(59)).
 :- not supported(acute(52)).
 :- not supported(acute(19)).
 :- not supported(acute(14)).
 :- not supported(acute(89)).
 :- not supported(acute(21)).
 :- not supported(acute(100)).
 :- not supported(acute(71)).
 :- not supported(acute(9)).
 :- not supported(acute(85)).
 :- not supported(acute(22)).
 :- not supported(acute(26)).
 :- not supported(acute(30)).
 :- not supported(acute(57)).
 :- not supported(acute(17)).
 :- supported(acute(66)).
 :- supported(acute(64)).
 :- supported(acute(82)).
 :- supported(acute(78)).
 :- supported(acute(96)).
 :- supported(acute(110)).
 :- supported(acute(58)).
 :- supported(acute(69)).
 :- supported(acute(33)).
 :- supported(acute(74)).
 :- supported(acute(51)).
 :- supported(acute(20)).
 :- supported(acute(95)).
 :- supported(acute(113)).
 :- supported(acute(88)).
 :- supported(acute(53)).
 :- supported(acute(23)).
 :- supported(acute(16)).
 :- supported(acute(3)).
 :- supported(acute(68)).
 :- supported(acute(5)).
 :- supported(acute(87)).
 :- supported(acute(75)).
 :- supported(acute(114)).
