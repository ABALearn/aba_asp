head(id(1),a1(116)).
head(id(2),a3(116)).
head(id(3),a4(116)).
head(id(4),a5(116)).
head(id(5),a6(116)).
head(id(6),age3(116)).
head(id(7),female(116)).
head(id(8),white(116)).
head(id(9),parent(116)).
head(id(10),a1(34)).
head(id(11),a2(34)).
head(id(12),a3(34)).
head(id(13),a4(34)).
head(id(14),a5(34)).
head(id(15),a6(34)).
head(id(16),a7(34)).
head(id(17),age1(34)).
head(id(18),female(34)).
head(id(19),white(34)).
head(id(20),jaundice(34)).
head(id(21),self(34)).
head(id(22),a1(219)).
head(id(23),a2(219)).
head(id(24),a4(219)).
head(id(25),a5(219)).
head(id(26),a7(219)).
head(id(27),age1(219)).
head(id(28),white(219)).
head(id(29),self(219)).
head(id(30),a1(266)).
head(id(31),a2(266)).
head(id(32),a3(266)).
head(id(33),a5(266)).
head(id(34),a7(266)).
head(id(35),age3(266)).
head(id(36),asian(266)).
head(id(37),self(266)).
head(id(38),a1(125)).
head(id(39),a3(125)).
head(id(40),a4(125)).
head(id(41),a5(125)).
head(id(42),a6(125)).
head(id(43),a7(125)).
head(id(44),age2(125)).
head(id(45),female(125)).
head(id(46),white(125)).
head(id(47),pdd(125)).
head(id(48),self(125)).
head(id(49),a1(111)).
head(id(50),a3(111)).
head(id(51),a4(111)).
head(id(52),a5(111)).
head(id(53),a6(111)).
head(id(54),a7(111)).
head(id(55),age2(111)).
head(id(56),female(111)).
head(id(57),white(111)).
head(id(58),pdd(111)).
head(id(59),self(111)).
head(id(60),a1(203)).
head(id(61),a2(203)).
head(id(62),a4(203)).
head(id(63),a5(203)).
head(id(64),age2(203)).
head(id(65),female(203)).
head(id(66),white(203)).
head(id(67),self(203)).
head(id(68),a1(308)).
head(id(69),a4(308)).
head(id(70),a5(308)).
head(id(71),a6(308)).
head(id(72),a7(308)).
head(id(73),age2(308)).
head(id(74),female(308)).
head(id(75),white(308)).
head(id(76),self(308)).
head(id(77),a1(309)).
head(id(78),a2(309)).
head(id(79),a3(309)).
head(id(80),a4(309)).
head(id(81),a5(309)).
head(id(82),a6(309)).
head(id(83),age2(309)).
head(id(84),female(309)).
head(id(85),others(309)).
head(id(86),self(309)).
head(id(87),a1(196)).
head(id(88),a3(196)).
head(id(89),a4(196)).
head(id(90),a5(196)).
head(id(91),a6(196)).
head(id(92),a7(196)).
head(id(93),age5(196)).
head(id(94),female(196)).
head(id(95),white(196)).
head(id(96),self(196)).
head(id(97),a1(290)).
head(id(98),a2(290)).
head(id(99),a3(290)).
head(id(100),a5(290)).
head(id(101),a6(290)).
head(id(102),a7(290)).
head(id(103),age5(290)).
head(id(104),white(290)).
head(id(105),jaundice(290)).
head(id(106),self(290)).
head(id(107),a1(122)).
head(id(108),a3(122)).
head(id(109),a4(122)).
head(id(110),a5(122)).
head(id(111),a6(122)).
head(id(112),a7(122)).
head(id(113),age1(122)).
head(id(114),female(122)).
head(id(115),white(122)).
head(id(116),self(122)).
head(id(117),a1(177)).
head(id(118),a2(177)).
head(id(119),a3(177)).
head(id(120),a4(177)).
head(id(121),a5(177)).
head(id(122),a6(177)).
head(id(123),age4(177)).
head(id(124),female(177)).
head(id(125),black(177)).
head(id(126),self(177)).
head(id(127),a1(297)).
head(id(128),a2(297)).
head(id(129),a3(297)).
head(id(130),a4(297)).
head(id(131),a5(297)).
head(id(132),a6(297)).
head(id(133),age1(297)).
head(id(134),female(297)).
head(id(135),white(297)).
head(id(136),jaundice(297)).
head(id(137),parent(297)).
head(id(138),a1(272)).
head(id(139),a2(272)).
head(id(140),a3(272)).
head(id(141),a4(272)).
head(id(142),age3(272)).
head(id(143),female(272)).
head(id(144),black(272)).
head(id(145),pdd(272)).
head(id(146),parent(272)).
head(id(147),a1(302)).
head(id(148),a2(302)).
head(id(149),a3(302)).
head(id(150),a4(302)).
head(id(151),a5(302)).
head(id(152),a6(302)).
head(id(153),a7(302)).
head(id(154),age3(302)).
head(id(155),female(302)).
head(id(156),white(302)).
head(id(157),jaundice(302)).
head(id(158),self(302)).
head(id(159),a1(121)).
head(id(160),a2(121)).
head(id(161),a3(121)).
head(id(162),a4(121)).
head(id(163),a5(121)).
head(id(164),a6(121)).
head(id(165),age2(121)).
head(id(166),white(121)).
head(id(167),self(121)).
head(id(168),a1(313)).
head(id(169),a3(313)).
head(id(170),a5(313)).
head(id(171),a6(313)).
head(id(172),a7(313)).
head(id(173),age1(313)).
head(id(174),hispanic(313)).
head(id(175),self(313)).
head(id(176),a1(10)).
head(id(177),a2(10)).
head(id(178),a3(10)).
head(id(179),a4(10)).
head(id(180),a6(10)).
head(id(181),a7(10)).
head(id(182),age1(10)).
head(id(183),asian(10)).
head(id(184),jaundice(10)).
head(id(185),pdd(10)).
head(id(186),hcprofessional(10)).
head(id(187),a1(201)).
head(id(188),a2(201)).
head(id(189),a3(201)).
head(id(190),a4(201)).
head(id(191),a5(201)).
head(id(192),a7(201)).
head(id(193),age2(201)).
head(id(194),female(201)).
head(id(195),white(201)).
head(id(196),self(201)).
head(id(197),a1(216)).
head(id(198),a2(216)).
head(id(199),a5(216)).
head(id(200),a6(216)).
head(id(201),a7(216)).
head(id(202),age2(216)).
head(id(203),female(216)).
head(id(204),black(216)).
head(id(205),self(216)).
head(id(206),a1(197)).
head(id(207),a2(197)).
head(id(208),a3(197)).
head(id(209),a4(197)).
head(id(210),a5(197)).
head(id(211),a6(197)).
head(id(212),a7(197)).
head(id(213),age2(197)).
head(id(214),white(197)).
head(id(215),self(197)).
head(id(216),a1(6)).
head(id(217),a2(6)).
head(id(218),a3(6)).
head(id(219),a4(6)).
head(id(220),a5(6)).
head(id(221),a7(6)).
head(id(222),age3(6)).
head(id(223),others(6)).
head(id(224),jaundice(6)).
head(id(225),self(6)).
head(id(226),a1(32)).
head(id(227),a4(32)).
head(id(228),a5(32)).
head(id(229),a6(32)).
head(id(230),a7(32)).
head(id(231),age3(32)).
head(id(232),female(32)).
head(id(233),white(32)).
head(id(234),pdd(32)).
head(id(235),self(32)).
head(id(236),a1(54)).
head(id(237),a3(54)).
head(id(238),a4(54)).
head(id(239),a5(54)).
head(id(240),a6(54)).
head(id(241),a7(54)).
head(id(242),age2(54)).
head(id(243),latino(54)).
head(id(244),pdd(54)).
head(id(245),self(54)).
head(id(246),a1(95)).
head(id(247),a2(95)).
head(id(248),a3(95)).
head(id(249),a4(95)).
head(id(250),a5(95)).
head(id(251),age4(95)).
head(id(252),female(95)).
head(id(253),white(95)).
head(id(254),pdd(95)).
head(id(255),self(95)).
head(id(256),a1(204)).
head(id(257),a2(204)).
head(id(258),a3(204)).
head(id(259),a4(204)).
head(id(260),a5(204)).
head(id(261),a6(204)).
head(id(262),a7(204)).
head(id(263),age6(204)).
head(id(264),female(204)).
head(id(265),white(204)).
head(id(266),pdd(204)).
head(id(267),relative(204)).
head(id(268),a1(279)).
head(id(269),a3(279)).
head(id(270),a4(279)).
head(id(271),a5(279)).
head(id(272),a6(279)).
head(id(273),a7(279)).
head(id(274),age3(279)).
head(id(275),female(279)).
head(id(276),white(279)).
head(id(277),self(279)).
head(id(278),a1(56)).
head(id(279),a2(56)).
head(id(280),a3(56)).
head(id(281),a4(56)).
head(id(282),a5(56)).
head(id(283),a6(56)).
head(id(284),age3(56)).
head(id(285),female(56)).
head(id(286),asian(56)).
head(id(287),self(56)).
head(id(288),a1(90)).
head(id(289),a2(90)).
head(id(290),a3(90)).
head(id(291),a4(90)).
head(id(292),a5(90)).
head(id(293),a6(90)).
head(id(294),age2(90)).
head(id(295),female(90)).
head(id(296),white(90)).
head(id(297),self(90)).
head(id(298),a1(57)).
head(id(299),a3(57)).
head(id(300),a4(57)).
head(id(301),a5(57)).
head(id(302),a6(57)).
head(id(303),age2(57)).
head(id(304),female(57)).
head(id(305),white(57)).
head(id(306),self(57)).
head(id(307),a1(186)).
head(id(308),a3(186)).
head(id(309),a4(186)).
head(id(310),a5(186)).
head(id(311),a6(186)).
head(id(312),a7(186)).
head(id(313),age2(186)).
head(id(314),southasian(186)).
head(id(315),self(186)).
head(id(316),a1(225)).
head(id(317),a2(225)).
head(id(318),a3(225)).
head(id(319),a4(225)).
head(id(320),a5(225)).
head(id(321),a6(225)).
head(id(322),a7(225)).
head(id(323),age2(225)).
head(id(324),female(225)).
head(id(325),white(225)).
head(id(326),self(225)).
head(id(327),a1(292)).
head(id(328),a2(292)).
head(id(329),a4(292)).
head(id(330),a5(292)).
head(id(331),age3(292)).
head(id(332),female(292)).
head(id(333),black(292)).
head(id(334),self(292)).
head(id(335),a1(148)).
head(id(336),a2(148)).
head(id(337),a3(148)).
head(id(338),a4(148)).
head(id(339),a5(148)).
head(id(340),a6(148)).
head(id(341),a7(148)).
head(id(342),age1(148)).
head(id(343),female(148)).
head(id(344),white(148)).
head(id(345),self(148)).
head(id(346),a1(207)).
head(id(347),a2(207)).
head(id(348),a3(207)).
head(id(349),a4(207)).
head(id(350),a5(207)).
head(id(351),a6(207)).
head(id(352),a7(207)).
head(id(353),age2(207)).
head(id(354),middleeastern(207)).
head(id(355),pdd(207)).
head(id(356),parent(207)).
head(id(357),a1(61)).
head(id(358),a3(61)).
head(id(359),a4(61)).
head(id(360),a5(61)).
head(id(361),a6(61)).
head(id(362),a7(61)).
head(id(363),age2(61)).
head(id(364),female(61)).
head(id(365),others(61)).
head(id(366),self(61)).
head(id(367),a1(150)).
head(id(368),a2(150)).
head(id(369),a3(150)).
head(id(370),a4(150)).
head(id(371),a5(150)).
head(id(372),a7(150)).
head(id(373),age3(150)).
head(id(374),white(150)).
head(id(375),jaundice(150)).
head(id(376),pdd(150)).
head(id(377),self(150)).
head(id(378),a1(120)).
head(id(379),a2(120)).
head(id(380),a3(120)).
head(id(381),a4(120)).
head(id(382),a5(120)).
head(id(383),a6(120)).
head(id(384),age4(120)).
head(id(385),white(120)).
head(id(386),self(120)).
head(id(387),a1(210)).
head(id(388),a4(210)).
head(id(389),a5(210)).
head(id(390),a6(210)).
head(id(391),a7(210)).
head(id(392),age2(210)).
head(id(393),female(210)).
head(id(394),white(210)).
head(id(395),self(210)).
head(id(396),a1(208)).
head(id(397),a2(208)).
head(id(398),a3(208)).
head(id(399),a5(208)).
head(id(400),age2(208)).
head(id(401),female(208)).
head(id(402),white(208)).
head(id(403),self(208)).
head(id(404),a1(206)).
head(id(405),a2(206)).
head(id(406),a3(206)).
head(id(407),a4(206)).
head(id(408),a5(206)).
head(id(409),a6(206)).
head(id(410),a7(206)).
head(id(411),age5(206)).
head(id(412),white(206)).
head(id(413),self(206)).
head(id(414),a1(117)).
head(id(415),a2(117)).
head(id(416),a3(117)).
head(id(417),a4(117)).
head(id(418),a5(117)).
head(id(419),a6(117)).
head(id(420),age2(117)).
head(id(421),female(117)).
head(id(422),white(117)).
head(id(423),self(117)).
head(id(424),a1(146)).
head(id(425),a4(146)).
head(id(426),a5(146)).
head(id(427),a6(146)).
head(id(428),a7(146)).
head(id(429),age2(146)).
head(id(430),white(146)).
head(id(431),parent(146)).
head(id(432),a1(271)).
head(id(433),a3(271)).
head(id(434),a4(271)).
head(id(435),a5(271)).
head(id(436),a6(271)).
head(id(437),age2(271)).
head(id(438),female(271)).
head(id(439),pdd(271)).
head(id(440),a1(300)).
head(id(441),a2(300)).
head(id(442),a3(300)).
head(id(443),a4(300)).
head(id(444),a5(300)).
head(id(445),a6(300)).
head(id(446),a7(300)).
head(id(447),age1(300)).
head(id(448),female(300)).
head(id(449),white(300)).
head(id(450),jaundice(300)).
head(id(451),self(300)).
head(id(452),a1(124)).
head(id(453),a4(124)).
head(id(454),a5(124)).
head(id(455),a6(124)).
head(id(456),a7(124)).
head(id(457),age3(124)).
head(id(458),asian(124)).
head(id(459),jaundice(124)).
head(id(460),self(124)).
head(id(461),a1(291)).
head(id(462),a2(291)).
head(id(463),a3(291)).
head(id(464),a5(291)).
head(id(465),a6(291)).
head(id(466),a7(291)).
head(id(467),age2(291)).
head(id(468),female(291)).
head(id(469),white(291)).
head(id(470),self(291)).
head(id(471),a1(298)).
head(id(472),a2(298)).
head(id(473),a3(298)).
head(id(474),a4(298)).
head(id(475),a6(298)).
head(id(476),age5(298)).
head(id(477),white(298)).
head(id(478),pdd(298)).
head(id(479),others(298)).
head(id(480),a1(211)).
head(id(481),a3(211)).
head(id(482),a4(211)).
head(id(483),a5(211)).
head(id(484),a6(211)).
head(id(485),a7(211)).
head(id(486),age3(211)).
head(id(487),female(211)).
head(id(488),white(211)).
head(id(489),pdd(211)).
head(id(490),self(211)).
head(id(491),a1(3)).
head(id(492),a2(3)).
head(id(493),a4(3)).
head(id(494),a5(3)).
head(id(495),a7(3)).
head(id(496),age2(3)).
head(id(497),latino(3)).
head(id(498),jaundice(3)).
head(id(499),pdd(3)).
head(id(500),parent(3)).
head(id(501),a1(35)).
head(id(502),a2(35)).
head(id(503),a3(35)).
head(id(504),a4(35)).
head(id(505),a5(35)).
head(id(506),a6(35)).
head(id(507),a7(35)).
head(id(508),age1(35)).
head(id(509),female(35)).
head(id(510),white(35)).
head(id(511),self(35)).
head(id(512),a1(199)).
head(id(513),a2(199)).
head(id(514),a3(199)).
head(id(515),a5(199)).
head(id(516),a6(199)).
head(id(517),age3(199)).
head(id(518),white(199)).
head(id(519),self(199)).
head(id(520),a1(227)).
head(id(521),a2(227)).
head(id(522),a3(227)).
head(id(523),a4(227)).
head(id(524),a5(227)).
head(id(525),a6(227)).
head(id(526),a7(227)).
head(id(527),age1(227)).
head(id(528),asian(227)).
head(id(529),jaundice(227)).
head(id(530),relative(227)).
head(id(531),a1(191)).
head(id(532),a2(191)).
head(id(533),a3(191)).
head(id(534),a4(191)).
head(id(535),a5(191)).
head(id(536),a6(191)).
head(id(537),age3(191)).
head(id(538),white(191)).
head(id(539),self(191)).
head(id(540),a1(45)).
head(id(541),a2(45)).
head(id(542),a3(45)).
head(id(543),a4(45)).
head(id(544),a5(45)).
head(id(545),a6(45)).
head(id(546),age2(45)).
head(id(547),female(45)).
head(id(548),white(45)).
head(id(549),self(45)).
head(id(550),a1(189)).
head(id(551),a2(189)).
head(id(552),a4(189)).
head(id(553),a5(189)).
head(id(554),a6(189)).
head(id(555),age5(189)).
head(id(556),female(189)).
head(id(557),white(189)).
head(id(558),pdd(189)).
head(id(559),self(189)).
head(id(560),a1(284)).
head(id(561),a2(284)).
head(id(562),a3(284)).
head(id(563),a4(284)).
head(id(564),a5(284)).
head(id(565),a6(284)).
head(id(566),a7(284)).
head(id(567),age4(284)).
head(id(568),female(284)).
head(id(569),white(284)).
head(id(570),self(284)).
head(id(571),a1(58)).
head(id(572),a2(58)).
head(id(573),a3(58)).
head(id(574),a4(58)).
head(id(575),a5(58)).
head(id(576),a6(58)).
head(id(577),age4(58)).
head(id(578),female(58)).
head(id(579),white(58)).
head(id(580),self(58)).
head(id(581),a1(55)).
head(id(582),a2(55)).
head(id(583),a3(55)).
head(id(584),a4(55)).
head(id(585),a5(55)).
head(id(586),a6(55)).
head(id(587),a7(55)).
head(id(588),age4(55)).
head(id(589),white(55)).
head(id(590),self(55)).
head(id(591),a1(314)).
head(id(592),a3(314)).
head(id(593),a4(314)).
head(id(594),a5(314)).
head(id(595),a6(314)).
head(id(596),age1(314)).
head(id(597),hispanic(314)).
head(id(598),self(314)).
head(id(599),a1(224)).
head(id(600),a3(224)).
head(id(601),a4(224)).
head(id(602),a6(224)).
head(id(603),a7(224)).
head(id(604),age2(224)).
head(id(605),white(224)).
head(id(606),self(224)).
head(id(607),a1(40)).
head(id(608),a3(40)).
head(id(609),a4(40)).
head(id(610),a6(40)).
head(id(611),a7(40)).
head(id(612),age3(40)).
head(id(613),female(40)).
head(id(614),white(40)).
head(id(615),pdd(40)).
head(id(616),self(40)).
head(id(617),a1(83)).
head(id(618),a2(83)).
head(id(619),a3(83)).
head(id(620),a4(83)).
head(id(621),a5(83)).
head(id(622),a6(83)).
head(id(623),a7(83)).
head(id(624),age3(83)).
head(id(625),female(83)).
head(id(626),white(83)).
head(id(627),pdd(83)).
head(id(628),self(83)).
head(id(629),a1(310)).
head(id(630),a2(310)).
head(id(631),a3(310)).
head(id(632),a4(310)).
head(id(633),a5(310)).
head(id(634),a6(310)).
head(id(635),age5(310)).
head(id(636),female(310)).
head(id(637),middleeastern(310)).
head(id(638),self(310)).
head(id(639),a1(78)).
head(id(640),a2(78)).
head(id(641),a4(78)).
head(id(642),a5(78)).
head(id(643),a6(78)).
head(id(644),a7(78)).
head(id(645),age3(78)).
head(id(646),female(78)).
head(id(647),black(78)).
head(id(648),pdd(78)).
head(id(649),self(78)).
head(id(650),a1(273)).
head(id(651),a2(273)).
head(id(652),a3(273)).
head(id(653),a4(273)).
head(id(654),a5(273)).
head(id(655),a6(273)).
head(id(656),a7(273)).
head(id(657),age4(273)).
head(id(658),white(273)).
head(id(659),self(273)).
head(id(660),a1(170)).
head(id(661),a2(170)).
head(id(662),a3(170)).
head(id(663),a4(170)).
head(id(664),a5(170)).
head(id(665),age3(170)).
head(id(666),female(170)).
head(id(667),latino(170)).
head(id(668),pdd(170)).
head(id(669),self(170)).
head(id(670),a1(46)).
head(id(671),a3(46)).
head(id(672),a4(46)).
head(id(673),a5(46)).
head(id(674),a6(46)).
head(id(675),age5(46)).
head(id(676),female(46)).
head(id(677),white(46)).
head(id(678),relative(46)).
head(id(679),a1(52)).
head(id(680),a2(52)).
head(id(681),a3(52)).
head(id(682),a4(52)).
head(id(683),a5(52)).
head(id(684),a6(52)).
head(id(685),a7(52)).
head(id(686),age3(52)).
head(id(687),female(52)).
head(id(688),black(52)).
head(id(689),parent(52)).
head(id(690),a1(62)).
head(id(691),a3(62)).
head(id(692),a4(62)).
head(id(693),a6(62)).
head(id(694),a7(62)).
head(id(695),age2(62)).
head(id(696),female(62)).
head(id(697),others(62)).
head(id(698),self(62)).
head(id(699),a1(39)).
head(id(700),a4(39)).
head(id(701),a5(39)).
head(id(702),a6(39)).
head(id(703),a7(39)).
head(id(704),age5(39)).
head(id(705),female(39)).
head(id(706),white(39)).
head(id(707),self(39)).
head(id(708),a1(126)).
head(id(709),a2(126)).
head(id(710),a5(126)).
head(id(711),a6(126)).
head(id(712),a7(126)).
head(id(713),age2(126)).
head(id(714),female(126)).
head(id(715),white(126)).
head(id(716),self(126)).
head(id(717),a1(198)).
head(id(718),a3(198)).
head(id(719),a4(198)).
head(id(720),a5(198)).
head(id(721),a6(198)).
head(id(722),a7(198)).
head(id(723),age3(198)).
head(id(724),white(198)).
head(id(725),self(198)).
head(id(726),a3(303)).
head(id(727),a4(303)).
head(id(728),a5(303)).
head(id(729),a6(303)).
head(id(730),a7(303)).
head(id(731),age4(303)).
head(id(732),female(303)).
head(id(733),white(303)).
head(id(734),self(303)).
head(id(735),a1(190)).
head(id(736),a2(190)).
head(id(737),a3(190)).
head(id(738),a5(190)).
head(id(739),a7(190)).
head(id(740),age2(190)).
head(id(741),white(190)).
head(id(742),self(190)).
head(id(743),a1(53)).
head(id(744),age2(53)).
head(id(745),female(53)).
head(id(746),pasifika(53)).
head(id(747),self(53)).
head(id(748),a1(187)).
head(id(749),a7(187)).
head(id(750),age3(187)).
head(id(751),others(187)).
head(id(752),pdd(187)).
head(id(753),self(187)).
head(id(754),a1(215)).
head(id(755),a2(215)).
head(id(756),a3(215)).
head(id(757),a4(215)).
head(id(758),age4(215)).
head(id(759),white(215)).
head(id(760),self(215)).
head(id(761),a3(222)).
head(id(762),age2(222)).
head(id(763),female(222)).
head(id(764),a1(277)).
head(id(765),a5(277)).
head(id(766),age3(277)).
head(id(767),a3(48)).
head(id(768),a4(48)).
head(id(769),a5(48)).
head(id(770),a7(48)).
head(id(771),age2(48)).
head(id(772),pasifika(48)).
head(id(773),relative(48)).
head(id(774),a2(195)).
head(id(775),a4(195)).
head(id(776),age3(195)).
head(id(777),white(195)).
head(id(778),pdd(195)).
head(id(779),self(195)).
head(id(780),a1(98)).
head(id(781),a4(98)).
head(id(782),a5(98)).
head(id(783),a7(98)).
head(id(784),age2(98)).
head(id(785),others(98)).
head(id(786),self(98)).
head(id(787),a1(136)).
head(id(788),a3(136)).
head(id(789),a4(136)).
head(id(790),age2(136)).
head(id(791),asian(136)).
head(id(792),self(136)).
head(id(793),a1(168)).
head(id(794),a5(168)).
head(id(795),a7(168)).
head(id(796),age2(168)).
head(id(797),female(168)).
head(id(798),asian(168)).
head(id(799),self(168)).
head(id(800),a2(7)).
head(id(801),age1(7)).
head(id(802),female(7)).
head(id(803),black(7)).
head(id(804),self(7)).
head(id(805),a1(74)).
head(id(806),a2(74)).
head(id(807),a3(74)).
head(id(808),age2(74)).
head(id(809),others(74)).
head(id(810),self(74)).
head(id(811),a1(2)).
head(id(812),a2(2)).
head(id(813),a4(2)).
head(id(814),age2(2)).
head(id(815),latino(2)).
head(id(816),pdd(2)).
head(id(817),self(2)).
head(id(818),a3(72)).
head(id(819),a4(72)).
head(id(820),age5(72)).
head(id(821),asian(72)).
head(id(822),self(72)).
head(id(823),age4(289)).
head(id(824),female(289)).
head(id(825),white(289)).
head(id(826),self(289)).
head(id(827),a4(254)).
head(id(828),a7(254)).
head(id(829),age2(254)).
head(id(830),southasian(254)).
head(id(831),self(254)).
head(id(832),a1(241)).
head(id(833),a4(241)).
head(id(834),a5(241)).
head(id(835),a7(241)).
head(id(836),age2(241)).
head(id(837),asian(241)).
head(id(838),self(241)).
head(id(839),a1(77)).
head(id(840),a7(77)).
head(id(841),age2(77)).
head(id(842),middleeastern(77)).
head(id(843),self(77)).
head(id(844),a1(118)).
head(id(845),a2(118)).
head(id(846),a3(118)).
head(id(847),a5(118)).
head(id(848),a7(118)).
head(id(849),age2(118)).
head(id(850),white(118)).
head(id(851),self(118)).
head(id(852),a1(232)).
head(id(853),a4(232)).
head(id(854),age2(232)).
head(id(855),white(232)).
head(id(856),self(232)).
head(id(857),a1(240)).
head(id(858),age2(240)).
head(id(859),pasifika(240)).
head(id(860),self(240)).
head(id(861),a1(104)).
head(id(862),a2(104)).
head(id(863),a5(104)).
head(id(864),a7(104)).
head(id(865),age2(104)).
head(id(866),asian(104)).
head(id(867),self(104)).
head(id(868),age4(295)).
head(id(869),female(295)).
head(id(870),middleeastern(295)).
head(id(871),parent(295)).
head(id(872),a2(239)).
head(id(873),age2(239)).
head(id(874),a7(20)).
head(id(875),age3(20)).
head(id(876),jaundice(20)).
head(id(877),age4(24)).
head(id(878),middleeastern(24)).
head(id(879),jaundice(24)).
head(id(880),relative(24)).
head(id(881),a1(133)).
head(id(882),a2(133)).
head(id(883),age2(133)).
head(id(884),southasian(133)).
head(id(885),self(133)).
head(id(886),a1(71)).
head(id(887),a2(71)).
head(id(888),a7(71)).
head(id(889),age2(71)).
head(id(890),female(71)).
head(id(891),southasian(71)).
head(id(892),self(71)).
head(id(893),a1(79)).
head(id(894),a4(79)).
head(id(895),a5(79)).
head(id(896),age2(79)).
head(id(897),middleeastern(79)).
head(id(898),self(79)).
head(id(899),a2(67)).
head(id(900),age2(67)).
head(id(901),middleeastern(67)).
head(id(902),parent(67)).
head(id(903),a2(135)).
head(id(904),a5(135)).
head(id(905),a6(135)).
head(id(906),age2(135)).
head(id(907),asian(135)).
head(id(908),self(135)).
head(id(909),a1(153)).
head(id(910),a2(153)).
head(id(911),a5(153)).
head(id(912),age3(153)).
head(id(913),female(153)).
head(id(914),southasian(153)).
head(id(915),self(153)).
head(id(916),a2(137)).
head(id(917),a3(137)).
head(id(918),a6(137)).
head(id(919),age2(137)).
head(id(920),asian(137)).
head(id(921),self(137)).
head(id(922),a1(218)).
head(id(923),a2(218)).
head(id(924),age3(218)).
head(id(925),white(218)).
head(id(926),pdd(218)).
head(id(927),parent(218)).
head(id(928),a1(164)).
head(id(929),a2(164)).
head(id(930),age2(164)).
head(id(931),asian(164)).
head(id(932),self(164)).
head(id(933),a1(99)).
head(id(934),a2(99)).
head(id(935),age2(99)).
head(id(936),female(99)).
head(id(937),pasifika(99)).
head(id(938),self(99)).
head(id(939),a3(107)).
head(id(940),a5(107)).
head(id(941),a6(107)).
head(id(942),a7(107)).
head(id(943),age2(107)).
head(id(944),southasian(107)).
head(id(945),self(107)).
head(id(946),age3(304)).
head(id(947),female(304)).
head(id(948),others(304)).
head(id(949),self(304)).
head(id(950),a1(5)).
head(id(951),age4(5)).
head(id(952),female(5)).
head(id(953),a1(109)).
head(id(954),a4(109)).
head(id(955),a5(109)).
head(id(956),a6(109)).
head(id(957),a7(109)).
head(id(958),age1(109)).
head(id(959),female(109)).
head(id(960),asian(109)).
head(id(961),parent(109)).
head(id(962),a1(237)).
head(id(963),a5(237)).
head(id(964),a6(237)).
head(id(965),a7(237)).
head(id(966),age2(237)).
head(id(967),asian(237)).
head(id(968),self(237)).
head(id(969),a1(1)).
head(id(970),a2(1)).
head(id(971),a3(1)).
head(id(972),a4(1)).
head(id(973),a7(1)).
head(id(974),age2(1)).
head(id(975),female(1)).
head(id(976),white(1)).
head(id(977),self(1)).
head(id(978),a3(81)).
head(id(979),a4(81)).
head(id(980),a7(81)).
head(id(981),age3(81)).
head(id(982),jaundice(81)).
head(id(983),pdd(81)).
head(id(984),a1(88)).
head(id(985),age3(88)).
head(id(986),white(88)).
head(id(987),self(88)).
head(id(988),a1(306)).
head(id(989),a2(306)).
head(id(990),a4(306)).
head(id(991),age3(306)).
head(id(992),female(306)).
head(id(993),white(306)).
head(id(994),self(306)).
head(id(995),a2(280)).
head(id(996),a3(280)).
head(id(997),a5(280)).
head(id(998),age2(280)).
head(id(999),hispanic(280)).
head(id(1000),jaundice(280)).
head(id(1001),self(280)).
head(id(1002),a1(233)).
head(id(1003),a2(233)).
head(id(1004),a5(233)).
head(id(1005),age2(233)).
head(id(1006),white(233)).
head(id(1007),self(233)).
head(id(1008),a1(80)).
head(id(1009),a2(80)).
head(id(1010),age4(80)).
head(id(1011),female(80)).
head(id(1012),jaundice(80)).
head(id(1013),a1(299)).
head(id(1014),a4(299)).
head(id(1015),a7(299)).
head(id(1016),age2(299)).
head(id(1017),female(299)).
head(id(1018),white(299)).
head(id(1019),jaundice(299)).
head(id(1020),self(299)).
head(id(1021),a1(182)).
head(id(1022),a2(182)).
head(id(1023),a3(182)).
head(id(1024),a4(182)).
head(id(1025),a5(182)).
head(id(1026),age1(182)).
head(id(1027),female(182)).
head(id(1028),asian(182)).
head(id(1029),self(182)).
head(id(1030),a1(9)).
head(id(1031),a2(9)).
head(id(1032),a5(9)).
head(id(1033),age2(9)).
head(id(1034),white(9)).
head(id(1035),self(9)).
head(id(1036),a1(274)).
head(id(1037),a2(274)).
head(id(1038),age1(274)).
head(id(1039),white(274)).
head(id(1040),others(274)).
head(id(1041),a1(131)).
head(id(1042),a2(131)).
head(id(1043),age1(131)).
head(id(1044),female(131)).
head(id(1045),white(131)).
head(id(1046),self(131)).
head(id(1047),a2(183)).
head(id(1048),a4(183)).
head(id(1049),a5(183)).
head(id(1050),a6(183)).
head(id(1051),age3(183)).
head(id(1052),white(183)).
head(id(1053),others(183)).
head(id(1054),a1(139)).
head(id(1055),a7(139)).
head(id(1056),age2(139)).
head(id(1057),asian(139)).
head(id(1058),self(139)).
head(id(1059),a1(193)).
head(id(1060),age4(193)).
head(id(1061),hispanic(193)).
head(id(1062),self(193)).
head(id(1063),age2(127)).
head(id(1064),female(127)).
head(id(1065),white(127)).
head(id(1066),self(127)).
head(id(1067),age3(163)).
head(id(1068),female(163)).
head(id(1069),southasian(163)).
head(id(1070),self(163)).
head(id(1071),a1(15)).
head(id(1072),a7(15)).
head(id(1073),age1(15)).
head(id(1074),female(15)).
head(id(1075),a1(268)).
head(id(1076),age2(268)).
head(id(1077),pasifika(268)).
head(id(1078),self(268)).
head(id(1079),a2(228)).
head(id(1080),age2(228)).
head(id(1081),white(228)).
head(id(1082),self(228)).
head(id(1083),a2(44)).
head(id(1084),a3(44)).
head(id(1085),a4(44)).
head(id(1086),age3(44)).
head(id(1087),female(44)).
head(id(1088),white(44)).
head(id(1089),jaundice(44)).
head(id(1090),pdd(44)).
head(id(1091),self(44)).
head(id(1092),a1(252)).
head(id(1093),a4(252)).
head(id(1094),a7(252)).
head(id(1095),age2(252)).
head(id(1096),asian(252)).
head(id(1097),self(252)).
head(id(1098),a3(169)).
head(id(1099),a4(169)).
head(id(1100),a5(169)).
head(id(1101),age3(169)).
head(id(1102),female(169)).
head(id(1103),latino(169)).
head(id(1104),pdd(169)).
head(id(1105),self(169)).
head(id(1106),a1(275)).
head(id(1107),a2(275)).
head(id(1108),a3(275)).
head(id(1109),age4(275)).
head(id(1110),female(275)).
head(id(1111),white(275)).
head(id(1112),pdd(275)).
head(id(1113),self(275)).
head(id(1114),a1(66)).
head(id(1115),a3(66)).
head(id(1116),age2(66)).
head(id(1117),middleeastern(66)).
head(id(1118),self(66)).
head(id(1119),a1(281)).
head(id(1120),age2(281)).
head(id(1121),female(281)).
head(id(1122),hispanic(281)).
head(id(1123),pdd(281)).
head(id(1124),self(281)).
head(id(1125),a1(144)).
head(id(1126),a4(144)).
head(id(1127),a5(144)).
head(id(1128),age2(144)).
head(id(1129),asian(144)).
head(id(1130),self(144)).
head(id(1131),a1(188)).
head(id(1132),a7(188)).
head(id(1133),age2(188)).
head(id(1134),female(188)).
head(id(1135),white(188)).
head(id(1136),self(188)).
head(id(1137),a1(179)).
head(id(1138),a3(179)).
head(id(1139),a5(179)).
head(id(1140),age2(179)).
head(id(1141),middleeastern(179)).
head(id(1142),self(179)).
head(id(1143),a1(213)).
head(id(1144),a2(213)).
head(id(1145),a6(213)).
head(id(1146),a7(213)).
head(id(1147),age3(213)).
head(id(1148),female(213)).
head(id(1149),white(213)).
head(id(1150),self(213)).
head(id(1151),a1(89)).
head(id(1152),age3(89)).
head(id(1153),female(89)).
head(id(1154),white(89)).
head(id(1155),pdd(89)).
head(id(1156),self(89)).
head(id(1157),a1(14)).
head(id(1158),a7(14)).
head(id(1159),age1(14)).
head(id(1160),a2(276)).
head(id(1161),a3(276)).
head(id(1162),a4(276)).
head(id(1163),age2(276)).
head(id(1164),asian(276)).
head(id(1165),others(276)).
head(id(1166),age4(28)).
head(id(1167),middleeastern(28)).
head(id(1168),jaundice(28)).
head(id(1169),pdd(28)).
head(id(1170),parent(28)).
head(id(1171),a7(261)).
head(id(1172),age2(261)).
head(id(1173),asian(261)).
head(id(1174),self(261)).
head(id(1175),a1(155)).
head(id(1176),a5(155)).
head(id(1177),a7(155)).
head(id(1178),age3(155)).
head(id(1179),asian(155)).
head(id(1180),self(155)).
head(id(1181),a2(235)).
head(id(1182),a3(235)).
head(id(1183),age2(235)).
head(id(1184),black(235)).
head(id(1185),self(235)).
head(id(1186),age2(100)).
head(id(1187),pasifika(100)).
head(id(1188),self(100)).
head(id(1189),a1(316)).
head(id(1190),a2(316)).
head(id(1191),age2(316)).
head(id(1192),a1(257)).
head(id(1193),a6(257)).
head(id(1194),age2(257)).
head(id(1195),southasian(257)).
head(id(1196),self(257)).
head(id(1197),a1(223)).
head(id(1198),a2(223)).
head(id(1199),a3(223)).
head(id(1200),a4(223)).
head(id(1201),a5(223)).
head(id(1202),age2(223)).
head(id(1203),white(223)).
head(id(1204),self(223)).
head(id(1205),a1(214)).
head(id(1206),a3(214)).
head(id(1207),a4(214)).
head(id(1208),age3(214)).
head(id(1209),female(214)).
head(id(1210),white(214)).
head(id(1211),self(214)).
head(id(1212),a1(91)).
head(id(1213),a3(91)).
head(id(1214),a4(91)).
head(id(1215),age1(91)).
head(id(1216),female(91)).
head(id(1217),white(91)).
head(id(1218),pdd(91)).
head(id(1219),self(91)).
head(id(1220),a1(305)).
head(id(1221),a2(305)).
head(id(1222),a3(305)).
head(id(1223),a4(305)).
head(id(1224),a5(305)).
head(id(1225),age3(305)).
head(id(1226),asian(305)).
head(id(1227),self(305)).
head(id(1228),a1(97)).
head(id(1229),a5(97)).
head(id(1230),a7(97)).
head(id(1231),age2(97)).
head(id(1232),female(97)).
head(id(1233),white(97)).
head(id(1234),self(97)).
head(id(1235),a1(260)).
head(id(1236),a7(260)).
head(id(1237),age2(260)).
head(id(1238),asian(260)).
head(id(1239),self(260)).
head(id(1240),age2(145)).
head(id(1241),southasian(145)).
head(id(1242),self(145)).
head(id(1243),a1(86)).
head(id(1244),age2(86)).
head(id(1245),female(86)).
head(id(1246),middleeastern(86)).
head(id(1247),self(86)).
head(id(1248),a1(242)).
head(id(1249),a5(242)).
head(id(1250),a7(242)).
head(id(1251),age2(242)).
head(id(1252),others(242)).
head(id(1253),self(242)).
head(id(1254),a1(68)).
head(id(1255),a3(68)).
head(id(1256),a5(68)).
head(id(1257),a6(68)).
head(id(1258),a7(68)).
head(id(1259),age2(68)).
head(id(1260),hispanic(68)).
head(id(1261),self(68)).
head(id(1262),a1(267)).
head(id(1263),a4(267)).
head(id(1264),age2(267)).
head(id(1265),asian(267)).
head(id(1266),self(267)).
head(id(1267),a3(244)).
head(id(1268),a5(244)).
head(id(1269),a6(244)).
head(id(1270),age3(244)).
head(id(1271),others(244)).
head(id(1272),self(244)).
head(id(1273),age2(264)).
head(id(1274),others(264)).
head(id(1275),self(264)).
head(id(1276),age4(29)).
head(id(1277),black(29)).
head(id(1278),self(29)).
head(id(1279),age3(18)).
head(id(1280),white(18)).
head(id(1281),self(18)).
head(id(1282),a1(166)).
head(id(1283),a5(166)).
head(id(1284),a7(166)).
head(id(1285),age4(166)).
head(id(1286),asian(166)).
head(id(1287),self(166)).
head(id(1288),a1(294)).
head(id(1289),a5(294)).
head(id(1290),a7(294)).
head(id(1291),age2(294)).
head(id(1292),female(294)).
head(id(1293),white(294)).
head(id(1294),pdd(294)).
head(id(1295),self(294)).
head(id(1296),a1(17)).
head(id(1297),a7(17)).
head(id(1298),age3(17)).
head(id(1299),middleeastern(17)).
head(id(1300),self(17)).
head(id(1301),a3(43)).
head(id(1302),a4(43)).
head(id(1303),age3(43)).
head(id(1304),female(43)).
head(id(1305),middleeastern(43)).
head(id(1306),pdd(43)).
head(id(1307),self(43)).
head(id(1308),a1(238)).
head(id(1309),age1(238)).
head(id(1310),southasian(238)).
head(id(1311),self(238)).
head(id(1312),a1(134)).
head(id(1313),a3(134)).
head(id(1314),a4(134)).
head(id(1315),age2(134)).
head(id(1316),asian(134)).
head(id(1317),self(134)).
head(id(1318),a1(236)).
head(id(1319),age2(236)).
head(id(1320),southasian(236)).
head(id(1321),self(236)).
head(id(1322),a4(212)).
head(id(1323),a6(212)).
head(id(1324),age3(212)).
head(id(1325),asian(212)).
head(id(1326),pdd(212)).
head(id(1327),self(212)).
head(id(1328),a1(175)).
head(id(1329),a4(175)).
head(id(1330),age5(175)).
head(id(1331),white(175)).
head(id(1332),self(175)).
head(id(1333),a5(138)).
head(id(1334),age2(138)).
head(id(1335),asian(138)).
head(id(1336),self(138)).
head(id(1337),a2(37)).
head(id(1338),a3(37)).
head(id(1339),a5(37)).
head(id(1340),age5(37)).
head(id(1341),middleeastern(37)).
head(id(1342),self(37)).
head(id(1343),a1(311)).
head(id(1344),a3(311)).
head(id(1345),age3(311)).
head(id(1346),female(311)).
head(id(1347),white(311)).
head(id(1348),self(311)).
head(id(1349),a1(256)).
head(id(1350),a2(256)).
head(id(1351),a5(256)).
head(id(1352),age3(256)).
head(id(1353),turkish(256)).
head(id(1354),self(256)).
head(id(1355),a1(64)).
head(id(1356),a4(64)).
head(id(1357),a5(64)).
head(id(1358),age1(64)).
head(id(1359),white(64)).
head(id(1360),parent(64)).
head(id(1361),a1(159)).
head(id(1362),a4(159)).
head(id(1363),age2(159)).
head(id(1364),female(159)).
head(id(1365),asian(159)).
head(id(1366),self(159)).
head(id(1367),a1(96)).
head(id(1368),a2(96)).
head(id(1369),age3(96)).
head(id(1370),female(96)).
head(id(1371),white(96)).
head(id(1372),self(96)).
head(id(1373),a1(209)).
head(id(1374),a2(209)).
head(id(1375),a3(209)).
head(id(1376),a4(209)).
head(id(1377),a7(209)).
head(id(1378),age5(209)).
head(id(1379),white(209)).
head(id(1380),self(209)).
head(id(1381),a2(158)).
head(id(1382),a5(158)).
head(id(1383),age2(158)).
head(id(1384),female(158)).
head(id(1385),southasian(158)).
head(id(1386),self(158)).
head(id(1387),a4(23)).
head(id(1388),a7(23)).
head(id(1389),age2(23)).
head(id(1390),middleeastern(23)).
head(id(1391),self(23)).
head(id(1392),a3(248)).
head(id(1393),a4(248)).
head(id(1394),a6(248)).
head(id(1395),age2(248)).
head(id(1396),white(248)).
head(id(1397),self(248)).
head(id(1398),a5(70)).
head(id(1399),age4(70)).
head(id(1400),black(70)).
head(id(1401),self(70)).
head(id(1402),a1(8)).
head(id(1403),a2(8)).
head(id(1404),a3(8)).
head(id(1405),a4(8)).
head(id(1406),age6(8)).
head(id(1407),white(8)).
head(id(1408),parent(8)).
head(id(1409),a1(123)).
head(id(1410),age2(123)).
head(id(1411),female(123)).
head(id(1412),black(123)).
head(id(1413),self(123)).
head(id(1414),a1(200)).
head(id(1415),a2(200)).
head(id(1416),a3(200)).
head(id(1417),a4(200)).
head(id(1418),age3(200)).
head(id(1419),female(200)).
head(id(1420),pasifika(200)).
head(id(1421),pdd(200)).
head(id(1422),self(200)).
head(id(1423),a1(265)).
head(id(1424),a5(265)).
head(id(1425),age2(265)).
head(id(1426),female(265)).
head(id(1427),asian(265)).
head(id(1428),self(265)).
head(id(1429),age4(27)).
head(id(1430),pasifika(27)).
head(id(1431),jaundice(27)).
head(id(1432),pdd(27)).
head(id(1433),self(27)).
head(id(1434),a3(178)).
head(id(1435),a4(178)).
head(id(1436),a5(178)).
head(id(1437),age2(178)).
head(id(1438),middleeastern(178)).
head(id(1439),self(178)).
head(id(1440),a3(185)).
head(id(1441),a4(185)).
head(id(1442),a5(185)).
head(id(1443),a7(185)).
head(id(1444),age2(185)).
head(id(1445),white(185)).
head(id(1446),self(185)).
head(id(1447),a3(184)).
head(id(1448),a4(184)).
head(id(1449),a5(184)).
head(id(1450),age3(184)).
head(id(1451),asian(184)).
head(id(1452),self(184)).
head(id(1453),a1(4)).
head(id(1454),a2(4)).
head(id(1455),a4(4)).
head(id(1456),a7(4)).
head(id(1457),age3(4)).
head(id(1458),female(4)).
head(id(1459),white(4)).
head(id(1460),pdd(4)).
head(id(1461),self(4)).
head(id(1462),a1(102)).
head(id(1463),age3(102)).
head(id(1464),female(102)).
head(id(1465),asian(102)).
head(id(1466),self(102)).
head(id(1467),a3(84)).
head(id(1468),a5(84)).
head(id(1469),age4(84)).
head(id(1470),female(84)).
head(id(1471),middleeastern(84)).
head(id(1472),self(84)).
head(id(1473),a1(221)).
head(id(1474),a2(221)).
head(id(1475),age4(221)).
head(id(1476),white(221)).
head(id(1477),self(221)).
head(id(1478),a1(60)).
head(id(1479),a2(60)).
head(id(1480),a3(60)).
head(id(1481),a4(60)).
head(id(1482),age4(60)).
head(id(1483),female(60)).
head(id(1484),white(60)).
head(id(1485),self(60)).
head(id(1486),a2(226)).
head(id(1487),a4(226)).
head(id(1488),age2(226)).
head(id(1489),female(226)).
head(id(1490),white(226)).
head(id(1491),self(226)).
head(id(1492),a1(16)).
head(id(1493),a2(16)).
head(id(1494),a4(16)).
head(id(1495),a5(16)).
head(id(1496),age1(16)).
head(id(1497),middleeastern(16)).
head(id(1498),pdd(16)).
head(id(1499),parent(16)).
head(id(1500),age2(22)).
head(id(1501),female(22)).
head(id(1502),black(22)).
head(id(1503),self(22)).
head(id(1504),a1(269)).
head(id(1505),a3(269)).
head(id(1506),a4(269)).
head(id(1507),a5(269)).
head(id(1508),age3(269)).
head(id(1509),female(269)).
head(id(1510),white(269)).
head(id(1511),self(269)).
head(id(1512),a1(103)).
head(id(1513),age2(103)).
head(id(1514),asian(103)).
head(id(1515),self(103)).
head(id(1516),a1(262)).
head(id(1517),a3(262)).
head(id(1518),a5(262)).
head(id(1519),age2(262)).
head(id(1520),female(262)).
head(id(1521),southasian(262)).
head(id(1522),self(262)).
head(id(1523),a1(129)).
head(id(1524),a3(129)).
head(id(1525),a4(129)).
head(id(1526),a7(129)).
head(id(1527),age4(129)).
head(id(1528),female(129)).
head(id(1529),white(129)).
head(id(1530),self(129)).
head(id(1531),a1(85)).
head(id(1532),a2(85)).
head(id(1533),age1(85)).
head(id(1534),female(85)).
head(id(1535),white(85)).
head(id(1536),self(85)).
head(id(1537),a4(286)).
head(id(1538),a5(286)).
head(id(1539),a6(286)).
head(id(1540),a7(286)).
head(id(1541),age3(286)).
head(id(1542),female(286)).
head(id(1543),a1(247)).
head(id(1544),a4(247)).
head(id(1545),a5(247)).
head(id(1546),a7(247)).
head(id(1547),age2(247)).
head(id(1548),pasifika(247)).
head(id(1549),self(247)).
head(id(1550),a1(157)).
head(id(1551),a6(157)).
head(id(1552),age2(157)).
head(id(1553),female(157)).
head(id(1554),asian(157)).
head(id(1555),self(157)).
head(id(1556),a1(165)).
head(id(1557),a3(165)).
head(id(1558),a5(165)).
head(id(1559),a7(165)).
head(id(1560),age2(165)).
head(id(1561),female(165)).
head(id(1562),asian(165)).
head(id(1563),self(165)).
head(id(1564),a2(114)).
head(id(1565),age2(114)).
head(id(1566),asian(114)).
head(id(1567),self(114)).
head(id(1568),a3(36)).
head(id(1569),age5(36)).
head(id(1570),white(36)).
head(id(1571),self(36)).
head(id(1572),a1(142)).
head(id(1573),age2(142)).
head(id(1574),southasian(142)).
head(id(1575),self(142)).
head(id(1576),age2(249)).
head(id(1577),asian(249)).
head(id(1578),self(249)).
head(id(1579),a2(101)).
head(id(1580),a3(101)).
head(id(1581),age2(101)).
head(id(1582),female(101)).
head(id(1583),southasian(101)).
head(id(1584),self(101)).
head(id(1585),a3(167)).
head(id(1586),age2(167)).
head(id(1587),female(167)).
head(id(1588),others(167)).
head(id(1589),self(167)).
head(id(1590),a1(82)).
head(id(1591),a7(82)).
head(id(1592),age3(82)).
head(id(1593),a1(259)).
head(id(1594),a5(259)).
head(id(1595),a6(259)).
head(id(1596),age2(259)).
head(id(1597),asian(259)).
head(id(1598),self(259)).
head(id(1599),a1(143)).
head(id(1600),a3(143)).
head(id(1601),age2(143)).
head(id(1602),asian(143)).
head(id(1603),self(143)).
head(id(1604),a1(180)).
head(id(1605),a3(180)).
head(id(1606),a5(180)).
head(id(1607),a7(180)).
head(id(1608),age3(180)).
head(id(1609),white(180)).
head(id(1610),self(180)).
head(id(1611),a1(246)).
head(id(1612),a7(246)).
head(id(1613),age2(246)).
head(id(1614),female(246)).
head(id(1615),asian(246)).
head(id(1616),self(246)).
head(id(1617),age2(106)).
head(id(1618),asian(106)).
head(id(1619),self(106)).
head(id(1620),a1(217)).
head(id(1621),a7(217)).
head(id(1622),age3(217)).
head(id(1623),female(217)).
head(id(1624),jaundice(217)).
head(id(1625),a4(93)).
head(id(1626),a5(93)).
head(id(1627),a6(93)).
head(id(1628),age2(93)).
head(id(1629),female(93)).
head(id(1630),pasifika(93)).
head(id(1631),self(93)).
head(id(1632),a1(315)).
head(id(1633),a4(315)).
head(id(1634),a5(315)).
head(id(1635),age2(315)).
head(id(1636),female(315)).
head(id(1637),white(315)).
head(id(1638),self(315)).
head(id(1639),a3(312)).
head(id(1640),a4(312)).
head(id(1641),a5(312)).
head(id(1642),age3(312)).
head(id(1643),white(312)).
head(id(1644),jaundice(312)).
head(id(1645),self(312)).
head(id(1646),a2(293)).
head(id(1647),a3(293)).
head(id(1648),a4(293)).
head(id(1649),age2(293)).
head(id(1650),white(293)).
head(id(1651),pdd(293)).
head(id(1652),self(293)).
head(id(1653),a2(317)).
head(id(1654),a7(317)).
head(id(1655),age2(317)).
head(id(1656),female(317)).
head(id(1657),middleeastern(317)).
head(id(1658),self(317)).
head(id(1659),a2(30)).
head(id(1660),a3(30)).
head(id(1661),age3(30)).
head(id(1662),middleeastern(30)).
head(id(1663),self(30)).
head(id(1664),a1(192)).
head(id(1665),a2(192)).
head(id(1666),a4(192)).
head(id(1667),age4(192)).
head(id(1668),latino(192)).
head(id(1669),jaundice(192)).
head(id(1670),pdd(192)).
head(id(1671),parent(192)).
head(id(1672),a2(258)).
head(id(1673),a3(258)).
head(id(1674),a5(258)).
head(id(1675),age2(258)).
head(id(1676),a1(51)).
head(id(1677),a4(51)).
head(id(1678),age2(51)).
head(id(1679),female(51)).
head(id(1680),latino(51)).
head(id(1681),self(51)).
head(id(1682),a1(110)).
head(id(1683),a6(110)).
head(id(1684),a7(110)).
head(id(1685),age1(110)).
head(id(1686),female(110)).
head(id(1687),asian(110)).
head(id(1688),parent(110)).
head(id(1689),age4(287)).
head(id(1690),white(287)).
head(id(1691),self(287)).
head(id(1692),a5(151)).
head(id(1693),age2(151)).
head(id(1694),asian(151)).
head(id(1695),self(151)).
head(id(1696),a1(270)).
head(id(1697),a4(270)).
head(id(1698),a5(270)).
head(id(1699),a7(270)).
head(id(1700),age2(270)).
head(id(1701),female(270)).
head(id(1702),asian(270)).
head(id(1703),self(270)).
head(id(1704),a3(173)).
head(id(1705),a4(173)).
head(id(1706),a5(173)).
head(id(1707),age2(173)).
head(id(1708),female(173)).
head(id(1709),asian(173)).
head(id(1710),self(173)).
head(id(1711),a1(194)).
head(id(1712),age3(194)).
head(id(1713),female(194)).
head(id(1714),asian(194)).
head(id(1715),self(194)).
head(id(1716),a2(140)).
head(id(1717),age4(140)).
head(id(1718),female(140)).
head(id(1719),asian(140)).
head(id(1720),self(140)).
head(id(1721),a1(113)).
head(id(1722),a5(113)).
head(id(1723),age3(113)).
head(id(1724),asian(113)).
head(id(1725),parent(113)).
head(id(1726),a1(171)).
head(id(1727),a3(171)).
head(id(1728),a4(171)).
head(id(1729),a7(171)).
head(id(1730),age5(171)).
head(id(1731),hispanic(171)).
head(id(1732),self(171)).
head(id(1733),a2(49)).
head(id(1734),a3(49)).
head(id(1735),a6(49)).
head(id(1736),age5(49)).
head(id(1737),white(49)).
head(id(1738),relative(49)).
head(id(1739),a1(160)).
head(id(1740),a7(160)).
head(id(1741),age3(160)).
head(id(1742),asian(160)).
head(id(1743),self(160)).
head(id(1744),age2(63)).
head(id(1745),a1(220)).
head(id(1746),a4(220)).
head(id(1747),age5(220)).
head(id(1748),female(220)).
head(id(1749),white(220)).
head(id(1750),pdd(220)).
head(id(1751),parent(220)).
head(id(1752),a1(181)).
head(id(1753),a5(181)).
head(id(1754),a7(181)).
head(id(1755),age3(181)).
head(id(1756),female(181)).
head(id(1757),white(181)).
head(id(1758),self(181)).
head(id(3668,A),autism(A)) :- dom(A).
body(id(3668,A),a1(A)) :- dom(A).
body(id(3668,A),a2(A)) :- dom(A).
body(id(3668,A),a4(A)) :- dom(A).
body(id(3668,A),a5(A)) :- dom(A).
body(id(3668,A),a7(A)) :- dom(A).
body(id(3668,A),age1(A)) :- dom(A).
body(id(3668,A),self(A)) :- dom(A).
body(id(3668,A),white(A)) :- dom(A).
head(id(5505,A),autism(A)) :- dom(A).
body(id(5505,A),a1(A)) :- dom(A).
body(id(5505,A),a2(A)) :- dom(A).
body(id(5505,A),a3(A)) :- dom(A).
body(id(5505,A),a5(A)) :- dom(A).
body(id(5505,A),a7(A)) :- dom(A).
body(id(5505,A),age3(A)) :- dom(A).
body(id(5505,A),asian(A)) :- dom(A).
body(id(5505,A),self(A)) :- dom(A).
head(id(7350,A),autism(A)) :- dom(A).
body(id(7350,A),a1(A)) :- dom(A).
body(id(7350,A),a2(A)) :- dom(A).
body(id(7350,A),a4(A)) :- dom(A).
body(id(7350,A),a5(A)) :- dom(A).
body(id(7350,A),age2(A)) :- dom(A).
body(id(7350,A),female(A)) :- dom(A).
body(id(7350,A),self(A)) :- dom(A).
body(id(7350,A),white(A)) :- dom(A).
head(id(9198,A),autism(A)) :- dom(A).
body(id(9198,A),a1(A)) :- dom(A).
body(id(9198,A),a3(A)) :- dom(A).
body(id(9198,A),a5(A)) :- dom(A).
body(id(9198,A),a6(A)) :- dom(A).
body(id(9198,A),a7(A)) :- dom(A).
body(id(9198,A),age1(A)) :- dom(A).
body(id(9198,A),hispanic(A)) :- dom(A).
body(id(9198,A),self(A)) :- dom(A).
head(id(11054,A),autism(A)) :- dom(A).
body(id(11054,A),a1(A)) :- dom(A).
body(id(11054,A),a2(A)) :- dom(A).
body(id(11054,A),a4(A)) :- dom(A).
body(id(11054,A),a5(A)) :- dom(A).
body(id(11054,A),age3(A)) :- dom(A).
body(id(11054,A),black(A)) :- dom(A).
body(id(11054,A),female(A)) :- dom(A).
body(id(11054,A),self(A)) :- dom(A).
head(id(12917,A),autism(A)) :- dom(A).
body(id(12917,A),a1(A)) :- dom(A).
body(id(12917,A),a2(A)) :- dom(A).
body(id(12917,A),a3(A)) :- dom(A).
body(id(12917,A),a5(A)) :- dom(A).
body(id(12917,A),age2(A)) :- dom(A).
body(id(12917,A),female(A)) :- dom(A).
body(id(12917,A),self(A)) :- dom(A).
body(id(12917,A),white(A)) :- dom(A).
head(id(14787,A),autism(A)) :- dom(A).
body(id(14787,A),a1(A)) :- dom(A).
body(id(14787,A),a4(A)) :- dom(A).
body(id(14787,A),a5(A)) :- dom(A).
body(id(14787,A),a6(A)) :- dom(A).
body(id(14787,A),a7(A)) :- dom(A).
body(id(14787,A),age2(A)) :- dom(A).
body(id(14787,A),parent(A)) :- dom(A).
body(id(14787,A),white(A)) :- dom(A).
head(id(16665,A),autism(A)) :- dom(A).
body(id(16665,A),a1(A)) :- dom(A).
body(id(16665,A),a3(A)) :- dom(A).
body(id(16665,A),a4(A)) :- dom(A).
body(id(16665,A),a5(A)) :- dom(A).
body(id(16665,A),a6(A)) :- dom(A).
body(id(16665,A),age2(A)) :- dom(A).
body(id(16665,A),female(A)) :- dom(A).
body(id(16665,A),pdd(A)) :- dom(A).
head(id(18549,A),autism(A)) :- dom(A).
body(id(18549,A),a1(A)) :- dom(A).
body(id(18549,A),a2(A)) :- dom(A).
body(id(18549,A),a3(A)) :- dom(A).
body(id(18549,A),a5(A)) :- dom(A).
body(id(18549,A),a6(A)) :- dom(A).
body(id(18549,A),age3(A)) :- dom(A).
body(id(18549,A),self(A)) :- dom(A).
body(id(18549,A),white(A)) :- dom(A).
head(id(20438,A),autism(A)) :- dom(A).
body(id(20438,A),a1(A)) :- dom(A).
body(id(20438,A),a3(A)) :- dom(A).
body(id(20438,A),a4(A)) :- dom(A).
body(id(20438,A),a5(A)) :- dom(A).
body(id(20438,A),a6(A)) :- dom(A).
body(id(20438,A),age1(A)) :- dom(A).
body(id(20438,A),hispanic(A)) :- dom(A).
body(id(20438,A),self(A)) :- dom(A).
head(id(22335,A),autism(A)) :- dom(A).
body(id(22335,A),a1(A)) :- dom(A).
body(id(22335,A),a3(A)) :- dom(A).
body(id(22335,A),a4(A)) :- dom(A).
body(id(22335,A),a6(A)) :- dom(A).
body(id(22335,A),a7(A)) :- dom(A).
body(id(22335,A),age2(A)) :- dom(A).
body(id(22335,A),self(A)) :- dom(A).
body(id(22335,A),white(A)) :- dom(A).
head(id(24239,A),autism(A)) :- dom(A).
body(id(24239,A),a1(A)) :- dom(A).
body(id(24239,A),a3(A)) :- dom(A).
body(id(24239,A),a4(A)) :- dom(A).
body(id(24239,A),a5(A)) :- dom(A).
body(id(24239,A),a6(A)) :- dom(A).
body(id(24239,A),age3(A)) :- dom(A).
body(id(24239,A),female(A)) :- dom(A).
body(id(24239,A),parent(A)) :- dom(A).
body(id(24239,A),white(A)) :- dom(A).
head(id(26152,A),autism(A)) :- dom(A).
body(id(26152,A),a1(A)) :- dom(A).
body(id(26152,A),a4(A)) :- dom(A).
body(id(26152,A),a5(A)) :- dom(A).
body(id(26152,A),a6(A)) :- dom(A).
body(id(26152,A),a7(A)) :- dom(A).
body(id(26152,A),age2(A)) :- dom(A).
body(id(26152,A),female(A)) :- dom(A).
body(id(26152,A),self(A)) :- dom(A).
body(id(26152,A),white(A)) :- dom(A).
head(id(28073,A),autism(A)) :- dom(A).
body(id(28073,A),a1(A)) :- dom(A).
body(id(28073,A),a2(A)) :- dom(A).
body(id(28073,A),a3(A)) :- dom(A).
body(id(28073,A),a4(A)) :- dom(A).
body(id(28073,A),age3(A)) :- dom(A).
body(id(28073,A),black(A)) :- dom(A).
body(id(28073,A),female(A)) :- dom(A).
body(id(28073,A),parent(A)) :- dom(A).
body(id(28073,A),pdd(A)) :- dom(A).
head(id(30003,A),autism(A)) :- dom(A).
body(id(30003,A),a1(A)) :- dom(A).
body(id(30003,A),a2(A)) :- dom(A).
body(id(30003,A),a3(A)) :- dom(A).
body(id(30003,A),a4(A)) :- dom(A).
body(id(30003,A),a5(A)) :- dom(A).
body(id(30003,A),a6(A)) :- dom(A).
body(id(30003,A),age2(A)) :- dom(A).
body(id(30003,A),self(A)) :- dom(A).
body(id(30003,A),white(A)) :- dom(A).
head(id(31942,A),autism(A)) :- dom(A).
body(id(31942,A),a1(A)) :- dom(A).
body(id(31942,A),a2(A)) :- dom(A).
body(id(31942,A),a5(A)) :- dom(A).
body(id(31942,A),a6(A)) :- dom(A).
body(id(31942,A),a7(A)) :- dom(A).
body(id(31942,A),age2(A)) :- dom(A).
body(id(31942,A),black(A)) :- dom(A).
body(id(31942,A),female(A)) :- dom(A).
body(id(31942,A),self(A)) :- dom(A).
head(id(33890,A),autism(A)) :- dom(A).
body(id(33890,A),a1(A)) :- dom(A).
body(id(33890,A),a3(A)) :- dom(A).
body(id(33890,A),a4(A)) :- dom(A).
body(id(33890,A),a5(A)) :- dom(A).
body(id(33890,A),a6(A)) :- dom(A).
body(id(33890,A),age2(A)) :- dom(A).
body(id(33890,A),female(A)) :- dom(A).
body(id(33890,A),self(A)) :- dom(A).
body(id(33890,A),white(A)) :- dom(A).
head(id(35847,A),autism(A)) :- dom(A).
body(id(35847,A),a1(A)) :- dom(A).
body(id(35847,A),a3(A)) :- dom(A).
body(id(35847,A),a4(A)) :- dom(A).
body(id(35847,A),a5(A)) :- dom(A).
body(id(35847,A),a6(A)) :- dom(A).
body(id(35847,A),a7(A)) :- dom(A).
body(id(35847,A),age2(A)) :- dom(A).
body(id(35847,A),self(A)) :- dom(A).
body(id(35847,A),southasian(A)) :- dom(A).
head(id(37813,A),autism(A)) :- dom(A).
body(id(37813,A),a1(A)) :- dom(A).
body(id(37813,A),a2(A)) :- dom(A).
body(id(37813,A),a3(A)) :- dom(A).
body(id(37813,A),a4(A)) :- dom(A).
body(id(37813,A),a5(A)) :- dom(A).
body(id(37813,A),a6(A)) :- dom(A).
body(id(37813,A),age4(A)) :- dom(A).
body(id(37813,A),self(A)) :- dom(A).
body(id(37813,A),white(A)) :- dom(A).
head(id(39784,A),autism(A)) :- dom(A).
body(id(39784,A),a1(A)) :- dom(A).
body(id(39784,A),a4(A)) :- dom(A).
body(id(39784,A),a5(A)) :- dom(A).
body(id(39784,A),a6(A)) :- dom(A).
body(id(39784,A),a7(A)) :- dom(A).
body(id(39784,A),age3(A)) :- dom(A).
body(id(39784,A),asian(A)) :- dom(A).
body(id(39784,A),jaundice(A)) :- dom(A).
body(id(39784,A),self(A)) :- dom(A).
head(id(41764,A),autism(A)) :- dom(A).
body(id(41764,A),a1(A)) :- dom(A).
body(id(41764,A),a2(A)) :- dom(A).
body(id(41764,A),a3(A)) :- dom(A).
body(id(41764,A),a4(A)) :- dom(A).
body(id(41764,A),a6(A)) :- dom(A).
body(id(41764,A),age5(A)) :- dom(A).
body(id(41764,A),others(A)) :- dom(A).
body(id(41764,A),pdd(A)) :- dom(A).
body(id(41764,A),white(A)) :- dom(A).
head(id(43753,A),autism(A)) :- dom(A).
body(id(43753,A),a1(A)) :- dom(A).
body(id(43753,A),a3(A)) :- dom(A).
body(id(43753,A),a4(A)) :- dom(A).
body(id(43753,A),a5(A)) :- dom(A).
body(id(43753,A),a6(A)) :- dom(A).
body(id(43753,A),age5(A)) :- dom(A).
body(id(43753,A),female(A)) :- dom(A).
body(id(43753,A),relative(A)) :- dom(A).
body(id(43753,A),white(A)) :- dom(A).
head(id(45751,A),autism(A)) :- dom(A).
body(id(45751,A),a1(A)) :- dom(A).
body(id(45751,A),a3(A)) :- dom(A).
body(id(45751,A),a4(A)) :- dom(A).
body(id(45751,A),a6(A)) :- dom(A).
body(id(45751,A),a7(A)) :- dom(A).
body(id(45751,A),age2(A)) :- dom(A).
body(id(45751,A),female(A)) :- dom(A).
body(id(45751,A),others(A)) :- dom(A).
body(id(45751,A),self(A)) :- dom(A).
head(id(47757,A),autism(A)) :- dom(A).
body(id(47757,A),a1(A)) :- dom(A).
body(id(47757,A),a4(A)) :- dom(A).
body(id(47757,A),a5(A)) :- dom(A).
body(id(47757,A),a6(A)) :- dom(A).
body(id(47757,A),a7(A)) :- dom(A).
body(id(47757,A),age5(A)) :- dom(A).
body(id(47757,A),female(A)) :- dom(A).
body(id(47757,A),self(A)) :- dom(A).
body(id(47757,A),white(A)) :- dom(A).
head(id(49771,A),autism(A)) :- dom(A).
body(id(49771,A),a1(A)) :- dom(A).
body(id(49771,A),a2(A)) :- dom(A).
body(id(49771,A),a5(A)) :- dom(A).
body(id(49771,A),a6(A)) :- dom(A).
body(id(49771,A),a7(A)) :- dom(A).
body(id(49771,A),age2(A)) :- dom(A).
body(id(49771,A),female(A)) :- dom(A).
body(id(49771,A),self(A)) :- dom(A).
body(id(49771,A),white(A)) :- dom(A).
head(id(51794,A),autism(A)) :- dom(A).
body(id(51794,A),a1(A)) :- dom(A).
body(id(51794,A),a3(A)) :- dom(A).
body(id(51794,A),a4(A)) :- dom(A).
body(id(51794,A),a5(A)) :- dom(A).
body(id(51794,A),a6(A)) :- dom(A).
body(id(51794,A),a7(A)) :- dom(A).
body(id(51794,A),age3(A)) :- dom(A).
body(id(51794,A),self(A)) :- dom(A).
body(id(51794,A),white(A)) :- dom(A).
head(id(53824,A),autism(A)) :- dom(A).
body(id(53824,A),a1(A)) :- dom(A).
body(id(53824,A),a2(A)) :- dom(A).
body(id(53824,A),a3(A)) :- dom(A).
body(id(53824,A),a4(A)) :- dom(A).
body(id(53824,A),a5(A)) :- dom(A).
body(id(53824,A),a6(A)) :- dom(A).
body(id(53824,A),age2(A)) :- dom(A).
body(id(53824,A),female(A)) :- dom(A).
body(id(53824,A),others(A)) :- dom(A).
body(id(53824,A),self(A)) :- dom(A).
head(id(55864,A),autism(A)) :- dom(A).
body(id(55864,A),a1(A)) :- dom(A).
body(id(55864,A),a2(A)) :- dom(A).
body(id(55864,A),a3(A)) :- dom(A).
body(id(55864,A),a5(A)) :- dom(A).
body(id(55864,A),a6(A)) :- dom(A).
body(id(55864,A),a7(A)) :- dom(A).
body(id(55864,A),age5(A)) :- dom(A).
body(id(55864,A),jaundice(A)) :- dom(A).
body(id(55864,A),self(A)) :- dom(A).
body(id(55864,A),white(A)) :- dom(A).
head(id(57914,A),autism(A)) :- dom(A).
body(id(57914,A),a1(A)) :- dom(A).
body(id(57914,A),a3(A)) :- dom(A).
body(id(57914,A),a4(A)) :- dom(A).
body(id(57914,A),a5(A)) :- dom(A).
body(id(57914,A),a6(A)) :- dom(A).
body(id(57914,A),a7(A)) :- dom(A).
body(id(57914,A),age1(A)) :- dom(A).
body(id(57914,A),female(A)) :- dom(A).
body(id(57914,A),self(A)) :- dom(A).
body(id(57914,A),white(A)) :- dom(A).
head(id(59974,A),autism(A)) :- dom(A).
body(id(59974,A),a1(A)) :- dom(A).
body(id(59974,A),a2(A)) :- dom(A).
body(id(59974,A),a3(A)) :- dom(A).
body(id(59974,A),a4(A)) :- dom(A).
body(id(59974,A),a5(A)) :- dom(A).
body(id(59974,A),a6(A)) :- dom(A).
body(id(59974,A),age4(A)) :- dom(A).
body(id(59974,A),black(A)) :- dom(A).
body(id(59974,A),female(A)) :- dom(A).
body(id(59974,A),self(A)) :- dom(A).
head(id(62044,A),autism(A)) :- dom(A).
body(id(62044,A),a1(A)) :- dom(A).
body(id(62044,A),a2(A)) :- dom(A).
body(id(62044,A),a3(A)) :- dom(A).
body(id(62044,A),a4(A)) :- dom(A).
body(id(62044,A),a5(A)) :- dom(A).
body(id(62044,A),a7(A)) :- dom(A).
body(id(62044,A),age3(A)) :- dom(A).
body(id(62044,A),jaundice(A)) :- dom(A).
body(id(62044,A),others(A)) :- dom(A).
body(id(62044,A),self(A)) :- dom(A).
head(id(64124,A),autism(A)) :- dom(A).
body(id(64124,A),a1(A)) :- dom(A).
body(id(64124,A),a4(A)) :- dom(A).
body(id(64124,A),a5(A)) :- dom(A).
body(id(64124,A),a6(A)) :- dom(A).
body(id(64124,A),a7(A)) :- dom(A).
body(id(64124,A),age3(A)) :- dom(A).
body(id(64124,A),female(A)) :- dom(A).
body(id(64124,A),pdd(A)) :- dom(A).
body(id(64124,A),self(A)) :- dom(A).
body(id(64124,A),white(A)) :- dom(A).
head(id(66214,A),autism(A)) :- dom(A).
body(id(66214,A),a1(A)) :- dom(A).
body(id(66214,A),a3(A)) :- dom(A).
body(id(66214,A),a4(A)) :- dom(A).
body(id(66214,A),a5(A)) :- dom(A).
body(id(66214,A),a6(A)) :- dom(A).
body(id(66214,A),a7(A)) :- dom(A).
body(id(66214,A),age2(A)) :- dom(A).
body(id(66214,A),latino(A)) :- dom(A).
body(id(66214,A),pdd(A)) :- dom(A).
body(id(66214,A),self(A)) :- dom(A).
head(id(68314,A),autism(A)) :- dom(A).
body(id(68314,A),a1(A)) :- dom(A).
body(id(68314,A),a2(A)) :- dom(A).
body(id(68314,A),a3(A)) :- dom(A).
body(id(68314,A),a4(A)) :- dom(A).
body(id(68314,A),a5(A)) :- dom(A).
body(id(68314,A),age4(A)) :- dom(A).
body(id(68314,A),female(A)) :- dom(A).
body(id(68314,A),pdd(A)) :- dom(A).
body(id(68314,A),self(A)) :- dom(A).
body(id(68314,A),white(A)) :- dom(A).
head(id(70424,A),autism(A)) :- dom(A).
body(id(70424,A),a1(A)) :- dom(A).
body(id(70424,A),a2(A)) :- dom(A).
body(id(70424,A),a3(A)) :- dom(A).
body(id(70424,A),a4(A)) :- dom(A).
body(id(70424,A),a5(A)) :- dom(A).
body(id(70424,A),a6(A)) :- dom(A).
body(id(70424,A),age3(A)) :- dom(A).
body(id(70424,A),asian(A)) :- dom(A).
body(id(70424,A),female(A)) :- dom(A).
body(id(70424,A),self(A)) :- dom(A).
head(id(72544,A),autism(A)) :- dom(A).
body(id(72544,A),a1(A)) :- dom(A).
body(id(72544,A),a2(A)) :- dom(A).
body(id(72544,A),a3(A)) :- dom(A).
body(id(72544,A),a4(A)) :- dom(A).
body(id(72544,A),a5(A)) :- dom(A).
body(id(72544,A),a6(A)) :- dom(A).
body(id(72544,A),a7(A)) :- dom(A).
body(id(72544,A),age5(A)) :- dom(A).
body(id(72544,A),self(A)) :- dom(A).
body(id(72544,A),white(A)) :- dom(A).
head(id(74674,A),autism(A)) :- dom(A).
body(id(74674,A),a1(A)) :- dom(A).
body(id(74674,A),a2(A)) :- dom(A).
body(id(74674,A),a4(A)) :- dom(A).
body(id(74674,A),a5(A)) :- dom(A).
body(id(74674,A),a7(A)) :- dom(A).
body(id(74674,A),age2(A)) :- dom(A).
body(id(74674,A),jaundice(A)) :- dom(A).
body(id(74674,A),latino(A)) :- dom(A).
body(id(74674,A),parent(A)) :- dom(A).
body(id(74674,A),pdd(A)) :- dom(A).
head(id(76814,A),autism(A)) :- dom(A).
body(id(76814,A),a1(A)) :- dom(A).
body(id(76814,A),a2(A)) :- dom(A).
body(id(76814,A),a4(A)) :- dom(A).
body(id(76814,A),a5(A)) :- dom(A).
body(id(76814,A),a6(A)) :- dom(A).
body(id(76814,A),age5(A)) :- dom(A).
body(id(76814,A),female(A)) :- dom(A).
body(id(76814,A),pdd(A)) :- dom(A).
body(id(76814,A),self(A)) :- dom(A).
body(id(76814,A),white(A)) :- dom(A).
head(id(78964,A),autism(A)) :- dom(A).
body(id(78964,A),a1(A)) :- dom(A).
body(id(78964,A),a3(A)) :- dom(A).
body(id(78964,A),a4(A)) :- dom(A).
body(id(78964,A),a6(A)) :- dom(A).
body(id(78964,A),a7(A)) :- dom(A).
body(id(78964,A),age3(A)) :- dom(A).
body(id(78964,A),female(A)) :- dom(A).
body(id(78964,A),pdd(A)) :- dom(A).
body(id(78964,A),self(A)) :- dom(A).
body(id(78964,A),white(A)) :- dom(A).
head(id(81124,A),autism(A)) :- dom(A).
body(id(81124,A),a1(A)) :- dom(A).
body(id(81124,A),a2(A)) :- dom(A).
body(id(81124,A),a3(A)) :- dom(A).
body(id(81124,A),a4(A)) :- dom(A).
body(id(81124,A),a5(A)) :- dom(A).
body(id(81124,A),a6(A)) :- dom(A).
body(id(81124,A),age5(A)) :- dom(A).
body(id(81124,A),female(A)) :- dom(A).
body(id(81124,A),middleeastern(A)) :- dom(A).
body(id(81124,A),self(A)) :- dom(A).
head(id(83294,A),autism(A)) :- dom(A).
body(id(83294,A),a1(A)) :- dom(A).
body(id(83294,A),a2(A)) :- dom(A).
body(id(83294,A),a3(A)) :- dom(A).
body(id(83294,A),a4(A)) :- dom(A).
body(id(83294,A),a5(A)) :- dom(A).
body(id(83294,A),age3(A)) :- dom(A).
body(id(83294,A),female(A)) :- dom(A).
body(id(83294,A),latino(A)) :- dom(A).
body(id(83294,A),pdd(A)) :- dom(A).
body(id(83294,A),self(A)) :- dom(A).
head(id(85474,A),autism(A)) :- dom(A).
body(id(85474,A),a1(A)) :- dom(A).
body(id(85474,A),a2(A)) :- dom(A).
body(id(85474,A),a3(A)) :- dom(A).
body(id(85474,A),a4(A)) :- dom(A).
body(id(85474,A),a5(A)) :- dom(A).
body(id(85474,A),a6(A)) :- dom(A).
body(id(85474,A),age1(A)) :- dom(A).
body(id(85474,A),female(A)) :- dom(A).
body(id(85474,A),jaundice(A)) :- dom(A).
body(id(85474,A),parent(A)) :- dom(A).
body(id(85474,A),white(A)) :- dom(A).
head(id(87665,A),autism(A)) :- dom(A).
body(id(87665,A),a1(A)) :- dom(A).
body(id(87665,A),a2(A)) :- dom(A).
body(id(87665,A),a3(A)) :- dom(A).
body(id(87665,A),a4(A)) :- dom(A).
body(id(87665,A),a6(A)) :- dom(A).
body(id(87665,A),a7(A)) :- dom(A).
body(id(87665,A),age1(A)) :- dom(A).
body(id(87665,A),asian(A)) :- dom(A).
body(id(87665,A),hcprofessional(A)) :- dom(A).
body(id(87665,A),jaundice(A)) :- dom(A).
body(id(87665,A),pdd(A)) :- dom(A).
head(id(89867,A),autism(A)) :- dom(A).
body(id(89867,A),a1(A)) :- dom(A).
body(id(89867,A),a2(A)) :- dom(A).
body(id(89867,A),a3(A)) :- dom(A).
body(id(89867,A),a4(A)) :- dom(A).
body(id(89867,A),a5(A)) :- dom(A).
body(id(89867,A),a6(A)) :- dom(A).
body(id(89867,A),a7(A)) :- dom(A).
body(id(89867,A),age2(A)) :- dom(A).
body(id(89867,A),middleeastern(A)) :- dom(A).
body(id(89867,A),parent(A)) :- dom(A).
body(id(89867,A),pdd(A)) :- dom(A).
head(id(92080,A),autism(A)) :- dom(A).
body(id(92080,A),a1(A)) :- dom(A).
body(id(92080,A),a2(A)) :- dom(A).
body(id(92080,A),a3(A)) :- dom(A).
body(id(92080,A),a4(A)) :- dom(A).
body(id(92080,A),a5(A)) :- dom(A).
body(id(92080,A),a7(A)) :- dom(A).
body(id(92080,A),age3(A)) :- dom(A).
body(id(92080,A),jaundice(A)) :- dom(A).
body(id(92080,A),pdd(A)) :- dom(A).
body(id(92080,A),self(A)) :- dom(A).
body(id(92080,A),white(A)) :- dom(A).
head(id(94304,A),autism(A)) :- dom(A).
body(id(94304,A),a1(A)) :- dom(A).
body(id(94304,A),a2(A)) :- dom(A).
body(id(94304,A),a3(A)) :- dom(A).
body(id(94304,A),a4(A)) :- dom(A).
body(id(94304,A),a5(A)) :- dom(A).
body(id(94304,A),a6(A)) :- dom(A).
body(id(94304,A),a7(A)) :- dom(A).
body(id(94304,A),age1(A)) :- dom(A).
body(id(94304,A),asian(A)) :- dom(A).
body(id(94304,A),jaundice(A)) :- dom(A).
body(id(94304,A),relative(A)) :- dom(A).
head(id(96539,A),autism(A)) :- dom(A).
body(id(96539,A),a1(A)) :- dom(A).
body(id(96539,A),a2(A)) :- dom(A).
body(id(96539,A),a3(A)) :- dom(A).
body(id(96539,A),a4(A)) :- dom(A).
body(id(96539,A),a5(A)) :- dom(A).
body(id(96539,A),a6(A)) :- dom(A).
body(id(96539,A),a7(A)) :- dom(A).
body(id(96539,A),age3(A)) :- dom(A).
body(id(96539,A),black(A)) :- dom(A).
body(id(96539,A),female(A)) :- dom(A).
body(id(96539,A),parent(A)) :- dom(A).
head(id(98785,A),autism(A)) :- dom(A).
body(id(98785,A),a1(A)) :- dom(A).
body(id(98785,A),a2(A)) :- dom(A).
body(id(98785,A),a3(A)) :- dom(A).
body(id(98785,A),a4(A)) :- dom(A).
body(id(98785,A),a5(A)) :- dom(A).
body(id(98785,A),a6(A)) :- dom(A).
body(id(98785,A),a7(A)) :- dom(A).
body(id(98785,A),age6(A)) :- dom(A).
body(id(98785,A),female(A)) :- dom(A).
body(id(98785,A),pdd(A)) :- dom(A).
body(id(98785,A),relative(A)) :- dom(A).
body(id(98785,A),white(A)) :- dom(A).

dom(1).
dom(2).
dom(3).
dom(4).
dom(5).
dom(6).
dom(7).
dom(8).
dom(9).
dom(10).
dom(14).
dom(15).
dom(16).
dom(17).
dom(18).
dom(20).
dom(22).
dom(23).
dom(24).
dom(27).
dom(28).
dom(29).
dom(30).
dom(32).
dom(34).
dom(35).
dom(36).
dom(37).
dom(39).
dom(40).
dom(43).
dom(44).
dom(45).
dom(46).
dom(48).
dom(49).
dom(51).
dom(52).
dom(53).
dom(54).
dom(55).
dom(56).
dom(57).
dom(58).
dom(60).
dom(61).
dom(62).
dom(63).
dom(64).
dom(66).
dom(67).
dom(68).
dom(70).
dom(71).
dom(72).
dom(74).
dom(77).
dom(78).
dom(79).
dom(80).
dom(81).
dom(82).
dom(83).
dom(84).
dom(85).
dom(86).
dom(88).
dom(89).
dom(90).
dom(91).
dom(93).
dom(95).
dom(96).
dom(97).
dom(98).
dom(99).
dom(100).
dom(101).
dom(102).
dom(103).
dom(104).
dom(106).
dom(107).
dom(109).
dom(110).
dom(111).
dom(113).
dom(114).
dom(116).
dom(117).
dom(118).
dom(120).
dom(121).
dom(122).
dom(123).
dom(124).
dom(125).
dom(126).
dom(127).
dom(129).
dom(131).
dom(133).
dom(134).
dom(135).
dom(136).
dom(137).
dom(138).
dom(139).
dom(140).
dom(142).
dom(143).
dom(144).
dom(145).
dom(146).
dom(148).
dom(150).
dom(151).
dom(153).
dom(155).
dom(157).
dom(158).
dom(159).
dom(160).
dom(163).
dom(164).
dom(165).
dom(166).
dom(167).
dom(168).
dom(169).
dom(170).
dom(171).
dom(173).
dom(175).
dom(177).
dom(178).
dom(179).
dom(180).
dom(181).
dom(182).
dom(183).
dom(184).
dom(185).
dom(186).
dom(187).
dom(188).
dom(189).
dom(190).
dom(191).
dom(192).
dom(193).
dom(194).
dom(195).
dom(196).
dom(197).
dom(198).
dom(199).
dom(200).
dom(201).
dom(203).
dom(204).
dom(206).
dom(207).
dom(208).
dom(209).
dom(210).
dom(211).
dom(212).
dom(213).
dom(214).
dom(215).
dom(216).
dom(217).
dom(218).
dom(219).
dom(220).
dom(221).
dom(222).
dom(223).
dom(224).
dom(225).
dom(226).
dom(227).
dom(228).
dom(232).
dom(233).
dom(235).
dom(236).
dom(237).
dom(238).
dom(239).
dom(240).
dom(241).
dom(242).
dom(244).
dom(246).
dom(247).
dom(248).
dom(249).
dom(252).
dom(254).
dom(256).
dom(257).
dom(258).
dom(259).
dom(260).
dom(261).
dom(262).
dom(264).
dom(265).
dom(266).
dom(267).
dom(268).
dom(269).
dom(270).
dom(271).
dom(272).
dom(273).
dom(274).
dom(275).
dom(276).
dom(277).
dom(279).
dom(280).
dom(281).
dom(284).
dom(286).
dom(287).
dom(289).
dom(290).
dom(291).
dom(292).
dom(293).
dom(294).
dom(295).
dom(297).
dom(298).
dom(299).
dom(300).
dom(302).
dom(303).
dom(304).
dom(305).
dom(306).
dom(308).
dom(309).
dom(310).
dom(311).
dom(312).
dom(313).
dom(314).
dom(315).
dom(316).
dom(317).
