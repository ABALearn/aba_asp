head(id(1),a4(11)).
head(id(2),a5(11)).
head(id(3),a6(11)).
head(id(4),lo(54)).
head(id(5),a4(54)).
head(id(6),a5(54)).
head(id(7),a6(54)).
head(id(8),lo(37)).
head(id(9),a4(37)).
head(id(10),hi(84)).
head(id(11),a2(84)).
head(id(12),a3(84)).
head(id(13),a4(84)).
head(id(14),a5(84)).
head(id(15),a6(84)).
head(id(16),hi(80)).
head(id(17),a2(80)).
head(id(18),a3(80)).
head(id(19),a4(80)).
head(id(20),a5(80)).
head(id(21),a6(80)).
head(id(22),a4(14)).
head(id(23),a5(14)).
head(id(24),a6(14)).
head(id(25),hi(89)).
head(id(26),a2(89)).
head(id(27),a3(89)).
head(id(28),a4(89)).
head(id(29),a5(89)).
head(id(30),a4(21)).
head(id(31),a5(21)).
head(id(32),hi(100)).
head(id(33),a2(100)).
head(id(34),a3(100)).
head(id(35),a4(100)).
head(id(36),a5(100)).
head(id(37),hi(71)).
head(id(38),a2(71)).
head(id(39),a3(71)).
head(id(40),a4(71)).
head(id(41),a5(71)).
head(id(42),a6(71)).
head(id(43),a4(9)).
head(id(44),a5(9)).
head(id(45),a6(9)).
head(id(46),hi(85)).
head(id(47),a2(85)).
head(id(48),a3(85)).
head(id(49),a4(85)).
head(id(50),a5(85)).
head(id(51),a4(22)).
head(id(52),a5(22)).
head(id(53),a4(26)).
head(id(54),a5(26)).
head(id(55),a6(26)).
head(id(56),a4(30)).
head(id(57),a5(30)).
head(id(58),a6(30)).
head(id(59),lo(57)).
head(id(60),a4(57)).
head(id(61),a5(57)).
head(id(62),a4(17)).
head(id(63),a5(17)).
head(id(64),a6(17)).
head(id(65),lo(50)).
head(id(66),a4(50)).
head(id(67),a5(50)).
head(id(68),hi(99)).
head(id(69),a2(99)).
head(id(70),a3(99)).
head(id(71),a4(99)).
head(id(72),a5(99)).
head(id(73),hi(90)).
head(id(74),a2(90)).
head(id(75),a3(90)).
head(id(76),a4(90)).
head(id(77),a5(90)).
head(id(78),a6(90)).
head(id(79),lo(49)).
head(id(80),a4(49)).
head(id(81),a5(49)).
head(id(82),lo(44)).
head(id(83),a4(44)).
head(id(84),lo(40)).
head(id(85),a4(40)).
head(id(86),a5(40)).
head(id(87),mo(66)).
head(id(88),a3(66)).
head(id(89),a4(66)).
head(id(90),a6(66)).
head(id(91),mo(64)).
head(id(92),a3(64)).
head(id(93),a4(64)).
head(id(94),a6(64)).
head(id(95),hi(82)).
head(id(96),a2(82)).
head(id(97),a3(82)).
head(id(98),a5(82)).
head(id(99),hi(78)).
head(id(100),a3(78)).
head(id(101),a4(78)).
head(id(102),a6(78)).
head(id(103),hi(96)).
head(id(104),a2(96)).
head(id(105),a3(96)).
head(id(106),a5(96)).
head(id(107),vh(110)).
head(id(108),a3(110)).
head(id(109),a4(110)).
head(id(110),a6(110)).
head(id(111),hi(95)).
head(id(112),vh(113)).
head(id(113),a2(113)).
head(id(114),a3(113)).
head(id(115),a5(113)).
head(id(116),hi(88)).
head(id(117),a2(88)).
head(id(118),a3(88)).
head(id(119),a5(88)).
head(id(120),lo(53)).
head(id(121),a3(53)).
head(id(122),a3(23)).
head(id(123),a3(16)).
head(id(124),a3(3)).
head(id(125),mo(68)).
head(id(126),a3(68)).
head(id(127),a4(68)).
head(id(128),a6(68)).
head(id(129),a3(5)).
head(id(130),hi(87)).
head(id(131),hi(75)).
head(id(132),vh(114)).
head(id(133),a3(114)).
head(id(134),a4(114)).
head(id(135),a6(114)).
head(id(136),a3(1)).
head(id(137),lo(38)).
head(id(138),a3(38)).
head(id(139),hi(76)).
head(id(140),a2(76)).
head(id(141),a3(76)).
head(id(142),a5(76)).
head(id(143),a3(8)).
head(id(144),hi(97)).
head(id(145),a3(97)).
head(id(146),a4(97)).
head(id(147),a6(97)).
head(id(148),lo(35)).
head(id(149),a3(35)).
head(id(150),hi(103)).
head(id(674,A),acute(A)) :- dom(A).
body(id(674,A),alpha_1(A)) :- dom(A).
body(id(674,A),a4(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).

dom(1).
dom(3).
dom(5).
dom(8).
dom(9).
dom(11).
dom(14).
dom(16).
dom(17).
dom(21).
dom(22).
dom(23).
dom(26).
dom(30).
dom(35).
dom(37).
dom(38).
dom(40).
dom(44).
dom(49).
dom(50).
dom(53).
dom(54).
dom(57).
dom(64).
dom(66).
dom(68).
dom(71).
dom(75).
dom(76).
dom(78).
dom(80).
dom(82).
dom(84).
dom(85).
dom(87).
dom(88).
dom(89).
dom(90).
dom(95).
dom(96).
dom(97).
dom(99).
dom(100).
dom(103).
dom(110).
dom(113).
dom(114).
 :- not supported(acute(11)).
 :- not supported(acute(54)).
 :- not supported(acute(37)).
 :- not supported(acute(84)).
 :- not supported(acute(80)).
 :- not supported(acute(14)).
 :- not supported(acute(89)).
 :- not supported(acute(21)).
 :- not supported(acute(100)).
 :- not supported(acute(71)).
 :- not supported(acute(9)).
 :- not supported(acute(85)).
 :- not supported(acute(22)).
 :- not supported(acute(26)).
 :- not supported(acute(30)).
 :- not supported(acute(57)).
 :- not supported(acute(17)).
 :- not supported(acute(50)).
 :- not supported(acute(99)).
 :- not supported(acute(90)).
 :- not supported(acute(49)).
 :- not supported(acute(44)).
 :- not supported(acute(40)).
 :- supported(acute(66)).
 :- supported(acute(64)).
 :- supported(acute(82)).
 :- supported(acute(78)).
 :- supported(acute(96)).
 :- supported(acute(110)).
 :- supported(acute(95)).
 :- supported(acute(113)).
 :- supported(acute(88)).
 :- supported(acute(53)).
 :- supported(acute(23)).
 :- supported(acute(16)).
 :- supported(acute(3)).
 :- supported(acute(68)).
 :- supported(acute(5)).
 :- supported(acute(87)).
 :- supported(acute(75)).
 :- supported(acute(114)).
 :- supported(acute(1)).
 :- supported(acute(38)).
 :- supported(acute(76)).
 :- supported(acute(8)).
 :- supported(acute(97)).
 :- supported(acute(35)).
 :- supported(acute(103)).
