head(id(1),cap_shapef(6363)).
head(id(2),cap_surfaces(6363)).
head(id(3),cap_colore(6363)).
head(id(4),odorf(6363)).
head(id(5),gill_spacing(6363)).
head(id(6),gill_size(6363)).
head(id(7),gill_colorb(6363)).
head(id(8),stalk_surface_above_rings(6363)).
head(id(9),stalk_surface_below_ringk(6363)).
head(id(10),stalk_color_above_ringw(6363)).
head(id(11),stalk_color_below_ringp(6363)).
head(id(12),veil_colorw(6363)).
head(id(13),ring_numbero(6363)).
head(id(14),ring_typee(6363)).
head(id(15),spore_print_colorw(6363)).
head(id(16),populationv(6363)).
head(id(17),habitatl(6363)).
head(id(18),cap_surfaces(4107)).
head(id(19),cap_colorb(4107)).
head(id(20),bruises(4107)).
head(id(21),odorn(4107)).
head(id(22),gill_spacing(4107)).
head(id(23),gill_colorg(4107)).
head(id(24),stalk_rootb(4107)).
head(id(25),stalk_surface_above_rings(4107)).
head(id(26),stalk_surface_below_rings(4107)).
head(id(27),stalk_color_above_ringw(4107)).
head(id(28),stalk_color_below_ringw(4107)).
head(id(29),veil_colorw(4107)).
head(id(30),spore_print_colorr(4107)).
head(id(31),populationv(4107)).
head(id(32),habitatm(4107)).
head(id(33),cap_shapex(5522)).
head(id(34),cap_colorn(5522)).
head(id(35),odors(5522)).
head(id(36),gill_spacing(5522)).
head(id(37),gill_size(5522)).
head(id(38),gill_colorb(5522)).
head(id(39),stalk_surface_above_ringk(5522)).
head(id(40),stalk_surface_below_ringk(5522)).
head(id(41),stalk_color_above_ringw(5522)).
head(id(42),stalk_color_below_ringw(5522)).
head(id(43),veil_colorw(5522)).
head(id(44),ring_numbero(5522)).
head(id(45),ring_typee(5522)).
head(id(46),spore_print_colorw(5522)).
head(id(47),populationv(5522)).
head(id(48),habitatd(5522)).
head(id(49),cap_shapex(4271)).
head(id(50),cap_surfacef(4271)).
head(id(51),odorf(4271)).
head(id(52),gill_spacing(4271)).
head(id(53),gill_colorg(4271)).
head(id(54),stalk_rootb(4271)).
head(id(55),stalk_surface_above_ringk(4271)).
head(id(56),stalk_surface_below_ringk(4271)).
head(id(57),stalk_color_above_ringb(4271)).
head(id(58),stalk_color_below_ringp(4271)).
head(id(59),veil_colorw(4271)).
head(id(60),ring_numbero(4271)).
head(id(61),ring_typel(4271)).
head(id(62),spore_print_colorh(4271)).
head(id(63),populationv(4271)).
head(id(64),habitatp(4271)).
head(id(65),cap_shapex(4499)).
head(id(66),cap_colorn(4499)).
head(id(67),gill_spacing(4499)).
head(id(68),gill_size(4499)).
head(id(69),gill_colorb(4499)).
head(id(70),stalk_surface_above_rings(4499)).
head(id(71),stalk_surface_below_ringk(4499)).
head(id(72),stalk_color_above_ringp(4499)).
head(id(73),stalk_color_below_ringp(4499)).
head(id(74),veil_colorw(4499)).
head(id(75),ring_numbero(4499)).
head(id(76),ring_typee(4499)).
head(id(77),spore_print_colorw(4499)).
head(id(78),populationv(4499)).
head(id(79),habitatp(4499)).
head(id(80),cap_shapec(5509)).
head(id(81),cap_colorw(5509)).
head(id(82),bruises(5509)).
head(id(83),odorn(5509)).
head(id(84),gill_size(5509)).
head(id(85),gill_colorw(5509)).
head(id(86),stalk_rootb(5509)).
head(id(87),stalk_surface_above_rings(5509)).
head(id(88),stalk_surface_below_rings(5509)).
head(id(89),stalk_color_above_ringw(5509)).
head(id(90),stalk_color_below_ringw(5509)).
head(id(91),veil_colorw(5509)).
head(id(92),ring_numbero(5509)).
head(id(93),spore_print_colorw(5509)).
head(id(94),populationc(5509)).
head(id(95),habitatl(5509)).
head(id(96),cap_shapef(6946)).
head(id(97),cap_colore(6946)).
head(id(98),odorm(6946)).
head(id(99),gill_attachment(6946)).
head(id(100),gill_spacing(6946)).
head(id(101),gill_colorw(6946)).
head(id(102),stalk_rootc(6946)).
head(id(103),stalk_surface_above_ringk(6946)).
head(id(104),stalk_color_above_ringc(6946)).
head(id(105),stalk_color_below_ringc(6946)).
head(id(106),veil_colorw(6946)).
head(id(107),ring_numbern(6946)).
head(id(108),ring_typen(6946)).
head(id(109),spore_print_colorw(6946)).
head(id(110),populationc(6946)).
head(id(111),habitatd(6946)).
head(id(112),cap_shapex(3338)).
head(id(113),cap_surfacef(3338)).
head(id(114),cap_colorw(3338)).
head(id(115),odorc(3338)).
head(id(116),gill_size(3338)).
head(id(117),gill_colorg(3338)).
head(id(118),stalk_rootb(3338)).
head(id(119),stalk_surface_above_rings(3338)).
head(id(120),stalk_surface_below_rings(3338)).
head(id(121),stalk_color_above_ringw(3338)).
head(id(122),stalk_color_below_ringw(3338)).
head(id(123),veil_colorw(3338)).
head(id(124),ring_numbero(3338)).
head(id(125),spore_print_colork(3338)).
head(id(126),populationv(3338)).
head(id(127),habitatd(3338)).
head(id(128),cap_shapef(6507)).
head(id(129),cap_colore(6507)).
head(id(130),odorf(6507)).
head(id(131),gill_spacing(6507)).
head(id(132),gill_size(6507)).
head(id(133),gill_colorb(6507)).
head(id(134),stalk_surface_above_rings(6507)).
head(id(135),stalk_surface_below_rings(6507)).
head(id(136),stalk_color_above_ringp(6507)).
head(id(137),stalk_color_below_ringp(6507)).
head(id(138),veil_colorw(6507)).
head(id(139),ring_numbero(6507)).
head(id(140),ring_typee(6507)).
head(id(141),spore_print_colorw(6507)).
head(id(142),populationv(6507)).
head(id(143),habitatp(6507)).
head(id(144),cap_shapef(6341)).
head(id(145),cap_colore(6341)).
head(id(146),odorf(6341)).
head(id(147),gill_spacing(6341)).
head(id(148),gill_size(6341)).
head(id(149),gill_colorb(6341)).
head(id(150),stalk_surface_above_rings(6341)).
head(id(151),stalk_surface_below_ringk(6341)).
head(id(152),stalk_color_above_ringp(6341)).
head(id(153),stalk_color_below_ringw(6341)).
head(id(154),veil_colorw(6341)).
head(id(155),ring_numbero(6341)).
head(id(156),ring_typee(6341)).
head(id(157),spore_print_colorw(6341)).
head(id(158),populationv(6341)).
head(id(159),habitatd(6341)).
head(id(160),cap_shapek(7422)).
head(id(161),cap_colorn(7422)).
head(id(162),odors(7422)).
head(id(163),gill_spacing(7422)).
head(id(164),gill_size(7422)).
head(id(165),gill_colorb(7422)).
head(id(166),stalk_surface_above_rings(7422)).
head(id(167),stalk_surface_below_rings(7422)).
head(id(168),stalk_color_above_ringp(7422)).
head(id(169),stalk_color_below_ringw(7422)).
head(id(170),veil_colorw(7422)).
head(id(171),ring_numbero(7422)).
head(id(172),ring_typee(7422)).
head(id(173),spore_print_colorw(7422)).
head(id(174),populationv(7422)).
head(id(175),habitatd(7422)).
head(id(176),cap_shapex(4595)).
head(id(177),cap_surfacef(4595)).
head(id(178),odorf(4595)).
head(id(179),gill_spacing(4595)).
head(id(180),gill_colorh(4595)).
head(id(181),stalk_rootb(4595)).
head(id(182),stalk_surface_above_ringk(4595)).
head(id(183),stalk_surface_below_ringk(4595)).
head(id(184),stalk_color_above_ringb(4595)).
head(id(185),stalk_color_below_ringp(4595)).
head(id(186),veil_colorw(4595)).
head(id(187),ring_numbero(4595)).
head(id(188),ring_typel(4595)).
head(id(189),spore_print_colorh(4595)).
head(id(190),populationv(4595)).
head(id(191),habitatd(4595)).
head(id(192),cap_shapex(6456)).
head(id(193),cap_surfaces(6456)).
head(id(194),cap_colorn(6456)).
head(id(195),odorf(6456)).
head(id(196),gill_spacing(6456)).
head(id(197),gill_size(6456)).
head(id(198),gill_colorb(6456)).
head(id(199),stalk_surface_above_ringk(6456)).
head(id(200),stalk_surface_below_ringk(6456)).
head(id(201),stalk_color_above_ringp(6456)).
head(id(202),stalk_color_below_ringp(6456)).
head(id(203),veil_colorw(6456)).
head(id(204),ring_numbero(6456)).
head(id(205),ring_typee(6456)).
head(id(206),spore_print_colorw(6456)).
head(id(207),populationv(6456)).
head(id(208),habitatp(6456)).
head(id(209),cap_shapef(4513)).
head(id(210),cap_surfacef(4513)).
head(id(211),odorf(4513)).
head(id(212),gill_spacing(4513)).
head(id(213),gill_colorh(4513)).
head(id(214),stalk_rootb(4513)).
head(id(215),stalk_surface_above_ringk(4513)).
head(id(216),stalk_surface_below_ringk(4513)).
head(id(217),stalk_color_above_ringb(4513)).
head(id(218),stalk_color_below_ringp(4513)).
head(id(219),veil_colorw(4513)).
head(id(220),ring_numbero(4513)).
head(id(221),ring_typel(4513)).
head(id(222),spore_print_colorh(4513)).
head(id(223),habitatp(4513)).
head(id(224),cap_shapex(3436)).
head(id(225),cap_surfacef(3436)).
head(id(226),cap_colorg(3436)).
head(id(227),odorc(3436)).
head(id(228),gill_size(3436)).
head(id(229),gill_colorg(3436)).
head(id(230),stalk_rootb(3436)).
head(id(231),stalk_surface_above_rings(3436)).
head(id(232),stalk_surface_below_rings(3436)).
head(id(233),stalk_color_above_ringw(3436)).
head(id(234),stalk_color_below_ringw(3436)).
head(id(235),veil_colorw(3436)).
head(id(236),ring_numbero(3436)).
head(id(237),spore_print_colorn(3436)).
head(id(238),populationv(3436)).
head(id(239),habitatd(3436)).
head(id(240),cap_shapex(4725)).
head(id(241),cap_surfacef(4725)).
head(id(242),odorf(4725)).
head(id(243),gill_spacing(4725)).
head(id(244),gill_colorp(4725)).
head(id(245),stalk_rootb(4725)).
head(id(246),stalk_surface_above_ringk(4725)).
head(id(247),stalk_surface_below_ringk(4725)).
head(id(248),stalk_color_above_ringb(4725)).
head(id(249),stalk_color_below_ringp(4725)).
head(id(250),veil_colorw(4725)).
head(id(251),ring_numbero(4725)).
head(id(252),ring_typel(4725)).
head(id(253),spore_print_colorh(4725)).
head(id(254),habitatd(4725)).
head(id(255),cap_shapex(4341)).
head(id(256),cap_colorg(4341)).
head(id(257),odorf(4341)).
head(id(258),gill_spacing(4341)).
head(id(259),gill_colorg(4341)).
head(id(260),stalk_rootb(4341)).
head(id(261),stalk_surface_above_ringk(4341)).
head(id(262),stalk_surface_below_ringk(4341)).
head(id(263),stalk_color_above_ringp(4341)).
head(id(264),stalk_color_below_ringn(4341)).
head(id(265),veil_colorw(4341)).
head(id(266),ring_numbero(4341)).
head(id(267),ring_typel(4341)).
head(id(268),spore_print_colorh(4341)).
head(id(269),habitatg(4341)).
head(id(270),cap_shapef(4195)).
head(id(271),cap_surfaces(4195)).
head(id(272),cap_colorb(4195)).
head(id(273),bruises(4195)).
head(id(274),odorf(4195)).
head(id(275),gill_spacing(4195)).
head(id(276),gill_colorw(4195)).
head(id(277),stalk_rootb(4195)).
head(id(278),stalk_surface_above_ringf(4195)).
head(id(279),stalk_surface_below_ringf(4195)).
head(id(280),stalk_color_above_ringw(4195)).
head(id(281),stalk_color_below_ringw(4195)).
head(id(282),veil_colorw(4195)).
head(id(283),ring_numbero(4195)).
head(id(284),spore_print_colorh(4195)).
head(id(285),populations(4195)).
head(id(286),habitatu(4195)).
head(id(287),cap_shapex(4477)).
head(id(288),odorf(4477)).
head(id(289),gill_spacing(4477)).
head(id(290),gill_colorp(4477)).
head(id(291),stalk_rootb(4477)).
head(id(292),stalk_surface_above_ringk(4477)).
head(id(293),stalk_surface_below_ringk(4477)).
head(id(294),stalk_color_above_ringb(4477)).
head(id(295),stalk_color_below_ringn(4477)).
head(id(296),veil_colorw(4477)).
head(id(297),ring_numbero(4477)).
head(id(298),ring_typel(4477)).
head(id(299),spore_print_colorh(4477)).
head(id(300),populationv(4477)).
head(id(301),habitatp(4477)).
head(id(302),cap_shapex(5816)).
head(id(303),cap_colorn(5816)).
head(id(304),odors(5816)).
head(id(305),gill_spacing(5816)).
head(id(306),gill_size(5816)).
head(id(307),gill_colorb(5816)).
head(id(308),stalk_surface_above_ringk(5816)).
head(id(309),stalk_surface_below_ringk(5816)).
head(id(310),stalk_color_above_ringp(5816)).
head(id(311),stalk_color_below_ringp(5816)).
head(id(312),veil_colorw(5816)).
head(id(313),ring_numbero(5816)).
head(id(314),ring_typee(5816)).
head(id(315),spore_print_colorw(5816)).
head(id(316),populationv(5816)).
head(id(317),habitatl(5816)).
head(id(318),cap_shapex(6443)).
head(id(319),cap_surfaces(6443)).
head(id(320),cap_colorn(6443)).
head(id(321),gill_spacing(6443)).
head(id(322),gill_size(6443)).
head(id(323),gill_colorb(6443)).
head(id(324),stalk_surface_above_rings(6443)).
head(id(325),stalk_surface_below_rings(6443)).
head(id(326),stalk_color_above_ringw(6443)).
head(id(327),stalk_color_below_ringw(6443)).
head(id(328),veil_colorw(6443)).
head(id(329),ring_numbero(6443)).
head(id(330),ring_typee(6443)).
head(id(331),spore_print_colorw(6443)).
head(id(332),populationv(6443)).
head(id(333),habitatl(6443)).
head(id(334),cap_shapek(7047)).
head(id(335),cap_surfacef(7047)).
head(id(336),cap_colorg(7047)).
head(id(337),odorn(7047)).
head(id(338),gill_colorp(7047)).
head(id(339),stalk_surface_above_rings(7047)).
head(id(340),stalk_surface_below_ringk(7047)).
head(id(341),stalk_color_above_ringw(7047)).
head(id(342),stalk_color_below_ringw(7047)).
head(id(343),veil_colorw(7047)).
head(id(344),spore_print_colorw(7047)).
head(id(345),populationn(7047)).
head(id(346),habitatg(7047)).
head(id(347),cap_colorw(209)).
head(id(348),bruises(209)).
head(id(349),odorl(209)).
head(id(350),gill_spacing(209)).
head(id(351),gill_colorn(209)).
head(id(352),stalk_rootc(209)).
head(id(353),stalk_surface_above_rings(209)).
head(id(354),stalk_surface_below_rings(209)).
head(id(355),stalk_color_above_ringw(209)).
head(id(356),stalk_color_below_ringw(209)).
head(id(357),veil_colorw(209)).
head(id(358),ring_numbero(209)).
head(id(359),spore_print_colorn(209)).
head(id(360),populationn(209)).
head(id(361),habitatg(209)).
head(id(362),cap_shapek(8106)).
head(id(363),cap_surfaces(8106)).
head(id(364),cap_colorn(8106)).
head(id(365),odorn(8106)).
head(id(366),gill_attachment(8106)).
head(id(367),gill_spacing(8106)).
head(id(368),stalk_surface_above_rings(8106)).
head(id(369),stalk_surface_below_rings(8106)).
head(id(370),stalk_color_above_ringo(8106)).
head(id(371),stalk_color_below_ringo(8106)).
head(id(372),veil_colorn(8106)).
head(id(373),ring_numbero(8106)).
head(id(374),populationv(8106)).
head(id(375),habitatl(8106)).
head(id(376),cap_shapex(3047)).
head(id(377),cap_colore(3047)).
head(id(378),bruises(3047)).
head(id(379),odorn(3047)).
head(id(380),gill_spacing(3047)).
head(id(381),gill_colorn(3047)).
head(id(382),stalk_rootb(3047)).
head(id(383),stalk_surface_above_rings(3047)).
head(id(384),stalk_surface_below_rings(3047)).
head(id(385),stalk_color_above_ringp(3047)).
head(id(386),stalk_color_below_ringp(3047)).
head(id(387),veil_colorw(3047)).
head(id(388),ring_numbero(3047)).
head(id(389),spore_print_colork(3047)).
head(id(390),populationv(3047)).
head(id(391),habitatd(3047)).
head(id(392),cap_shapek(6763)).
head(id(393),cap_surfacef(6763)).
head(id(394),cap_colorg(6763)).
head(id(395),odorn(6763)).
head(id(396),gill_colorp(6763)).
head(id(397),stalk_surface_above_ringk(6763)).
head(id(398),stalk_surface_below_rings(6763)).
head(id(399),stalk_color_above_ringw(6763)).
head(id(400),stalk_color_below_ringw(6763)).
head(id(401),veil_colorw(6763)).
head(id(402),spore_print_colorw(6763)).
head(id(403),populations(6763)).
head(id(404),habitatg(6763)).
head(id(405),cap_shapex(2011)).
head(id(406),cap_surfaces(2011)).
head(id(407),cap_colorn(2011)).
head(id(408),odorn(2011)).
head(id(409),gill_colork(2011)).
head(id(410),stalk_roote(2011)).
head(id(411),stalk_surface_above_ringf(2011)).
head(id(412),stalk_surface_below_ringf(2011)).
head(id(413),stalk_color_above_ringw(2011)).
head(id(414),stalk_color_below_ringw(2011)).
head(id(415),veil_colorw(2011)).
head(id(416),ring_numbero(2011)).
head(id(417),ring_typee(2011)).
head(id(418),spore_print_colorn(2011)).
head(id(419),populationa(2011)).
head(id(420),habitatg(2011)).
head(id(421),cap_shapek(7571)).
head(id(422),cap_surfaces(7571)).
head(id(423),cap_colorn(7571)).
head(id(424),odorn(7571)).
head(id(425),gill_spacing(7571)).
head(id(426),gill_colorw(7571)).
head(id(427),stalk_rootb(7571)).
head(id(428),stalk_color_above_ringn(7571)).
head(id(429),stalk_color_below_ringn(7571)).
head(id(430),veil_colorw(7571)).
head(id(431),spore_print_colorw(7571)).
head(id(432),habitatp(7571)).
head(id(433),cap_shapef(1328)).
head(id(434),cap_surfaces(1328)).
head(id(435),cap_colorg(1328)).
head(id(436),odorn(1328)).
head(id(437),gill_colork(1328)).
head(id(438),stalk_roote(1328)).
head(id(439),stalk_surface_above_ringf(1328)).
head(id(440),stalk_surface_below_ringf(1328)).
head(id(441),stalk_color_above_ringw(1328)).
head(id(442),stalk_color_below_ringw(1328)).
head(id(443),veil_colorw(1328)).
head(id(444),ring_numbero(1328)).
head(id(445),ring_typee(1328)).
head(id(446),spore_print_colorn(1328)).
head(id(447),populationa(1328)).
head(id(448),habitatg(1328)).
head(id(449),cap_shapef(4912)).
head(id(450),cap_surfaces(4912)).
head(id(451),cap_colore(4912)).
head(id(452),bruises(4912)).
head(id(453),odorn(4912)).
head(id(454),gill_spacing(4912)).
head(id(455),gill_colorw(4912)).
head(id(456),stalk_surface_above_rings(4912)).
head(id(457),stalk_surface_below_rings(4912)).
head(id(458),stalk_color_above_ringw(4912)).
head(id(459),stalk_color_below_ringe(4912)).
head(id(460),veil_colorw(4912)).
head(id(461),ring_typee(4912)).
head(id(462),spore_print_colorw(4912)).
head(id(463),populationc(4912)).
head(id(464),cap_shapef(2681)).
head(id(465),cap_surfacef(2681)).
head(id(466),cap_colorn(2681)).
head(id(467),bruises(2681)).
head(id(468),odorn(2681)).
head(id(469),gill_spacing(2681)).
head(id(470),gill_colorp(2681)).
head(id(471),stalk_rootb(2681)).
head(id(472),stalk_surface_above_rings(2681)).
head(id(473),stalk_surface_below_rings(2681)).
head(id(474),stalk_color_above_ringp(2681)).
head(id(475),stalk_color_below_ringp(2681)).
head(id(476),veil_colorw(2681)).
head(id(477),ring_numbero(2681)).
head(id(478),spore_print_colorn(2681)).
head(id(479),populationv(2681)).
head(id(480),habitatd(2681)).
head(id(481),cap_shapes(782)).
head(id(482),cap_surfacef(782)).
head(id(483),cap_colorn(782)).
head(id(484),odorn(782)).
head(id(485),gill_spacing(782)).
head(id(486),gill_size(782)).
head(id(487),gill_colorg(782)).
head(id(488),stalk_roote(782)).
head(id(489),stalk_surface_above_rings(782)).
head(id(490),stalk_surface_below_rings(782)).
head(id(491),stalk_color_above_ringw(782)).
head(id(492),stalk_color_below_ringw(782)).
head(id(493),veil_colorw(782)).
head(id(494),ring_numbero(782)).
head(id(495),spore_print_colork(782)).
head(id(496),habitatu(782)).
head(id(497),cap_shapex(1331)).
head(id(498),cap_surfacef(1331)).
head(id(499),cap_colorg(1331)).
head(id(500),odorn(1331)).
head(id(501),gill_colork(1331)).
head(id(502),stalk_roote(1331)).
head(id(503),stalk_surface_above_rings(1331)).
head(id(504),stalk_surface_below_rings(1331)).
head(id(505),stalk_color_above_ringw(1331)).
head(id(506),stalk_color_below_ringw(1331)).
head(id(507),veil_colorw(1331)).
head(id(508),ring_numbero(1331)).
head(id(509),ring_typee(1331)).
head(id(510),spore_print_colork(1331)).
head(id(511),populations(1331)).
head(id(512),habitatg(1331)).
head(id(513),cap_shapex(2137)).
head(id(514),cap_colorg(2137)).
head(id(515),bruises(2137)).
head(id(516),odorn(2137)).
head(id(517),gill_spacing(2137)).
head(id(518),gill_colorw(2137)).
head(id(519),stalk_rootb(2137)).
head(id(520),stalk_surface_above_rings(2137)).
head(id(521),stalk_surface_below_rings(2137)).
head(id(522),stalk_color_above_ringg(2137)).
head(id(523),stalk_color_below_ringw(2137)).
head(id(524),veil_colorw(2137)).
head(id(525),ring_numbero(2137)).
head(id(526),spore_print_colorn(2137)).
head(id(527),populationv(2137)).
head(id(528),habitatd(2137)).
head(id(529),cap_shapex(2472)).
head(id(530),cap_surfacef(2472)).
head(id(531),cap_colorg(2472)).
head(id(532),bruises(2472)).
head(id(533),odorn(2472)).
head(id(534),gill_spacing(2472)).
head(id(535),gill_colorp(2472)).
head(id(536),stalk_rootb(2472)).
head(id(537),stalk_surface_above_rings(2472)).
head(id(538),stalk_surface_below_rings(2472)).
head(id(539),stalk_color_above_ringw(2472)).
head(id(540),stalk_color_below_ringg(2472)).
head(id(541),veil_colorw(2472)).
head(id(542),ring_numbero(2472)).
head(id(543),spore_print_colorn(2472)).
head(id(544),populationv(2472)).
head(id(545),habitatd(2472)).
head(id(546),cap_shapef(3143)).
head(id(547),cap_colorg(3143)).
head(id(548),bruises(3143)).
head(id(549),odorn(3143)).
head(id(550),gill_spacing(3143)).
head(id(551),gill_colorw(3143)).
head(id(552),stalk_rootb(3143)).
head(id(553),stalk_surface_above_rings(3143)).
head(id(554),stalk_surface_below_rings(3143)).
head(id(555),stalk_color_above_ringp(3143)).
head(id(556),stalk_color_below_ringp(3143)).
head(id(557),veil_colorw(3143)).
head(id(558),ring_numbero(3143)).
head(id(559),spore_print_colork(3143)).
head(id(560),habitatd(3143)).
head(id(561),cap_shapef(3635)).
head(id(562),cap_colorn(3635)).
head(id(563),bruises(3635)).
head(id(564),odorn(3635)).
head(id(565),gill_spacing(3635)).
head(id(566),gill_colorn(3635)).
head(id(567),stalk_rootb(3635)).
head(id(568),stalk_surface_above_rings(3635)).
head(id(569),stalk_surface_below_rings(3635)).
head(id(570),stalk_color_above_ringw(3635)).
head(id(571),stalk_color_below_ringp(3635)).
head(id(572),veil_colorw(3635)).
head(id(573),ring_numbero(3635)).
head(id(574),spore_print_colorn(3635)).
head(id(575),populationv(3635)).
head(id(576),habitatd(3635)).
head(id(577),cap_shapex(1530)).
head(id(578),cap_surfaces(1530)).
head(id(579),cap_colorw(1530)).
head(id(580),odorn(1530)).
head(id(581),gill_colorn(1530)).
head(id(582),stalk_roote(1530)).
head(id(583),stalk_surface_above_ringf(1530)).
head(id(584),stalk_surface_below_ringf(1530)).
head(id(585),stalk_color_above_ringw(1530)).
head(id(586),stalk_color_below_ringw(1530)).
head(id(587),veil_colorw(1530)).
head(id(588),ring_numbero(1530)).
head(id(589),ring_typee(1530)).
head(id(590),spore_print_colork(1530)).
head(id(591),populationa(1530)).
head(id(592),habitatg(1530)).
head(id(593),cap_shapex(7538)).
head(id(594),cap_surfaces(7538)).
head(id(595),cap_colorn(7538)).
head(id(596),odorn(7538)).
head(id(597),gill_attachment(7538)).
head(id(598),gill_spacing(7538)).
head(id(599),stalk_surface_above_rings(7538)).
head(id(600),stalk_surface_below_rings(7538)).
head(id(601),stalk_color_above_ringo(7538)).
head(id(602),stalk_color_below_ringo(7538)).
head(id(603),veil_coloro(7538)).
head(id(604),ring_numbero(7538)).
head(id(605),populationc(7538)).
head(id(606),habitatl(7538)).
head(id(607),cap_shapex(2575)).
head(id(608),cap_colorn(2575)).
head(id(609),bruises(2575)).
head(id(610),odorn(2575)).
head(id(611),gill_spacing(2575)).
head(id(612),gill_colorp(2575)).
head(id(613),stalk_rootb(2575)).
head(id(614),stalk_surface_above_rings(2575)).
head(id(615),stalk_surface_below_rings(2575)).
head(id(616),stalk_color_above_ringg(2575)).
head(id(617),stalk_color_below_ringw(2575)).
head(id(618),veil_colorw(2575)).
head(id(619),ring_numbero(2575)).
head(id(620),spore_print_colork(2575)).
head(id(621),populationv(2575)).
head(id(622),habitatd(2575)).
head(id(2556,A),poisoned(A)) :- dom(A).
body(id(2556,A),alpha_1(A)) :- dom(A).
body(id(2556,A),cap_shapef(A)) :- dom(A).
head(id(4517,A),poisoned(A)) :- dom(A).
body(id(4517,A),alpha_2(A)) :- dom(A).
body(id(4517,A),cap_surfaces(A)) :- dom(A).
head(id(6511,A),poisoned(A)) :- dom(A).
body(id(6511,A),alpha_3(A)) :- dom(A).
body(id(6511,A),cap_shapex(A)) :- dom(A).
head(id(9209,A),poisoned(A)) :- dom(A).
body(id(9209,A),cap_shapec(A)) :- dom(A).
head(id(13911,A),poisoned(A)) :- dom(A).
body(id(13911,A),alpha_4(A)) :- dom(A).
body(id(13911,A),cap_shapek(A)) :- dom(A).
head(id(23326,A),c_alpha_1(A)) :- dom(A).
body(id(23326,A),cap_surfaces(A)) :- dom(A).
head(id(26678,A),c_alpha_1(A)) :- dom(A).
body(id(26678,A),alpha_5(A)) :- dom(A).
body(id(26678,A),cap_surfacef(A)) :- dom(A).
head(id(29382,A),c_alpha_1(A)) :- dom(A).
body(id(29382,A),cap_colorg(A)) :- dom(A).
head(id(32087,A),c_alpha_1(A)) :- dom(A).
body(id(32087,A),cap_colorn(A)) :- dom(A).
head(id(36823,A),c_alpha_2(A)) :- dom(A).
body(id(36823,A),cap_colorg(A)) :- dom(A).
head(id(38175,A),c_alpha_2(A)) :- dom(A).
body(id(38175,A),cap_shapex(A)) :- dom(A).
head(id(43596,A),c_alpha_2(A)) :- dom(A).
body(id(43596,A),alpha_6(A)) :- dom(A).
body(id(43596,A),cap_colore(A)) :- dom(A).
head(id(45640,A),c_alpha_2(A)) :- dom(A).
body(id(45640,A),cap_shapek(A)) :- dom(A).
head(id(51093,A),c_alpha_3(A)) :- dom(A).
body(id(51093,A),alpha_7(A)) :- dom(A).
body(id(51093,A),cap_colorg(A)) :- dom(A).
head(id(55910,A),c_alpha_3(A)) :- dom(A).
body(id(55910,A),alpha_8(A)) :- dom(A).
body(id(55910,A),cap_colorw(A)) :- dom(A).
head(id(60762,A),c_alpha_3(A)) :- dom(A).
body(id(60762,A),alpha_9(A)) :- dom(A).
body(id(60762,A),cap_colorn(A)) :- dom(A).
head(id(65655,A),c_alpha_3(A)) :- dom(A).
body(id(65655,A),cap_colore(A)) :- dom(A).
head(id(69146,A),c_alpha_4(A)) :- dom(A).
body(id(69146,A),cap_surfacef(A)) :- dom(A).
head(id(72637,A),c_alpha_4(A)) :- dom(A).
body(id(72637,A),cap_surfaces(A)) :- dom(A).
head(id(74729,A),c_alpha_5(A)) :- dom(A).
body(id(74729,A),cap_shapef(A)) :- dom(A).
head(id(80328,A),c_alpha_6(A)) :- dom(A).
body(id(80328,A),odorf(A)) :- dom(A).
head(id(85935,A),c_alpha_7(A)) :- dom(A).
body(id(85935,A),odorc(A)) :- dom(A).
head(id(90145,A),c_alpha_7(A)) :- dom(A).
body(id(90145,A),odorf(A)) :- dom(A).
head(id(92954,A),c_alpha_8(A)) :- dom(A).
body(id(92954,A),cap_surfacef(A)) :- dom(A).
head(id(97880,A),c_alpha_9(A)) :- dom(A).
body(id(97880,A),alpha_10(A)) :- dom(A).
body(id(97880,A),gill_spacing(A)) :- dom(A).
head(id(104943,A),c_alpha_10(A)) :- dom(A).
body(id(104943,A),bruises(A)) :- dom(A).
head(id(110598,A),c_alpha_10(A)) :- dom(A).
body(id(110598,A),odorn(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
assumption(alpha_4(A)) :- dom(A).
assumption(alpha_5(A)) :- dom(A).
assumption(alpha_6(A)) :- dom(A).
assumption(alpha_7(A)) :- dom(A).
assumption(alpha_8(A)) :- dom(A).
assumption(alpha_9(A)) :- dom(A).
assumption(alpha_10(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).
contrary(alpha_4(A),c_alpha_4(A)) :- assumption(alpha_4(A)).
contrary(alpha_5(A),c_alpha_5(A)) :- assumption(alpha_5(A)).
contrary(alpha_6(A),c_alpha_6(A)) :- assumption(alpha_6(A)).
contrary(alpha_7(A),c_alpha_7(A)) :- assumption(alpha_7(A)).
contrary(alpha_8(A),c_alpha_8(A)) :- assumption(alpha_8(A)).
contrary(alpha_9(A),c_alpha_9(A)) :- assumption(alpha_9(A)).
contrary(alpha_10(A),c_alpha_10(A)) :- assumption(alpha_10(A)).

dom(209).
dom(782).
dom(1328).
dom(1331).
dom(1530).
dom(2011).
dom(2137).
dom(2472).
dom(2575).
dom(2681).
dom(3047).
dom(3143).
dom(3338).
dom(3436).
dom(3635).
dom(4107).
dom(4195).
dom(4271).
dom(4341).
dom(4477).
dom(4499).
dom(4513).
dom(4595).
dom(4725).
dom(4912).
dom(5509).
dom(5522).
dom(5816).
dom(6341).
dom(6363).
dom(6443).
dom(6456).
dom(6507).
dom(6763).
dom(6946).
dom(7047).
dom(7422).
dom(7538).
dom(7571).
dom(8106).
