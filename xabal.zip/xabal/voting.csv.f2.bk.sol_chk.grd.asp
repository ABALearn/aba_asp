head(id(1),physician_fee_freeze(301)).
head(id(2),el_salvador_aid(301)).
head(id(3),anti_satellite_test_ban(301)).
head(id(4),aid_to_nicaraguan_contras(301)).
head(id(5),mx_missile(301)).
head(id(6),immigration(301)).
head(id(7),education_spending(301)).
head(id(8),superfund_right_to_sue(301)).
head(id(9),crime(301)).
head(id(10),export_administration_act_south_africa(301)).
head(id(11),handicapped_infants(405)).
head(id(12),water_project_cost_sharing(405)).
head(id(13),physician_fee_freeze(405)).
head(id(14),el_salvador_aid(405)).
head(id(15),religious_groups_in_schools(405)).
head(id(16),immigration(405)).
head(id(17),education_spending(405)).
head(id(18),superfund_right_to_sue(405)).
head(id(19),crime(405)).
head(id(20),export_administration_act_south_africa(405)).
head(id(21),physician_fee_freeze(143)).
head(id(22),el_salvador_aid(143)).
head(id(23),religious_groups_in_schools(143)).
head(id(24),anti_satellite_test_ban(143)).
head(id(25),aid_to_nicaraguan_contras(143)).
head(id(26),mx_missile(143)).
head(id(27),immigration(143)).
head(id(28),education_spending(143)).
head(id(29),superfund_right_to_sue(143)).
head(id(30),crime(143)).
head(id(31),export_administration_act_south_africa(143)).
head(id(32),physician_fee_freeze(357)).
head(id(33),el_salvador_aid(357)).
head(id(34),religious_groups_in_schools(357)).
head(id(35),education_spending(357)).
head(id(36),superfund_right_to_sue(357)).
head(id(37),crime(357)).
head(id(38),physician_fee_freeze(240)).
head(id(39),el_salvador_aid(240)).
head(id(40),religious_groups_in_schools(240)).
head(id(41),anti_satellite_test_ban(240)).
head(id(42),immigration(240)).
head(id(43),crime(240)).
head(id(44),duty_free_exports(240)).
head(id(45),export_administration_act_south_africa(240)).
head(id(46),physician_fee_freeze(406)).
head(id(47),el_salvador_aid(406)).
head(id(48),religious_groups_in_schools(406)).
head(id(49),education_spending(406)).
head(id(50),superfund_right_to_sue(406)).
head(id(51),crime(406)).
head(id(52),export_administration_act_south_africa(406)).
head(id(53),handicapped_infants(74)).
head(id(54),budget_resolution(74)).
head(id(55),physician_fee_freeze(74)).
head(id(56),el_salvador_aid(74)).
head(id(57),anti_satellite_test_ban(74)).
head(id(58),mx_missile(74)).
head(id(59),immigration(74)).
head(id(60),superfund_right_to_sue(74)).
head(id(61),crime(74)).
head(id(62),export_administration_act_south_africa(74)).
head(id(63),physician_fee_freeze(88)).
head(id(64),el_salvador_aid(88)).
head(id(65),religious_groups_in_schools(88)).
head(id(66),education_spending(88)).
head(id(67),superfund_right_to_sue(88)).
head(id(68),crime(88)).
head(id(69),physician_fee_freeze(341)).
head(id(70),el_salvador_aid(341)).
head(id(71),religious_groups_in_schools(341)).
head(id(72),immigration(341)).
head(id(73),synfuels_corporation_cutback(341)).
head(id(74),education_spending(341)).
head(id(75),crime(341)).
head(id(76),export_administration_act_south_africa(341)).
head(id(77),physician_fee_freeze(303)).
head(id(78),el_salvador_aid(303)).
head(id(79),religious_groups_in_schools(303)).
head(id(80),anti_satellite_test_ban(303)).
head(id(81),immigration(303)).
head(id(82),education_spending(303)).
head(id(83),superfund_right_to_sue(303)).
head(id(84),crime(303)).
head(id(85),export_administration_act_south_africa(303)).
head(id(86),water_project_cost_sharing(147)).
head(id(87),physician_fee_freeze(147)).
head(id(88),el_salvador_aid(147)).
head(id(89),religious_groups_in_schools(147)).
head(id(90),education_spending(147)).
head(id(91),superfund_right_to_sue(147)).
head(id(92),crime(147)).
head(id(93),export_administration_act_south_africa(147)).
head(id(94),handicapped_infants(365)).
head(id(95),water_project_cost_sharing(365)).
head(id(96),physician_fee_freeze(365)).
head(id(97),el_salvador_aid(365)).
head(id(98),religious_groups_in_schools(365)).
head(id(99),synfuels_corporation_cutback(365)).
head(id(100),superfund_right_to_sue(365)).
head(id(101),crime(365)).
head(id(102),export_administration_act_south_africa(365)).
head(id(103),handicapped_infants(38)).
head(id(104),water_project_cost_sharing(38)).
head(id(105),physician_fee_freeze(38)).
head(id(106),el_salvador_aid(38)).
head(id(107),religious_groups_in_schools(38)).
head(id(108),superfund_right_to_sue(38)).
head(id(109),crime(38)).
head(id(110),export_administration_act_south_africa(38)).
head(id(111),water_project_cost_sharing(57)).
head(id(112),physician_fee_freeze(57)).
head(id(113),el_salvador_aid(57)).
head(id(114),religious_groups_in_schools(57)).
head(id(115),immigration(57)).
head(id(116),synfuels_corporation_cutback(57)).
head(id(117),education_spending(57)).
head(id(118),superfund_right_to_sue(57)).
head(id(119),crime(57)).
head(id(120),export_administration_act_south_africa(57)).
head(id(121),handicapped_infants(118)).
head(id(122),water_project_cost_sharing(118)).
head(id(123),budget_resolution(118)).
head(id(124),physician_fee_freeze(118)).
head(id(125),el_salvador_aid(118)).
head(id(126),anti_satellite_test_ban(118)).
head(id(127),education_spending(118)).
head(id(128),superfund_right_to_sue(118)).
head(id(129),crime(118)).
head(id(130),export_administration_act_south_africa(118)).
head(id(131),handicapped_infants(29)).
head(id(132),physician_fee_freeze(29)).
head(id(133),el_salvador_aid(29)).
head(id(134),anti_satellite_test_ban(29)).
head(id(135),aid_to_nicaraguan_contras(29)).
head(id(136),mx_missile(29)).
head(id(137),education_spending(29)).
head(id(138),superfund_right_to_sue(29)).
head(id(139),crime(29)).
head(id(140),export_administration_act_south_africa(29)).
head(id(141),water_project_cost_sharing(231)).
head(id(142),physician_fee_freeze(231)).
head(id(143),el_salvador_aid(231)).
head(id(144),religious_groups_in_schools(231)).
head(id(145),education_spending(231)).
head(id(146),superfund_right_to_sue(231)).
head(id(147),crime(231)).
head(id(148),export_administration_act_south_africa(231)).
head(id(149),physician_fee_freeze(306)).
head(id(150),el_salvador_aid(306)).
head(id(151),religious_groups_in_schools(306)).
head(id(152),immigration(306)).
head(id(153),education_spending(306)).
head(id(154),superfund_right_to_sue(306)).
head(id(155),crime(306)).
head(id(156),handicapped_infants(393)).
head(id(157),water_project_cost_sharing(393)).
head(id(158),physician_fee_freeze(393)).
head(id(159),el_salvador_aid(393)).
head(id(160),religious_groups_in_schools(393)).
head(id(161),synfuels_corporation_cutback(393)).
head(id(162),education_spending(393)).
head(id(163),superfund_right_to_sue(393)).
head(id(164),crime(393)).
head(id(165),export_administration_act_south_africa(393)).
head(id(166),handicapped_infants(348)).
head(id(167),physician_fee_freeze(348)).
head(id(168),el_salvador_aid(348)).
head(id(169),religious_groups_in_schools(348)).
head(id(170),immigration(348)).
head(id(171),education_spending(348)).
head(id(172),superfund_right_to_sue(348)).
head(id(173),crime(348)).
head(id(174),handicapped_infants(151)).
head(id(175),water_project_cost_sharing(151)).
head(id(176),physician_fee_freeze(151)).
head(id(177),el_salvador_aid(151)).
head(id(178),religious_groups_in_schools(151)).
head(id(179),immigration(151)).
head(id(180),education_spending(151)).
head(id(181),superfund_right_to_sue(151)).
head(id(182),crime(151)).
head(id(183),export_administration_act_south_africa(151)).
head(id(184),physician_fee_freeze(267)).
head(id(185),el_salvador_aid(267)).
head(id(186),religious_groups_in_schools(267)).
head(id(187),immigration(267)).
head(id(188),education_spending(267)).
head(id(189),crime(267)).
head(id(190),export_administration_act_south_africa(267)).
head(id(191),physician_fee_freeze(347)).
head(id(192),el_salvador_aid(347)).
head(id(193),religious_groups_in_schools(347)).
head(id(194),immigration(347)).
head(id(195),education_spending(347)).
head(id(196),superfund_right_to_sue(347)).
head(id(197),crime(347)).
head(id(198),export_administration_act_south_africa(347)).
head(id(199),physician_fee_freeze(134)).
head(id(200),el_salvador_aid(134)).
head(id(201),religious_groups_in_schools(134)).
head(id(202),immigration(134)).
head(id(203),education_spending(134)).
head(id(204),superfund_right_to_sue(134)).
head(id(205),crime(134)).
head(id(206),export_administration_act_south_africa(134)).
head(id(207),budget_resolution(201)).
head(id(208),anti_satellite_test_ban(201)).
head(id(209),aid_to_nicaraguan_contras(201)).
head(id(210),mx_missile(201)).
head(id(211),crime(201)).
head(id(212),duty_free_exports(201)).
head(id(213),export_administration_act_south_africa(201)).
head(id(214),handicapped_infants(420)).
head(id(215),water_project_cost_sharing(420)).
head(id(216),budget_resolution(420)).
head(id(217),anti_satellite_test_ban(420)).
head(id(218),aid_to_nicaraguan_contras(420)).
head(id(219),mx_missile(420)).
head(id(220),export_administration_act_south_africa(420)).
head(id(221),water_project_cost_sharing(153)).
head(id(222),budget_resolution(153)).
head(id(223),religious_groups_in_schools(153)).
head(id(224),aid_to_nicaraguan_contras(153)).
head(id(225),mx_missile(153)).
head(id(226),immigration(153)).
head(id(227),synfuels_corporation_cutback(153)).
head(id(228),superfund_right_to_sue(153)).
head(id(229),duty_free_exports(153)).
head(id(230),export_administration_act_south_africa(153)).
head(id(231),water_project_cost_sharing(366)).
head(id(232),el_salvador_aid(366)).
head(id(233),religious_groups_in_schools(366)).
head(id(234),immigration(366)).
head(id(235),synfuels_corporation_cutback(366)).
head(id(236),superfund_right_to_sue(366)).
head(id(237),crime(366)).
head(id(238),water_project_cost_sharing(89)).
head(id(239),budget_resolution(89)).
head(id(240),el_salvador_aid(89)).
head(id(241),religious_groups_in_schools(89)).
head(id(242),anti_satellite_test_ban(89)).
head(id(243),mx_missile(89)).
head(id(244),immigration(89)).
head(id(245),synfuels_corporation_cutback(89)).
head(id(246),superfund_right_to_sue(89)).
head(id(247),crime(89)).
head(id(248),export_administration_act_south_africa(89)).
head(id(249),budget_resolution(154)).
head(id(250),religious_groups_in_schools(154)).
head(id(251),anti_satellite_test_ban(154)).
head(id(252),aid_to_nicaraguan_contras(154)).
head(id(253),mx_missile(154)).
head(id(254),immigration(154)).
head(id(255),synfuels_corporation_cutback(154)).
head(id(256),superfund_right_to_sue(154)).
head(id(257),crime(154)).
head(id(258),export_administration_act_south_africa(154)).
head(id(259),water_project_cost_sharing(176)).
head(id(260),budget_resolution(176)).
head(id(261),anti_satellite_test_ban(176)).
head(id(262),aid_to_nicaraguan_contras(176)).
head(id(263),mx_missile(176)).
head(id(264),immigration(176)).
head(id(265),duty_free_exports(176)).
head(id(266),export_administration_act_south_africa(176)).
head(id(267),water_project_cost_sharing(220)).
head(id(268),budget_resolution(220)).
head(id(269),aid_to_nicaraguan_contras(220)).
head(id(270),mx_missile(220)).
head(id(271),synfuels_corporation_cutback(220)).
head(id(272),crime(220)).
head(id(273),duty_free_exports(220)).
head(id(274),export_administration_act_south_africa(220)).
head(id(275),handicapped_infants(384)).
head(id(276),water_project_cost_sharing(384)).
head(id(277),budget_resolution(384)).
head(id(278),el_salvador_aid(384)).
head(id(279),religious_groups_in_schools(384)).
head(id(280),aid_to_nicaraguan_contras(384)).
head(id(281),mx_missile(384)).
head(id(282),immigration(384)).
head(id(283),synfuels_corporation_cutback(384)).
head(id(284),export_administration_act_south_africa(384)).
head(id(285),handicapped_infants(40)).
head(id(286),budget_resolution(40)).
head(id(287),anti_satellite_test_ban(40)).
head(id(288),aid_to_nicaraguan_contras(40)).
head(id(289),mx_missile(40)).
head(id(290),immigration(40)).
head(id(291),synfuels_corporation_cutback(40)).
head(id(292),superfund_right_to_sue(40)).
head(id(293),duty_free_exports(40)).
head(id(294),export_administration_act_south_africa(40)).
head(id(295),budget_resolution(227)).
head(id(296),religious_groups_in_schools(227)).
head(id(297),anti_satellite_test_ban(227)).
head(id(298),aid_to_nicaraguan_contras(227)).
head(id(299),mx_missile(227)).
head(id(300),synfuels_corporation_cutback(227)).
head(id(301),crime(227)).
head(id(302),duty_free_exports(227)).
head(id(303),export_administration_act_south_africa(227)).
head(id(304),water_project_cost_sharing(369)).
head(id(305),budget_resolution(369)).
head(id(306),religious_groups_in_schools(369)).
head(id(307),anti_satellite_test_ban(369)).
head(id(308),aid_to_nicaraguan_contras(369)).
head(id(309),immigration(369)).
head(id(310),duty_free_exports(369)).
head(id(311),export_administration_act_south_africa(369)).
head(id(312),water_project_cost_sharing(78)).
head(id(313),budget_resolution(78)).
head(id(314),physician_fee_freeze(78)).
head(id(315),el_salvador_aid(78)).
head(id(316),religious_groups_in_schools(78)).
head(id(317),aid_to_nicaraguan_contras(78)).
head(id(318),mx_missile(78)).
head(id(319),immigration(78)).
head(id(320),synfuels_corporation_cutback(78)).
head(id(321),education_spending(78)).
head(id(322),superfund_right_to_sue(78)).
head(id(323),crime(78)).
head(id(324),export_administration_act_south_africa(78)).
head(id(325),handicapped_infants(190)).
head(id(326),budget_resolution(190)).
head(id(327),anti_satellite_test_ban(190)).
head(id(328),aid_to_nicaraguan_contras(190)).
head(id(329),mx_missile(190)).
head(id(330),duty_free_exports(190)).
head(id(331),export_administration_act_south_africa(190)).
head(id(332),handicapped_infants(242)).
head(id(333),budget_resolution(242)).
head(id(334),anti_satellite_test_ban(242)).
head(id(335),aid_to_nicaraguan_contras(242)).
head(id(336),mx_missile(242)).
head(id(337),immigration(242)).
head(id(338),synfuels_corporation_cutback(242)).
head(id(339),crime(242)).
head(id(340),duty_free_exports(242)).
head(id(341),export_administration_act_south_africa(242)).
head(id(342),handicapped_infants(170)).
head(id(343),budget_resolution(170)).
head(id(344),anti_satellite_test_ban(170)).
head(id(345),aid_to_nicaraguan_contras(170)).
head(id(346),mx_missile(170)).
head(id(347),immigration(170)).
head(id(348),synfuels_corporation_cutback(170)).
head(id(349),crime(170)).
head(id(350),export_administration_act_south_africa(170)).
head(id(351),handicapped_infants(415)).
head(id(352),water_project_cost_sharing(415)).
head(id(353),budget_resolution(415)).
head(id(354),anti_satellite_test_ban(415)).
head(id(355),aid_to_nicaraguan_contras(415)).
head(id(356),mx_missile(415)).
head(id(357),export_administration_act_south_africa(415)).
head(id(358),water_project_cost_sharing(6)).
head(id(359),budget_resolution(6)).
head(id(360),el_salvador_aid(6)).
head(id(361),religious_groups_in_schools(6)).
head(id(362),superfund_right_to_sue(6)).
head(id(363),crime(6)).
head(id(364),duty_free_exports(6)).
head(id(365),export_administration_act_south_africa(6)).
head(id(366),water_project_cost_sharing(163)).
head(id(367),budget_resolution(163)).
head(id(368),el_salvador_aid(163)).
head(id(369),religious_groups_in_schools(163)).
head(id(370),anti_satellite_test_ban(163)).
head(id(371),synfuels_corporation_cutback(163)).
head(id(372),education_spending(163)).
head(id(373),superfund_right_to_sue(163)).
head(id(374),crime(163)).
head(id(375),export_administration_act_south_africa(163)).
head(id(376),water_project_cost_sharing(424)).
head(id(377),budget_resolution(424)).
head(id(378),religious_groups_in_schools(424)).
head(id(379),anti_satellite_test_ban(424)).
head(id(380),aid_to_nicaraguan_contras(424)).
head(id(381),mx_missile(424)).
head(id(382),synfuels_corporation_cutback(424)).
head(id(383),crime(424)).
head(id(384),duty_free_exports(424)).
head(id(385),export_administration_act_south_africa(424)).
head(id(386),handicapped_infants(407)).
head(id(387),budget_resolution(407)).
head(id(388),el_salvador_aid(407)).
head(id(389),religious_groups_in_schools(407)).
head(id(390),mx_missile(407)).
head(id(391),immigration(407)).
head(id(392),superfund_right_to_sue(407)).
head(id(393),crime(407)).
head(id(394),export_administration_act_south_africa(407)).
head(id(395),handicapped_infants(392)).
head(id(396),water_project_cost_sharing(392)).
head(id(397),aid_to_nicaraguan_contras(392)).
head(id(398),mx_missile(392)).
head(id(399),synfuels_corporation_cutback(392)).
head(id(400),duty_free_exports(392)).
head(id(401),handicapped_infants(338)).
head(id(402),budget_resolution(338)).
head(id(403),anti_satellite_test_ban(338)).
head(id(404),aid_to_nicaraguan_contras(338)).
head(id(405),mx_missile(338)).
head(id(406),duty_free_exports(338)).
head(id(407),export_administration_act_south_africa(338)).
head(id(408),handicapped_infants(30)).
head(id(409),water_project_cost_sharing(30)).
head(id(410),budget_resolution(30)).
head(id(411),anti_satellite_test_ban(30)).
head(id(412),aid_to_nicaraguan_contras(30)).
head(id(413),mx_missile(30)).
head(id(414),synfuels_corporation_cutback(30)).
head(id(415),duty_free_exports(30)).
head(id(416),export_administration_act_south_africa(30)).
head(id(1741,A),republican(A)) :- dom(A).
body(id(1741,A),alpha_1(A)) :- dom(A).
body(id(1741,A),physician_fee_freeze(A)) :- dom(A).
head(id(12994,A),c_alpha_1(A)) :- dom(A).
body(id(12994,A),alpha_2(A)) :- dom(A).
body(id(12994,A),water_project_cost_sharing(A)) :- dom(A).
head(id(13867,A),c_alpha_2(A)) :- dom(A).
body(id(13867,A),handicapped_infants(A)) :- dom(A).
head(id(16931,A),c_alpha_2(A)) :- dom(A).
body(id(16931,A),alpha_3(A)) :- dom(A).
body(id(16931,A),el_salvador_aid(A)) :- dom(A).
head(id(21741,A),c_alpha_3(A)) :- dom(A).
body(id(21741,A),budget_resolution(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).

dom(6).
dom(29).
dom(30).
dom(38).
dom(40).
dom(57).
dom(74).
dom(78).
dom(88).
dom(89).
dom(118).
dom(134).
dom(143).
dom(147).
dom(151).
dom(153).
dom(154).
dom(163).
dom(170).
dom(176).
dom(190).
dom(201).
dom(220).
dom(227).
dom(231).
dom(240).
dom(242).
dom(267).
dom(301).
dom(303).
dom(306).
dom(338).
dom(341).
dom(347).
dom(348).
dom(357).
dom(365).
dom(366).
dom(369).
dom(384).
dom(392).
dom(393).
dom(405).
dom(406).
dom(407).
dom(415).
dom(420).
dom(424).
 :- not supported(republican(301)).
 :- not supported(republican(405)).
 :- not supported(republican(143)).
 :- not supported(republican(357)).
 :- not supported(republican(240)).
 :- not supported(republican(406)).
 :- not supported(republican(74)).
 :- not supported(republican(88)).
 :- not supported(republican(341)).
 :- not supported(republican(303)).
 :- not supported(republican(147)).
 :- not supported(republican(365)).
 :- not supported(republican(38)).
 :- not supported(republican(57)).
 :- not supported(republican(118)).
 :- not supported(republican(29)).
 :- not supported(republican(231)).
 :- not supported(republican(306)).
 :- not supported(republican(393)).
 :- not supported(republican(348)).
 :- not supported(republican(151)).
 :- not supported(republican(267)).
 :- not supported(republican(347)).
 :- not supported(republican(134)).
 :- supported(republican(201)).
 :- supported(republican(420)).
 :- supported(republican(153)).
 :- supported(republican(366)).
 :- supported(republican(89)).
 :- supported(republican(154)).
 :- supported(republican(176)).
 :- supported(republican(220)).
 :- supported(republican(384)).
 :- supported(republican(40)).
 :- supported(republican(227)).
 :- supported(republican(369)).
 :- supported(republican(78)).
 :- supported(republican(190)).
 :- supported(republican(242)).
 :- supported(republican(170)).
 :- supported(republican(415)).
 :- supported(republican(6)).
 :- supported(republican(163)).
 :- supported(republican(424)).
 :- supported(republican(407)).
 :- supported(republican(392)).
 :- supported(republican(338)).
 :- supported(republican(30)).
