% training data:
% no. positive ex.: 14
% no. negative ex.: 27
% query: 
train :- aba_asp('./xabal/autism.csv.f1.bk',[autism(509),autism(660),autism(559),autism(521),autism(654),autism(203),autism(224),autism(189),autism(693),autism(472),autism(545),autism(494),autism(638),autism(449)],[autism(215),autism(633),autism(202),autism(113),autism(520),autism(160),autism(295),autism(133),autism(88),autism(205),autism(267),autism(321),autism(286),autism(527),autism(110),autism(342),autism(306),autism(581),autism(617),autism(676),autism(157),autism(44),autism(131),autism(259),autism(470),autism(489),autism(9)]).
% test data:
% no. positive ex.: 3
% no. negative ex.: 6
% query: 
test :- test_abaf('./xabal/autism.csv.f1.bk.sol',[pos(autism(434),[a1(434),a2(434),a3(434),a4(434),a5(434),a6(434),a8(434),a9(434),age3(434),female(434),white(434),self(434)]),pos(autism(529),[a1(529),a2(529),a3(529),a4(529),a5(529),a6(529),a7(529),a8(529),a9(529),a10(529),age4(529),female(529),white(529),jaundice(529),pdd(529),self(529)]),pos(autism(124),[a1(124),a4(124),a5(124),a6(124),a7(124),a8(124),a10(124),age3(124),asian(124),jaundice(124),self(124)])],[neg(autism(304),[a8(304),a9(304),age3(304),female(304),others(304),self(304)]),neg(autism(608),[a8(608),age2(608),female(608),asian(608),jaundice(608),self(608)]),neg(autism(64),[a1(64),a4(64),a5(64),a8(64),a9(64),age1(64),white(64),parent(64)]),neg(autism(294),[a1(294),a5(294),a7(294),a10(294),age2(294),female(294),white(294),pdd(294),self(294)]),neg(autism(132),[a1(132),a8(132),a10(132),age2(132),black(132),self(132)]),neg(autism(600),[a1(600),a3(600),a4(600),a8(600),a9(600),a10(600),age3(600),female(600),asian(600),parent(600)])]).
