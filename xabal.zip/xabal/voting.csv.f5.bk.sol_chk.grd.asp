head(id(1),physician_fee_freeze(301)).
head(id(2),el_salvador_aid(301)).
head(id(3),anti_satellite_test_ban(301)).
head(id(4),aid_to_nicaraguan_contras(301)).
head(id(5),mx_missile(301)).
head(id(6),immigration(301)).
head(id(7),education_spending(301)).
head(id(8),superfund_right_to_sue(301)).
head(id(9),crime(301)).
head(id(10),export_administration_act_south_africa(301)).
head(id(11),handicapped_infants(405)).
head(id(12),water_project_cost_sharing(405)).
head(id(13),physician_fee_freeze(405)).
head(id(14),el_salvador_aid(405)).
head(id(15),religious_groups_in_schools(405)).
head(id(16),immigration(405)).
head(id(17),education_spending(405)).
head(id(18),superfund_right_to_sue(405)).
head(id(19),crime(405)).
head(id(20),export_administration_act_south_africa(405)).
head(id(21),physician_fee_freeze(143)).
head(id(22),el_salvador_aid(143)).
head(id(23),religious_groups_in_schools(143)).
head(id(24),anti_satellite_test_ban(143)).
head(id(25),aid_to_nicaraguan_contras(143)).
head(id(26),mx_missile(143)).
head(id(27),immigration(143)).
head(id(28),education_spending(143)).
head(id(29),superfund_right_to_sue(143)).
head(id(30),crime(143)).
head(id(31),export_administration_act_south_africa(143)).
head(id(32),physician_fee_freeze(357)).
head(id(33),el_salvador_aid(357)).
head(id(34),religious_groups_in_schools(357)).
head(id(35),education_spending(357)).
head(id(36),superfund_right_to_sue(357)).
head(id(37),crime(357)).
head(id(38),physician_fee_freeze(240)).
head(id(39),el_salvador_aid(240)).
head(id(40),religious_groups_in_schools(240)).
head(id(41),anti_satellite_test_ban(240)).
head(id(42),immigration(240)).
head(id(43),crime(240)).
head(id(44),duty_free_exports(240)).
head(id(45),export_administration_act_south_africa(240)).
head(id(46),physician_fee_freeze(406)).
head(id(47),el_salvador_aid(406)).
head(id(48),religious_groups_in_schools(406)).
head(id(49),education_spending(406)).
head(id(50),superfund_right_to_sue(406)).
head(id(51),crime(406)).
head(id(52),export_administration_act_south_africa(406)).
head(id(53),water_project_cost_sharing(62)).
head(id(54),physician_fee_freeze(62)).
head(id(55),el_salvador_aid(62)).
head(id(56),religious_groups_in_schools(62)).
head(id(57),education_spending(62)).
head(id(58),superfund_right_to_sue(62)).
head(id(59),crime(62)).
head(id(60),water_project_cost_sharing(59)).
head(id(61),physician_fee_freeze(59)).
head(id(62),el_salvador_aid(59)).
head(id(63),religious_groups_in_schools(59)).
head(id(64),immigration(59)).
head(id(65),education_spending(59)).
head(id(66),superfund_right_to_sue(59)).
head(id(67),crime(59)).
head(id(68),export_administration_act_south_africa(59)).
head(id(69),water_project_cost_sharing(34)).
head(id(70),physician_fee_freeze(34)).
head(id(71),el_salvador_aid(34)).
head(id(72),religious_groups_in_schools(34)).
head(id(73),education_spending(34)).
head(id(74),superfund_right_to_sue(34)).
head(id(75),crime(34)).
head(id(76),export_administration_act_south_africa(34)).
head(id(77),water_project_cost_sharing(164)).
head(id(78),physician_fee_freeze(164)).
head(id(79),el_salvador_aid(164)).
head(id(80),religious_groups_in_schools(164)).
head(id(81),anti_satellite_test_ban(164)).
head(id(82),education_spending(164)).
head(id(83),superfund_right_to_sue(164)).
head(id(84),crime(164)).
head(id(85),export_administration_act_south_africa(164)).
head(id(86),physician_fee_freeze(84)).
head(id(87),el_salvador_aid(84)).
head(id(88),religious_groups_in_schools(84)).
head(id(89),education_spending(84)).
head(id(90),superfund_right_to_sue(84)).
head(id(91),crime(84)).
head(id(92),physician_fee_freeze(83)).
head(id(93),el_salvador_aid(83)).
head(id(94),religious_groups_in_schools(83)).
head(id(95),immigration(83)).
head(id(96),education_spending(83)).
head(id(97),superfund_right_to_sue(83)).
head(id(98),crime(83)).
head(id(99),export_administration_act_south_africa(83)).
head(id(100),handicapped_infants(74)).
head(id(101),budget_resolution(74)).
head(id(102),physician_fee_freeze(74)).
head(id(103),el_salvador_aid(74)).
head(id(104),anti_satellite_test_ban(74)).
head(id(105),mx_missile(74)).
head(id(106),immigration(74)).
head(id(107),superfund_right_to_sue(74)).
head(id(108),crime(74)).
head(id(109),export_administration_act_south_africa(74)).
head(id(110),physician_fee_freeze(88)).
head(id(111),el_salvador_aid(88)).
head(id(112),religious_groups_in_schools(88)).
head(id(113),education_spending(88)).
head(id(114),superfund_right_to_sue(88)).
head(id(115),crime(88)).
head(id(116),physician_fee_freeze(341)).
head(id(117),el_salvador_aid(341)).
head(id(118),religious_groups_in_schools(341)).
head(id(119),immigration(341)).
head(id(120),synfuels_corporation_cutback(341)).
head(id(121),education_spending(341)).
head(id(122),crime(341)).
head(id(123),export_administration_act_south_africa(341)).
head(id(124),physician_fee_freeze(303)).
head(id(125),el_salvador_aid(303)).
head(id(126),religious_groups_in_schools(303)).
head(id(127),anti_satellite_test_ban(303)).
head(id(128),immigration(303)).
head(id(129),education_spending(303)).
head(id(130),superfund_right_to_sue(303)).
head(id(131),crime(303)).
head(id(132),export_administration_act_south_africa(303)).
head(id(133),water_project_cost_sharing(147)).
head(id(134),physician_fee_freeze(147)).
head(id(135),el_salvador_aid(147)).
head(id(136),religious_groups_in_schools(147)).
head(id(137),education_spending(147)).
head(id(138),superfund_right_to_sue(147)).
head(id(139),crime(147)).
head(id(140),export_administration_act_south_africa(147)).
head(id(141),handicapped_infants(365)).
head(id(142),water_project_cost_sharing(365)).
head(id(143),physician_fee_freeze(365)).
head(id(144),el_salvador_aid(365)).
head(id(145),religious_groups_in_schools(365)).
head(id(146),synfuels_corporation_cutback(365)).
head(id(147),superfund_right_to_sue(365)).
head(id(148),crime(365)).
head(id(149),export_administration_act_south_africa(365)).
head(id(150),handicapped_infants(38)).
head(id(151),water_project_cost_sharing(38)).
head(id(152),physician_fee_freeze(38)).
head(id(153),el_salvador_aid(38)).
head(id(154),religious_groups_in_schools(38)).
head(id(155),superfund_right_to_sue(38)).
head(id(156),crime(38)).
head(id(157),export_administration_act_south_africa(38)).
head(id(158),water_project_cost_sharing(57)).
head(id(159),physician_fee_freeze(57)).
head(id(160),el_salvador_aid(57)).
head(id(161),religious_groups_in_schools(57)).
head(id(162),immigration(57)).
head(id(163),synfuels_corporation_cutback(57)).
head(id(164),education_spending(57)).
head(id(165),superfund_right_to_sue(57)).
head(id(166),crime(57)).
head(id(167),export_administration_act_south_africa(57)).
head(id(168),handicapped_infants(118)).
head(id(169),water_project_cost_sharing(118)).
head(id(170),budget_resolution(118)).
head(id(171),physician_fee_freeze(118)).
head(id(172),el_salvador_aid(118)).
head(id(173),anti_satellite_test_ban(118)).
head(id(174),education_spending(118)).
head(id(175),superfund_right_to_sue(118)).
head(id(176),crime(118)).
head(id(177),export_administration_act_south_africa(118)).
head(id(178),handicapped_infants(29)).
head(id(179),physician_fee_freeze(29)).
head(id(180),el_salvador_aid(29)).
head(id(181),anti_satellite_test_ban(29)).
head(id(182),aid_to_nicaraguan_contras(29)).
head(id(183),mx_missile(29)).
head(id(184),education_spending(29)).
head(id(185),superfund_right_to_sue(29)).
head(id(186),crime(29)).
head(id(187),export_administration_act_south_africa(29)).
head(id(188),water_project_cost_sharing(231)).
head(id(189),physician_fee_freeze(231)).
head(id(190),el_salvador_aid(231)).
head(id(191),religious_groups_in_schools(231)).
head(id(192),education_spending(231)).
head(id(193),superfund_right_to_sue(231)).
head(id(194),crime(231)).
head(id(195),export_administration_act_south_africa(231)).
head(id(196),physician_fee_freeze(306)).
head(id(197),el_salvador_aid(306)).
head(id(198),religious_groups_in_schools(306)).
head(id(199),immigration(306)).
head(id(200),education_spending(306)).
head(id(201),superfund_right_to_sue(306)).
head(id(202),crime(306)).
head(id(203),budget_resolution(201)).
head(id(204),anti_satellite_test_ban(201)).
head(id(205),aid_to_nicaraguan_contras(201)).
head(id(206),mx_missile(201)).
head(id(207),crime(201)).
head(id(208),duty_free_exports(201)).
head(id(209),export_administration_act_south_africa(201)).
head(id(210),handicapped_infants(420)).
head(id(211),water_project_cost_sharing(420)).
head(id(212),budget_resolution(420)).
head(id(213),anti_satellite_test_ban(420)).
head(id(214),aid_to_nicaraguan_contras(420)).
head(id(215),mx_missile(420)).
head(id(216),export_administration_act_south_africa(420)).
head(id(217),water_project_cost_sharing(153)).
head(id(218),budget_resolution(153)).
head(id(219),religious_groups_in_schools(153)).
head(id(220),aid_to_nicaraguan_contras(153)).
head(id(221),mx_missile(153)).
head(id(222),immigration(153)).
head(id(223),synfuels_corporation_cutback(153)).
head(id(224),superfund_right_to_sue(153)).
head(id(225),duty_free_exports(153)).
head(id(226),export_administration_act_south_africa(153)).
head(id(227),water_project_cost_sharing(366)).
head(id(228),el_salvador_aid(366)).
head(id(229),religious_groups_in_schools(366)).
head(id(230),immigration(366)).
head(id(231),synfuels_corporation_cutback(366)).
head(id(232),superfund_right_to_sue(366)).
head(id(233),crime(366)).
head(id(234),water_project_cost_sharing(89)).
head(id(235),budget_resolution(89)).
head(id(236),el_salvador_aid(89)).
head(id(237),religious_groups_in_schools(89)).
head(id(238),anti_satellite_test_ban(89)).
head(id(239),mx_missile(89)).
head(id(240),immigration(89)).
head(id(241),synfuels_corporation_cutback(89)).
head(id(242),superfund_right_to_sue(89)).
head(id(243),crime(89)).
head(id(244),export_administration_act_south_africa(89)).
head(id(245),budget_resolution(154)).
head(id(246),religious_groups_in_schools(154)).
head(id(247),anti_satellite_test_ban(154)).
head(id(248),aid_to_nicaraguan_contras(154)).
head(id(249),mx_missile(154)).
head(id(250),immigration(154)).
head(id(251),synfuels_corporation_cutback(154)).
head(id(252),superfund_right_to_sue(154)).
head(id(253),crime(154)).
head(id(254),export_administration_act_south_africa(154)).
head(id(255),religious_groups_in_schools(317)).
head(id(256),aid_to_nicaraguan_contras(317)).
head(id(257),mx_missile(317)).
head(id(258),synfuels_corporation_cutback(317)).
head(id(259),education_spending(317)).
head(id(260),superfund_right_to_sue(317)).
head(id(261),crime(317)).
head(id(262),duty_free_exports(317)).
head(id(263),handicapped_infants(203)).
head(id(264),budget_resolution(203)).
head(id(265),religious_groups_in_schools(203)).
head(id(266),anti_satellite_test_ban(203)).
head(id(267),aid_to_nicaraguan_contras(203)).
head(id(268),mx_missile(203)).
head(id(269),immigration(203)).
head(id(270),synfuels_corporation_cutback(203)).
head(id(271),duty_free_exports(203)).
head(id(272),export_administration_act_south_africa(203)).
head(id(273),handicapped_infants(386)).
head(id(274),water_project_cost_sharing(386)).
head(id(275),el_salvador_aid(386)).
head(id(276),religious_groups_in_schools(386)).
head(id(277),synfuels_corporation_cutback(386)).
head(id(278),education_spending(386)).
head(id(279),superfund_right_to_sue(386)).
head(id(280),crime(386)).
head(id(281),duty_free_exports(386)).
head(id(282),handicapped_infants(261)).
head(id(283),budget_resolution(261)).
head(id(284),anti_satellite_test_ban(261)).
head(id(285),aid_to_nicaraguan_contras(261)).
head(id(286),mx_missile(261)).
head(id(287),immigration(261)).
head(id(288),export_administration_act_south_africa(261)).
head(id(289),handicapped_infants(140)).
head(id(290),budget_resolution(140)).
head(id(291),religious_groups_in_schools(140)).
head(id(292),anti_satellite_test_ban(140)).
head(id(293),aid_to_nicaraguan_contras(140)).
head(id(294),mx_missile(140)).
head(id(295),duty_free_exports(140)).
head(id(296),export_administration_act_south_africa(140)).
head(id(297),handicapped_infants(412)).
head(id(298),budget_resolution(412)).
head(id(299),religious_groups_in_schools(412)).
head(id(300),anti_satellite_test_ban(412)).
head(id(301),aid_to_nicaraguan_contras(412)).
head(id(302),mx_missile(412)).
head(id(303),immigration(412)).
head(id(304),synfuels_corporation_cutback(412)).
head(id(305),export_administration_act_south_africa(412)).
head(id(306),water_project_cost_sharing(176)).
head(id(307),budget_resolution(176)).
head(id(308),anti_satellite_test_ban(176)).
head(id(309),aid_to_nicaraguan_contras(176)).
head(id(310),mx_missile(176)).
head(id(311),immigration(176)).
head(id(312),duty_free_exports(176)).
head(id(313),export_administration_act_south_africa(176)).
head(id(314),water_project_cost_sharing(220)).
head(id(315),budget_resolution(220)).
head(id(316),aid_to_nicaraguan_contras(220)).
head(id(317),mx_missile(220)).
head(id(318),synfuels_corporation_cutback(220)).
head(id(319),crime(220)).
head(id(320),duty_free_exports(220)).
head(id(321),export_administration_act_south_africa(220)).
head(id(322),handicapped_infants(384)).
head(id(323),water_project_cost_sharing(384)).
head(id(324),budget_resolution(384)).
head(id(325),el_salvador_aid(384)).
head(id(326),religious_groups_in_schools(384)).
head(id(327),aid_to_nicaraguan_contras(384)).
head(id(328),mx_missile(384)).
head(id(329),immigration(384)).
head(id(330),synfuels_corporation_cutback(384)).
head(id(331),export_administration_act_south_africa(384)).
head(id(332),handicapped_infants(40)).
head(id(333),budget_resolution(40)).
head(id(334),anti_satellite_test_ban(40)).
head(id(335),aid_to_nicaraguan_contras(40)).
head(id(336),mx_missile(40)).
head(id(337),immigration(40)).
head(id(338),synfuels_corporation_cutback(40)).
head(id(339),superfund_right_to_sue(40)).
head(id(340),duty_free_exports(40)).
head(id(341),export_administration_act_south_africa(40)).
head(id(342),budget_resolution(227)).
head(id(343),religious_groups_in_schools(227)).
head(id(344),anti_satellite_test_ban(227)).
head(id(345),aid_to_nicaraguan_contras(227)).
head(id(346),mx_missile(227)).
head(id(347),synfuels_corporation_cutback(227)).
head(id(348),crime(227)).
head(id(349),duty_free_exports(227)).
head(id(350),export_administration_act_south_africa(227)).
head(id(351),water_project_cost_sharing(369)).
head(id(352),budget_resolution(369)).
head(id(353),religious_groups_in_schools(369)).
head(id(354),anti_satellite_test_ban(369)).
head(id(355),aid_to_nicaraguan_contras(369)).
head(id(356),immigration(369)).
head(id(357),duty_free_exports(369)).
head(id(358),export_administration_act_south_africa(369)).
head(id(359),water_project_cost_sharing(78)).
head(id(360),budget_resolution(78)).
head(id(361),physician_fee_freeze(78)).
head(id(362),el_salvador_aid(78)).
head(id(363),religious_groups_in_schools(78)).
head(id(364),aid_to_nicaraguan_contras(78)).
head(id(365),mx_missile(78)).
head(id(366),immigration(78)).
head(id(367),synfuels_corporation_cutback(78)).
head(id(368),education_spending(78)).
head(id(369),superfund_right_to_sue(78)).
head(id(370),crime(78)).
head(id(371),export_administration_act_south_africa(78)).
head(id(372),handicapped_infants(190)).
head(id(373),budget_resolution(190)).
head(id(374),anti_satellite_test_ban(190)).
head(id(375),aid_to_nicaraguan_contras(190)).
head(id(376),mx_missile(190)).
head(id(377),duty_free_exports(190)).
head(id(378),export_administration_act_south_africa(190)).
head(id(379),handicapped_infants(242)).
head(id(380),budget_resolution(242)).
head(id(381),anti_satellite_test_ban(242)).
head(id(382),aid_to_nicaraguan_contras(242)).
head(id(383),mx_missile(242)).
head(id(384),immigration(242)).
head(id(385),synfuels_corporation_cutback(242)).
head(id(386),crime(242)).
head(id(387),duty_free_exports(242)).
head(id(388),export_administration_act_south_africa(242)).
head(id(389),handicapped_infants(170)).
head(id(390),budget_resolution(170)).
head(id(391),anti_satellite_test_ban(170)).
head(id(392),aid_to_nicaraguan_contras(170)).
head(id(393),mx_missile(170)).
head(id(394),immigration(170)).
head(id(395),synfuels_corporation_cutback(170)).
head(id(396),crime(170)).
head(id(397),export_administration_act_south_africa(170)).
head(id(398),handicapped_infants(415)).
head(id(399),water_project_cost_sharing(415)).
head(id(400),budget_resolution(415)).
head(id(401),anti_satellite_test_ban(415)).
head(id(402),aid_to_nicaraguan_contras(415)).
head(id(403),mx_missile(415)).
head(id(404),export_administration_act_south_africa(415)).
head(id(405),water_project_cost_sharing(6)).
head(id(406),budget_resolution(6)).
head(id(407),el_salvador_aid(6)).
head(id(408),religious_groups_in_schools(6)).
head(id(409),superfund_right_to_sue(6)).
head(id(410),crime(6)).
head(id(411),duty_free_exports(6)).
head(id(412),export_administration_act_south_africa(6)).
head(id(1725,A),republican(A)) :- dom(A).
body(id(1725,A),alpha_1(A)) :- dom(A).
body(id(1725,A),physician_fee_freeze(A)) :- dom(A).
head(id(12874,A),c_alpha_1(A)) :- dom(A).
body(id(12874,A),alpha_2(A)) :- dom(A).
body(id(12874,A),water_project_cost_sharing(A)) :- dom(A).
head(id(15920,A),c_alpha_2(A)) :- dom(A).
body(id(15920,A),alpha_3(A)) :- dom(A).
body(id(15920,A),el_salvador_aid(A)) :- dom(A).
head(id(22405,A),c_alpha_3(A)) :- dom(A).
body(id(22405,A),alpha_4(A)) :- dom(A).
body(id(22405,A),budget_resolution(A)) :- dom(A).
head(id(23274,A),c_alpha_4(A)) :- dom(A).
body(id(23274,A),handicapped_infants(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
assumption(alpha_4(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).
contrary(alpha_4(A),c_alpha_4(A)) :- assumption(alpha_4(A)).

dom(6).
dom(29).
dom(34).
dom(38).
dom(40).
dom(57).
dom(59).
dom(62).
dom(74).
dom(78).
dom(83).
dom(84).
dom(88).
dom(89).
dom(118).
dom(140).
dom(143).
dom(147).
dom(153).
dom(154).
dom(164).
dom(170).
dom(176).
dom(190).
dom(201).
dom(203).
dom(220).
dom(227).
dom(231).
dom(240).
dom(242).
dom(261).
dom(301).
dom(303).
dom(306).
dom(317).
dom(341).
dom(357).
dom(365).
dom(366).
dom(369).
dom(384).
dom(386).
dom(405).
dom(406).
dom(412).
dom(415).
dom(420).
 :- not supported(republican(301)).
 :- not supported(republican(405)).
 :- not supported(republican(143)).
 :- not supported(republican(357)).
 :- not supported(republican(240)).
 :- not supported(republican(406)).
 :- not supported(republican(62)).
 :- not supported(republican(59)).
 :- not supported(republican(34)).
 :- not supported(republican(164)).
 :- not supported(republican(84)).
 :- not supported(republican(83)).
 :- not supported(republican(74)).
 :- not supported(republican(88)).
 :- not supported(republican(341)).
 :- not supported(republican(303)).
 :- not supported(republican(147)).
 :- not supported(republican(365)).
 :- not supported(republican(38)).
 :- not supported(republican(57)).
 :- not supported(republican(118)).
 :- not supported(republican(29)).
 :- not supported(republican(231)).
 :- not supported(republican(306)).
 :- supported(republican(201)).
 :- supported(republican(420)).
 :- supported(republican(153)).
 :- supported(republican(366)).
 :- supported(republican(89)).
 :- supported(republican(154)).
 :- supported(republican(317)).
 :- supported(republican(203)).
 :- supported(republican(386)).
 :- supported(republican(261)).
 :- supported(republican(140)).
 :- supported(republican(412)).
 :- supported(republican(176)).
 :- supported(republican(220)).
 :- supported(republican(384)).
 :- supported(republican(40)).
 :- supported(republican(227)).
 :- supported(republican(369)).
 :- supported(republican(78)).
 :- supported(republican(190)).
 :- supported(republican(242)).
 :- supported(republican(170)).
 :- supported(republican(415)).
 :- supported(republican(6)).
