head(id(1),clump_thickness__5(44)).
head(id(2),cell_size_uniformity__6(44)).
head(id(3),cell_shape_uniformity__5(44)).
head(id(4),marginal_adhesion__6(44)).
head(id(5),bare_nuclei__1(44)).
head(id(6),bland_chromatin__3(44)).
head(id(7),normal_nucleoli__1(44)).
head(id(8),mitoses__1(44)).
head(id(9),clump_thickness__5(125)).
head(id(10),cell_size_uniformity__4(125)).
head(id(11),cell_shape_uniformity__6(125)).
head(id(12),marginal_adhesion__7(125)).
head(id(13),single_epi_cell_size__9(125)).
head(id(14),bare_nuclei__7(125)).
head(id(15),bland_chromatin__8(125)).
head(id(16),mitoses__1(125)).
head(id(17),clump_thickness__6(64)).
head(id(18),cell_size_uniformity__3(64)).
head(id(19),cell_shape_uniformity__4(64)).
head(id(20),marginal_adhesion__1(64)).
head(id(21),single_epi_cell_size__5(64)).
head(id(22),bare_nuclei__2(64)).
head(id(23),bland_chromatin__3(64)).
head(id(24),normal_nucleoli__9(64)).
head(id(25),mitoses__1(64)).
head(id(26),clump_thickness__8(211)).
head(id(27),single_epi_cell_size__5(211)).
head(id(28),bland_chromatin__8(211)).
head(id(29),mitoses__6(211)).
head(id(30),clump_thickness__5(189)).
head(id(31),cell_size_uniformity__8(189)).
head(id(32),cell_shape_uniformity__4(189)).
head(id(33),single_epi_cell_size__5(189)).
head(id(34),bare_nuclei__8(189)).
head(id(35),bland_chromatin__9(189)).
head(id(36),mitoses__1(189)).
head(id(37),clump_thickness__7(50)).
head(id(38),cell_size_uniformity__8(50)).
head(id(39),cell_shape_uniformity__7(50)).
head(id(40),marginal_adhesion__2(50)).
head(id(41),single_epi_cell_size__4(50)).
head(id(42),bare_nuclei__8(50)).
head(id(43),bland_chromatin__3(50)).
head(id(44),normal_nucleoli__8(50)).
head(id(45),mitoses__2(50)).
head(id(46),clump_thickness__8(69)).
head(id(47),cell_size_uniformity__3(69)).
head(id(48),cell_shape_uniformity__8(69)).
head(id(49),marginal_adhesion__3(69)).
head(id(50),single_epi_cell_size__4(69)).
head(id(51),bare_nuclei__9(69)).
head(id(52),bland_chromatin__8(69)).
head(id(53),normal_nucleoli__9(69)).
head(id(54),mitoses__8(69)).
head(id(55),clump_thickness__8(212)).
head(id(56),cell_shape_uniformity__8(212)).
head(id(57),marginal_adhesion__8(212)).
head(id(58),single_epi_cell_size__4(212)).
head(id(59),bare_nuclei__8(212)).
head(id(60),bland_chromatin__7(212)).
head(id(61),normal_nucleoli__7(212)).
head(id(62),mitoses__1(212)).
head(id(63),clump_thickness__7(100)).
head(id(64),cell_size_uniformity__5(100)).
head(id(65),cell_shape_uniformity__6(100)).
head(id(66),single_epi_cell_size__5(100)).
head(id(67),bland_chromatin__7(100)).
head(id(68),normal_nucleoli__9(100)).
head(id(69),mitoses__4(100)).
head(id(70),clump_thickness__5(61)).
head(id(71),cell_size_uniformity__3(61)).
head(id(72),cell_shape_uniformity__5(61)).
head(id(73),marginal_adhesion__5(61)).
head(id(74),single_epi_cell_size__3(61)).
head(id(75),bare_nuclei__3(61)).
head(id(76),bland_chromatin__4(61)).
head(id(77),mitoses__1(61)).
head(id(78),cell_size_uniformity__8(202)).
head(id(79),cell_shape_uniformity__8(202)).
head(id(80),marginal_adhesion__4(202)).
head(id(81),bland_chromatin__8(202)).
head(id(82),normal_nucleoli__1(202)).
head(id(83),mitoses__1(202)).
head(id(84),clump_thickness__9(74)).
head(id(85),cell_size_uniformity__4(74)).
head(id(86),cell_shape_uniformity__5(74)).
head(id(87),single_epi_cell_size__6(74)).
head(id(88),bland_chromatin__4(74)).
head(id(89),normal_nucleoli__8(74)).
head(id(90),mitoses__1(74)).
head(id(91),clump_thickness__7(127)).
head(id(92),cell_size_uniformity__5(127)).
head(id(93),cell_shape_uniformity__3(127)).
head(id(94),marginal_adhesion__7(127)).
head(id(95),single_epi_cell_size__4(127)).
head(id(96),bland_chromatin__7(127)).
head(id(97),normal_nucleoli__5(127)).
head(id(98),mitoses__5(127)).
head(id(99),clump_thickness__8(57)).
head(id(100),marginal_adhesion__1(57)).
head(id(101),single_epi_cell_size__3(57)).
head(id(102),bare_nuclei__6(57)).
head(id(103),bland_chromatin__3(57)).
head(id(104),normal_nucleoli__9(57)).
head(id(105),mitoses__1(57)).
head(id(106),cell_size_uniformity__3(53)).
head(id(107),cell_shape_uniformity__6(53)).
head(id(108),marginal_adhesion__2(53)).
head(id(109),single_epi_cell_size__3(53)).
head(id(110),bare_nuclei__5(53)).
head(id(111),bland_chromatin__4(53)).
head(id(112),mitoses__2(53)).
head(id(113),clump_thickness__7(21)).
head(id(114),cell_size_uniformity__3(21)).
head(id(115),cell_shape_uniformity__2(21)).
head(id(116),single_epi_cell_size__5(21)).
head(id(117),bland_chromatin__5(21)).
head(id(118),normal_nucleoli__4(21)).
head(id(119),mitoses__4(21)).
head(id(120),clump_thickness__8(150)).
head(id(121),cell_size_uniformity__8(150)).
head(id(122),cell_shape_uniformity__7(150)).
head(id(123),marginal_adhesion__4(150)).
head(id(124),bland_chromatin__7(150)).
head(id(125),normal_nucleoli__8(150)).
head(id(126),mitoses__7(150)).
head(id(127),cell_size_uniformity__4(240)).
head(id(128),cell_shape_uniformity__3(240)).
head(id(129),marginal_adhesion__2(240)).
head(id(130),single_epi_cell_size__3(240)).
head(id(131),bland_chromatin__5(240)).
head(id(132),normal_nucleoli__3(240)).
head(id(133),mitoses__2(240)).
head(id(134),cell_size_uniformity__4(42)).
head(id(135),cell_shape_uniformity__3(42)).
head(id(136),marginal_adhesion__1(42)).
head(id(137),single_epi_cell_size__3(42)).
head(id(138),bare_nuclei__3(42)).
head(id(139),bland_chromatin__6(42)).
head(id(140),normal_nucleoli__5(42)).
head(id(141),mitoses__2(42)).
head(id(142),clump_thickness__3(147)).
head(id(143),cell_size_uniformity__4(147)).
head(id(144),cell_shape_uniformity__5(147)).
head(id(145),marginal_adhesion__2(147)).
head(id(146),single_epi_cell_size__6(147)).
head(id(147),bare_nuclei__8(147)).
head(id(148),bland_chromatin__4(147)).
head(id(149),normal_nucleoli__1(147)).
head(id(150),mitoses__1(147)).
head(id(151),cell_size_uniformity__5(55)).
head(id(152),cell_shape_uniformity__5(55)).
head(id(153),marginal_adhesion__6(55)).
head(id(154),single_epi_cell_size__8(55)).
head(id(155),bare_nuclei__8(55)).
head(id(156),bland_chromatin__7(55)).
head(id(157),normal_nucleoli__1(55)).
head(id(158),mitoses__1(55)).
head(id(159),clump_thickness__1(187)).
head(id(160),cell_size_uniformity__5(187)).
head(id(161),cell_shape_uniformity__8(187)).
head(id(162),marginal_adhesion__6(187)).
head(id(163),single_epi_cell_size__5(187)).
head(id(164),bare_nuclei__8(187)).
head(id(165),bland_chromatin__7(187)).
head(id(166),mitoses__1(187)).
head(id(167),marginal_adhesion__8(191)).
head(id(168),single_epi_cell_size__6(191)).
head(id(169),bare_nuclei__8(191)).
head(id(170),bland_chromatin__7(191)).
head(id(171),mitoses__1(191)).
head(id(172),cell_shape_uniformity__9(207)).
head(id(173),marginal_adhesion__3(207)).
head(id(174),single_epi_cell_size__7(207)).
head(id(175),bare_nuclei__5(207)).
head(id(176),bland_chromatin__3(207)).
head(id(177),normal_nucleoli__5(207)).
head(id(178),mitoses__1(207)).
head(id(179),clump_thickness__9(63)).
head(id(180),marginal_adhesion__1(63)).
head(id(181),bare_nuclei__8(63)).
head(id(182),bland_chromatin__3(63)).
head(id(183),normal_nucleoli__3(63)).
head(id(184),mitoses__1(63)).
head(id(185),marginal_adhesion__8(107)).
head(id(186),single_epi_cell_size__2(107)).
head(id(187),bland_chromatin__4(107)).
head(id(188),normal_nucleoli__1(107)).
head(id(189),mitoses__1(107)).
head(id(190),clump_thickness__3(85)).
head(id(191),cell_size_uniformity__5(85)).
head(id(192),cell_shape_uniformity__7(85)).
head(id(193),marginal_adhesion__8(85)).
head(id(194),single_epi_cell_size__8(85)).
head(id(195),bare_nuclei__9(85)).
head(id(196),bland_chromatin__7(85)).
head(id(197),mitoses__7(85)).
head(id(198),clump_thickness__8(175)).
head(id(199),cell_size_uniformity__6(175)).
head(id(200),cell_shape_uniformity__5(175)).
head(id(201),marginal_adhesion__4(175)).
head(id(202),single_epi_cell_size__3(175)).
head(id(203),bland_chromatin__6(175)).
head(id(204),normal_nucleoli__1(175)).
head(id(205),mitoses__1(175)).
head(id(206),clump_thickness__9(51)).
head(id(207),cell_size_uniformity__5(51)).
head(id(208),cell_shape_uniformity__8(51)).
head(id(209),marginal_adhesion__1(51)).
head(id(210),single_epi_cell_size__2(51)).
head(id(211),bare_nuclei__3(51)).
head(id(212),bland_chromatin__2(51)).
head(id(213),normal_nucleoli__1(51)).
head(id(214),mitoses__5(51)).
head(id(215),cell_shape_uniformity__8(153)).
head(id(216),marginal_adhesion__6(153)).
head(id(217),single_epi_cell_size__4(153)).
head(id(218),bare_nuclei__5(153)).
head(id(219),bland_chromatin__8(153)).
head(id(220),mitoses__1(153)).
head(id(221),cell_size_uniformity__4(66)).
head(id(222),cell_shape_uniformity__2(66)).
head(id(223),marginal_adhesion__1(66)).
head(id(224),single_epi_cell_size__3(66)).
head(id(225),bare_nuclei__2(66)).
head(id(226),bland_chromatin__4(66)).
head(id(227),normal_nucleoli__3(66)).
head(id(228),clump_thickness__5(167)).
head(id(229),cell_size_uniformity__6(167)).
head(id(230),cell_shape_uniformity__7(167)).
head(id(231),marginal_adhesion__8(167)).
head(id(232),single_epi_cell_size__8(167)).
head(id(233),bland_chromatin__3(167)).
head(id(234),mitoses__3(167)).
head(id(235),clump_thickness__9(60)).
head(id(236),cell_size_uniformity__5(60)).
head(id(237),cell_shape_uniformity__5(60)).
head(id(238),marginal_adhesion__2(60)).
head(id(239),single_epi_cell_size__2(60)).
head(id(240),bare_nuclei__2(60)).
head(id(241),bland_chromatin__5(60)).
head(id(242),normal_nucleoli__1(60)).
head(id(243),mitoses__1(60)).
head(id(244),cell_size_uniformity__7(19)).
head(id(245),cell_shape_uniformity__7(19)).
head(id(246),marginal_adhesion__6(19)).
head(id(247),single_epi_cell_size__4(19)).
head(id(248),bland_chromatin__4(19)).
head(id(249),normal_nucleoli__1(19)).
head(id(250),mitoses__2(19)).
head(id(251),clump_thickness__2(40)).
head(id(252),cell_size_uniformity__5(40)).
head(id(253),cell_shape_uniformity__3(40)).
head(id(254),marginal_adhesion__3(40)).
head(id(255),single_epi_cell_size__6(40)).
head(id(256),bare_nuclei__7(40)).
head(id(257),bland_chromatin__7(40)).
head(id(258),normal_nucleoli__5(40)).
head(id(259),mitoses__1(40)).
head(id(260),clump_thickness__6(72)).
head(id(261),cell_shape_uniformity__2(72)).
head(id(262),marginal_adhesion__8(72)).
head(id(263),bare_nuclei__2(72)).
head(id(264),bland_chromatin__7(72)).
head(id(265),normal_nucleoli__8(72)).
head(id(266),clump_thickness__3(88)).
head(id(267),cell_size_uniformity__6(88)).
head(id(268),cell_shape_uniformity__6(88)).
head(id(269),marginal_adhesion__6(88)).
head(id(270),single_epi_cell_size__5(88)).
head(id(271),bland_chromatin__6(88)).
head(id(272),normal_nucleoli__8(88)).
head(id(273),mitoses__3(88)).
head(id(274),clump_thickness__8(239)).
head(id(275),marginal_adhesion__8(239)).
head(id(276),single_epi_cell_size__6(239)).
head(id(277),bare_nuclei__9(239)).
head(id(278),bland_chromatin__3(239)).
head(id(279),cell_size_uniformity__8(237)).
head(id(280),cell_shape_uniformity__8(237)).
head(id(281),marginal_adhesion__2(237)).
head(id(282),single_epi_cell_size__8(237)).
head(id(283),bland_chromatin__4(237)).
head(id(284),normal_nucleoli__8(237)).
head(id(285),cell_size_uniformity__7(161)).
head(id(286),cell_shape_uniformity__7(161)).
head(id(287),marginal_adhesion__4(161)).
head(id(288),single_epi_cell_size__5(161)).
head(id(289),bland_chromatin__5(161)).
head(id(290),normal_nucleoli__7(161)).
head(id(291),mitoses__2(161)).
head(id(292),clump_thickness__5(180)).
head(id(293),cell_size_uniformity__3(180)).
head(id(294),cell_shape_uniformity__3(180)).
head(id(295),marginal_adhesion__3(180)).
head(id(296),single_epi_cell_size__6(180)).
head(id(297),bland_chromatin__3(180)).
head(id(298),normal_nucleoli__1(180)).
head(id(299),mitoses__1(180)).
head(id(300),single_epi_cell_size__7(214)).
head(id(301),bland_chromatin__7(214)).
head(id(302),mitoses__4(214)).
head(id(303),clump_thickness__7(152)).
head(id(304),cell_size_uniformity__2(152)).
head(id(305),cell_shape_uniformity__4(152)).
head(id(306),marginal_adhesion__1(152)).
head(id(307),single_epi_cell_size__6(152)).
head(id(308),bland_chromatin__5(152)).
head(id(309),normal_nucleoli__4(152)).
head(id(310),mitoses__3(152)).
head(id(311),cell_size_uniformity__5(188)).
head(id(312),cell_shape_uniformity__6(188)).
head(id(313),single_epi_cell_size__6(188)).
head(id(314),bland_chromatin__7(188)).
head(id(315),normal_nucleoli__7(188)).
head(id(316),marginal_adhesion__4(45)).
head(id(317),single_epi_cell_size__8(45)).
head(id(318),bare_nuclei__1(45)).
head(id(319),bland_chromatin__8(45)).
head(id(320),mitoses__1(45)).
head(id(321),cell_size_uniformity__3(101)).
head(id(322),cell_shape_uniformity__5(101)).
head(id(323),marginal_adhesion__1(101)).
head(id(324),bare_nuclei__5(101)).
head(id(325),bland_chromatin__3(101)).
head(id(326),mitoses__2(101)).
head(id(327),clump_thickness__8(112)).
head(id(328),cell_size_uniformity__6(112)).
head(id(329),cell_shape_uniformity__4(112)).
head(id(330),marginal_adhesion__3(112)).
head(id(331),single_epi_cell_size__5(112)).
head(id(332),bare_nuclei__9(112)).
head(id(333),bland_chromatin__3(112)).
head(id(334),normal_nucleoli__1(112)).
head(id(335),mitoses__1(112)).
head(id(336),clump_thickness__5(59)).
head(id(337),cell_size_uniformity__2(59)).
head(id(338),cell_shape_uniformity__3(59)).
head(id(339),marginal_adhesion__1(59)).
head(id(340),single_epi_cell_size__6(59)).
head(id(341),bland_chromatin__5(59)).
head(id(342),normal_nucleoli__1(59)).
head(id(343),mitoses__1(59)).
head(id(344),bare_nuclei__1(105)).
head(id(345),bland_chromatin__8(105)).
head(id(346),normal_nucleoli__8(105)).
head(id(347),mitoses__8(105)).
head(id(348),clump_thickness__9(238)).
head(id(349),cell_size_uniformity__8(238)).
head(id(350),cell_shape_uniformity__8(238)).
head(id(351),marginal_adhesion__5(238)).
head(id(352),single_epi_cell_size__6(238)).
head(id(353),bare_nuclei__2(238)).
head(id(354),bland_chromatin__4(238)).
head(id(355),mitoses__4(238)).
head(id(356),marginal_adhesion__3(114)).
head(id(357),bare_nuclei__8(114)).
head(id(358),bland_chromatin__8(114)).
head(id(359),normal_nucleoli__1(114)).
head(id(360),mitoses__1(114)).
head(id(361),clump_thickness__7(224)).
head(id(362),cell_size_uniformity__5(224)).
head(id(363),cell_shape_uniformity__6(224)).
head(id(364),marginal_adhesion__3(224)).
head(id(365),single_epi_cell_size__3(224)).
head(id(366),bare_nuclei__8(224)).
head(id(367),bland_chromatin__7(224)).
head(id(368),normal_nucleoli__4(224)).
head(id(369),mitoses__1(224)).
head(id(370),cell_size_uniformity__6(56)).
head(id(371),cell_shape_uniformity__6(56)).
head(id(372),marginal_adhesion__3(56)).
head(id(373),single_epi_cell_size__4(56)).
head(id(374),bare_nuclei__5(56)).
head(id(375),bland_chromatin__3(56)).
head(id(376),normal_nucleoli__6(56)).
head(id(377),mitoses__1(56)).
head(id(378),clump_thickness__5(26)).
head(id(379),cell_size_uniformity__2(26)).
head(id(380),cell_shape_uniformity__3(26)).
head(id(381),marginal_adhesion__4(26)).
head(id(382),single_epi_cell_size__2(26)).
head(id(383),bare_nuclei__7(26)).
head(id(384),bland_chromatin__3(26)).
head(id(385),normal_nucleoli__6(26)).
head(id(386),mitoses__1(26)).
head(id(387),cell_size_uniformity__5(225)).
head(id(388),cell_shape_uniformity__5(225)).
head(id(389),marginal_adhesion__6(225)).
head(id(390),single_epi_cell_size__3(225)).
head(id(391),bland_chromatin__7(225)).
head(id(392),normal_nucleoli__9(225)).
head(id(393),mitoses__2(225)).
head(id(394),clump_thickness__5(124)).
head(id(395),cell_size_uniformity__3(124)).
head(id(396),cell_shape_uniformity__5(124)).
head(id(397),marginal_adhesion__1(124)).
head(id(398),single_epi_cell_size__8(124)).
head(id(399),bland_chromatin__5(124)).
head(id(400),normal_nucleoli__3(124)).
head(id(401),mitoses__1(124)).
head(id(402),cell_size_uniformity__3(113)).
head(id(403),cell_shape_uniformity__3(113)).
head(id(404),single_epi_cell_size__2(113)).
head(id(405),bland_chromatin__7(113)).
head(id(406),normal_nucleoli__3(113)).
head(id(407),mitoses__3(113)).
head(id(408),clump_thickness__5(54)).
head(id(409),cell_size_uniformity__5(54)).
head(id(410),cell_shape_uniformity__5(54)).
head(id(411),marginal_adhesion__8(54)).
head(id(412),bare_nuclei__8(54)).
head(id(413),bland_chromatin__7(54)).
head(id(414),normal_nucleoli__3(54)).
head(id(415),mitoses__7(54)).
head(id(416),clump_thickness__7(192)).
head(id(417),cell_size_uniformity__5(192)).
head(id(418),bland_chromatin__4(192)).
head(id(419),mitoses__3(192)).
head(id(420),clump_thickness__8(104)).
head(id(421),cell_size_uniformity__2(104)).
head(id(422),cell_shape_uniformity__3(104)).
head(id(423),marginal_adhesion__1(104)).
head(id(424),single_epi_cell_size__6(104)).
head(id(425),bare_nuclei__3(104)).
head(id(426),bland_chromatin__7(104)).
head(id(427),normal_nucleoli__1(104)).
head(id(428),mitoses__1(104)).
head(id(429),clump_thickness__5(206)).
head(id(430),marginal_adhesion__9(206)).
head(id(431),single_epi_cell_size__6(206)).
head(id(432),bland_chromatin__7(206)).
head(id(433),mitoses__5(206)).
head(id(434),cell_size_uniformity__4(234)).
head(id(435),cell_shape_uniformity__5(234)).
head(id(436),marginal_adhesion__5(234)).
head(id(437),single_epi_cell_size__5(234)).
head(id(438),bland_chromatin__4(234)).
head(id(439),normal_nucleoli__1(234)).
head(id(440),mitoses__1(234)).
head(id(441),cell_size_uniformity__7(33)).
head(id(442),cell_shape_uniformity__7(33)).
head(id(443),marginal_adhesion__3(33)).
head(id(444),single_epi_cell_size__8(33)).
head(id(445),bare_nuclei__5(33)).
head(id(446),bland_chromatin__7(33)).
head(id(447),normal_nucleoli__4(33)).
head(id(448),mitoses__3(33)).
head(id(449),clump_thickness__6(232)).
head(id(450),cell_size_uniformity__8(232)).
head(id(451),cell_shape_uniformity__7(232)).
head(id(452),marginal_adhesion__5(232)).
head(id(453),single_epi_cell_size__6(232)).
head(id(454),bare_nuclei__8(232)).
head(id(455),bland_chromatin__8(232)).
head(id(456),normal_nucleoli__9(232)).
head(id(457),mitoses__2(232)).
head(id(458),clump_thickness__8(6)).
head(id(459),marginal_adhesion__8(6)).
head(id(460),single_epi_cell_size__7(6)).
head(id(461),bland_chromatin__9(6)).
head(id(462),normal_nucleoli__7(6)).
head(id(463),mitoses__1(6)).
head(id(464),clump_thickness__6(219)).
head(id(465),cell_shape_uniformity__7(219)).
head(id(466),marginal_adhesion__7(219)).
head(id(467),single_epi_cell_size__6(219)).
head(id(468),bare_nuclei__4(219)).
head(id(469),bland_chromatin__8(219)).
head(id(470),mitoses__2(219)).
head(id(471),clump_thickness__2(102)).
head(id(472),cell_size_uniformity__3(102)).
head(id(473),cell_shape_uniformity__4(102)).
head(id(474),marginal_adhesion__4(102)).
head(id(475),single_epi_cell_size__2(102)).
head(id(476),bare_nuclei__5(102)).
head(id(477),bland_chromatin__2(102)).
head(id(478),normal_nucleoli__5(102)).
head(id(479),mitoses__1(102)).
head(id(480),clump_thickness__5(52)).
head(id(481),cell_size_uniformity__3(52)).
head(id(482),cell_shape_uniformity__3(52)).
head(id(483),marginal_adhesion__4(52)).
head(id(484),single_epi_cell_size__2(52)).
head(id(485),bare_nuclei__4(52)).
head(id(486),bland_chromatin__3(52)).
head(id(487),normal_nucleoli__4(52)).
head(id(488),mitoses__1(52)).
head(id(489),cell_size_uniformity__6(222)).
head(id(490),cell_shape_uniformity__4(222)).
head(id(491),marginal_adhesion__3(222)).
head(id(492),bland_chromatin__9(222)).
head(id(493),mitoses__1(222)).
head(id(494),clump_thickness__9(160)).
head(id(495),cell_size_uniformity__9(160)).
head(id(496),marginal_adhesion__3(160)).
head(id(497),single_epi_cell_size__6(160)).
head(id(498),bland_chromatin__7(160)).
head(id(499),mitoses__6(160)).
head(id(500),cell_size_uniformity__8(168)).
head(id(501),single_epi_cell_size__6(168)).
head(id(502),bare_nuclei__1(168)).
head(id(503),bland_chromatin__3(168)).
head(id(504),normal_nucleoli__1(168)).
head(id(505),clump_thickness__6(174)).
head(id(506),single_epi_cell_size__8(174)).
head(id(507),mitoses__7(174)).
head(id(508),clump_thickness__3(47)).
head(id(509),cell_size_uniformity__7(47)).
head(id(510),cell_shape_uniformity__7(47)).
head(id(511),marginal_adhesion__4(47)).
head(id(512),single_epi_cell_size__4(47)).
head(id(513),bare_nuclei__9(47)).
head(id(514),bland_chromatin__4(47)).
head(id(515),normal_nucleoli__8(47)).
head(id(516),mitoses__1(47)).
head(id(517),clump_thickness__8(228)).
head(id(518),cell_size_uniformity__9(228)).
head(id(519),cell_shape_uniformity__9(228)).
head(id(520),marginal_adhesion__5(228)).
head(id(521),single_epi_cell_size__3(228)).
head(id(522),bare_nuclei__5(228)).
head(id(523),bland_chromatin__7(228)).
head(id(524),normal_nucleoli__7(228)).
head(id(525),mitoses__1(228)).
head(id(526),clump_thickness__4(223)).
head(id(527),cell_size_uniformity__1(223)).
head(id(528),cell_shape_uniformity__1(223)).
head(id(529),marginal_adhesion__3(223)).
head(id(530),single_epi_cell_size__1(223)).
head(id(531),bare_nuclei__5(223)).
head(id(532),bland_chromatin__2(223)).
head(id(533),normal_nucleoli__1(223)).
head(id(534),mitoses__1(223)).
head(id(535),clump_thickness__5(68)).
head(id(536),cell_size_uniformity__3(68)).
head(id(537),cell_shape_uniformity__4(68)).
head(id(538),marginal_adhesion__1(68)).
head(id(539),single_epi_cell_size__8(68)).
head(id(540),bland_chromatin__4(68)).
head(id(541),normal_nucleoli__9(68)).
head(id(542),mitoses__1(68)).
head(id(543),single_epi_cell_size__3(215)).
head(id(544),normal_nucleoli__6(215)).
head(id(545),mitoses__1(215)).
head(id(546),clump_thickness__5(156)).
head(id(547),cell_size_uniformity__5(156)).
head(id(548),cell_shape_uniformity__5(156)).
head(id(549),marginal_adhesion__6(156)).
head(id(550),single_epi_cell_size__3(156)).
head(id(551),bland_chromatin__3(156)).
head(id(552),normal_nucleoli__1(156)).
head(id(553),mitoses__1(156)).
head(id(554),clump_thickness__3(87)).
head(id(555),cell_size_uniformity__3(87)).
head(id(556),cell_shape_uniformity__6(87)).
head(id(557),marginal_adhesion__4(87)).
head(id(558),single_epi_cell_size__5(87)).
head(id(559),bare_nuclei__8(87)).
head(id(560),bland_chromatin__4(87)).
head(id(561),normal_nucleoli__4(87)).
head(id(562),mitoses__1(87)).
head(id(563),clump_thickness__6(43)).
head(id(564),marginal_adhesion__2(43)).
head(id(565),single_epi_cell_size__8(43)).
head(id(566),bland_chromatin__7(43)).
head(id(567),normal_nucleoli__3(43)).
head(id(568),mitoses__3(43)).
head(id(569),clump_thickness__7(16)).
head(id(570),cell_size_uniformity__4(16)).
head(id(571),cell_shape_uniformity__6(16)).
head(id(572),marginal_adhesion__4(16)).
head(id(573),single_epi_cell_size__6(16)).
head(id(574),bare_nuclei__1(16)).
head(id(575),bland_chromatin__4(16)).
head(id(576),normal_nucleoli__3(16)).
head(id(577),mitoses__1(16)).
head(id(578),clump_thickness__9(201)).
head(id(579),cell_size_uniformity__7(201)).
head(id(580),cell_shape_uniformity__7(201)).
head(id(581),marginal_adhesion__5(201)).
head(id(582),single_epi_cell_size__5(201)).
head(id(583),bland_chromatin__7(201)).
head(id(584),normal_nucleoli__8(201)).
head(id(585),mitoses__3(201)).
head(id(586),clump_thickness__7(106)).
head(id(587),cell_size_uniformity__3(106)).
head(id(588),cell_shape_uniformity__4(106)).
head(id(589),marginal_adhesion__4(106)).
head(id(590),single_epi_cell_size__3(106)).
head(id(591),bare_nuclei__3(106)).
head(id(592),bland_chromatin__3(106)).
head(id(593),normal_nucleoli__2(106)).
head(id(594),mitoses__7(106)).
head(id(595),clump_thickness__8(15)).
head(id(596),cell_size_uniformity__7(15)).
head(id(597),cell_shape_uniformity__5(15)).
head(id(598),single_epi_cell_size__7(15)).
head(id(599),bare_nuclei__9(15)).
head(id(600),bland_chromatin__5(15)).
head(id(601),normal_nucleoli__5(15)).
head(id(602),mitoses__4(15)).
head(id(603),clump_thickness__5(86)).
head(id(604),cell_shape_uniformity__6(86)).
head(id(605),marginal_adhesion__1(86)).
head(id(606),bare_nuclei__4(86)).
head(id(607),bland_chromatin__4(86)).
head(id(608),clump_thickness__5(178)).
head(id(609),marginal_adhesion__3(178)).
head(id(610),single_epi_cell_size__8(178)).
head(id(611),bare_nuclei__1(178)).
head(id(612),bland_chromatin__5(178)).
head(id(613),mitoses__3(178)).
head(id(614),clump_thickness__2(81)).
head(id(615),cell_size_uniformity__2(81)).
head(id(616),cell_shape_uniformity__2(81)).
head(id(617),marginal_adhesion__1(81)).
head(id(618),single_epi_cell_size__1(81)).
head(id(619),bare_nuclei__1(81)).
head(id(620),bland_chromatin__7(81)).
head(id(621),normal_nucleoli__1(81)).
head(id(622),mitoses__1(81)).
head(id(623),clump_thickness__1(170)).
head(id(624),cell_size_uniformity__1(170)).
head(id(625),cell_shape_uniformity__1(170)).
head(id(626),marginal_adhesion__2(170)).
head(id(627),single_epi_cell_size__1(170)).
head(id(628),bare_nuclei__1(170)).
head(id(629),bland_chromatin__1(170)).
head(id(630),normal_nucleoli__1(170)).
head(id(631),mitoses__1(170)).
head(id(632),clump_thickness__2(90)).
head(id(633),cell_size_uniformity__1(90)).
head(id(634),cell_shape_uniformity__1(90)).
head(id(635),marginal_adhesion__2(90)).
head(id(636),single_epi_cell_size__3(90)).
head(id(637),bare_nuclei__1(90)).
head(id(638),bland_chromatin__2(90)).
head(id(639),normal_nucleoli__1(90)).
head(id(640),mitoses__1(90)).
head(id(641),clump_thickness__4(17)).
head(id(642),cell_size_uniformity__1(17)).
head(id(643),cell_shape_uniformity__1(17)).
head(id(644),marginal_adhesion__1(17)).
head(id(645),single_epi_cell_size__2(17)).
head(id(646),bare_nuclei__1(17)).
head(id(647),bland_chromatin__2(17)).
head(id(648),normal_nucleoli__1(17)).
head(id(649),mitoses__1(17)).
head(id(650),clump_thickness__1(245)).
head(id(651),cell_size_uniformity__1(245)).
head(id(652),cell_shape_uniformity__1(245)).
head(id(653),marginal_adhesion__1(245)).
head(id(654),single_epi_cell_size__2(245)).
head(id(655),bare_nuclei__1(245)).
head(id(656),bland_chromatin__3(245)).
head(id(657),normal_nucleoli__1(245)).
head(id(658),mitoses__1(245)).
head(id(659),clump_thickness__5(1)).
head(id(660),cell_size_uniformity__1(1)).
head(id(661),cell_shape_uniformity__1(1)).
head(id(662),marginal_adhesion__1(1)).
head(id(663),single_epi_cell_size__2(1)).
head(id(664),bare_nuclei__1(1)).
head(id(665),bland_chromatin__3(1)).
head(id(666),normal_nucleoli__1(1)).
head(id(667),mitoses__1(1)).
head(id(668),clump_thickness__1(209)).
head(id(669),cell_size_uniformity__1(209)).
head(id(670),cell_shape_uniformity__1(209)).
head(id(671),marginal_adhesion__1(209)).
head(id(672),single_epi_cell_size__1(209)).
head(id(673),bare_nuclei__1(209)).
head(id(674),bland_chromatin__3(209)).
head(id(675),normal_nucleoli__1(209)).
head(id(676),mitoses__1(209)).
head(id(677),clump_thickness__3(120)).
head(id(678),cell_size_uniformity__2(120)).
head(id(679),cell_shape_uniformity__1(120)).
head(id(680),marginal_adhesion__1(120)).
head(id(681),single_epi_cell_size__2(120)).
head(id(682),bare_nuclei__2(120)).
head(id(683),bland_chromatin__3(120)).
head(id(684),normal_nucleoli__1(120)).
head(id(685),mitoses__1(120)).
head(id(686),clump_thickness__1(144)).
head(id(687),cell_size_uniformity__1(144)).
head(id(688),cell_shape_uniformity__1(144)).
head(id(689),marginal_adhesion__1(144)).
head(id(690),single_epi_cell_size__2(144)).
head(id(691),bare_nuclei__5(144)).
head(id(692),bland_chromatin__1(144)).
head(id(693),normal_nucleoli__1(144)).
head(id(694),mitoses__1(144)).
head(id(695),clump_thickness__4(103)).
head(id(696),cell_size_uniformity__1(103)).
head(id(697),cell_shape_uniformity__2(103)).
head(id(698),marginal_adhesion__1(103)).
head(id(699),single_epi_cell_size__2(103)).
head(id(700),bare_nuclei__1(103)).
head(id(701),bland_chromatin__3(103)).
head(id(702),normal_nucleoli__1(103)).
head(id(703),mitoses__1(103)).
head(id(704),clump_thickness__3(138)).
head(id(705),cell_size_uniformity__1(138)).
head(id(706),cell_shape_uniformity__1(138)).
head(id(707),marginal_adhesion__1(138)).
head(id(708),single_epi_cell_size__2(138)).
head(id(709),bare_nuclei__1(138)).
head(id(710),bland_chromatin__1(138)).
head(id(711),normal_nucleoli__1(138)).
head(id(712),mitoses__1(138)).
head(id(713),clump_thickness__2(97)).
head(id(714),cell_size_uniformity__1(97)).
head(id(715),cell_shape_uniformity__1(97)).
head(id(716),marginal_adhesion__2(97)).
head(id(717),single_epi_cell_size__2(97)).
head(id(718),bare_nuclei__1(97)).
head(id(719),bland_chromatin__1(97)).
head(id(720),normal_nucleoli__1(97)).
head(id(721),mitoses__1(97)).
head(id(722),clump_thickness__1(182)).
head(id(723),cell_size_uniformity__1(182)).
head(id(724),cell_shape_uniformity__1(182)).
head(id(725),marginal_adhesion__1(182)).
head(id(726),single_epi_cell_size__2(182)).
head(id(727),bare_nuclei__1(182)).
head(id(728),bland_chromatin__1(182)).
head(id(729),normal_nucleoli__1(182)).
head(id(730),mitoses__1(182)).
head(id(731),clump_thickness__1(121)).
head(id(732),cell_size_uniformity__1(121)).
head(id(733),cell_shape_uniformity__2(121)).
head(id(734),marginal_adhesion__2(121)).
head(id(735),single_epi_cell_size__2(121)).
head(id(736),bare_nuclei__1(121)).
head(id(737),bland_chromatin__3(121)).
head(id(738),normal_nucleoli__1(121)).
head(id(739),mitoses__1(121)).
head(id(740),clump_thickness__1(116)).
head(id(741),cell_size_uniformity__1(116)).
head(id(742),cell_shape_uniformity__1(116)).
head(id(743),marginal_adhesion__1(116)).
head(id(744),single_epi_cell_size__2(116)).
head(id(745),bare_nuclei__5(116)).
head(id(746),bland_chromatin__1(116)).
head(id(747),normal_nucleoli__1(116)).
head(id(748),mitoses__1(116)).
head(id(749),clump_thickness__4(18)).
head(id(750),cell_size_uniformity__1(18)).
head(id(751),cell_shape_uniformity__1(18)).
head(id(752),marginal_adhesion__1(18)).
head(id(753),single_epi_cell_size__2(18)).
head(id(754),bare_nuclei__1(18)).
head(id(755),bland_chromatin__3(18)).
head(id(756),normal_nucleoli__1(18)).
head(id(757),mitoses__1(18)).
head(id(758),clump_thickness__1(62)).
head(id(759),cell_size_uniformity__1(62)).
head(id(760),cell_shape_uniformity__1(62)).
head(id(761),marginal_adhesion__1(62)).
head(id(762),single_epi_cell_size__2(62)).
head(id(763),bare_nuclei__2(62)).
head(id(764),bland_chromatin__2(62)).
head(id(765),normal_nucleoli__1(62)).
head(id(766),mitoses__1(62)).
head(id(767),clump_thickness__1(226)).
head(id(768),cell_size_uniformity__1(226)).
head(id(769),cell_shape_uniformity__1(226)).
head(id(770),marginal_adhesion__1(226)).
head(id(771),single_epi_cell_size__2(226)).
head(id(772),bare_nuclei__1(226)).
head(id(773),bland_chromatin__2(226)).
head(id(774),normal_nucleoli__1(226)).
head(id(775),mitoses__1(226)).
head(id(776),clump_thickness__1(151)).
head(id(777),cell_size_uniformity__1(151)).
head(id(778),cell_shape_uniformity__1(151)).
head(id(779),marginal_adhesion__1(151)).
head(id(780),single_epi_cell_size__1(151)).
head(id(781),bare_nuclei__1(151)).
head(id(782),bland_chromatin__3(151)).
head(id(783),normal_nucleoli__1(151)).
head(id(784),mitoses__1(151)).
head(id(785),clump_thickness__2(36)).
head(id(786),cell_size_uniformity__1(36)).
head(id(787),cell_shape_uniformity__1(36)).
head(id(788),marginal_adhesion__1(36)).
head(id(789),single_epi_cell_size__2(36)).
head(id(790),bare_nuclei__1(36)).
head(id(791),bland_chromatin__2(36)).
head(id(792),normal_nucleoli__1(36)).
head(id(793),mitoses__1(36)).
head(id(794),clump_thickness__1(213)).
head(id(795),cell_size_uniformity__1(213)).
head(id(796),cell_shape_uniformity__1(213)).
head(id(797),marginal_adhesion__1(213)).
head(id(798),single_epi_cell_size__2(213)).
head(id(799),bare_nuclei__1(213)).
head(id(800),bland_chromatin__3(213)).
head(id(801),normal_nucleoli__1(213)).
head(id(802),mitoses__1(213)).
head(id(803),clump_thickness__2(80)).
head(id(804),cell_size_uniformity__1(80)).
head(id(805),cell_shape_uniformity__1(80)).
head(id(806),marginal_adhesion__1(80)).
head(id(807),single_epi_cell_size__3(80)).
head(id(808),bare_nuclei__1(80)).
head(id(809),bland_chromatin__2(80)).
head(id(810),normal_nucleoli__1(80)).
head(id(811),mitoses__1(80)).
head(id(812),clump_thickness__3(79)).
head(id(813),cell_size_uniformity__1(79)).
head(id(814),cell_shape_uniformity__1(79)).
head(id(815),marginal_adhesion__1(79)).
head(id(816),single_epi_cell_size__2(79)).
head(id(817),bare_nuclei__3(79)).
head(id(818),bland_chromatin__3(79)).
head(id(819),normal_nucleoli__1(79)).
head(id(820),mitoses__1(79)).
head(id(821),clump_thickness__1(94)).
head(id(822),cell_size_uniformity__1(94)).
head(id(823),cell_shape_uniformity__1(94)).
head(id(824),marginal_adhesion__1(94)).
head(id(825),single_epi_cell_size__2(94)).
head(id(826),bare_nuclei__1(94)).
head(id(827),bland_chromatin__2(94)).
head(id(828),normal_nucleoli__1(94)).
head(id(829),mitoses__1(94)).
head(id(830),clump_thickness__4(179)).
head(id(831),cell_size_uniformity__1(179)).
head(id(832),cell_shape_uniformity__1(179)).
head(id(833),marginal_adhesion__1(179)).
head(id(834),single_epi_cell_size__2(179)).
head(id(835),bare_nuclei__1(179)).
head(id(836),bland_chromatin__3(179)).
head(id(837),normal_nucleoli__1(179)).
head(id(838),mitoses__1(179)).
head(id(839),clump_thickness__3(134)).
head(id(840),cell_size_uniformity__1(134)).
head(id(841),cell_shape_uniformity__1(134)).
head(id(842),marginal_adhesion__1(134)).
head(id(843),single_epi_cell_size__2(134)).
head(id(844),bare_nuclei__1(134)).
head(id(845),bland_chromatin__2(134)).
head(id(846),normal_nucleoli__2(134)).
head(id(847),mitoses__1(134)).
head(id(848),clump_thickness__1(221)).
head(id(849),cell_size_uniformity__1(221)).
head(id(850),cell_shape_uniformity__1(221)).
head(id(851),marginal_adhesion__2(221)).
head(id(852),single_epi_cell_size__2(221)).
head(id(853),bare_nuclei__1(221)).
head(id(854),bland_chromatin__3(221)).
head(id(855),normal_nucleoli__1(221)).
head(id(856),mitoses__1(221)).
head(id(857),clump_thickness__3(23)).
head(id(858),cell_size_uniformity__1(23)).
head(id(859),cell_shape_uniformity__1(23)).
head(id(860),marginal_adhesion__1(23)).
head(id(861),single_epi_cell_size__2(23)).
head(id(862),bare_nuclei__1(23)).
head(id(863),bland_chromatin__2(23)).
head(id(864),normal_nucleoli__1(23)).
head(id(865),mitoses__1(23)).
head(id(866),clump_thickness__1(109)).
head(id(867),cell_size_uniformity__1(109)).
head(id(868),cell_shape_uniformity__1(109)).
head(id(869),marginal_adhesion__1(109)).
head(id(870),single_epi_cell_size__2(109)).
head(id(871),bare_nuclei__1(109)).
head(id(872),bland_chromatin__2(109)).
head(id(873),normal_nucleoli__3(109)).
head(id(874),mitoses__1(109)).
head(id(875),clump_thickness__5(241)).
head(id(876),cell_size_uniformity__1(241)).
head(id(877),cell_shape_uniformity__3(241)).
head(id(878),marginal_adhesion__3(241)).
head(id(879),single_epi_cell_size__2(241)).
head(id(880),bare_nuclei__2(241)).
head(id(881),bland_chromatin__2(241)).
head(id(882),normal_nucleoli__3(241)).
head(id(883),mitoses__1(241)).
head(id(884),clump_thickness__4(162)).
head(id(885),cell_size_uniformity__1(162)).
head(id(886),cell_shape_uniformity__1(162)).
head(id(887),marginal_adhesion__1(162)).
head(id(888),single_epi_cell_size__2(162)).
head(id(889),bare_nuclei__1(162)).
head(id(890),bland_chromatin__3(162)).
head(id(891),normal_nucleoli__2(162)).
head(id(892),mitoses__1(162)).
head(id(893),clump_thickness__5(28)).
head(id(894),cell_size_uniformity__1(28)).
head(id(895),cell_shape_uniformity__1(28)).
head(id(896),marginal_adhesion__1(28)).
head(id(897),single_epi_cell_size__2(28)).
head(id(898),bare_nuclei__1(28)).
head(id(899),bland_chromatin__2(28)).
head(id(900),normal_nucleoli__1(28)).
head(id(901),mitoses__1(28)).
head(id(902),clump_thickness__5(204)).
head(id(903),cell_size_uniformity__1(204)).
head(id(904),cell_shape_uniformity__1(204)).
head(id(905),marginal_adhesion__1(204)).
head(id(906),single_epi_cell_size__2(204)).
head(id(907),bare_nuclei__1(204)).
head(id(908),bland_chromatin__3(204)).
head(id(909),normal_nucleoli__1(204)).
head(id(910),mitoses__1(204)).
head(id(911),clump_thickness__8(117)).
head(id(912),cell_size_uniformity__3(117)).
head(id(913),cell_shape_uniformity__3(117)).
head(id(914),marginal_adhesion__1(117)).
head(id(915),single_epi_cell_size__2(117)).
head(id(916),bare_nuclei__2(117)).
head(id(917),bland_chromatin__3(117)).
head(id(918),normal_nucleoli__2(117)).
head(id(919),mitoses__1(117)).
head(id(920),clump_thickness__1(164)).
head(id(921),cell_size_uniformity__1(164)).
head(id(922),cell_shape_uniformity__1(164)).
head(id(923),marginal_adhesion__2(164)).
head(id(924),single_epi_cell_size__1(164)).
head(id(925),bare_nuclei__3(164)).
head(id(926),bland_chromatin__1(164)).
head(id(927),normal_nucleoli__1(164)).
head(id(928),mitoses__7(164)).
head(id(929),clump_thickness__2(145)).
head(id(930),cell_size_uniformity__1(145)).
head(id(931),cell_shape_uniformity__1(145)).
head(id(932),marginal_adhesion__1(145)).
head(id(933),single_epi_cell_size__2(145)).
head(id(934),bare_nuclei__1(145)).
head(id(935),bland_chromatin__2(145)).
head(id(936),normal_nucleoli__1(145)).
head(id(937),mitoses__1(145)).
head(id(938),clump_thickness__5(198)).
head(id(939),cell_size_uniformity__1(198)).
head(id(940),cell_shape_uniformity__1(198)).
head(id(941),marginal_adhesion__4(198)).
head(id(942),single_epi_cell_size__2(198)).
head(id(943),bare_nuclei__1(198)).
head(id(944),bland_chromatin__3(198)).
head(id(945),normal_nucleoli__1(198)).
head(id(946),mitoses__1(198)).
head(id(947),clump_thickness__3(195)).
head(id(948),cell_size_uniformity__1(195)).
head(id(949),cell_shape_uniformity__1(195)).
head(id(950),marginal_adhesion__1(195)).
head(id(951),single_epi_cell_size__2(195)).
head(id(952),bare_nuclei__1(195)).
head(id(953),bland_chromatin__3(195)).
head(id(954),normal_nucleoli__1(195)).
head(id(955),mitoses__1(195)).
head(id(956),clump_thickness__1(205)).
head(id(957),cell_size_uniformity__1(205)).
head(id(958),cell_shape_uniformity__1(205)).
head(id(959),marginal_adhesion__1(205)).
head(id(960),single_epi_cell_size__2(205)).
head(id(961),bare_nuclei__1(205)).
head(id(962),bland_chromatin__3(205)).
head(id(963),normal_nucleoli__1(205)).
head(id(964),mitoses__1(205)).
head(id(965),clump_thickness__1(14)).
head(id(966),cell_size_uniformity__1(14)).
head(id(967),cell_shape_uniformity__1(14)).
head(id(968),marginal_adhesion__1(14)).
head(id(969),single_epi_cell_size__2(14)).
head(id(970),bare_nuclei__3(14)).
head(id(971),bland_chromatin__3(14)).
head(id(972),normal_nucleoli__1(14)).
head(id(973),mitoses__1(14)).
head(id(974),clump_thickness__4(196)).
head(id(975),cell_size_uniformity__1(196)).
head(id(976),cell_shape_uniformity__1(196)).
head(id(977),marginal_adhesion__1(196)).
head(id(978),single_epi_cell_size__2(196)).
head(id(979),bare_nuclei__1(196)).
head(id(980),bland_chromatin__3(196)).
head(id(981),normal_nucleoli__1(196)).
head(id(982),mitoses__1(196)).
head(id(983),clump_thickness__1(11)).
head(id(984),cell_size_uniformity__1(11)).
head(id(985),cell_shape_uniformity__1(11)).
head(id(986),marginal_adhesion__1(11)).
head(id(987),single_epi_cell_size__1(11)).
head(id(988),bare_nuclei__1(11)).
head(id(989),bland_chromatin__3(11)).
head(id(990),normal_nucleoli__1(11)).
head(id(991),mitoses__1(11)).
head(id(992),clump_thickness__3(141)).
head(id(993),cell_size_uniformity__1(141)).
head(id(994),cell_shape_uniformity__1(141)).
head(id(995),marginal_adhesion__1(141)).
head(id(996),single_epi_cell_size__2(141)).
head(id(997),bare_nuclei__1(141)).
head(id(998),bland_chromatin__1(141)).
head(id(999),normal_nucleoli__1(141)).
head(id(1000),mitoses__1(141)).
head(id(1001),clump_thickness__1(30)).
head(id(1002),cell_size_uniformity__1(30)).
head(id(1003),cell_shape_uniformity__3(30)).
head(id(1004),marginal_adhesion__1(30)).
head(id(1005),single_epi_cell_size__2(30)).
head(id(1006),bare_nuclei__1(30)).
head(id(1007),bland_chromatin__1(30)).
head(id(1008),normal_nucleoli__1(30)).
head(id(1009),mitoses__1(30)).
head(id(1010),clump_thickness__3(242)).
head(id(1011),cell_size_uniformity__1(242)).
head(id(1012),cell_shape_uniformity__1(242)).
head(id(1013),marginal_adhesion__3(242)).
head(id(1014),single_epi_cell_size__1(242)).
head(id(1015),bare_nuclei__1(242)).
head(id(1016),bland_chromatin__3(242)).
head(id(1017),normal_nucleoli__1(242)).
head(id(1018),mitoses__1(242)).
head(id(1019),clump_thickness__5(136)).
head(id(1020),cell_size_uniformity__1(136)).
head(id(1021),cell_shape_uniformity__1(136)).
head(id(1022),marginal_adhesion__1(136)).
head(id(1023),single_epi_cell_size__2(136)).
head(id(1024),bare_nuclei__2(136)).
head(id(1025),bland_chromatin__3(136)).
head(id(1026),normal_nucleoli__3(136)).
head(id(1027),mitoses__1(136)).
head(id(1028),clump_thickness__1(65)).
head(id(1029),cell_size_uniformity__1(65)).
head(id(1030),cell_shape_uniformity__1(65)).
head(id(1031),marginal_adhesion__1(65)).
head(id(1032),single_epi_cell_size__2(65)).
head(id(1033),bare_nuclei__1(65)).
head(id(1034),bland_chromatin__2(65)).
head(id(1035),normal_nucleoli__1(65)).
head(id(1036),mitoses__1(65)).
head(id(1037),clump_thickness__5(98)).
head(id(1038),cell_size_uniformity__1(98)).
head(id(1039),cell_shape_uniformity__1(98)).
head(id(1040),marginal_adhesion__1(98)).
head(id(1041),single_epi_cell_size__2(98)).
head(id(1042),bare_nuclei__1(98)).
head(id(1043),bland_chromatin__3(98)).
head(id(1044),normal_nucleoli__1(98)).
head(id(1045),mitoses__1(98)).
head(id(1046),clump_thickness__1(173)).
head(id(1047),cell_size_uniformity__1(173)).
head(id(1048),cell_shape_uniformity__1(173)).
head(id(1049),marginal_adhesion__1(173)).
head(id(1050),single_epi_cell_size__2(173)).
head(id(1051),bare_nuclei__1(173)).
head(id(1052),bland_chromatin__2(173)).
head(id(1053),normal_nucleoli__1(173)).
head(id(1054),mitoses__1(173)).
head(id(1055),clump_thickness__6(4)).
head(id(1056),cell_size_uniformity__8(4)).
head(id(1057),cell_shape_uniformity__8(4)).
head(id(1058),marginal_adhesion__1(4)).
head(id(1059),single_epi_cell_size__3(4)).
head(id(1060),bare_nuclei__4(4)).
head(id(1061),bland_chromatin__3(4)).
head(id(1062),normal_nucleoli__7(4)).
head(id(1063),mitoses__1(4)).
head(id(1064),clump_thickness__1(119)).
head(id(1065),cell_size_uniformity__1(119)).
head(id(1066),cell_shape_uniformity__1(119)).
head(id(1067),marginal_adhesion__1(119)).
head(id(1068),single_epi_cell_size__4(119)).
head(id(1069),bare_nuclei__3(119)).
head(id(1070),bland_chromatin__1(119)).
head(id(1071),normal_nucleoli__1(119)).
head(id(1072),mitoses__1(119)).
head(id(1073),clump_thickness__1(244)).
head(id(1074),cell_size_uniformity__1(244)).
head(id(1075),cell_shape_uniformity__1(244)).
head(id(1076),marginal_adhesion__1(244)).
head(id(1077),single_epi_cell_size__2(244)).
head(id(1078),bare_nuclei__5(244)).
head(id(1079),bland_chromatin__5(244)).
head(id(1080),normal_nucleoli__1(244)).
head(id(1081),mitoses__1(244)).
head(id(1082),clump_thickness__2(32)).
head(id(1083),cell_size_uniformity__1(32)).
head(id(1084),cell_shape_uniformity__1(32)).
head(id(1085),marginal_adhesion__1(32)).
head(id(1086),single_epi_cell_size__2(32)).
head(id(1087),bare_nuclei__1(32)).
head(id(1088),bland_chromatin__3(32)).
head(id(1089),normal_nucleoli__1(32)).
head(id(1090),mitoses__1(32)).
head(id(1091),clump_thickness__3(171)).
head(id(1092),cell_size_uniformity__1(171)).
head(id(1093),cell_shape_uniformity__1(171)).
head(id(1094),marginal_adhesion__1(171)).
head(id(1095),single_epi_cell_size__2(171)).
head(id(1096),bare_nuclei__1(171)).
head(id(1097),bland_chromatin__1(171)).
head(id(1098),normal_nucleoli__1(171)).
head(id(1099),mitoses__1(171)).
head(id(1100),clump_thickness__5(2)).
head(id(1101),cell_size_uniformity__4(2)).
head(id(1102),cell_shape_uniformity__4(2)).
head(id(1103),marginal_adhesion__5(2)).
head(id(1104),single_epi_cell_size__7(2)).
head(id(1105),bland_chromatin__3(2)).
head(id(1106),normal_nucleoli__2(2)).
head(id(1107),mitoses__1(2)).
head(id(1108),clump_thickness__5(83)).
head(id(1109),cell_size_uniformity__2(83)).
head(id(1110),cell_shape_uniformity__1(83)).
head(id(1111),marginal_adhesion__1(83)).
head(id(1112),single_epi_cell_size__2(83)).
head(id(1113),bare_nuclei__1(83)).
head(id(1114),bland_chromatin__3(83)).
head(id(1115),normal_nucleoli__1(83)).
head(id(1116),mitoses__1(83)).
head(id(1117),clump_thickness__4(49)).
head(id(1118),cell_size_uniformity__1(49)).
head(id(1119),cell_shape_uniformity__1(49)).
head(id(1120),marginal_adhesion__3(49)).
head(id(1121),single_epi_cell_size__2(49)).
head(id(1122),bare_nuclei__1(49)).
head(id(1123),bland_chromatin__3(49)).
head(id(1124),normal_nucleoli__1(49)).
head(id(1125),mitoses__1(49)).
head(id(1126),clump_thickness__6(38)).
head(id(1127),cell_size_uniformity__2(38)).
head(id(1128),cell_shape_uniformity__1(38)).
head(id(1129),marginal_adhesion__1(38)).
head(id(1130),single_epi_cell_size__1(38)).
head(id(1131),bare_nuclei__1(38)).
head(id(1132),bland_chromatin__7(38)).
head(id(1133),normal_nucleoli__1(38)).
head(id(1134),mitoses__1(38)).
head(id(1135),clump_thickness__3(200)).
head(id(1136),cell_size_uniformity__1(200)).
head(id(1137),cell_shape_uniformity__1(200)).
head(id(1138),marginal_adhesion__1(200)).
head(id(1139),single_epi_cell_size__2(200)).
head(id(1140),bare_nuclei__1(200)).
head(id(1141),bland_chromatin__2(200)).
head(id(1142),normal_nucleoli__1(200)).
head(id(1143),mitoses__1(200)).
head(id(1144),clump_thickness__4(137)).
head(id(1145),cell_size_uniformity__1(137)).
head(id(1146),cell_shape_uniformity__1(137)).
head(id(1147),marginal_adhesion__1(137)).
head(id(1148),single_epi_cell_size__2(137)).
head(id(1149),bare_nuclei__1(137)).
head(id(1150),bland_chromatin__2(137)).
head(id(1151),normal_nucleoli__1(137)).
head(id(1152),mitoses__1(137)).
head(id(1153),clump_thickness__2(95)).
head(id(1154),cell_size_uniformity__1(95)).
head(id(1155),cell_shape_uniformity__1(95)).
head(id(1156),marginal_adhesion__1(95)).
head(id(1157),single_epi_cell_size__2(95)).
head(id(1158),bare_nuclei__1(95)).
head(id(1159),bland_chromatin__3(95)).
head(id(1160),normal_nucleoli__1(95)).
head(id(1161),mitoses__1(95)).
head(id(1162),clump_thickness__2(34)).
head(id(1163),cell_size_uniformity__1(34)).
head(id(1164),cell_shape_uniformity__1(34)).
head(id(1165),marginal_adhesion__2(34)).
head(id(1166),single_epi_cell_size__2(34)).
head(id(1167),bare_nuclei__1(34)).
head(id(1168),bland_chromatin__3(34)).
head(id(1169),normal_nucleoli__1(34)).
head(id(1170),mitoses__1(34)).
head(id(1171),clump_thickness__3(149)).
head(id(1172),cell_size_uniformity__1(149)).
head(id(1173),cell_shape_uniformity__1(149)).
head(id(1174),marginal_adhesion__3(149)).
head(id(1175),single_epi_cell_size__8(149)).
head(id(1176),bare_nuclei__1(149)).
head(id(1177),bland_chromatin__5(149)).
head(id(1178),normal_nucleoli__8(149)).
head(id(1179),mitoses__1(149)).
head(id(1180),clump_thickness__3(31)).
head(id(1181),cell_size_uniformity__1(31)).
head(id(1182),cell_shape_uniformity__1(31)).
head(id(1183),marginal_adhesion__1(31)).
head(id(1184),single_epi_cell_size__1(31)).
head(id(1185),bare_nuclei__1(31)).
head(id(1186),bland_chromatin__2(31)).
head(id(1187),normal_nucleoli__1(31)).
head(id(1188),mitoses__1(31)).
head(id(1189),clump_thickness__4(10)).
head(id(1190),cell_size_uniformity__2(10)).
head(id(1191),cell_shape_uniformity__1(10)).
head(id(1192),marginal_adhesion__1(10)).
head(id(1193),single_epi_cell_size__2(10)).
head(id(1194),bare_nuclei__1(10)).
head(id(1195),bland_chromatin__2(10)).
head(id(1196),normal_nucleoli__1(10)).
head(id(1197),mitoses__1(10)).
head(id(1198),clump_thickness__1(218)).
head(id(1199),cell_size_uniformity__1(218)).
head(id(1200),cell_shape_uniformity__1(218)).
head(id(1201),marginal_adhesion__1(218)).
head(id(1202),single_epi_cell_size__2(218)).
head(id(1203),bare_nuclei__1(218)).
head(id(1204),bland_chromatin__3(218)).
head(id(1205),normal_nucleoli__1(218)).
head(id(1206),mitoses__1(218)).
head(id(1207),clump_thickness__6(220)).
head(id(1208),cell_size_uniformity__1(220)).
head(id(1209),cell_shape_uniformity__3(220)).
head(id(1210),marginal_adhesion__1(220)).
head(id(1211),single_epi_cell_size__2(220)).
head(id(1212),bare_nuclei__1(220)).
head(id(1213),bland_chromatin__3(220)).
head(id(1214),normal_nucleoli__1(220)).
head(id(1215),mitoses__1(220)).
head(id(1216),clump_thickness__4(5)).
head(id(1217),cell_size_uniformity__1(5)).
head(id(1218),cell_shape_uniformity__1(5)).
head(id(1219),marginal_adhesion__3(5)).
head(id(1220),single_epi_cell_size__2(5)).
head(id(1221),bare_nuclei__1(5)).
head(id(1222),bland_chromatin__3(5)).
head(id(1223),normal_nucleoli__1(5)).
head(id(1224),mitoses__1(5)).
head(id(1225),clump_thickness__1(208)).
head(id(1226),cell_size_uniformity__1(208)).
head(id(1227),cell_shape_uniformity__1(208)).
head(id(1228),marginal_adhesion__1(208)).
head(id(1229),single_epi_cell_size__1(208)).
head(id(1230),bare_nuclei__1(208)).
head(id(1231),bland_chromatin__3(208)).
head(id(1232),normal_nucleoli__1(208)).
head(id(1233),mitoses__1(208)).
head(id(1234),clump_thickness__3(3)).
head(id(1235),cell_size_uniformity__1(3)).
head(id(1236),cell_shape_uniformity__1(3)).
head(id(1237),marginal_adhesion__1(3)).
head(id(1238),single_epi_cell_size__2(3)).
head(id(1239),bare_nuclei__2(3)).
head(id(1240),bland_chromatin__3(3)).
head(id(1241),normal_nucleoli__1(3)).
head(id(1242),mitoses__1(3)).
head(id(1243),clump_thickness__4(93)).
head(id(1244),cell_size_uniformity__1(93)).
head(id(1245),cell_shape_uniformity__1(93)).
head(id(1246),marginal_adhesion__1(93)).
head(id(1247),single_epi_cell_size__2(93)).
head(id(1248),bare_nuclei__1(93)).
head(id(1249),bland_chromatin__3(93)).
head(id(1250),normal_nucleoli__1(93)).
head(id(1251),mitoses__1(93)).
head(id(1252),clump_thickness__4(67)).
head(id(1253),cell_size_uniformity__1(67)).
head(id(1254),cell_shape_uniformity__1(67)).
head(id(1255),marginal_adhesion__1(67)).
head(id(1256),single_epi_cell_size__2(67)).
head(id(1257),bare_nuclei__1(67)).
head(id(1258),bland_chromatin__3(67)).
head(id(1259),normal_nucleoli__1(67)).
head(id(1260),mitoses__1(67)).
head(id(1261),clump_thickness__1(130)).
head(id(1262),cell_size_uniformity__1(130)).
head(id(1263),cell_shape_uniformity__1(130)).
head(id(1264),marginal_adhesion__1(130)).
head(id(1265),bare_nuclei__1(130)).
head(id(1266),bland_chromatin__1(130)).
head(id(1267),normal_nucleoli__1(130)).
head(id(1268),mitoses__1(130)).
head(id(1269),clump_thickness__1(194)).
head(id(1270),cell_size_uniformity__1(194)).
head(id(1271),cell_shape_uniformity__1(194)).
head(id(1272),marginal_adhesion__1(194)).
head(id(1273),single_epi_cell_size__2(194)).
head(id(1274),bare_nuclei__1(194)).
head(id(1275),bland_chromatin__3(194)).
head(id(1276),normal_nucleoli__1(194)).
head(id(1277),mitoses__1(194)).
head(id(1278),clump_thickness__1(148)).
head(id(1279),cell_size_uniformity__1(148)).
head(id(1280),cell_shape_uniformity__1(148)).
head(id(1281),marginal_adhesion__1(148)).
head(id(1282),single_epi_cell_size__3(148)).
head(id(1283),bare_nuclei__2(148)).
head(id(1284),bland_chromatin__2(148)).
head(id(1285),normal_nucleoli__1(148)).
head(id(1286),mitoses__1(148)).
head(id(1287),clump_thickness__4(82)).
head(id(1288),cell_size_uniformity__1(82)).
head(id(1289),cell_shape_uniformity__1(82)).
head(id(1290),marginal_adhesion__2(82)).
head(id(1291),single_epi_cell_size__2(82)).
head(id(1292),bare_nuclei__1(82)).
head(id(1293),bland_chromatin__2(82)).
head(id(1294),normal_nucleoli__1(82)).
head(id(1295),mitoses__1(82)).
head(id(1296),clump_thickness__3(92)).
head(id(1297),cell_size_uniformity__1(92)).
head(id(1298),cell_shape_uniformity__1(92)).
head(id(1299),marginal_adhesion__2(92)).
head(id(1300),single_epi_cell_size__2(92)).
head(id(1301),bare_nuclei__1(92)).
head(id(1302),bland_chromatin__1(92)).
head(id(1303),normal_nucleoli__1(92)).
head(id(1304),mitoses__1(92)).
head(id(1305),clump_thickness__2(12)).
head(id(1306),cell_size_uniformity__1(12)).
head(id(1307),cell_shape_uniformity__1(12)).
head(id(1308),marginal_adhesion__1(12)).
head(id(1309),single_epi_cell_size__2(12)).
head(id(1310),bare_nuclei__1(12)).
head(id(1311),bland_chromatin__2(12)).
head(id(1312),normal_nucleoli__1(12)).
head(id(1313),mitoses__1(12)).
head(id(1314),clump_thickness__1(172)).
head(id(1315),cell_size_uniformity__1(172)).
head(id(1316),cell_shape_uniformity__1(172)).
head(id(1317),marginal_adhesion__1(172)).
head(id(1318),single_epi_cell_size__2(172)).
head(id(1319),bare_nuclei__1(172)).
head(id(1320),bland_chromatin__3(172)).
head(id(1321),normal_nucleoli__1(172)).
head(id(1322),mitoses__1(172)).
head(id(1323),clump_thickness__1(7)).
head(id(1324),cell_size_uniformity__1(7)).
head(id(1325),cell_shape_uniformity__1(7)).
head(id(1326),marginal_adhesion__1(7)).
head(id(1327),single_epi_cell_size__2(7)).
head(id(1328),bland_chromatin__3(7)).
head(id(1329),normal_nucleoli__1(7)).
head(id(1330),mitoses__1(7)).
head(id(1331),clump_thickness__1(190)).
head(id(1332),cell_size_uniformity__2(190)).
head(id(1333),cell_shape_uniformity__3(190)).
head(id(1334),marginal_adhesion__1(190)).
head(id(1335),single_epi_cell_size__2(190)).
head(id(1336),bare_nuclei__1(190)).
head(id(1337),bland_chromatin__3(190)).
head(id(1338),normal_nucleoli__1(190)).
head(id(1339),mitoses__1(190)).
head(id(1340),clump_thickness__1(229)).
head(id(1341),cell_size_uniformity__1(229)).
head(id(1342),cell_shape_uniformity__1(229)).
head(id(1343),marginal_adhesion__1(229)).
head(id(1344),single_epi_cell_size__1(229)).
head(id(1345),bare_nuclei__1(229)).
head(id(1346),bland_chromatin__3(229)).
head(id(1347),normal_nucleoli__1(229)).
head(id(1348),mitoses__1(229)).
head(id(1349),clump_thickness__1(181)).
head(id(1350),cell_size_uniformity__1(181)).
head(id(1351),cell_shape_uniformity__1(181)).
head(id(1352),marginal_adhesion__1(181)).
head(id(1353),single_epi_cell_size__1(181)).
head(id(1354),bare_nuclei__1(181)).
head(id(1355),bland_chromatin__3(181)).
head(id(1356),normal_nucleoli__1(181)).
head(id(1357),mitoses__1(181)).
head(id(1358),clump_thickness__1(199)).
head(id(1359),cell_size_uniformity__1(199)).
head(id(1360),cell_shape_uniformity__1(199)).
head(id(1361),marginal_adhesion__1(199)).
head(id(1362),single_epi_cell_size__2(199)).
head(id(1363),bare_nuclei__1(199)).
head(id(1364),bland_chromatin__1(199)).
head(id(1365),normal_nucleoli__1(199)).
head(id(1366),mitoses__1(199)).
head(id(1367),clump_thickness__4(154)).
head(id(1368),cell_size_uniformity__1(154)).
head(id(1369),cell_shape_uniformity__1(154)).
head(id(1370),marginal_adhesion__1(154)).
head(id(1371),single_epi_cell_size__2(154)).
head(id(1372),bare_nuclei__3(154)).
head(id(1373),bland_chromatin__1(154)).
head(id(1374),normal_nucleoli__1(154)).
head(id(1375),mitoses__1(154)).
head(id(1376),clump_thickness__3(235)).
head(id(1377),cell_size_uniformity__3(235)).
head(id(1378),cell_shape_uniformity__2(235)).
head(id(1379),marginal_adhesion__1(235)).
head(id(1380),single_epi_cell_size__3(235)).
head(id(1381),bare_nuclei__1(235)).
head(id(1382),bland_chromatin__3(235)).
head(id(1383),normal_nucleoli__6(235)).
head(id(1384),mitoses__1(235)).
head(id(1385),clump_thickness__1(126)).
head(id(1386),cell_size_uniformity__1(126)).
head(id(1387),cell_shape_uniformity__1(126)).
head(id(1388),marginal_adhesion__1(126)).
head(id(1389),single_epi_cell_size__2(126)).
head(id(1390),bare_nuclei__1(126)).
head(id(1391),bland_chromatin__2(126)).
head(id(1392),normal_nucleoli__1(126)).
head(id(1393),mitoses__1(126)).
head(id(1394),clump_thickness__1(155)).
head(id(1395),cell_size_uniformity__1(155)).
head(id(1396),cell_shape_uniformity__1(155)).
head(id(1397),marginal_adhesion__1(155)).
head(id(1398),single_epi_cell_size__2(155)).
head(id(1399),bare_nuclei__1(155)).
head(id(1400),bland_chromatin__1(155)).
head(id(1401),normal_nucleoli__1(155)).
head(id(1402),mitoses__1(155)).
head(id(1403),clump_thickness__4(122)).
head(id(1404),cell_size_uniformity__2(122)).
head(id(1405),cell_shape_uniformity__1(122)).
head(id(1406),marginal_adhesion__1(122)).
head(id(1407),single_epi_cell_size__2(122)).
head(id(1408),bare_nuclei__2(122)).
head(id(1409),bland_chromatin__3(122)).
head(id(1410),normal_nucleoli__1(122)).
head(id(1411),mitoses__1(122)).
head(id(1412),clump_thickness__5(131)).
head(id(1413),cell_size_uniformity__1(131)).
head(id(1414),cell_shape_uniformity__3(131)).
head(id(1415),marginal_adhesion__1(131)).
head(id(1416),single_epi_cell_size__2(131)).
head(id(1417),bare_nuclei__1(131)).
head(id(1418),bland_chromatin__2(131)).
head(id(1419),normal_nucleoli__1(131)).
head(id(1420),mitoses__1(131)).
head(id(1421),clump_thickness__1(203)).
head(id(1422),cell_size_uniformity__1(203)).
head(id(1423),cell_shape_uniformity__1(203)).
head(id(1424),marginal_adhesion__1(203)).
head(id(1425),single_epi_cell_size__2(203)).
head(id(1426),bare_nuclei__1(203)).
head(id(1427),bland_chromatin__3(203)).
head(id(1428),normal_nucleoli__1(203)).
head(id(1429),mitoses__1(203)).
head(id(1430),clump_thickness__3(84)).
head(id(1431),cell_size_uniformity__1(84)).
head(id(1432),cell_shape_uniformity__1(84)).
head(id(1433),marginal_adhesion__1(84)).
head(id(1434),single_epi_cell_size__2(84)).
head(id(1435),bare_nuclei__2(84)).
head(id(1436),bland_chromatin__7(84)).
head(id(1437),normal_nucleoli__1(84)).
head(id(1438),mitoses__1(84)).
head(id(1439),clump_thickness__2(177)).
head(id(1440),cell_size_uniformity__1(177)).
head(id(1441),cell_shape_uniformity__1(177)).
head(id(1442),marginal_adhesion__1(177)).
head(id(1443),single_epi_cell_size__2(177)).
head(id(1444),bare_nuclei__1(177)).
head(id(1445),bland_chromatin__3(177)).
head(id(1446),normal_nucleoli__1(177)).
head(id(1447),mitoses__1(177)).
head(id(1448),clump_thickness__8(233)).
head(id(1449),cell_size_uniformity__4(233)).
head(id(1450),cell_shape_uniformity__6(233)).
head(id(1451),marginal_adhesion__3(233)).
head(id(1452),single_epi_cell_size__3(233)).
head(id(1453),bare_nuclei__1(233)).
head(id(1454),bland_chromatin__4(233)).
head(id(1455),normal_nucleoli__3(233)).
head(id(1456),mitoses__1(233)).
head(id(1457),clump_thickness__2(158)).
head(id(1458),cell_size_uniformity__1(158)).
head(id(1459),cell_shape_uniformity__1(158)).
head(id(1460),marginal_adhesion__1(158)).
head(id(1461),single_epi_cell_size__2(158)).
head(id(1462),bare_nuclei__1(158)).
head(id(1463),bland_chromatin__3(158)).
head(id(1464),normal_nucleoli__1(158)).
head(id(1465),mitoses__1(158)).
head(id(1466),clump_thickness__6(20)).
head(id(1467),cell_size_uniformity__1(20)).
head(id(1468),cell_shape_uniformity__1(20)).
head(id(1469),marginal_adhesion__1(20)).
head(id(1470),single_epi_cell_size__2(20)).
head(id(1471),bare_nuclei__1(20)).
head(id(1472),bland_chromatin__3(20)).
head(id(1473),normal_nucleoli__1(20)).
head(id(1474),mitoses__1(20)).
head(id(1475),clump_thickness__8(197)).
head(id(1476),cell_size_uniformity__4(197)).
head(id(1477),cell_shape_uniformity__4(197)).
head(id(1478),marginal_adhesion__5(197)).
head(id(1479),single_epi_cell_size__4(197)).
head(id(1480),bare_nuclei__7(197)).
head(id(1481),bland_chromatin__7(197)).
head(id(1482),normal_nucleoli__8(197)).
head(id(1483),mitoses__2(197)).
head(id(1484),clump_thickness__1(48)).
head(id(1485),cell_size_uniformity__1(48)).
head(id(1486),cell_shape_uniformity__1(48)).
head(id(1487),marginal_adhesion__1(48)).
head(id(1488),single_epi_cell_size__2(48)).
head(id(1489),bare_nuclei__1(48)).
head(id(1490),bland_chromatin__2(48)).
head(id(1491),normal_nucleoli__1(48)).
head(id(1492),mitoses__1(48)).
head(id(1493),clump_thickness__1(73)).
head(id(1494),cell_size_uniformity__3(73)).
head(id(1495),cell_shape_uniformity__3(73)).
head(id(1496),marginal_adhesion__2(73)).
head(id(1497),single_epi_cell_size__2(73)).
head(id(1498),bare_nuclei__1(73)).
head(id(1499),bland_chromatin__7(73)).
head(id(1500),normal_nucleoli__2(73)).
head(id(1501),mitoses__1(73)).
head(id(1502),clump_thickness__6(183)).
head(id(1503),cell_size_uniformity__1(183)).
head(id(1504),cell_shape_uniformity__1(183)).
head(id(1505),marginal_adhesion__1(183)).
head(id(1506),single_epi_cell_size__2(183)).
head(id(1507),bare_nuclei__1(183)).
head(id(1508),bland_chromatin__3(183)).
head(id(1509),normal_nucleoli__1(183)).
head(id(1510),mitoses__1(183)).
head(id(1511),clump_thickness__2(186)).
head(id(1512),cell_size_uniformity__1(186)).
head(id(1513),cell_shape_uniformity__1(186)).
head(id(1514),marginal_adhesion__1(186)).
head(id(1515),single_epi_cell_size__1(186)).
head(id(1516),bare_nuclei__1(186)).
head(id(1517),bland_chromatin__3(186)).
head(id(1518),normal_nucleoli__1(186)).
head(id(1519),mitoses__1(186)).
head(id(1520),clump_thickness__1(46)).
head(id(1521),cell_size_uniformity__1(46)).
head(id(1522),cell_shape_uniformity__1(46)).
head(id(1523),marginal_adhesion__1(46)).
head(id(1524),single_epi_cell_size__2(46)).
head(id(1525),bare_nuclei__1(46)).
head(id(1526),bland_chromatin__2(46)).
head(id(1527),normal_nucleoli__1(46)).
head(id(1528),mitoses__2(46)).
head(id(1529),clump_thickness__3(169)).
head(id(1530),cell_size_uniformity__1(169)).
head(id(1531),cell_shape_uniformity__1(169)).
head(id(1532),marginal_adhesion__1(169)).
head(id(1533),single_epi_cell_size__2(169)).
head(id(1534),bare_nuclei__1(169)).
head(id(1535),bland_chromatin__3(169)).
head(id(1536),normal_nucleoli__1(169)).
head(id(1537),mitoses__1(169)).
head(id(1538),clump_thickness__5(210)).
head(id(1539),cell_size_uniformity__1(210)).
head(id(1540),cell_shape_uniformity__1(210)).
head(id(1541),marginal_adhesion__1(210)).
head(id(1542),single_epi_cell_size__1(210)).
head(id(1543),bare_nuclei__1(210)).
head(id(1544),bland_chromatin__3(210)).
head(id(1545),normal_nucleoli__1(210)).
head(id(1546),mitoses__1(210)).
head(id(1547),clump_thickness__3(128)).
head(id(1548),cell_size_uniformity__1(128)).
head(id(1549),cell_shape_uniformity__1(128)).
head(id(1550),marginal_adhesion__1(128)).
head(id(1551),single_epi_cell_size__2(128)).
head(id(1552),bare_nuclei__1(128)).
head(id(1553),bland_chromatin__3(128)).
head(id(1554),normal_nucleoli__1(128)).
head(id(1555),mitoses__1(128)).
head(id(1556),clump_thickness__1(96)).
head(id(1557),cell_size_uniformity__1(96)).
head(id(1558),cell_shape_uniformity__1(96)).
head(id(1559),marginal_adhesion__1(96)).
head(id(1560),single_epi_cell_size__2(96)).
head(id(1561),bare_nuclei__1(96)).
head(id(1562),bland_chromatin__3(96)).
head(id(1563),normal_nucleoli__1(96)).
head(id(1564),mitoses__1(96)).
head(id(3304,A),malignant(A)) :- dom(A).
body(id(3304,A),bland_chromatin__7(A)) :- dom(A).
body(id(3304,A),mitoses__4(A)) :- dom(A).
body(id(3304,A),single_epi_cell_size__7(A)) :- dom(A).
head(id(4958,A),malignant(A)) :- dom(A).
body(id(4958,A),clump_thickness__6(A)) :- dom(A).
body(id(4958,A),mitoses__7(A)) :- dom(A).
body(id(4958,A),single_epi_cell_size__8(A)) :- dom(A).
head(id(8275,A),malignant(A)) :- dom(A).
body(id(8275,A),alpha_1(A)) :- dom(A).
body(id(8275,A),mitoses__1(A)) :- dom(A).
body(id(8275,A),normal_nucleoli__6(A)) :- dom(A).
body(id(8275,A),single_epi_cell_size__3(A)) :- dom(A).
head(id(9941,A),malignant(A)) :- dom(A).
body(id(9941,A),bland_chromatin__8(A)) :- dom(A).
body(id(9941,A),clump_thickness__8(A)) :- dom(A).
body(id(9941,A),mitoses__6(A)) :- dom(A).
body(id(9941,A),single_epi_cell_size__5(A)) :- dom(A).
head(id(11608,A),malignant(A)) :- dom(A).
body(id(11608,A),bare_nuclei__1(A)) :- dom(A).
body(id(11608,A),bland_chromatin__8(A)) :- dom(A).
body(id(11608,A),mitoses__8(A)) :- dom(A).
body(id(11608,A),normal_nucleoli__8(A)) :- dom(A).
head(id(13279,A),malignant(A)) :- dom(A).
body(id(13279,A),bland_chromatin__4(A)) :- dom(A).
body(id(13279,A),cell_size_uniformity__5(A)) :- dom(A).
body(id(13279,A),clump_thickness__7(A)) :- dom(A).
body(id(13279,A),mitoses__3(A)) :- dom(A).
head(id(14954,A),malignant(A)) :- dom(A).
body(id(14954,A),bare_nuclei__8(A)) :- dom(A).
body(id(14954,A),bland_chromatin__7(A)) :- dom(A).
body(id(14954,A),marginal_adhesion__8(A)) :- dom(A).
body(id(14954,A),mitoses__1(A)) :- dom(A).
body(id(14954,A),single_epi_cell_size__6(A)) :- dom(A).
head(id(16634,A),malignant(A)) :- dom(A).
body(id(16634,A),bland_chromatin__4(A)) :- dom(A).
body(id(16634,A),marginal_adhesion__8(A)) :- dom(A).
body(id(16634,A),mitoses__1(A)) :- dom(A).
body(id(16634,A),normal_nucleoli__1(A)) :- dom(A).
body(id(16634,A),single_epi_cell_size__2(A)) :- dom(A).
head(id(18319,A),malignant(A)) :- dom(A).
body(id(18319,A),bare_nuclei__9(A)) :- dom(A).
body(id(18319,A),bland_chromatin__3(A)) :- dom(A).
body(id(18319,A),clump_thickness__8(A)) :- dom(A).
body(id(18319,A),marginal_adhesion__8(A)) :- dom(A).
body(id(18319,A),single_epi_cell_size__6(A)) :- dom(A).
head(id(20009,A),malignant(A)) :- dom(A).
body(id(20009,A),bland_chromatin__7(A)) :- dom(A).
body(id(20009,A),cell_shape_uniformity__6(A)) :- dom(A).
body(id(20009,A),cell_size_uniformity__5(A)) :- dom(A).
body(id(20009,A),normal_nucleoli__7(A)) :- dom(A).
body(id(20009,A),single_epi_cell_size__6(A)) :- dom(A).
head(id(21704,A),malignant(A)) :- dom(A).
body(id(21704,A),bare_nuclei__1(A)) :- dom(A).
body(id(21704,A),bland_chromatin__8(A)) :- dom(A).
body(id(21704,A),marginal_adhesion__4(A)) :- dom(A).
body(id(21704,A),mitoses__1(A)) :- dom(A).
body(id(21704,A),single_epi_cell_size__8(A)) :- dom(A).
head(id(23404,A),malignant(A)) :- dom(A).
body(id(23404,A),bare_nuclei__8(A)) :- dom(A).
body(id(23404,A),bland_chromatin__8(A)) :- dom(A).
body(id(23404,A),marginal_adhesion__3(A)) :- dom(A).
body(id(23404,A),mitoses__1(A)) :- dom(A).
body(id(23404,A),normal_nucleoli__1(A)) :- dom(A).
head(id(25109,A),malignant(A)) :- dom(A).
body(id(25109,A),bland_chromatin__7(A)) :- dom(A).
body(id(25109,A),clump_thickness__5(A)) :- dom(A).
body(id(25109,A),marginal_adhesion__9(A)) :- dom(A).
body(id(25109,A),mitoses__5(A)) :- dom(A).
body(id(25109,A),single_epi_cell_size__6(A)) :- dom(A).
head(id(26819,A),malignant(A)) :- dom(A).
body(id(26819,A),bland_chromatin__9(A)) :- dom(A).
body(id(26819,A),cell_shape_uniformity__4(A)) :- dom(A).
body(id(26819,A),cell_size_uniformity__6(A)) :- dom(A).
body(id(26819,A),marginal_adhesion__3(A)) :- dom(A).
body(id(26819,A),mitoses__1(A)) :- dom(A).
head(id(28534,A),malignant(A)) :- dom(A).
body(id(28534,A),bare_nuclei__1(A)) :- dom(A).
body(id(28534,A),bland_chromatin__3(A)) :- dom(A).
body(id(28534,A),cell_size_uniformity__8(A)) :- dom(A).
body(id(28534,A),normal_nucleoli__1(A)) :- dom(A).
body(id(28534,A),single_epi_cell_size__6(A)) :- dom(A).
head(id(30254,A),malignant(A)) :- dom(A).
body(id(30254,A),bare_nuclei__4(A)) :- dom(A).
body(id(30254,A),bland_chromatin__4(A)) :- dom(A).
body(id(30254,A),cell_shape_uniformity__6(A)) :- dom(A).
body(id(30254,A),clump_thickness__5(A)) :- dom(A).
body(id(30254,A),marginal_adhesion__1(A)) :- dom(A).
head(id(31979,A),malignant(A)) :- dom(A).
body(id(31979,A),bland_chromatin__8(A)) :- dom(A).
body(id(31979,A),cell_shape_uniformity__8(A)) :- dom(A).
body(id(31979,A),cell_size_uniformity__8(A)) :- dom(A).
body(id(31979,A),marginal_adhesion__4(A)) :- dom(A).
body(id(31979,A),mitoses__1(A)) :- dom(A).
body(id(31979,A),normal_nucleoli__1(A)) :- dom(A).
head(id(33710,A),malignant(A)) :- dom(A).
body(id(33710,A),bare_nuclei__8(A)) :- dom(A).
body(id(33710,A),bland_chromatin__3(A)) :- dom(A).
body(id(33710,A),clump_thickness__9(A)) :- dom(A).
body(id(33710,A),marginal_adhesion__1(A)) :- dom(A).
body(id(33710,A),mitoses__1(A)) :- dom(A).
body(id(33710,A),normal_nucleoli__3(A)) :- dom(A).
head(id(35447,A),malignant(A)) :- dom(A).
body(id(35447,A),bare_nuclei__5(A)) :- dom(A).
body(id(35447,A),bland_chromatin__8(A)) :- dom(A).
body(id(35447,A),cell_shape_uniformity__8(A)) :- dom(A).
body(id(35447,A),marginal_adhesion__6(A)) :- dom(A).
body(id(35447,A),mitoses__1(A)) :- dom(A).
body(id(35447,A),single_epi_cell_size__4(A)) :- dom(A).
head(id(37190,A),malignant(A)) :- dom(A).
body(id(37190,A),bare_nuclei__2(A)) :- dom(A).
body(id(37190,A),bland_chromatin__7(A)) :- dom(A).
body(id(37190,A),cell_shape_uniformity__2(A)) :- dom(A).
body(id(37190,A),clump_thickness__6(A)) :- dom(A).
body(id(37190,A),marginal_adhesion__8(A)) :- dom(A).
body(id(37190,A),normal_nucleoli__8(A)) :- dom(A).
head(id(38939,A),malignant(A)) :- dom(A).
body(id(38939,A),bland_chromatin__4(A)) :- dom(A).
body(id(38939,A),cell_shape_uniformity__8(A)) :- dom(A).
body(id(38939,A),cell_size_uniformity__8(A)) :- dom(A).
body(id(38939,A),marginal_adhesion__2(A)) :- dom(A).
body(id(38939,A),normal_nucleoli__8(A)) :- dom(A).
body(id(38939,A),single_epi_cell_size__8(A)) :- dom(A).
head(id(40694,A),malignant(A)) :- dom(A).
body(id(40694,A),bare_nuclei__5(A)) :- dom(A).
body(id(40694,A),bland_chromatin__3(A)) :- dom(A).
body(id(40694,A),cell_shape_uniformity__5(A)) :- dom(A).
body(id(40694,A),cell_size_uniformity__3(A)) :- dom(A).
body(id(40694,A),marginal_adhesion__1(A)) :- dom(A).
body(id(40694,A),mitoses__2(A)) :- dom(A).
head(id(42455,A),malignant(A)) :- dom(A).
body(id(42455,A),bland_chromatin__7(A)) :- dom(A).
body(id(42455,A),cell_shape_uniformity__3(A)) :- dom(A).
body(id(42455,A),cell_size_uniformity__3(A)) :- dom(A).
body(id(42455,A),mitoses__3(A)) :- dom(A).
body(id(42455,A),normal_nucleoli__3(A)) :- dom(A).
body(id(42455,A),single_epi_cell_size__2(A)) :- dom(A).
head(id(44222,A),malignant(A)) :- dom(A).
body(id(44222,A),bland_chromatin__9(A)) :- dom(A).
body(id(44222,A),clump_thickness__8(A)) :- dom(A).
body(id(44222,A),marginal_adhesion__8(A)) :- dom(A).
body(id(44222,A),mitoses__1(A)) :- dom(A).
body(id(44222,A),normal_nucleoli__7(A)) :- dom(A).
body(id(44222,A),single_epi_cell_size__7(A)) :- dom(A).
head(id(45995,A),malignant(A)) :- dom(A).
body(id(45995,A),bland_chromatin__7(A)) :- dom(A).
body(id(45995,A),cell_size_uniformity__9(A)) :- dom(A).
body(id(45995,A),clump_thickness__9(A)) :- dom(A).
body(id(45995,A),marginal_adhesion__3(A)) :- dom(A).
body(id(45995,A),mitoses__6(A)) :- dom(A).
body(id(45995,A),single_epi_cell_size__6(A)) :- dom(A).
head(id(47774,A),malignant(A)) :- dom(A).
body(id(47774,A),bland_chromatin__7(A)) :- dom(A).
body(id(47774,A),clump_thickness__6(A)) :- dom(A).
body(id(47774,A),marginal_adhesion__2(A)) :- dom(A).
body(id(47774,A),mitoses__3(A)) :- dom(A).
body(id(47774,A),normal_nucleoli__3(A)) :- dom(A).
body(id(47774,A),single_epi_cell_size__8(A)) :- dom(A).
head(id(49559,A),malignant(A)) :- dom(A).
body(id(49559,A),bare_nuclei__1(A)) :- dom(A).
body(id(49559,A),bland_chromatin__5(A)) :- dom(A).
body(id(49559,A),clump_thickness__5(A)) :- dom(A).
body(id(49559,A),marginal_adhesion__3(A)) :- dom(A).
body(id(49559,A),mitoses__3(A)) :- dom(A).
body(id(49559,A),single_epi_cell_size__8(A)) :- dom(A).
head(id(51350,A),malignant(A)) :- dom(A).
body(id(51350,A),bare_nuclei__8(A)) :- dom(A).
body(id(51350,A),bland_chromatin__9(A)) :- dom(A).
body(id(51350,A),cell_shape_uniformity__4(A)) :- dom(A).
body(id(51350,A),cell_size_uniformity__8(A)) :- dom(A).
body(id(51350,A),clump_thickness__5(A)) :- dom(A).
body(id(51350,A),mitoses__1(A)) :- dom(A).
body(id(51350,A),single_epi_cell_size__5(A)) :- dom(A).
head(id(53148,A),malignant(A)) :- dom(A).
body(id(53148,A),bland_chromatin__7(A)) :- dom(A).
body(id(53148,A),cell_shape_uniformity__6(A)) :- dom(A).
body(id(53148,A),cell_size_uniformity__5(A)) :- dom(A).
body(id(53148,A),clump_thickness__7(A)) :- dom(A).
body(id(53148,A),mitoses__4(A)) :- dom(A).
body(id(53148,A),normal_nucleoli__9(A)) :- dom(A).
body(id(53148,A),single_epi_cell_size__5(A)) :- dom(A).
head(id(54953,A),malignant(A)) :- dom(A).
body(id(54953,A),bland_chromatin__4(A)) :- dom(A).
body(id(54953,A),cell_shape_uniformity__5(A)) :- dom(A).
body(id(54953,A),cell_size_uniformity__4(A)) :- dom(A).
body(id(54953,A),clump_thickness__9(A)) :- dom(A).
body(id(54953,A),mitoses__1(A)) :- dom(A).
body(id(54953,A),normal_nucleoli__8(A)) :- dom(A).
body(id(54953,A),single_epi_cell_size__6(A)) :- dom(A).
head(id(56765,A),malignant(A)) :- dom(A).
body(id(56765,A),bare_nuclei__6(A)) :- dom(A).
body(id(56765,A),bland_chromatin__3(A)) :- dom(A).
body(id(56765,A),clump_thickness__8(A)) :- dom(A).
body(id(56765,A),marginal_adhesion__1(A)) :- dom(A).
body(id(56765,A),mitoses__1(A)) :- dom(A).
body(id(56765,A),normal_nucleoli__9(A)) :- dom(A).
body(id(56765,A),single_epi_cell_size__3(A)) :- dom(A).
head(id(58584,A),malignant(A)) :- dom(A).
body(id(58584,A),bare_nuclei__5(A)) :- dom(A).
body(id(58584,A),bland_chromatin__4(A)) :- dom(A).
body(id(58584,A),cell_shape_uniformity__6(A)) :- dom(A).
body(id(58584,A),cell_size_uniformity__3(A)) :- dom(A).
body(id(58584,A),marginal_adhesion__2(A)) :- dom(A).
body(id(58584,A),mitoses__2(A)) :- dom(A).
body(id(58584,A),single_epi_cell_size__3(A)) :- dom(A).
head(id(60410,A),malignant(A)) :- dom(A).
body(id(60410,A),bland_chromatin__5(A)) :- dom(A).
body(id(60410,A),cell_shape_uniformity__2(A)) :- dom(A).
body(id(60410,A),cell_size_uniformity__3(A)) :- dom(A).
body(id(60410,A),clump_thickness__7(A)) :- dom(A).
body(id(60410,A),mitoses__4(A)) :- dom(A).
body(id(60410,A),normal_nucleoli__4(A)) :- dom(A).
body(id(60410,A),single_epi_cell_size__5(A)) :- dom(A).
head(id(62243,A),malignant(A)) :- dom(A).
body(id(62243,A),bland_chromatin__7(A)) :- dom(A).
body(id(62243,A),cell_shape_uniformity__7(A)) :- dom(A).
body(id(62243,A),cell_size_uniformity__8(A)) :- dom(A).
body(id(62243,A),clump_thickness__8(A)) :- dom(A).
body(id(62243,A),marginal_adhesion__4(A)) :- dom(A).
body(id(62243,A),mitoses__7(A)) :- dom(A).
body(id(62243,A),normal_nucleoli__8(A)) :- dom(A).
head(id(64083,A),malignant(A)) :- dom(A).
body(id(64083,A),bland_chromatin__5(A)) :- dom(A).
body(id(64083,A),cell_shape_uniformity__3(A)) :- dom(A).
body(id(64083,A),cell_size_uniformity__4(A)) :- dom(A).
body(id(64083,A),marginal_adhesion__2(A)) :- dom(A).
body(id(64083,A),mitoses__2(A)) :- dom(A).
body(id(64083,A),normal_nucleoli__3(A)) :- dom(A).
body(id(64083,A),single_epi_cell_size__3(A)) :- dom(A).
head(id(65930,A),malignant(A)) :- dom(A).
body(id(65930,A),bare_nuclei__5(A)) :- dom(A).
body(id(65930,A),bland_chromatin__3(A)) :- dom(A).
body(id(65930,A),cell_shape_uniformity__9(A)) :- dom(A).
body(id(65930,A),marginal_adhesion__3(A)) :- dom(A).
body(id(65930,A),mitoses__1(A)) :- dom(A).
body(id(65930,A),normal_nucleoli__5(A)) :- dom(A).
body(id(65930,A),single_epi_cell_size__7(A)) :- dom(A).
head(id(67784,A),malignant(A)) :- dom(A).
body(id(67784,A),bare_nuclei__2(A)) :- dom(A).
body(id(67784,A),bland_chromatin__4(A)) :- dom(A).
body(id(67784,A),cell_shape_uniformity__2(A)) :- dom(A).
body(id(67784,A),cell_size_uniformity__4(A)) :- dom(A).
body(id(67784,A),marginal_adhesion__1(A)) :- dom(A).
body(id(67784,A),normal_nucleoli__3(A)) :- dom(A).
body(id(67784,A),single_epi_cell_size__3(A)) :- dom(A).
head(id(69645,A),malignant(A)) :- dom(A).
body(id(69645,A),bland_chromatin__3(A)) :- dom(A).
body(id(69645,A),cell_shape_uniformity__7(A)) :- dom(A).
body(id(69645,A),cell_size_uniformity__6(A)) :- dom(A).
body(id(69645,A),clump_thickness__5(A)) :- dom(A).
body(id(69645,A),marginal_adhesion__8(A)) :- dom(A).
body(id(69645,A),mitoses__3(A)) :- dom(A).
body(id(69645,A),single_epi_cell_size__8(A)) :- dom(A).
head(id(71513,A),malignant(A)) :- dom(A).
body(id(71513,A),bland_chromatin__4(A)) :- dom(A).
body(id(71513,A),cell_shape_uniformity__7(A)) :- dom(A).
body(id(71513,A),cell_size_uniformity__7(A)) :- dom(A).
body(id(71513,A),marginal_adhesion__6(A)) :- dom(A).
body(id(71513,A),mitoses__2(A)) :- dom(A).
body(id(71513,A),normal_nucleoli__1(A)) :- dom(A).
body(id(71513,A),single_epi_cell_size__4(A)) :- dom(A).
head(id(73388,A),malignant(A)) :- dom(A).
body(id(73388,A),bland_chromatin__5(A)) :- dom(A).
body(id(73388,A),cell_shape_uniformity__7(A)) :- dom(A).
body(id(73388,A),cell_size_uniformity__7(A)) :- dom(A).
body(id(73388,A),marginal_adhesion__4(A)) :- dom(A).
body(id(73388,A),mitoses__2(A)) :- dom(A).
body(id(73388,A),normal_nucleoli__7(A)) :- dom(A).
body(id(73388,A),single_epi_cell_size__5(A)) :- dom(A).
head(id(75270,A),malignant(A)) :- dom(A).
body(id(75270,A),bland_chromatin__7(A)) :- dom(A).
body(id(75270,A),cell_shape_uniformity__5(A)) :- dom(A).
body(id(75270,A),cell_size_uniformity__5(A)) :- dom(A).
body(id(75270,A),marginal_adhesion__6(A)) :- dom(A).
body(id(75270,A),mitoses__2(A)) :- dom(A).
body(id(75270,A),normal_nucleoli__9(A)) :- dom(A).
body(id(75270,A),single_epi_cell_size__3(A)) :- dom(A).
head(id(77159,A),malignant(A)) :- dom(A).
body(id(77159,A),bland_chromatin__4(A)) :- dom(A).
body(id(77159,A),cell_shape_uniformity__5(A)) :- dom(A).
body(id(77159,A),cell_size_uniformity__4(A)) :- dom(A).
body(id(77159,A),marginal_adhesion__5(A)) :- dom(A).
body(id(77159,A),mitoses__1(A)) :- dom(A).
body(id(77159,A),normal_nucleoli__1(A)) :- dom(A).
body(id(77159,A),single_epi_cell_size__5(A)) :- dom(A).
head(id(79055,A),malignant(A)) :- dom(A).
body(id(79055,A),bare_nuclei__4(A)) :- dom(A).
body(id(79055,A),bland_chromatin__8(A)) :- dom(A).
body(id(79055,A),cell_shape_uniformity__7(A)) :- dom(A).
body(id(79055,A),clump_thickness__6(A)) :- dom(A).
body(id(79055,A),marginal_adhesion__7(A)) :- dom(A).
body(id(79055,A),mitoses__2(A)) :- dom(A).
body(id(79055,A),single_epi_cell_size__6(A)) :- dom(A).
head(id(80958,A),malignant(A)) :- dom(A).
body(id(80958,A),bare_nuclei__1(A)) :- dom(A).
body(id(80958,A),bland_chromatin__3(A)) :- dom(A).
body(id(80958,A),cell_shape_uniformity__5(A)) :- dom(A).
body(id(80958,A),cell_size_uniformity__6(A)) :- dom(A).
body(id(80958,A),clump_thickness__5(A)) :- dom(A).
body(id(80958,A),marginal_adhesion__6(A)) :- dom(A).
body(id(80958,A),mitoses__1(A)) :- dom(A).
body(id(80958,A),normal_nucleoli__1(A)) :- dom(A).
head(id(82869,A),malignant(A)) :- dom(A).
body(id(82869,A),bare_nuclei__7(A)) :- dom(A).
body(id(82869,A),bland_chromatin__8(A)) :- dom(A).
body(id(82869,A),cell_shape_uniformity__6(A)) :- dom(A).
body(id(82869,A),cell_size_uniformity__4(A)) :- dom(A).
body(id(82869,A),clump_thickness__5(A)) :- dom(A).
body(id(82869,A),marginal_adhesion__7(A)) :- dom(A).
body(id(82869,A),mitoses__1(A)) :- dom(A).
body(id(82869,A),single_epi_cell_size__9(A)) :- dom(A).
head(id(84788,A),malignant(A)) :- dom(A).
body(id(84788,A),bare_nuclei__8(A)) :- dom(A).
body(id(84788,A),bland_chromatin__7(A)) :- dom(A).
body(id(84788,A),cell_shape_uniformity__8(A)) :- dom(A).
body(id(84788,A),clump_thickness__8(A)) :- dom(A).
body(id(84788,A),marginal_adhesion__8(A)) :- dom(A).
body(id(84788,A),mitoses__1(A)) :- dom(A).
body(id(84788,A),normal_nucleoli__7(A)) :- dom(A).
body(id(84788,A),single_epi_cell_size__4(A)) :- dom(A).
head(id(86715,A),malignant(A)) :- dom(A).
body(id(86715,A),bare_nuclei__3(A)) :- dom(A).
body(id(86715,A),bland_chromatin__4(A)) :- dom(A).
body(id(86715,A),cell_shape_uniformity__5(A)) :- dom(A).
body(id(86715,A),cell_size_uniformity__3(A)) :- dom(A).
body(id(86715,A),clump_thickness__5(A)) :- dom(A).
body(id(86715,A),marginal_adhesion__5(A)) :- dom(A).
body(id(86715,A),mitoses__1(A)) :- dom(A).
body(id(86715,A),single_epi_cell_size__3(A)) :- dom(A).
head(id(88650,A),malignant(A)) :- dom(A).
body(id(88650,A),bland_chromatin__7(A)) :- dom(A).
body(id(88650,A),cell_shape_uniformity__3(A)) :- dom(A).
body(id(88650,A),cell_size_uniformity__5(A)) :- dom(A).
body(id(88650,A),clump_thickness__7(A)) :- dom(A).
body(id(88650,A),marginal_adhesion__7(A)) :- dom(A).
body(id(88650,A),mitoses__5(A)) :- dom(A).
body(id(88650,A),normal_nucleoli__5(A)) :- dom(A).
body(id(88650,A),single_epi_cell_size__4(A)) :- dom(A).
head(id(90593,A),malignant(A)) :- dom(A).
body(id(90593,A),bare_nuclei__3(A)) :- dom(A).
body(id(90593,A),bland_chromatin__6(A)) :- dom(A).
body(id(90593,A),cell_shape_uniformity__3(A)) :- dom(A).
body(id(90593,A),cell_size_uniformity__4(A)) :- dom(A).
body(id(90593,A),marginal_adhesion__1(A)) :- dom(A).
body(id(90593,A),mitoses__2(A)) :- dom(A).
body(id(90593,A),normal_nucleoli__5(A)) :- dom(A).
body(id(90593,A),single_epi_cell_size__3(A)) :- dom(A).
head(id(92544,A),malignant(A)) :- dom(A).
body(id(92544,A),bare_nuclei__8(A)) :- dom(A).
body(id(92544,A),bland_chromatin__7(A)) :- dom(A).
body(id(92544,A),cell_shape_uniformity__5(A)) :- dom(A).
body(id(92544,A),cell_size_uniformity__5(A)) :- dom(A).
body(id(92544,A),marginal_adhesion__6(A)) :- dom(A).
body(id(92544,A),mitoses__1(A)) :- dom(A).
body(id(92544,A),normal_nucleoli__1(A)) :- dom(A).
body(id(92544,A),single_epi_cell_size__8(A)) :- dom(A).
head(id(94503,A),malignant(A)) :- dom(A).
body(id(94503,A),bare_nuclei__8(A)) :- dom(A).
body(id(94503,A),bland_chromatin__7(A)) :- dom(A).
body(id(94503,A),cell_shape_uniformity__8(A)) :- dom(A).
body(id(94503,A),cell_size_uniformity__5(A)) :- dom(A).
body(id(94503,A),clump_thickness__1(A)) :- dom(A).
body(id(94503,A),marginal_adhesion__6(A)) :- dom(A).
body(id(94503,A),mitoses__1(A)) :- dom(A).
body(id(94503,A),single_epi_cell_size__5(A)) :- dom(A).
head(id(96470,A),malignant(A)) :- dom(A).
body(id(96470,A),bare_nuclei__9(A)) :- dom(A).
body(id(96470,A),bland_chromatin__7(A)) :- dom(A).
body(id(96470,A),cell_shape_uniformity__7(A)) :- dom(A).
body(id(96470,A),cell_size_uniformity__5(A)) :- dom(A).
body(id(96470,A),clump_thickness__3(A)) :- dom(A).
body(id(96470,A),marginal_adhesion__8(A)) :- dom(A).
body(id(96470,A),mitoses__7(A)) :- dom(A).
body(id(96470,A),single_epi_cell_size__8(A)) :- dom(A).
head(id(98445,A),malignant(A)) :- dom(A).
body(id(98445,A),bland_chromatin__6(A)) :- dom(A).
body(id(98445,A),cell_shape_uniformity__5(A)) :- dom(A).
body(id(98445,A),cell_size_uniformity__6(A)) :- dom(A).
body(id(98445,A),clump_thickness__8(A)) :- dom(A).
body(id(98445,A),marginal_adhesion__4(A)) :- dom(A).
body(id(98445,A),mitoses__1(A)) :- dom(A).
body(id(98445,A),normal_nucleoli__1(A)) :- dom(A).
body(id(98445,A),single_epi_cell_size__3(A)) :- dom(A).
head(id(100428,A),malignant(A)) :- dom(A).
body(id(100428,A),bland_chromatin__6(A)) :- dom(A).
body(id(100428,A),cell_shape_uniformity__6(A)) :- dom(A).
body(id(100428,A),cell_size_uniformity__6(A)) :- dom(A).
body(id(100428,A),clump_thickness__3(A)) :- dom(A).
body(id(100428,A),marginal_adhesion__6(A)) :- dom(A).
body(id(100428,A),mitoses__3(A)) :- dom(A).
body(id(100428,A),normal_nucleoli__8(A)) :- dom(A).
body(id(100428,A),single_epi_cell_size__5(A)) :- dom(A).
head(id(102419,A),malignant(A)) :- dom(A).
body(id(102419,A),bland_chromatin__3(A)) :- dom(A).
body(id(102419,A),cell_shape_uniformity__3(A)) :- dom(A).
body(id(102419,A),cell_size_uniformity__3(A)) :- dom(A).
body(id(102419,A),clump_thickness__5(A)) :- dom(A).
body(id(102419,A),marginal_adhesion__3(A)) :- dom(A).
body(id(102419,A),mitoses__1(A)) :- dom(A).
body(id(102419,A),normal_nucleoli__1(A)) :- dom(A).
body(id(102419,A),single_epi_cell_size__6(A)) :- dom(A).
head(id(104418,A),malignant(A)) :- dom(A).
body(id(104418,A),bland_chromatin__5(A)) :- dom(A).
body(id(104418,A),cell_shape_uniformity__4(A)) :- dom(A).
body(id(104418,A),cell_size_uniformity__2(A)) :- dom(A).
body(id(104418,A),clump_thickness__7(A)) :- dom(A).
body(id(104418,A),marginal_adhesion__1(A)) :- dom(A).
body(id(104418,A),mitoses__3(A)) :- dom(A).
body(id(104418,A),normal_nucleoli__4(A)) :- dom(A).
body(id(104418,A),single_epi_cell_size__6(A)) :- dom(A).
head(id(106425,A),malignant(A)) :- dom(A).
body(id(106425,A),bland_chromatin__5(A)) :- dom(A).
body(id(106425,A),cell_shape_uniformity__3(A)) :- dom(A).
body(id(106425,A),cell_size_uniformity__2(A)) :- dom(A).
body(id(106425,A),clump_thickness__5(A)) :- dom(A).
body(id(106425,A),marginal_adhesion__1(A)) :- dom(A).
body(id(106425,A),mitoses__1(A)) :- dom(A).
body(id(106425,A),normal_nucleoli__1(A)) :- dom(A).
body(id(106425,A),single_epi_cell_size__6(A)) :- dom(A).
head(id(108440,A),malignant(A)) :- dom(A).
body(id(108440,A),bare_nuclei__2(A)) :- dom(A).
body(id(108440,A),bland_chromatin__4(A)) :- dom(A).
body(id(108440,A),cell_shape_uniformity__8(A)) :- dom(A).
body(id(108440,A),cell_size_uniformity__8(A)) :- dom(A).
body(id(108440,A),clump_thickness__9(A)) :- dom(A).
body(id(108440,A),marginal_adhesion__5(A)) :- dom(A).
body(id(108440,A),mitoses__4(A)) :- dom(A).
body(id(108440,A),single_epi_cell_size__6(A)) :- dom(A).
head(id(110463,A),malignant(A)) :- dom(A).
body(id(110463,A),bare_nuclei__5(A)) :- dom(A).
body(id(110463,A),bland_chromatin__3(A)) :- dom(A).
body(id(110463,A),cell_shape_uniformity__6(A)) :- dom(A).
body(id(110463,A),cell_size_uniformity__6(A)) :- dom(A).
body(id(110463,A),marginal_adhesion__3(A)) :- dom(A).
body(id(110463,A),mitoses__1(A)) :- dom(A).
body(id(110463,A),normal_nucleoli__6(A)) :- dom(A).
body(id(110463,A),single_epi_cell_size__4(A)) :- dom(A).
head(id(112494,A),malignant(A)) :- dom(A).
body(id(112494,A),bland_chromatin__5(A)) :- dom(A).
body(id(112494,A),cell_shape_uniformity__5(A)) :- dom(A).
body(id(112494,A),cell_size_uniformity__3(A)) :- dom(A).
body(id(112494,A),clump_thickness__5(A)) :- dom(A).
body(id(112494,A),marginal_adhesion__1(A)) :- dom(A).
body(id(112494,A),mitoses__1(A)) :- dom(A).
body(id(112494,A),normal_nucleoli__3(A)) :- dom(A).
body(id(112494,A),single_epi_cell_size__8(A)) :- dom(A).
head(id(114533,A),malignant(A)) :- dom(A).
body(id(114533,A),bare_nuclei__8(A)) :- dom(A).
body(id(114533,A),bland_chromatin__7(A)) :- dom(A).
body(id(114533,A),cell_shape_uniformity__5(A)) :- dom(A).
body(id(114533,A),cell_size_uniformity__5(A)) :- dom(A).
body(id(114533,A),clump_thickness__5(A)) :- dom(A).
body(id(114533,A),marginal_adhesion__8(A)) :- dom(A).
body(id(114533,A),mitoses__7(A)) :- dom(A).
body(id(114533,A),normal_nucleoli__3(A)) :- dom(A).
head(id(116580,A),malignant(A)) :- dom(A).
body(id(116580,A),bare_nuclei__5(A)) :- dom(A).
body(id(116580,A),bland_chromatin__7(A)) :- dom(A).
body(id(116580,A),cell_shape_uniformity__7(A)) :- dom(A).
body(id(116580,A),cell_size_uniformity__7(A)) :- dom(A).
body(id(116580,A),marginal_adhesion__3(A)) :- dom(A).
body(id(116580,A),mitoses__3(A)) :- dom(A).
body(id(116580,A),normal_nucleoli__4(A)) :- dom(A).
body(id(116580,A),single_epi_cell_size__8(A)) :- dom(A).
head(id(118635,A),malignant(A)) :- dom(A).
body(id(118635,A),bland_chromatin__4(A)) :- dom(A).
body(id(118635,A),cell_shape_uniformity__4(A)) :- dom(A).
body(id(118635,A),cell_size_uniformity__3(A)) :- dom(A).
body(id(118635,A),clump_thickness__5(A)) :- dom(A).
body(id(118635,A),marginal_adhesion__1(A)) :- dom(A).
body(id(118635,A),mitoses__1(A)) :- dom(A).
body(id(118635,A),normal_nucleoli__9(A)) :- dom(A).
body(id(118635,A),single_epi_cell_size__8(A)) :- dom(A).
head(id(120698,A),malignant(A)) :- dom(A).
body(id(120698,A),bland_chromatin__3(A)) :- dom(A).
body(id(120698,A),cell_shape_uniformity__5(A)) :- dom(A).
body(id(120698,A),cell_size_uniformity__5(A)) :- dom(A).
body(id(120698,A),clump_thickness__5(A)) :- dom(A).
body(id(120698,A),marginal_adhesion__6(A)) :- dom(A).
body(id(120698,A),mitoses__1(A)) :- dom(A).
body(id(120698,A),normal_nucleoli__1(A)) :- dom(A).
body(id(120698,A),single_epi_cell_size__3(A)) :- dom(A).
head(id(122769,A),malignant(A)) :- dom(A).
body(id(122769,A),bland_chromatin__7(A)) :- dom(A).
body(id(122769,A),cell_shape_uniformity__7(A)) :- dom(A).
body(id(122769,A),cell_size_uniformity__7(A)) :- dom(A).
body(id(122769,A),clump_thickness__9(A)) :- dom(A).
body(id(122769,A),marginal_adhesion__5(A)) :- dom(A).
body(id(122769,A),mitoses__3(A)) :- dom(A).
body(id(122769,A),normal_nucleoli__8(A)) :- dom(A).
body(id(122769,A),single_epi_cell_size__5(A)) :- dom(A).
head(id(124848,A),malignant(A)) :- dom(A).
body(id(124848,A),bare_nuclei__9(A)) :- dom(A).
body(id(124848,A),bland_chromatin__5(A)) :- dom(A).
body(id(124848,A),cell_shape_uniformity__5(A)) :- dom(A).
body(id(124848,A),cell_size_uniformity__7(A)) :- dom(A).
body(id(124848,A),clump_thickness__8(A)) :- dom(A).
body(id(124848,A),mitoses__4(A)) :- dom(A).
body(id(124848,A),normal_nucleoli__5(A)) :- dom(A).
body(id(124848,A),single_epi_cell_size__7(A)) :- dom(A).
head(id(126935,A),malignant(A)) :- dom(A).
body(id(126935,A),bare_nuclei__2(A)) :- dom(A).
body(id(126935,A),bland_chromatin__3(A)) :- dom(A).
body(id(126935,A),cell_shape_uniformity__4(A)) :- dom(A).
body(id(126935,A),cell_size_uniformity__3(A)) :- dom(A).
body(id(126935,A),clump_thickness__6(A)) :- dom(A).
body(id(126935,A),marginal_adhesion__1(A)) :- dom(A).
body(id(126935,A),mitoses__1(A)) :- dom(A).
body(id(126935,A),normal_nucleoli__9(A)) :- dom(A).
body(id(126935,A),single_epi_cell_size__5(A)) :- dom(A).
head(id(129031,A),malignant(A)) :- dom(A).
body(id(129031,A),bare_nuclei__8(A)) :- dom(A).
body(id(129031,A),bland_chromatin__3(A)) :- dom(A).
body(id(129031,A),cell_shape_uniformity__7(A)) :- dom(A).
body(id(129031,A),cell_size_uniformity__8(A)) :- dom(A).
body(id(129031,A),clump_thickness__7(A)) :- dom(A).
body(id(129031,A),marginal_adhesion__2(A)) :- dom(A).
body(id(129031,A),mitoses__2(A)) :- dom(A).
body(id(129031,A),normal_nucleoli__8(A)) :- dom(A).
body(id(129031,A),single_epi_cell_size__4(A)) :- dom(A).
head(id(131136,A),malignant(A)) :- dom(A).
body(id(131136,A),bare_nuclei__9(A)) :- dom(A).
body(id(131136,A),bland_chromatin__8(A)) :- dom(A).
body(id(131136,A),cell_shape_uniformity__8(A)) :- dom(A).
body(id(131136,A),cell_size_uniformity__3(A)) :- dom(A).
body(id(131136,A),clump_thickness__8(A)) :- dom(A).
body(id(131136,A),marginal_adhesion__3(A)) :- dom(A).
body(id(131136,A),mitoses__8(A)) :- dom(A).
body(id(131136,A),normal_nucleoli__9(A)) :- dom(A).
body(id(131136,A),single_epi_cell_size__4(A)) :- dom(A).
head(id(133250,A),malignant(A)) :- dom(A).
body(id(133250,A),bare_nuclei__8(A)) :- dom(A).
body(id(133250,A),bland_chromatin__4(A)) :- dom(A).
body(id(133250,A),cell_shape_uniformity__5(A)) :- dom(A).
body(id(133250,A),cell_size_uniformity__4(A)) :- dom(A).
body(id(133250,A),clump_thickness__3(A)) :- dom(A).
body(id(133250,A),marginal_adhesion__2(A)) :- dom(A).
body(id(133250,A),mitoses__1(A)) :- dom(A).
body(id(133250,A),normal_nucleoli__1(A)) :- dom(A).
body(id(133250,A),single_epi_cell_size__6(A)) :- dom(A).
head(id(135373,A),malignant(A)) :- dom(A).
body(id(135373,A),bare_nuclei__3(A)) :- dom(A).
body(id(135373,A),bland_chromatin__2(A)) :- dom(A).
body(id(135373,A),cell_shape_uniformity__8(A)) :- dom(A).
body(id(135373,A),cell_size_uniformity__5(A)) :- dom(A).
body(id(135373,A),clump_thickness__9(A)) :- dom(A).
body(id(135373,A),marginal_adhesion__1(A)) :- dom(A).
body(id(135373,A),mitoses__5(A)) :- dom(A).
body(id(135373,A),normal_nucleoli__1(A)) :- dom(A).
body(id(135373,A),single_epi_cell_size__2(A)) :- dom(A).
head(id(137505,A),malignant(A)) :- dom(A).
body(id(137505,A),bare_nuclei__2(A)) :- dom(A).
body(id(137505,A),bland_chromatin__5(A)) :- dom(A).
body(id(137505,A),cell_shape_uniformity__5(A)) :- dom(A).
body(id(137505,A),cell_size_uniformity__5(A)) :- dom(A).
body(id(137505,A),clump_thickness__9(A)) :- dom(A).
body(id(137505,A),marginal_adhesion__2(A)) :- dom(A).
body(id(137505,A),mitoses__1(A)) :- dom(A).
body(id(137505,A),normal_nucleoli__1(A)) :- dom(A).
body(id(137505,A),single_epi_cell_size__2(A)) :- dom(A).
head(id(139646,A),malignant(A)) :- dom(A).
body(id(139646,A),bare_nuclei__7(A)) :- dom(A).
body(id(139646,A),bland_chromatin__7(A)) :- dom(A).
body(id(139646,A),cell_shape_uniformity__3(A)) :- dom(A).
body(id(139646,A),cell_size_uniformity__5(A)) :- dom(A).
body(id(139646,A),clump_thickness__2(A)) :- dom(A).
body(id(139646,A),marginal_adhesion__3(A)) :- dom(A).
body(id(139646,A),mitoses__1(A)) :- dom(A).
body(id(139646,A),normal_nucleoli__5(A)) :- dom(A).
body(id(139646,A),single_epi_cell_size__6(A)) :- dom(A).
head(id(141796,A),malignant(A)) :- dom(A).
body(id(141796,A),bare_nuclei__9(A)) :- dom(A).
body(id(141796,A),bland_chromatin__3(A)) :- dom(A).
body(id(141796,A),cell_shape_uniformity__4(A)) :- dom(A).
body(id(141796,A),cell_size_uniformity__6(A)) :- dom(A).
body(id(141796,A),clump_thickness__8(A)) :- dom(A).
body(id(141796,A),marginal_adhesion__3(A)) :- dom(A).
body(id(141796,A),mitoses__1(A)) :- dom(A).
body(id(141796,A),normal_nucleoli__1(A)) :- dom(A).
body(id(141796,A),single_epi_cell_size__5(A)) :- dom(A).
head(id(143955,A),malignant(A)) :- dom(A).
body(id(143955,A),bare_nuclei__8(A)) :- dom(A).
body(id(143955,A),bland_chromatin__7(A)) :- dom(A).
body(id(143955,A),cell_shape_uniformity__6(A)) :- dom(A).
body(id(143955,A),cell_size_uniformity__5(A)) :- dom(A).
body(id(143955,A),clump_thickness__7(A)) :- dom(A).
body(id(143955,A),marginal_adhesion__3(A)) :- dom(A).
body(id(143955,A),mitoses__1(A)) :- dom(A).
body(id(143955,A),normal_nucleoli__4(A)) :- dom(A).
body(id(143955,A),single_epi_cell_size__3(A)) :- dom(A).
head(id(146123,A),malignant(A)) :- dom(A).
body(id(146123,A),bare_nuclei__7(A)) :- dom(A).
body(id(146123,A),bland_chromatin__3(A)) :- dom(A).
body(id(146123,A),cell_shape_uniformity__3(A)) :- dom(A).
body(id(146123,A),cell_size_uniformity__2(A)) :- dom(A).
body(id(146123,A),clump_thickness__5(A)) :- dom(A).
body(id(146123,A),marginal_adhesion__4(A)) :- dom(A).
body(id(146123,A),mitoses__1(A)) :- dom(A).
body(id(146123,A),normal_nucleoli__6(A)) :- dom(A).
body(id(146123,A),single_epi_cell_size__2(A)) :- dom(A).
head(id(148300,A),malignant(A)) :- dom(A).
body(id(148300,A),bare_nuclei__3(A)) :- dom(A).
body(id(148300,A),bland_chromatin__7(A)) :- dom(A).
body(id(148300,A),cell_shape_uniformity__3(A)) :- dom(A).
body(id(148300,A),cell_size_uniformity__2(A)) :- dom(A).
body(id(148300,A),clump_thickness__8(A)) :- dom(A).
body(id(148300,A),marginal_adhesion__1(A)) :- dom(A).
body(id(148300,A),mitoses__1(A)) :- dom(A).
body(id(148300,A),normal_nucleoli__1(A)) :- dom(A).
body(id(148300,A),single_epi_cell_size__6(A)) :- dom(A).
head(id(150486,A),malignant(A)) :- dom(A).
body(id(150486,A),bare_nuclei__8(A)) :- dom(A).
body(id(150486,A),bland_chromatin__8(A)) :- dom(A).
body(id(150486,A),cell_shape_uniformity__7(A)) :- dom(A).
body(id(150486,A),cell_size_uniformity__8(A)) :- dom(A).
body(id(150486,A),clump_thickness__6(A)) :- dom(A).
body(id(150486,A),marginal_adhesion__5(A)) :- dom(A).
body(id(150486,A),mitoses__2(A)) :- dom(A).
body(id(150486,A),normal_nucleoli__9(A)) :- dom(A).
body(id(150486,A),single_epi_cell_size__6(A)) :- dom(A).
head(id(152681,A),malignant(A)) :- dom(A).
body(id(152681,A),bare_nuclei__5(A)) :- dom(A).
body(id(152681,A),bland_chromatin__2(A)) :- dom(A).
body(id(152681,A),cell_shape_uniformity__4(A)) :- dom(A).
body(id(152681,A),cell_size_uniformity__3(A)) :- dom(A).
body(id(152681,A),clump_thickness__2(A)) :- dom(A).
body(id(152681,A),marginal_adhesion__4(A)) :- dom(A).
body(id(152681,A),mitoses__1(A)) :- dom(A).
body(id(152681,A),normal_nucleoli__5(A)) :- dom(A).
body(id(152681,A),single_epi_cell_size__2(A)) :- dom(A).
head(id(154885,A),malignant(A)) :- dom(A).
body(id(154885,A),bare_nuclei__4(A)) :- dom(A).
body(id(154885,A),bland_chromatin__3(A)) :- dom(A).
body(id(154885,A),cell_shape_uniformity__3(A)) :- dom(A).
body(id(154885,A),cell_size_uniformity__3(A)) :- dom(A).
body(id(154885,A),clump_thickness__5(A)) :- dom(A).
body(id(154885,A),marginal_adhesion__4(A)) :- dom(A).
body(id(154885,A),mitoses__1(A)) :- dom(A).
body(id(154885,A),normal_nucleoli__4(A)) :- dom(A).
body(id(154885,A),single_epi_cell_size__2(A)) :- dom(A).
head(id(157098,A),malignant(A)) :- dom(A).
body(id(157098,A),bare_nuclei__9(A)) :- dom(A).
body(id(157098,A),bland_chromatin__4(A)) :- dom(A).
body(id(157098,A),cell_shape_uniformity__7(A)) :- dom(A).
body(id(157098,A),cell_size_uniformity__7(A)) :- dom(A).
body(id(157098,A),clump_thickness__3(A)) :- dom(A).
body(id(157098,A),marginal_adhesion__4(A)) :- dom(A).
body(id(157098,A),mitoses__1(A)) :- dom(A).
body(id(157098,A),normal_nucleoli__8(A)) :- dom(A).
body(id(157098,A),single_epi_cell_size__4(A)) :- dom(A).
head(id(159320,A),malignant(A)) :- dom(A).
body(id(159320,A),bare_nuclei__5(A)) :- dom(A).
body(id(159320,A),bland_chromatin__7(A)) :- dom(A).
body(id(159320,A),cell_shape_uniformity__9(A)) :- dom(A).
body(id(159320,A),cell_size_uniformity__9(A)) :- dom(A).
body(id(159320,A),clump_thickness__8(A)) :- dom(A).
body(id(159320,A),marginal_adhesion__5(A)) :- dom(A).
body(id(159320,A),mitoses__1(A)) :- dom(A).
body(id(159320,A),normal_nucleoli__7(A)) :- dom(A).
body(id(159320,A),single_epi_cell_size__3(A)) :- dom(A).
head(id(161551,A),malignant(A)) :- dom(A).
body(id(161551,A),bare_nuclei__5(A)) :- dom(A).
body(id(161551,A),bland_chromatin__2(A)) :- dom(A).
body(id(161551,A),cell_shape_uniformity__1(A)) :- dom(A).
body(id(161551,A),cell_size_uniformity__1(A)) :- dom(A).
body(id(161551,A),clump_thickness__4(A)) :- dom(A).
body(id(161551,A),marginal_adhesion__3(A)) :- dom(A).
body(id(161551,A),mitoses__1(A)) :- dom(A).
body(id(161551,A),normal_nucleoli__1(A)) :- dom(A).
body(id(161551,A),single_epi_cell_size__1(A)) :- dom(A).
head(id(163791,A),malignant(A)) :- dom(A).
body(id(163791,A),bare_nuclei__8(A)) :- dom(A).
body(id(163791,A),bland_chromatin__4(A)) :- dom(A).
body(id(163791,A),cell_shape_uniformity__6(A)) :- dom(A).
body(id(163791,A),cell_size_uniformity__3(A)) :- dom(A).
body(id(163791,A),clump_thickness__3(A)) :- dom(A).
body(id(163791,A),marginal_adhesion__4(A)) :- dom(A).
body(id(163791,A),mitoses__1(A)) :- dom(A).
body(id(163791,A),normal_nucleoli__4(A)) :- dom(A).
body(id(163791,A),single_epi_cell_size__5(A)) :- dom(A).
head(id(166040,A),malignant(A)) :- dom(A).
body(id(166040,A),bare_nuclei__1(A)) :- dom(A).
body(id(166040,A),bland_chromatin__4(A)) :- dom(A).
body(id(166040,A),cell_shape_uniformity__6(A)) :- dom(A).
body(id(166040,A),cell_size_uniformity__4(A)) :- dom(A).
body(id(166040,A),clump_thickness__7(A)) :- dom(A).
body(id(166040,A),marginal_adhesion__4(A)) :- dom(A).
body(id(166040,A),mitoses__1(A)) :- dom(A).
body(id(166040,A),normal_nucleoli__3(A)) :- dom(A).
body(id(166040,A),single_epi_cell_size__6(A)) :- dom(A).
head(id(168298,A),malignant(A)) :- dom(A).
body(id(168298,A),bare_nuclei__3(A)) :- dom(A).
body(id(168298,A),bland_chromatin__3(A)) :- dom(A).
body(id(168298,A),cell_shape_uniformity__4(A)) :- dom(A).
body(id(168298,A),cell_size_uniformity__3(A)) :- dom(A).
body(id(168298,A),clump_thickness__7(A)) :- dom(A).
body(id(168298,A),marginal_adhesion__4(A)) :- dom(A).
body(id(168298,A),mitoses__7(A)) :- dom(A).
body(id(168298,A),normal_nucleoli__2(A)) :- dom(A).
body(id(168298,A),single_epi_cell_size__3(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).

dom(1).
dom(2).
dom(3).
dom(4).
dom(5).
dom(6).
dom(7).
dom(10).
dom(11).
dom(12).
dom(14).
dom(15).
dom(16).
dom(17).
dom(18).
dom(19).
dom(20).
dom(21).
dom(23).
dom(26).
dom(28).
dom(30).
dom(31).
dom(32).
dom(33).
dom(34).
dom(36).
dom(38).
dom(40).
dom(42).
dom(43).
dom(44).
dom(45).
dom(46).
dom(47).
dom(48).
dom(49).
dom(50).
dom(51).
dom(52).
dom(53).
dom(54).
dom(55).
dom(56).
dom(57).
dom(59).
dom(60).
dom(61).
dom(62).
dom(63).
dom(64).
dom(65).
dom(66).
dom(67).
dom(68).
dom(69).
dom(72).
dom(73).
dom(74).
dom(79).
dom(80).
dom(81).
dom(82).
dom(83).
dom(84).
dom(85).
dom(86).
dom(87).
dom(88).
dom(90).
dom(92).
dom(93).
dom(94).
dom(95).
dom(96).
dom(97).
dom(98).
dom(100).
dom(101).
dom(102).
dom(103).
dom(104).
dom(105).
dom(106).
dom(107).
dom(109).
dom(112).
dom(113).
dom(114).
dom(116).
dom(117).
dom(119).
dom(120).
dom(121).
dom(122).
dom(124).
dom(125).
dom(126).
dom(127).
dom(128).
dom(130).
dom(131).
dom(134).
dom(136).
dom(137).
dom(138).
dom(141).
dom(144).
dom(145).
dom(147).
dom(148).
dom(149).
dom(150).
dom(151).
dom(152).
dom(153).
dom(154).
dom(155).
dom(156).
dom(158).
dom(160).
dom(161).
dom(162).
dom(164).
dom(167).
dom(168).
dom(169).
dom(170).
dom(171).
dom(172).
dom(173).
dom(174).
dom(175).
dom(177).
dom(178).
dom(179).
dom(180).
dom(181).
dom(182).
dom(183).
dom(186).
dom(187).
dom(188).
dom(189).
dom(190).
dom(191).
dom(192).
dom(194).
dom(195).
dom(196).
dom(197).
dom(198).
dom(199).
dom(200).
dom(201).
dom(202).
dom(203).
dom(204).
dom(205).
dom(206).
dom(207).
dom(208).
dom(209).
dom(210).
dom(211).
dom(212).
dom(213).
dom(214).
dom(215).
dom(218).
dom(219).
dom(220).
dom(221).
dom(222).
dom(223).
dom(224).
dom(225).
dom(226).
dom(228).
dom(229).
dom(232).
dom(233).
dom(234).
dom(235).
dom(237).
dom(238).
dom(239).
dom(240).
dom(241).
dom(242).
dom(244).
dom(245).
 :- not supported(malignant(44)).
 :- not supported(malignant(125)).
 :- not supported(malignant(64)).
 :- not supported(malignant(211)).
 :- not supported(malignant(189)).
 :- not supported(malignant(50)).
 :- not supported(malignant(69)).
 :- not supported(malignant(212)).
 :- not supported(malignant(100)).
 :- not supported(malignant(61)).
 :- not supported(malignant(202)).
 :- not supported(malignant(74)).
 :- not supported(malignant(127)).
 :- not supported(malignant(57)).
 :- not supported(malignant(53)).
 :- not supported(malignant(21)).
 :- not supported(malignant(150)).
 :- not supported(malignant(240)).
 :- not supported(malignant(42)).
 :- not supported(malignant(147)).
 :- not supported(malignant(55)).
 :- not supported(malignant(187)).
 :- not supported(malignant(191)).
 :- not supported(malignant(207)).
 :- not supported(malignant(63)).
 :- not supported(malignant(107)).
 :- not supported(malignant(85)).
 :- not supported(malignant(175)).
 :- not supported(malignant(51)).
 :- not supported(malignant(153)).
 :- not supported(malignant(66)).
 :- not supported(malignant(167)).
 :- not supported(malignant(60)).
 :- not supported(malignant(19)).
 :- not supported(malignant(40)).
 :- not supported(malignant(72)).
 :- not supported(malignant(88)).
 :- not supported(malignant(239)).
 :- not supported(malignant(237)).
 :- not supported(malignant(161)).
 :- not supported(malignant(180)).
 :- not supported(malignant(214)).
 :- not supported(malignant(152)).
 :- not supported(malignant(188)).
 :- not supported(malignant(45)).
 :- not supported(malignant(101)).
 :- not supported(malignant(112)).
 :- not supported(malignant(59)).
 :- not supported(malignant(105)).
 :- not supported(malignant(238)).
 :- not supported(malignant(114)).
 :- not supported(malignant(224)).
 :- not supported(malignant(56)).
 :- not supported(malignant(26)).
 :- not supported(malignant(225)).
 :- not supported(malignant(124)).
 :- not supported(malignant(113)).
 :- not supported(malignant(54)).
 :- not supported(malignant(192)).
 :- not supported(malignant(104)).
 :- not supported(malignant(206)).
 :- not supported(malignant(234)).
 :- not supported(malignant(33)).
 :- not supported(malignant(232)).
 :- not supported(malignant(6)).
 :- not supported(malignant(219)).
 :- not supported(malignant(102)).
 :- not supported(malignant(52)).
 :- not supported(malignant(222)).
 :- not supported(malignant(160)).
 :- not supported(malignant(168)).
 :- not supported(malignant(174)).
 :- not supported(malignant(47)).
 :- not supported(malignant(228)).
 :- not supported(malignant(223)).
 :- not supported(malignant(68)).
 :- not supported(malignant(215)).
 :- not supported(malignant(156)).
 :- not supported(malignant(87)).
 :- not supported(malignant(43)).
 :- not supported(malignant(16)).
 :- not supported(malignant(201)).
 :- not supported(malignant(106)).
 :- not supported(malignant(15)).
 :- not supported(malignant(86)).
 :- not supported(malignant(178)).
 :- supported(malignant(81)).
 :- supported(malignant(170)).
 :- supported(malignant(90)).
 :- supported(malignant(17)).
 :- supported(malignant(245)).
 :- supported(malignant(1)).
 :- supported(malignant(209)).
 :- supported(malignant(120)).
 :- supported(malignant(144)).
 :- supported(malignant(103)).
 :- supported(malignant(138)).
 :- supported(malignant(97)).
 :- supported(malignant(182)).
 :- supported(malignant(121)).
 :- supported(malignant(116)).
 :- supported(malignant(18)).
 :- supported(malignant(62)).
 :- supported(malignant(226)).
 :- supported(malignant(151)).
 :- supported(malignant(36)).
 :- supported(malignant(213)).
 :- supported(malignant(80)).
 :- supported(malignant(79)).
 :- supported(malignant(94)).
 :- supported(malignant(179)).
 :- supported(malignant(134)).
 :- supported(malignant(221)).
 :- supported(malignant(23)).
 :- supported(malignant(109)).
 :- supported(malignant(241)).
 :- supported(malignant(162)).
 :- supported(malignant(28)).
 :- supported(malignant(204)).
 :- supported(malignant(117)).
 :- supported(malignant(164)).
 :- supported(malignant(145)).
 :- supported(malignant(198)).
 :- supported(malignant(195)).
 :- supported(malignant(205)).
 :- supported(malignant(14)).
 :- supported(malignant(196)).
 :- supported(malignant(11)).
 :- supported(malignant(141)).
 :- supported(malignant(30)).
 :- supported(malignant(242)).
 :- supported(malignant(136)).
 :- supported(malignant(65)).
 :- supported(malignant(98)).
 :- supported(malignant(173)).
 :- supported(malignant(4)).
 :- supported(malignant(119)).
 :- supported(malignant(244)).
 :- supported(malignant(32)).
 :- supported(malignant(171)).
 :- supported(malignant(2)).
 :- supported(malignant(83)).
 :- supported(malignant(49)).
 :- supported(malignant(38)).
 :- supported(malignant(200)).
 :- supported(malignant(137)).
 :- supported(malignant(95)).
 :- supported(malignant(34)).
 :- supported(malignant(149)).
 :- supported(malignant(31)).
 :- supported(malignant(10)).
 :- supported(malignant(218)).
 :- supported(malignant(220)).
 :- supported(malignant(5)).
 :- supported(malignant(208)).
 :- supported(malignant(3)).
 :- supported(malignant(93)).
 :- supported(malignant(67)).
 :- supported(malignant(130)).
 :- supported(malignant(194)).
 :- supported(malignant(148)).
 :- supported(malignant(82)).
 :- supported(malignant(92)).
 :- supported(malignant(12)).
 :- supported(malignant(172)).
 :- supported(malignant(7)).
 :- supported(malignant(190)).
 :- supported(malignant(229)).
 :- supported(malignant(181)).
 :- supported(malignant(199)).
 :- supported(malignant(154)).
 :- supported(malignant(235)).
 :- supported(malignant(126)).
 :- supported(malignant(155)).
 :- supported(malignant(122)).
 :- supported(malignant(131)).
 :- supported(malignant(203)).
 :- supported(malignant(84)).
 :- supported(malignant(177)).
 :- supported(malignant(233)).
 :- supported(malignant(158)).
 :- supported(malignant(20)).
 :- supported(malignant(197)).
 :- supported(malignant(48)).
 :- supported(malignant(73)).
 :- supported(malignant(183)).
 :- supported(malignant(186)).
 :- supported(malignant(46)).
 :- supported(malignant(169)).
 :- supported(malignant(210)).
 :- supported(malignant(128)).
 :- supported(malignant(96)).
