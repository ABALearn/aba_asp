head(id(1),clump_thickness__5(125)).
head(id(2),cell_size_uniformity__4(125)).
head(id(3),cell_shape_uniformity__6(125)).
head(id(4),marginal_adhesion__7(125)).
head(id(5),single_epi_cell_size__9(125)).
head(id(6),bare_nuclei__7(125)).
head(id(7),bland_chromatin__8(125)).
head(id(8),mitoses__1(125)).
head(id(9),clump_thickness__8(216)).
head(id(10),cell_size_uniformity__7(216)).
head(id(11),cell_shape_uniformity__8(216)).
head(id(12),marginal_adhesion__7(216)).
head(id(13),single_epi_cell_size__5(216)).
head(id(14),bare_nuclei__5(216)).
head(id(15),bland_chromatin__5(216)).
head(id(16),mitoses__2(216)).
head(id(17),clump_thickness__8(301)).
head(id(18),cell_size_uniformity__4(301)).
head(id(19),marginal_adhesion__5(301)).
head(id(20),single_epi_cell_size__4(301)).
head(id(21),bare_nuclei__4(301)).
head(id(22),bland_chromatin__7(301)).
head(id(23),mitoses__1(301)).
head(id(24),clump_thickness__5(54)).
head(id(25),cell_size_uniformity__5(54)).
head(id(26),cell_shape_uniformity__5(54)).
head(id(27),marginal_adhesion__8(54)).
head(id(28),bare_nuclei__8(54)).
head(id(29),bland_chromatin__7(54)).
head(id(30),normal_nucleoli__3(54)).
head(id(31),mitoses__7(54)).
head(id(32),clump_thickness__9(426)).
head(id(33),mitoses__1(426)).
head(id(34),cell_size_uniformity__8(168)).
head(id(35),single_epi_cell_size__6(168)).
head(id(36),bare_nuclei__1(168)).
head(id(37),bland_chromatin__3(168)).
head(id(38),normal_nucleoli__1(168)).
head(id(39),clump_thickness__6(110)).
head(id(40),cell_size_uniformity__5(110)).
head(id(41),cell_shape_uniformity__4(110)).
head(id(42),marginal_adhesion__4(110)).
head(id(43),single_epi_cell_size__3(110)).
head(id(44),bare_nuclei__9(110)).
head(id(45),bland_chromatin__7(110)).
head(id(46),normal_nucleoli__8(110)).
head(id(47),mitoses__3(110)).
head(id(48),clump_thickness__7(152)).
head(id(49),cell_size_uniformity__2(152)).
head(id(50),cell_shape_uniformity__4(152)).
head(id(51),marginal_adhesion__1(152)).
head(id(52),single_epi_cell_size__6(152)).
head(id(53),bland_chromatin__5(152)).
head(id(54),normal_nucleoli__4(152)).
head(id(55),mitoses__3(152)).
head(id(56),cell_size_uniformity__8(202)).
head(id(57),cell_shape_uniformity__8(202)).
head(id(58),marginal_adhesion__4(202)).
head(id(59),bland_chromatin__8(202)).
head(id(60),normal_nucleoli__1(202)).
head(id(61),mitoses__1(202)).
head(id(62),clump_thickness__8(335)).
head(id(63),cell_size_uniformity__6(335)).
head(id(64),cell_shape_uniformity__7(335)).
head(id(65),marginal_adhesion__3(335)).
head(id(66),single_epi_cell_size__3(335)).
head(id(67),bland_chromatin__3(335)).
head(id(68),normal_nucleoli__4(335)).
head(id(69),mitoses__2(335)).
head(id(70),clump_thickness__7(265)).
head(id(71),cell_size_uniformity__9(265)).
head(id(72),cell_shape_uniformity__4(265)).
head(id(73),bare_nuclei__3(265)).
head(id(74),bland_chromatin__5(265)).
head(id(75),normal_nucleoli__3(265)).
head(id(76),mitoses__3(265)).
head(id(77),clump_thickness__7(321)).
head(id(78),cell_size_uniformity__6(321)).
head(id(79),cell_shape_uniformity__3(321)).
head(id(80),marginal_adhesion__2(321)).
head(id(81),single_epi_cell_size__5(321)).
head(id(82),bland_chromatin__7(321)).
head(id(83),normal_nucleoli__4(321)).
head(id(84),mitoses__6(321)).
head(id(85),cell_size_uniformity__6(467)).
head(id(86),cell_shape_uniformity__6(467)).
head(id(87),marginal_adhesion__2(467)).
head(id(88),single_epi_cell_size__4(467)).
head(id(89),bland_chromatin__9(467)).
head(id(90),normal_nucleoli__7(467)).
head(id(91),mitoses__1(467)).
head(id(92),clump_thickness__8(150)).
head(id(93),cell_size_uniformity__8(150)).
head(id(94),cell_shape_uniformity__7(150)).
head(id(95),marginal_adhesion__4(150)).
head(id(96),bland_chromatin__7(150)).
head(id(97),normal_nucleoli__8(150)).
head(id(98),mitoses__7(150)).
head(id(99),cell_size_uniformity__6(382)).
head(id(100),cell_shape_uniformity__3(382)).
head(id(101),marginal_adhesion__6(382)).
head(id(102),single_epi_cell_size__4(382)).
head(id(103),bland_chromatin__7(382)).
head(id(104),normal_nucleoli__8(382)).
head(id(105),mitoses__4(382)).
head(id(106),clump_thickness__1(203)).
head(id(107),cell_size_uniformity__1(203)).
head(id(108),cell_shape_uniformity__1(203)).
head(id(109),marginal_adhesion__1(203)).
head(id(110),single_epi_cell_size__2(203)).
head(id(111),bare_nuclei__1(203)).
head(id(112),bland_chromatin__3(203)).
head(id(113),normal_nucleoli__1(203)).
head(id(114),mitoses__1(203)).
head(id(115),clump_thickness__2(366)).
head(id(116),cell_size_uniformity__1(366)).
head(id(117),cell_shape_uniformity__1(366)).
head(id(118),marginal_adhesion__1(366)).
head(id(119),single_epi_cell_size__2(366)).
head(id(120),bare_nuclei__1(366)).
head(id(121),bland_chromatin__2(366)).
head(id(122),normal_nucleoli__1(366)).
head(id(123),mitoses__1(366)).
head(id(124),clump_thickness__4(371)).
head(id(125),cell_size_uniformity__3(371)).
head(id(126),cell_shape_uniformity__2(371)).
head(id(127),marginal_adhesion__1(371)).
head(id(128),single_epi_cell_size__3(371)).
head(id(129),bare_nuclei__1(371)).
head(id(130),bland_chromatin__2(371)).
head(id(131),normal_nucleoli__1(371)).
head(id(132),mitoses__1(371)).
head(id(133),clump_thickness__3(651)).
head(id(134),cell_size_uniformity__1(651)).
head(id(135),cell_shape_uniformity__1(651)).
head(id(136),marginal_adhesion__2(651)).
head(id(137),single_epi_cell_size__3(651)).
head(id(138),bare_nuclei__4(651)).
head(id(139),bland_chromatin__1(651)).
head(id(140),normal_nucleoli__1(651)).
head(id(141),mitoses__1(651)).
head(id(142),clump_thickness__3(434)).
head(id(143),cell_size_uniformity__2(434)).
head(id(144),cell_shape_uniformity__2(434)).
head(id(145),marginal_adhesion__3(434)).
head(id(146),single_epi_cell_size__2(434)).
head(id(147),bare_nuclei__1(434)).
head(id(148),bland_chromatin__1(434)).
head(id(149),normal_nucleoli__1(434)).
head(id(150),mitoses__1(434)).
head(id(151),clump_thickness__5(683)).
head(id(152),cell_size_uniformity__1(683)).
head(id(153),cell_shape_uniformity__1(683)).
head(id(154),marginal_adhesion__1(683)).
head(id(155),single_epi_cell_size__2(683)).
head(id(156),bare_nuclei__1(683)).
head(id(157),bland_chromatin__3(683)).
head(id(158),normal_nucleoli__2(683)).
head(id(159),mitoses__1(683)).
head(id(160),clump_thickness__3(476)).
head(id(161),cell_size_uniformity__1(476)).
head(id(162),cell_shape_uniformity__1(476)).
head(id(163),marginal_adhesion__1(476)).
head(id(164),single_epi_cell_size__2(476)).
head(id(165),bare_nuclei__1(476)).
head(id(166),bland_chromatin__1(476)).
head(id(167),normal_nucleoli__1(476)).
head(id(168),mitoses__1(476)).
head(id(169),clump_thickness__5(561)).
head(id(170),cell_size_uniformity__1(561)).
head(id(171),cell_shape_uniformity__1(561)).
head(id(172),marginal_adhesion__1(561)).
head(id(173),single_epi_cell_size__2(561)).
head(id(174),bare_nuclei__1(561)).
head(id(175),bland_chromatin__3(561)).
head(id(176),normal_nucleoli__1(561)).
head(id(177),mitoses__1(561)).
head(id(178),clump_thickness__2(409)).
head(id(179),cell_size_uniformity__3(409)).
head(id(180),cell_shape_uniformity__2(409)).
head(id(181),marginal_adhesion__2(409)).
head(id(182),single_epi_cell_size__2(409)).
head(id(183),bare_nuclei__2(409)).
head(id(184),bland_chromatin__3(409)).
head(id(185),normal_nucleoli__1(409)).
head(id(186),mitoses__1(409)).
head(id(187),clump_thickness__4(423)).
head(id(188),cell_size_uniformity__3(423)).
head(id(189),cell_shape_uniformity__3(423)).
head(id(190),marginal_adhesion__1(423)).
head(id(191),single_epi_cell_size__2(423)).
head(id(192),bare_nuclei__1(423)).
head(id(193),bland_chromatin__3(423)).
head(id(194),normal_nucleoli__3(423)).
head(id(195),mitoses__1(423)).
head(id(196),clump_thickness__5(333)).
head(id(197),cell_size_uniformity__2(333)).
head(id(198),cell_shape_uniformity__2(333)).
head(id(199),marginal_adhesion__2(333)).
head(id(200),single_epi_cell_size__2(333)).
head(id(201),bare_nuclei__1(333)).
head(id(202),bland_chromatin__2(333)).
head(id(203),normal_nucleoli__2(333)).
head(id(204),mitoses__1(333)).
head(id(205),clump_thickness__4(249)).
head(id(206),cell_size_uniformity__1(249)).
head(id(207),cell_shape_uniformity__1(249)).
head(id(208),marginal_adhesion__1(249)).
head(id(209),single_epi_cell_size__2(249)).
head(id(210),bare_nuclei__1(249)).
head(id(211),bland_chromatin__3(249)).
head(id(212),normal_nucleoli__6(249)).
head(id(213),mitoses__1(249)).
head(id(214),clump_thickness__1(486)).
head(id(215),cell_size_uniformity__1(486)).
head(id(216),cell_shape_uniformity__1(486)).
head(id(217),marginal_adhesion__3(486)).
head(id(218),single_epi_cell_size__1(486)).
head(id(219),bare_nuclei__3(486)).
head(id(220),bland_chromatin__1(486)).
head(id(221),normal_nucleoli__1(486)).
head(id(222),mitoses__1(486)).
head(id(223),clump_thickness__5(83)).
head(id(224),cell_size_uniformity__2(83)).
head(id(225),cell_shape_uniformity__1(83)).
head(id(226),marginal_adhesion__1(83)).
head(id(227),single_epi_cell_size__2(83)).
head(id(228),bare_nuclei__1(83)).
head(id(229),bland_chromatin__3(83)).
head(id(230),normal_nucleoli__1(83)).
head(id(231),mitoses__1(83)).
head(id(232),clump_thickness__3(396)).
head(id(233),cell_size_uniformity__1(396)).
head(id(234),cell_shape_uniformity__1(396)).
head(id(235),marginal_adhesion__1(396)).
head(id(236),single_epi_cell_size__2(396)).
head(id(237),bare_nuclei__1(396)).
head(id(238),bland_chromatin__2(396)).
head(id(239),normal_nucleoli__1(396)).
head(id(240),mitoses__1(396)).
head(id(241),clump_thickness__2(80)).
head(id(242),cell_size_uniformity__1(80)).
head(id(243),cell_shape_uniformity__1(80)).
head(id(244),marginal_adhesion__1(80)).
head(id(245),single_epi_cell_size__3(80)).
head(id(246),bare_nuclei__1(80)).
head(id(247),bland_chromatin__2(80)).
head(id(248),normal_nucleoli__1(80)).
head(id(249),mitoses__1(80)).
head(id(250),clump_thickness__1(190)).
head(id(251),cell_size_uniformity__2(190)).
head(id(252),cell_shape_uniformity__3(190)).
head(id(253),marginal_adhesion__1(190)).
head(id(254),single_epi_cell_size__2(190)).
head(id(255),bare_nuclei__1(190)).
head(id(256),bland_chromatin__3(190)).
head(id(257),normal_nucleoli__1(190)).
head(id(258),mitoses__1(190)).
head(id(259),clump_thickness__4(532)).
head(id(260),cell_size_uniformity__2(532)).
head(id(261),cell_shape_uniformity__2(532)).
head(id(262),marginal_adhesion__1(532)).
head(id(263),single_epi_cell_size__2(532)).
head(id(264),bare_nuclei__1(532)).
head(id(265),bland_chromatin__2(532)).
head(id(266),normal_nucleoli__1(532)).
head(id(267),mitoses__1(532)).
head(id(268),clump_thickness__1(431)).
head(id(269),cell_size_uniformity__3(431)).
head(id(270),cell_shape_uniformity__1(431)).
head(id(271),marginal_adhesion__1(431)).
head(id(272),single_epi_cell_size__2(431)).
head(id(273),bare_nuclei__1(431)).
head(id(274),bland_chromatin__2(431)).
head(id(275),normal_nucleoli__2(431)).
head(id(276),mitoses__1(431)).
head(id(277),clump_thickness__5(596)).
head(id(278),cell_size_uniformity__1(596)).
head(id(279),cell_shape_uniformity__1(596)).
head(id(280),marginal_adhesion__1(596)).
head(id(281),single_epi_cell_size__2(596)).
head(id(282),bare_nuclei__1(596)).
head(id(283),bland_chromatin__2(596)).
head(id(284),normal_nucleoli__1(596)).
head(id(285),mitoses__1(596)).
head(id(286),clump_thickness__5(414)).
head(id(287),cell_size_uniformity__1(414)).
head(id(288),cell_shape_uniformity__2(414)).
head(id(289),marginal_adhesion__1(414)).
head(id(290),single_epi_cell_size__2(414)).
head(id(291),bare_nuclei__1(414)).
head(id(292),bland_chromatin__3(414)).
head(id(293),normal_nucleoli__1(414)).
head(id(294),mitoses__1(414)).
head(id(295),clump_thickness__1(552)).
head(id(296),cell_size_uniformity__1(552)).
head(id(297),cell_shape_uniformity__1(552)).
head(id(298),marginal_adhesion__1(552)).
head(id(299),single_epi_cell_size__2(552)).
head(id(300),bare_nuclei__1(552)).
head(id(301),bland_chromatin__3(552)).
head(id(302),normal_nucleoli__1(552)).
head(id(303),mitoses__1(552)).
head(id(304),clump_thickness__3(23)).
head(id(305),cell_size_uniformity__1(23)).
head(id(306),cell_shape_uniformity__1(23)).
head(id(307),marginal_adhesion__1(23)).
head(id(308),single_epi_cell_size__2(23)).
head(id(309),bare_nuclei__1(23)).
head(id(310),bland_chromatin__2(23)).
head(id(311),normal_nucleoli__1(23)).
head(id(312),mitoses__1(23)).
head(id(313),clump_thickness__2(95)).
head(id(314),cell_size_uniformity__1(95)).
head(id(315),cell_shape_uniformity__1(95)).
head(id(316),marginal_adhesion__1(95)).
head(id(317),single_epi_cell_size__2(95)).
head(id(318),bare_nuclei__1(95)).
head(id(319),bland_chromatin__3(95)).
head(id(320),normal_nucleoli__1(95)).
head(id(321),mitoses__1(95)).
head(id(1334,A),malignant(A)) :- dom(A).
body(id(1334,A),alpha_1(A)) :- dom(A).
body(id(1334,A),clump_thickness__5(A)) :- dom(A).
head(id(2029,A),malignant(A)) :- dom(A).
body(id(2029,A),clump_thickness__8(A)) :- dom(A).
head(id(3412,A),malignant(A)) :- dom(A).
body(id(3412,A),clump_thickness__9(A)) :- dom(A).
head(id(4104,A),malignant(A)) :- dom(A).
body(id(4104,A),cell_size_uniformity__8(A)) :- dom(A).
head(id(4798,A),malignant(A)) :- dom(A).
body(id(4798,A),clump_thickness__6(A)) :- dom(A).
head(id(5494,A),malignant(A)) :- dom(A).
body(id(5494,A),clump_thickness__7(A)) :- dom(A).
head(id(7574,A),malignant(A)) :- dom(A).
body(id(7574,A),cell_size_uniformity__6(A)) :- dom(A).
head(id(9646,A),c_alpha_1(A)) :- dom(A).
body(id(9646,A),cell_size_uniformity__2(A)) :- dom(A).
head(id(11372,A),c_alpha_1(A)) :- dom(A).
body(id(11372,A),cell_size_uniformity__1(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).

dom(23).
dom(54).
dom(80).
dom(83).
dom(95).
dom(110).
dom(125).
dom(150).
dom(152).
dom(168).
dom(190).
dom(202).
dom(203).
dom(216).
dom(249).
dom(265).
dom(301).
dom(321).
dom(333).
dom(335).
dom(366).
dom(371).
dom(382).
dom(396).
dom(409).
dom(414).
dom(423).
dom(426).
dom(431).
dom(434).
dom(467).
dom(476).
dom(486).
dom(532).
dom(552).
dom(561).
dom(596).
dom(651).
dom(683).
 :- not supported(malignant(125)).
 :- not supported(malignant(216)).
 :- not supported(malignant(301)).
 :- not supported(malignant(54)).
 :- not supported(malignant(426)).
 :- not supported(malignant(168)).
 :- not supported(malignant(110)).
 :- not supported(malignant(152)).
 :- not supported(malignant(202)).
 :- not supported(malignant(335)).
 :- not supported(malignant(265)).
 :- not supported(malignant(321)).
 :- not supported(malignant(467)).
 :- not supported(malignant(150)).
 :- not supported(malignant(382)).
 :- supported(malignant(203)).
 :- supported(malignant(366)).
 :- supported(malignant(371)).
 :- supported(malignant(651)).
 :- supported(malignant(434)).
 :- supported(malignant(683)).
 :- supported(malignant(476)).
 :- supported(malignant(561)).
 :- supported(malignant(409)).
 :- supported(malignant(423)).
 :- supported(malignant(333)).
 :- supported(malignant(249)).
 :- supported(malignant(486)).
 :- supported(malignant(83)).
 :- supported(malignant(396)).
 :- supported(malignant(80)).
 :- supported(malignant(190)).
 :- supported(malignant(532)).
 :- supported(malignant(431)).
 :- supported(malignant(596)).
 :- supported(malignant(414)).
 :- supported(malignant(552)).
 :- supported(malignant(23)).
 :- supported(malignant(95)).
