head(id(1),a6(2221)).
head(id(2),a9(2221)).
head(id(3),a11(2221)).
head(id(4),a13(2221)).
head(id(5),n(2221)).
head(id(6),a18(2221)).
head(id(7),a20(2221)).
head(id(8),a21(2221)).
head(id(9),a22(2221)).
head(id(10),a26(2221)).
head(id(11),a31(2221)).
head(id(12),a33(2221)).
head(id(13),a34(2221)).
head(id(14),a6(420)).
head(id(15),a9(420)).
head(id(16),a11(420)).
head(id(17),n(420)).
head(id(18),a18(420)).
head(id(19),a22(420)).
head(id(20),a26(420)).
head(id(21),a34(420)).
head(id(22),a35(420)).
head(id(23),a5(296)).
head(id(24),a7(296)).
head(id(25),a8(296)).
head(id(26),a9(296)).
head(id(27),a13(296)).
head(id(28),n(296)).
head(id(29),a18(296)).
head(id(30),a24(296)).
head(id(31),a34(296)).
head(id(32),a35(296)).
head(id(33),a5(2181)).
head(id(34),a11(2181)).
head(id(35),a13(2181)).
head(id(36),w(2181)).
head(id(37),a21(2181)).
head(id(38),a26(2181)).
head(id(39),a31(2181)).
head(id(40),a2(2266)).
head(id(41),a5(2266)).
head(id(42),a9(2266)).
head(id(43),a13(2266)).
head(id(44),n(2266)).
head(id(45),a21(2266)).
head(id(46),a22(2266)).
head(id(47),a35(2266)).
head(id(48),a5(241)).
head(id(49),a6(241)).
head(id(50),a7(241)).
head(id(51),a11(241)).
head(id(52),a13(241)).
head(id(53),w(241)).
head(id(54),a24(241)).
head(id(55),a26(241)).
head(id(56),a34(241)).
head(id(57),a35(241)).
head(id(58),a6(1809)).
head(id(59),a7(1809)).
head(id(60),a11(1809)).
head(id(61),a13(1809)).
head(id(62),w(1809)).
head(id(63),a20(1809)).
head(id(64),a26(1809)).
head(id(65),a31(1809)).
head(id(66),a9(600)).
head(id(67),a13(600)).
head(id(68),n(600)).
head(id(69),a18(600)).
head(id(70),a22(600)).
head(id(71),a34(600)).
head(id(72),a35(600)).
head(id(73),a36(600)).
head(id(74),a2(1918)).
head(id(75),a3(1918)).
head(id(76),a6(1918)).
head(id(77),n(1918)).
head(id(78),a18(1918)).
head(id(79),a24(1918)).
head(id(80),a26(1918)).
head(id(81),a35(1918)).
head(id(82),a36(1918)).
head(id(83),a5(751)).
head(id(84),a6(751)).
head(id(85),a7(751)).
head(id(86),a13(751)).
head(id(87),n(751)).
head(id(88),a21(751)).
head(id(89),a35(751)).
head(id(90),a1(200)).
head(id(91),a6(200)).
head(id(92),a7(200)).
head(id(93),a11(200)).
head(id(94),a13(200)).
head(id(95),b(200)).
head(id(96),a18(200)).
head(id(97),a24(200)).
head(id(98),a26(200)).
head(id(99),a34(200)).
head(id(100),a35(200)).
head(id(101),a2(1702)).
head(id(102),a11(1702)).
head(id(103),a13(1702)).
head(id(104),w(1702)).
head(id(105),a20(1702)).
head(id(106),a26(1702)).
head(id(107),a31(1702)).
head(id(108),a5(68)).
head(id(109),a7(68)).
head(id(110),a13(68)).
head(id(111),n(68)).
head(id(112),a24(68)).
head(id(113),a26(68)).
head(id(114),a34(68)).
head(id(115),a35(68)).
head(id(116),a10(2011)).
head(id(117),a11(2011)).
head(id(118),a13(2011)).
head(id(119),w(2011)).
head(id(120),a18(2011)).
head(id(121),a20(2011)).
head(id(122),a21(2011)).
head(id(123),a24(2011)).
head(id(124),a26(2011)).
head(id(125),a31(2011)).
head(id(126),a33(2011)).
head(id(127),a34(2011)).
head(id(128),a35(2011)).
head(id(129),a1(49)).
head(id(130),a11(49)).
head(id(131),a13(49)).
head(id(132),n(49)).
head(id(133),a18(49)).
head(id(134),a24(49)).
head(id(135),a26(49)).
head(id(136),a31(49)).
head(id(137),a34(49)).
head(id(138),a1(2258)).
head(id(139),a4(2258)).
head(id(140),a6(2258)).
head(id(141),a11(2258)).
head(id(142),a13(2258)).
head(id(143),w(2258)).
head(id(144),a21(2258)).
head(id(145),a24(2258)).
head(id(146),a26(2258)).
head(id(147),a27(2258)).
head(id(148),a31(2258)).
head(id(149),a33(2258)).
head(id(150),a35(2258)).
head(id(151),a13(611)).
head(id(152),n(611)).
head(id(153),a24(611)).
head(id(154),a34(611)).
head(id(155),a35(611)).
head(id(156),a36(611)).
head(id(157),a2(2324)).
head(id(158),a5(2324)).
head(id(159),a9(2324)).
head(id(160),a13(2324)).
head(id(161),n(2324)).
head(id(162),a21(2324)).
head(id(163),a22(2324)).
head(id(164),a30(2324)).
head(id(165),a33(2324)).
head(id(166),a35(2324)).
head(id(167),a36(2324)).
head(id(168),a13(703)).
head(id(169),n(703)).
head(id(170),a18(703)).
head(id(171),a21(703)).
head(id(172),a26(703)).
head(id(173),a34(703)).
head(id(174),a35(703)).
head(id(175),a2(2308)).
head(id(176),a9(2308)).
head(id(177),a13(2308)).
head(id(178),n(2308)).
head(id(179),a21(2308)).
head(id(180),a22(2308)).
head(id(181),a24(2308)).
head(id(182),a33(2308)).
head(id(183),a35(2308)).
head(id(184),a36(2308)).
head(id(185),a1(2912)).
head(id(186),a4(2912)).
head(id(187),a6(2912)).
head(id(188),a11(2912)).
head(id(189),a13(2912)).
head(id(190),n(2912)).
head(id(191),a18(2912)).
head(id(192),a24(2912)).
head(id(193),a26(2912)).
head(id(194),a27(2912)).
head(id(195),a31(2912)).
head(id(196),a33(2912)).
head(id(197),a35(2912)).
head(id(198),w(3154)).
head(id(199),a18(3154)).
head(id(200),a20(3154)).
head(id(201),a24(3154)).
head(id(202),a26(3154)).
head(id(203),a29(3154)).
head(id(204),a32(3154)).
head(id(205),a34(3154)).
head(id(206),a6(3121)).
head(id(207),a9(3121)).
head(id(208),a13(3121)).
head(id(209),n(3121)).
head(id(210),a16(3121)).
head(id(211),a22(3121)).
head(id(212),a24(3121)).
head(id(213),a33(3121)).
head(id(214),a35(3121)).
head(id(215),a36(3121)).
head(id(216),a6(1452)).
head(id(217),a7(1452)).
head(id(218),a10(1452)).
head(id(219),a11(1452)).
head(id(220),n(1452)).
head(id(221),a18(1452)).
head(id(222),a26(1452)).
head(id(223),a34(1452)).
head(id(224),a35(1452)).
head(id(225),a10(1408)).
head(id(226),n(1408)).
head(id(227),a18(1408)).
head(id(228),a24(1408)).
head(id(229),a26(1408)).
head(id(230),a34(1408)).
head(id(231),a35(1408)).
head(id(232),a6(1531)).
head(id(233),a10(1531)).
head(id(234),a12(1531)).
head(id(235),n(1531)).
head(id(236),a18(1531)).
head(id(237),a34(1531)).
head(id(238),a35(1531)).
head(id(239),a4(3020)).
head(id(240),a5(3020)).
head(id(241),a6(3020)).
head(id(242),n(3020)).
head(id(243),a24(3020)).
head(id(244),a26(3020)).
head(id(245),a27(3020)).
head(id(246),a33(3020)).
head(id(247),a35(3020)).
head(id(248),a36(3020)).
head(id(249),a7(1250)).
head(id(250),a10(1250)).
head(id(251),a11(1250)).
head(id(252),a13(1250)).
head(id(253),n(1250)).
head(id(254),a18(1250)).
head(id(255),a26(1250)).
head(id(256),a33(1250)).
head(id(257),a34(1250)).
head(id(258),a35(1250)).
head(id(259),a5(1481)).
head(id(260),a6(1481)).
head(id(261),a7(1481)).
head(id(262),a8(1481)).
head(id(263),a9(1481)).
head(id(264),a10(1481)).
head(id(265),a11(1481)).
head(id(266),n(1481)).
head(id(267),a18(1481)).
head(id(268),a26(1481)).
head(id(269),a34(1481)).
head(id(270),a35(1481)).
head(id(271),a6(2576)).
head(id(272),a7(2576)).
head(id(273),a10(2576)).
head(id(274),a11(2576)).
head(id(275),a13(2576)).
head(id(276),w(2576)).
head(id(277),a18(2576)).
head(id(278),a20(2576)).
head(id(279),a26(2576)).
head(id(280),a31(2576)).
head(id(281),a33(2576)).
head(id(282),a34(2576)).
head(id(283),a11(2821)).
head(id(284),a13(2821)).
head(id(285),n(2821)).
head(id(286),a18(2821)).
head(id(287),a20(2821)).
head(id(288),a26(2821)).
head(id(289),a27(2821)).
head(id(290),a31(2821)).
head(id(291),a33(2821)).
head(id(292),a34(2821)).
head(id(293),a5(1045)).
head(id(294),a6(1045)).
head(id(295),a7(1045)).
head(id(296),a8(1045)).
head(id(297),a9(1045)).
head(id(298),a13(1045)).
head(id(299),n(1045)).
head(id(300),a18(1045)).
head(id(301),a33(1045)).
head(id(302),a35(1045)).
head(id(303),a10(1494)).
head(id(304),n(1494)).
head(id(305),a18(1494)).
head(id(306),a24(1494)).
head(id(307),a33(1494)).
head(id(308),a34(1494)).
head(id(309),a35(1494)).
head(id(310),a5(2868)).
head(id(311),a9(2868)).
head(id(312),a13(2868)).
head(id(313),n(2868)).
head(id(314),a20(2868)).
head(id(315),a22(2868)).
head(id(316),a26(2868)).
head(id(317),a32(2868)).
head(id(318),a34(2868)).
head(id(319),a1(2494)).
head(id(320),a3(2494)).
head(id(321),a7(2494)).
head(id(322),a8(2494)).
head(id(323),a9(2494)).
head(id(324),a10(2494)).
head(id(325),a11(2494)).
head(id(326),a13(2494)).
head(id(327),b(2494)).
head(id(328),a18(2494)).
head(id(329),a24(2494)).
head(id(330),a26(2494)).
head(id(331),a35(2494)).
head(id(332),a1(2833)).
head(id(333),a2(2833)).
head(id(334),a13(2833)).
head(id(335),b(2833)).
head(id(336),a18(2833)).
head(id(337),a26(2833)).
head(id(338),a32(2833)).
head(id(339),a11(925)).
head(id(340),a13(925)).
head(id(341),n(925)).
head(id(342),a18(925)).
head(id(343),a20(925)).
head(id(344),a26(925)).
head(id(345),a31(925)).
head(id(346),a33(925)).
head(id(347),a34(925)).
head(id(348),a2(1285)).
head(id(349),a10(1285)).
head(id(350),a13(1285)).
head(id(351),n(1285)).
head(id(352),a26(1285)).
head(id(353),a33(1285)).
head(id(354),a34(1285)).
head(id(355),a35(1285)).
head(id(356),a5(1144)).
head(id(357),a6(1144)).
head(id(358),a7(1144)).
head(id(359),n(1144)).
head(id(360),a18(1144)).
head(id(361),a24(1144)).
head(id(362),a33(1144)).
head(id(363),a34(1144)).
head(id(364),a35(1144)).
head(id(1521,A),krkp(A)) :- dom(A).
body(id(1521,A),alpha_1(A)) :- dom(A).
body(id(1521,A),a6(A)) :- dom(A).
head(id(3075,A),krkp(A)) :- dom(A).
body(id(3075,A),alpha_2(A)) :- dom(A).
body(id(3075,A),a5(A)) :- dom(A).
head(id(5799,A),krkp(A)) :- dom(A).
body(id(5799,A),alpha_3(A)) :- dom(A).
body(id(5799,A),a9(A)) :- dom(A).
head(id(8138,A),krkp(A)) :- dom(A).
body(id(8138,A),alpha_4(A)) :- dom(A).
body(id(8138,A),a2(A)) :- dom(A).
head(id(9708,A),krkp(A)) :- dom(A).
body(id(9708,A),alpha_5(A)) :- dom(A).
body(id(9708,A),a10(A)) :- dom(A).
head(id(10898,A),krkp(A)) :- dom(A).
body(id(10898,A),alpha_6(A)) :- dom(A).
body(id(10898,A),a1(A)) :- dom(A).
head(id(12496,A),krkp(A)) :- dom(A).
body(id(12496,A),alpha_7(A)) :- dom(A).
body(id(12496,A),a13(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
assumption(alpha_4(A)) :- dom(A).
assumption(alpha_5(A)) :- dom(A).
assumption(alpha_6(A)) :- dom(A).
assumption(alpha_7(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).
contrary(alpha_4(A),c_alpha_4(A)) :- assumption(alpha_4(A)).
contrary(alpha_5(A),c_alpha_5(A)) :- assumption(alpha_5(A)).
contrary(alpha_6(A),c_alpha_6(A)) :- assumption(alpha_6(A)).
contrary(alpha_7(A),c_alpha_7(A)) :- assumption(alpha_7(A)).

dom(49).
dom(68).
dom(200).
dom(241).
dom(296).
dom(420).
dom(600).
dom(611).
dom(703).
dom(751).
dom(925).
dom(1045).
dom(1144).
dom(1250).
dom(1285).
dom(1408).
dom(1452).
dom(1481).
dom(1494).
dom(1531).
dom(1702).
dom(1809).
dom(1918).
dom(2011).
dom(2181).
dom(2221).
dom(2258).
dom(2266).
dom(2308).
dom(2324).
dom(2494).
dom(2576).
dom(2821).
dom(2833).
dom(2868).
dom(2912).
dom(3020).
dom(3121).
dom(3154).
 :- not supported(krkp(2221)).
 :- not supported(krkp(420)).
 :- not supported(krkp(296)).
 :- not supported(krkp(2181)).
 :- not supported(krkp(2266)).
 :- not supported(krkp(241)).
 :- not supported(krkp(1809)).
 :- not supported(krkp(600)).
 :- not supported(krkp(1918)).
 :- not supported(krkp(751)).
 :- not supported(krkp(200)).
 :- not supported(krkp(1702)).
 :- not supported(krkp(68)).
 :- not supported(krkp(2011)).
 :- not supported(krkp(49)).
 :- not supported(krkp(2258)).
 :- not supported(krkp(611)).
 :- not supported(krkp(2324)).
 :- not supported(krkp(703)).
 :- not supported(krkp(2308)).
 :- supported(krkp(2912)).
 :- supported(krkp(3154)).
 :- supported(krkp(3121)).
 :- supported(krkp(1452)).
 :- supported(krkp(1408)).
 :- supported(krkp(1531)).
 :- supported(krkp(3020)).
 :- supported(krkp(1250)).
 :- supported(krkp(1481)).
 :- supported(krkp(2576)).
 :- supported(krkp(2821)).
 :- supported(krkp(1045)).
 :- supported(krkp(1494)).
 :- supported(krkp(2868)).
 :- supported(krkp(2494)).
 :- supported(krkp(2833)).
 :- supported(krkp(925)).
 :- supported(krkp(1285)).
 :- supported(krkp(1144)).
