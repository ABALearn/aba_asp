head(id(1),a1(509)).
head(id(2),a2(509)).
head(id(3),a3(509)).
head(id(4),a4(509)).
head(id(5),a5(509)).
head(id(6),a6(509)).
head(id(7),a7(509)).
head(id(8),a8(509)).
head(id(9),a9(509)).
head(id(10),a10(509)).
head(id(11),age4(509)).
head(id(12),female(509)).
head(id(13),white(509)).
head(id(14),jaundice(509)).
head(id(15),pdd(509)).
head(id(16),self(509)).
head(id(17),a1(660)).
head(id(18),a2(660)).
head(id(19),a3(660)).
head(id(20),a4(660)).
head(id(21),a5(660)).
head(id(22),a6(660)).
head(id(23),a9(660)).
head(id(24),a10(660)).
head(id(25),age4(660)).
head(id(26),a1(559)).
head(id(27),a2(559)).
head(id(28),a3(559)).
head(id(29),a4(559)).
head(id(30),a5(559)).
head(id(31),a6(559)).
head(id(32),a7(559)).
head(id(33),a8(559)).
head(id(34),a10(559)).
head(id(35),age2(559)).
head(id(36),female(559)).
head(id(37),white(559)).
head(id(38),self(559)).
head(id(39),a1(521)).
head(id(40),a2(521)).
head(id(41),a3(521)).
head(id(42),a4(521)).
head(id(43),a5(521)).
head(id(44),a8(521)).
head(id(45),a9(521)).
head(id(46),a10(521)).
head(id(47),age2(521)).
head(id(48),female(521)).
head(id(49),white(521)).
head(id(50),pdd(521)).
head(id(51),self(521)).
head(id(52),a1(654)).
head(id(53),a2(654)).
head(id(54),a3(654)).
head(id(55),a4(654)).
head(id(56),a5(654)).
head(id(57),a6(654)).
head(id(58),a7(654)).
head(id(59),a8(654)).
head(id(60),a9(654)).
head(id(61),a10(654)).
head(id(62),age3(654)).
head(id(63),female(654)).
head(id(64),white(654)).
head(id(65),pdd(654)).
head(id(66),self(654)).
head(id(67),a1(203)).
head(id(68),a2(203)).
head(id(69),a4(203)).
head(id(70),a5(203)).
head(id(71),a8(203)).
head(id(72),a9(203)).
head(id(73),a10(203)).
head(id(74),age2(203)).
head(id(75),female(203)).
head(id(76),white(203)).
head(id(77),self(203)).
head(id(78),a1(224)).
head(id(79),a3(224)).
head(id(80),a4(224)).
head(id(81),a6(224)).
head(id(82),a7(224)).
head(id(83),a8(224)).
head(id(84),a9(224)).
head(id(85),a10(224)).
head(id(86),age2(224)).
head(id(87),white(224)).
head(id(88),self(224)).
head(id(89),a1(189)).
head(id(90),a2(189)).
head(id(91),a4(189)).
head(id(92),a5(189)).
head(id(93),a6(189)).
head(id(94),a8(189)).
head(id(95),a9(189)).
head(id(96),a10(189)).
head(id(97),age5(189)).
head(id(98),female(189)).
head(id(99),white(189)).
head(id(100),pdd(189)).
head(id(101),self(189)).
head(id(102),a1(693)).
head(id(103),a2(693)).
head(id(104),a3(693)).
head(id(105),a5(693)).
head(id(106),a6(693)).
head(id(107),a7(693)).
head(id(108),a8(693)).
head(id(109),a10(693)).
head(id(110),age2(693)).
head(id(111),white(693)).
head(id(112),self(693)).
head(id(113),a1(472)).
head(id(114),a2(472)).
head(id(115),a3(472)).
head(id(116),a4(472)).
head(id(117),a5(472)).
head(id(118),a7(472)).
head(id(119),a8(472)).
head(id(120),age2(472)).
head(id(121),latino(472)).
head(id(122),self(472)).
head(id(123),a1(545)).
head(id(124),a3(545)).
head(id(125),a4(545)).
head(id(126),a5(545)).
head(id(127),a6(545)).
head(id(128),a7(545)).
head(id(129),a8(545)).
head(id(130),a9(545)).
head(id(131),a10(545)).
head(id(132),age3(545)).
head(id(133),female(545)).
head(id(134),white(545)).
head(id(135),jaundice(545)).
head(id(136),self(545)).
head(id(137),a1(494)).
head(id(138),a2(494)).
head(id(139),a3(494)).
head(id(140),a4(494)).
head(id(141),a5(494)).
head(id(142),a6(494)).
head(id(143),a7(494)).
head(id(144),a8(494)).
head(id(145),a9(494)).
head(id(146),a10(494)).
head(id(147),age3(494)).
head(id(148),latino(494)).
head(id(149),self(494)).
head(id(150),a1(638)).
head(id(151),a2(638)).
head(id(152),a3(638)).
head(id(153),a4(638)).
head(id(154),a5(638)).
head(id(155),a6(638)).
head(id(156),a7(638)).
head(id(157),a8(638)).
head(id(158),a9(638)).
head(id(159),a10(638)).
head(id(160),age2(638)).
head(id(161),female(638)).
head(id(162),white(638)).
head(id(163),self(638)).
head(id(164),a1(449)).
head(id(165),a2(449)).
head(id(166),a3(449)).
head(id(167),a4(449)).
head(id(168),a5(449)).
head(id(169),a6(449)).
head(id(170),a7(449)).
head(id(171),a9(449)).
head(id(172),a10(449)).
head(id(173),age5(449)).
head(id(174),white(449)).
head(id(175),self(449)).
head(id(176),a1(215)).
head(id(177),a2(215)).
head(id(178),a3(215)).
head(id(179),a4(215)).
head(id(180),a10(215)).
head(id(181),age4(215)).
head(id(182),white(215)).
head(id(183),self(215)).
head(id(184),a3(633)).
head(id(185),a8(633)).
head(id(186),age2(633)).
head(id(187),female(633)).
head(id(188),asian(633)).
head(id(189),parent(633)).
head(id(190),a1(202)).
head(id(191),a2(202)).
head(id(192),a4(202)).
head(id(193),a5(202)).
head(id(194),a9(202)).
head(id(195),a10(202)).
head(id(196),age2(202)).
head(id(197),female(202)).
head(id(198),white(202)).
head(id(199),self(202)).
head(id(200),a1(113)).
head(id(201),a5(113)).
head(id(202),a10(113)).
head(id(203),age3(113)).
head(id(204),asian(113)).
head(id(205),parent(113)).
head(id(206),a3(520)).
head(id(207),a4(520)).
head(id(208),a10(520)).
head(id(209),age3(520)).
head(id(210),middleeastern(520)).
head(id(211),self(520)).
head(id(212),a1(160)).
head(id(213),a7(160)).
head(id(214),a8(160)).
head(id(215),age3(160)).
head(id(216),asian(160)).
head(id(217),self(160)).
head(id(218),age4(295)).
head(id(219),female(295)).
head(id(220),middleeastern(295)).
head(id(221),parent(295)).
head(id(222),a1(133)).
head(id(223),a2(133)).
head(id(224),a8(133)).
head(id(225),age2(133)).
head(id(226),southasian(133)).
head(id(227),self(133)).
head(id(228),a1(88)).
head(id(229),age3(88)).
head(id(230),white(88)).
head(id(231),self(88)).
head(id(232),a1(205)).
head(id(233),a3(205)).
head(id(234),a4(205)).
head(id(235),age3(205)).
head(id(236),white(205)).
head(id(237),pdd(205)).
head(id(238),self(205)).
head(id(239),a1(267)).
head(id(240),a4(267)).
head(id(241),a9(267)).
head(id(242),age2(267)).
head(id(243),asian(267)).
head(id(244),self(267)).
head(id(245),a1(321)).
head(id(246),a2(321)).
head(id(247),age1(321)).
head(id(248),female(321)).
head(id(249),middleeastern(321)).
head(id(250),self(321)).
head(id(251),a4(286)).
head(id(252),a5(286)).
head(id(253),a6(286)).
head(id(254),a7(286)).
head(id(255),a9(286)).
head(id(256),a10(286)).
head(id(257),age3(286)).
head(id(258),female(286)).
head(id(259),a4(527)).
head(id(260),a7(527)).
head(id(261),a8(527)).
head(id(262),a10(527)).
head(id(263),age3(527)).
head(id(264),asian(527)).
head(id(265),self(527)).
head(id(266),a1(110)).
head(id(267),a6(110)).
head(id(268),a7(110)).
head(id(269),age1(110)).
head(id(270),female(110)).
head(id(271),asian(110)).
head(id(272),parent(110)).
head(id(273),a1(342)).
head(id(274),a2(342)).
head(id(275),a3(342)).
head(id(276),a4(342)).
head(id(277),a5(342)).
head(id(278),a8(342)).
head(id(279),age1(342)).
head(id(280),a1(306)).
head(id(281),a2(306)).
head(id(282),a4(306)).
head(id(283),a10(306)).
head(id(284),age3(306)).
head(id(285),female(306)).
head(id(286),white(306)).
head(id(287),self(306)).
head(id(288),a3(581)).
head(id(289),a4(581)).
head(id(290),age4(581)).
head(id(291),black(581)).
head(id(292),self(581)).
head(id(293),a1(617)).
head(id(294),a5(617)).
head(id(295),a7(617)).
head(id(296),age2(617)).
head(id(297),southasian(617)).
head(id(298),self(617)).
head(id(299),a1(676)).
head(id(300),a2(676)).
head(id(301),a3(676)).
head(id(302),a4(676)).
head(id(303),a9(676)).
head(id(304),age2(676)).
head(id(305),female(676)).
head(id(306),white(676)).
head(id(307),jaundice(676)).
head(id(308),self(676)).
head(id(309),a1(157)).
head(id(310),a6(157)).
head(id(311),a8(157)).
head(id(312),a10(157)).
head(id(313),age2(157)).
head(id(314),female(157)).
head(id(315),asian(157)).
head(id(316),self(157)).
head(id(317),a2(44)).
head(id(318),a3(44)).
head(id(319),a4(44)).
head(id(320),a10(44)).
head(id(321),age3(44)).
head(id(322),female(44)).
head(id(323),white(44)).
head(id(324),jaundice(44)).
head(id(325),pdd(44)).
head(id(326),self(44)).
head(id(327),a1(131)).
head(id(328),a2(131)).
head(id(329),a8(131)).
head(id(330),age1(131)).
head(id(331),female(131)).
head(id(332),white(131)).
head(id(333),self(131)).
head(id(334),a1(259)).
head(id(335),a5(259)).
head(id(336),a6(259)).
head(id(337),a8(259)).
head(id(338),a10(259)).
head(id(339),age2(259)).
head(id(340),asian(259)).
head(id(341),self(259)).
head(id(342),a8(470)).
head(id(343),age2(470)).
head(id(344),female(470)).
head(id(345),asian(470)).
head(id(346),jaundice(470)).
head(id(347),self(470)).
head(id(348),a2(489)).
head(id(349),a3(489)).
head(id(350),a7(489)).
head(id(351),a10(489)).
head(id(352),age1(489)).
head(id(353),black(489)).
head(id(354),self(489)).
head(id(355),a1(9)).
head(id(356),a2(9)).
head(id(357),a5(9)).
head(id(358),a8(9)).
head(id(359),a9(9)).
head(id(360),a10(9)).
head(id(361),age2(9)).
head(id(362),white(9)).
head(id(363),self(9)).
head(id(1499,A),autism(A)) :- dom(A).
body(id(1499,A),alpha_1(A)) :- dom(A).
body(id(1499,A),a1(A)) :- dom(A).
head(id(8548,A),c_alpha_1(A)) :- dom(A).
body(id(8548,A),alpha_2(A)) :- dom(A).
body(id(8548,A),a2(A)) :- dom(A).
head(id(10568,A),c_alpha_1(A)) :- dom(A).
body(id(10568,A),alpha_3(A)) :- dom(A).
body(id(10568,A),age3(A)) :- dom(A).
head(id(12623,A),c_alpha_1(A)) :- dom(A).
body(id(12623,A),alpha_4(A)) :- dom(A).
body(id(12623,A),a6(A)) :- dom(A).
head(id(18488,A),c_alpha_1(A)) :- dom(A).
body(id(18488,A),alpha_5(A)) :- dom(A).
body(id(18488,A),a4(A)) :- dom(A).
head(id(21936,A),c_alpha_1(A)) :- dom(A).
body(id(21936,A),alpha_6(A)) :- dom(A).
body(id(21936,A),a5(A)) :- dom(A).
head(id(25065,A),c_alpha_2(A)) :- dom(A).
body(id(25065,A),a4(A)) :- dom(A).
head(id(32106,A),c_alpha_2(A)) :- dom(A).
body(id(32106,A),a3(A)) :- dom(A).
head(id(33859,A),c_alpha_3(A)) :- dom(A).
body(id(33859,A),a2(A)) :- dom(A).
head(id(35616,A),c_alpha_3(A)) :- dom(A).
body(id(35616,A),a3(A)) :- dom(A).
head(id(37812,A),c_alpha_4(A)) :- dom(A).
body(id(37812,A),a2(A)) :- dom(A).
head(id(39573,A),c_alpha_4(A)) :- dom(A).
body(id(39573,A),a3(A)) :- dom(A).
head(id(46960,A),c_alpha_5(A)) :- dom(A).
body(id(46960,A),a5(A)) :- dom(A).
head(id(49554,A),c_alpha_5(A)) :- dom(A).
body(id(49554,A),alpha_7(A)) :- dom(A).
body(id(49554,A),a3(A)) :- dom(A).
head(id(58192,A),c_alpha_6(A)) :- dom(A).
body(id(58192,A),a6(A)) :- dom(A).
head(id(62933,A),c_alpha_6(A)) :- dom(A).
body(id(62933,A),alpha_8(A)) :- dom(A).
body(id(62933,A),a8(A)) :- dom(A).
head(id(71054,A),c_alpha_7(A)) :- dom(A).
body(id(71054,A),age3(A)) :- dom(A).
head(id(72755,A),c_alpha_7(A)) :- dom(A).
body(id(72755,A),a2(A)) :- dom(A).
head(id(79146,A),c_alpha_8(A)) :- dom(A).
body(id(79146,A),age1(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
assumption(alpha_4(A)) :- dom(A).
assumption(alpha_5(A)) :- dom(A).
assumption(alpha_6(A)) :- dom(A).
assumption(alpha_7(A)) :- dom(A).
assumption(alpha_8(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).
contrary(alpha_4(A),c_alpha_4(A)) :- assumption(alpha_4(A)).
contrary(alpha_5(A),c_alpha_5(A)) :- assumption(alpha_5(A)).
contrary(alpha_6(A),c_alpha_6(A)) :- assumption(alpha_6(A)).
contrary(alpha_7(A),c_alpha_7(A)) :- assumption(alpha_7(A)).
contrary(alpha_8(A),c_alpha_8(A)) :- assumption(alpha_8(A)).

dom(9).
dom(44).
dom(88).
dom(110).
dom(113).
dom(131).
dom(133).
dom(157).
dom(160).
dom(189).
dom(202).
dom(203).
dom(205).
dom(215).
dom(224).
dom(259).
dom(267).
dom(286).
dom(295).
dom(306).
dom(321).
dom(342).
dom(449).
dom(470).
dom(472).
dom(489).
dom(494).
dom(509).
dom(520).
dom(521).
dom(527).
dom(545).
dom(559).
dom(581).
dom(617).
dom(633).
dom(638).
dom(654).
dom(660).
dom(676).
dom(693).
 :- not supported(autism(509)).
 :- not supported(autism(660)).
 :- not supported(autism(559)).
 :- not supported(autism(521)).
 :- not supported(autism(654)).
 :- not supported(autism(203)).
 :- not supported(autism(224)).
 :- not supported(autism(189)).
 :- not supported(autism(693)).
 :- not supported(autism(472)).
 :- not supported(autism(545)).
 :- not supported(autism(494)).
 :- not supported(autism(638)).
 :- not supported(autism(449)).
 :- supported(autism(215)).
 :- supported(autism(633)).
 :- supported(autism(202)).
 :- supported(autism(113)).
 :- supported(autism(520)).
 :- supported(autism(160)).
 :- supported(autism(295)).
 :- supported(autism(133)).
 :- supported(autism(88)).
 :- supported(autism(205)).
 :- supported(autism(267)).
 :- supported(autism(321)).
 :- supported(autism(286)).
 :- supported(autism(527)).
 :- supported(autism(110)).
 :- supported(autism(342)).
 :- supported(autism(306)).
 :- supported(autism(581)).
 :- supported(autism(617)).
 :- supported(autism(676)).
 :- supported(autism(157)).
 :- supported(autism(44)).
 :- supported(autism(131)).
 :- supported(autism(259)).
 :- supported(autism(470)).
 :- supported(autism(489)).
 :- supported(autism(9)).
