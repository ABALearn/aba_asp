% training data:
% no. positive ex.: 13
% no. negative ex.: 26
% query: 
train :- aba_asp('./xabal/autism.csv.f5.bk',[autism(434),autism(529),autism(124),autism(509),autism(660),autism(559),autism(521),autism(654),autism(203),autism(224),autism(189),autism(693),autism(472)],[autism(304),autism(608),autism(64),autism(294),autism(132),autism(600),autism(215),autism(633),autism(202),autism(113),autism(520),autism(160),autism(295),autism(133),autism(88),autism(205),autism(267),autism(321),autism(286),autism(527),autism(110),autism(342),autism(306),autism(581),autism(617),autism(676)]).
% test data:
% no. positive ex.: 4
% no. negative ex.: 7
% query: 
test :- test_abaf('./xabal/autism.csv.f5.bk.sol',[pos(autism(545),[a1(545),a3(545),a4(545),a5(545),a6(545),a7(545),a8(545),a9(545),a10(545),age3(545),female(545),white(545),jaundice(545),self(545)]),pos(autism(494),[a1(494),a2(494),a3(494),a4(494),a5(494),a6(494),a7(494),a8(494),a9(494),a10(494),age3(494),latino(494),self(494)]),pos(autism(638),[a1(638),a2(638),a3(638),a4(638),a5(638),a6(638),a7(638),a8(638),a9(638),a10(638),age2(638),female(638),white(638),self(638)]),pos(autism(449),[a1(449),a2(449),a3(449),a4(449),a5(449),a6(449),a7(449),a9(449),a10(449),age5(449),white(449),self(449)])],[neg(autism(157),[a1(157),a6(157),a8(157),a10(157),age2(157),female(157),asian(157),self(157)]),neg(autism(44),[a2(44),a3(44),a4(44),a10(44),age3(44),female(44),white(44),jaundice(44),pdd(44),self(44)]),neg(autism(131),[a1(131),a2(131),a8(131),age1(131),female(131),white(131),self(131)]),neg(autism(259),[a1(259),a5(259),a6(259),a8(259),a10(259),age2(259),asian(259),self(259)]),neg(autism(470),[a8(470),age2(470),female(470),asian(470),jaundice(470),self(470)]),neg(autism(489),[a2(489),a3(489),a7(489),a10(489),age1(489),black(489),self(489)]),neg(autism(9),[a1(9),a2(9),a5(9),a8(9),a9(9),a10(9),age2(9),white(9),self(9)])]).
