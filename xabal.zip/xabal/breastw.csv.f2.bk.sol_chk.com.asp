head(id(1),clump_thickness__5(125)).
head(id(2),cell_size_uniformity__4(125)).
head(id(3),cell_shape_uniformity__6(125)).
head(id(4),marginal_adhesion__7(125)).
head(id(5),single_epi_cell_size__9(125)).
head(id(6),bare_nuclei__7(125)).
head(id(7),bland_chromatin__8(125)).
head(id(8),mitoses__1(125)).
head(id(9),clump_thickness__8(216)).
head(id(10),cell_size_uniformity__7(216)).
head(id(11),cell_shape_uniformity__8(216)).
head(id(12),marginal_adhesion__7(216)).
head(id(13),single_epi_cell_size__5(216)).
head(id(14),bare_nuclei__5(216)).
head(id(15),bland_chromatin__5(216)).
head(id(16),mitoses__2(216)).
head(id(17),clump_thickness__8(301)).
head(id(18),cell_size_uniformity__4(301)).
head(id(19),marginal_adhesion__5(301)).
head(id(20),single_epi_cell_size__4(301)).
head(id(21),bare_nuclei__4(301)).
head(id(22),bland_chromatin__7(301)).
head(id(23),mitoses__1(301)).
head(id(24),clump_thickness__7(152)).
head(id(25),cell_size_uniformity__2(152)).
head(id(26),cell_shape_uniformity__4(152)).
head(id(27),marginal_adhesion__1(152)).
head(id(28),single_epi_cell_size__6(152)).
head(id(29),bland_chromatin__5(152)).
head(id(30),normal_nucleoli__4(152)).
head(id(31),mitoses__3(152)).
head(id(32),cell_size_uniformity__8(202)).
head(id(33),cell_shape_uniformity__8(202)).
head(id(34),marginal_adhesion__4(202)).
head(id(35),bland_chromatin__8(202)).
head(id(36),normal_nucleoli__1(202)).
head(id(37),mitoses__1(202)).
head(id(38),clump_thickness__8(335)).
head(id(39),cell_size_uniformity__6(335)).
head(id(40),cell_shape_uniformity__7(335)).
head(id(41),marginal_adhesion__3(335)).
head(id(42),single_epi_cell_size__3(335)).
head(id(43),bland_chromatin__3(335)).
head(id(44),normal_nucleoli__4(335)).
head(id(45),mitoses__2(335)).
head(id(46),clump_thickness__7(265)).
head(id(47),cell_size_uniformity__9(265)).
head(id(48),cell_shape_uniformity__4(265)).
head(id(49),bare_nuclei__3(265)).
head(id(50),bland_chromatin__5(265)).
head(id(51),normal_nucleoli__3(265)).
head(id(52),mitoses__3(265)).
head(id(53),clump_thickness__7(321)).
head(id(54),cell_size_uniformity__6(321)).
head(id(55),cell_shape_uniformity__3(321)).
head(id(56),marginal_adhesion__2(321)).
head(id(57),single_epi_cell_size__5(321)).
head(id(58),bland_chromatin__7(321)).
head(id(59),normal_nucleoli__4(321)).
head(id(60),mitoses__6(321)).
head(id(61),cell_size_uniformity__6(467)).
head(id(62),cell_shape_uniformity__6(467)).
head(id(63),marginal_adhesion__2(467)).
head(id(64),single_epi_cell_size__4(467)).
head(id(65),bland_chromatin__9(467)).
head(id(66),normal_nucleoli__7(467)).
head(id(67),mitoses__1(467)).
head(id(68),clump_thickness__8(150)).
head(id(69),cell_size_uniformity__8(150)).
head(id(70),cell_shape_uniformity__7(150)).
head(id(71),marginal_adhesion__4(150)).
head(id(72),bland_chromatin__7(150)).
head(id(73),normal_nucleoli__8(150)).
head(id(74),mitoses__7(150)).
head(id(75),cell_size_uniformity__6(382)).
head(id(76),cell_shape_uniformity__3(382)).
head(id(77),marginal_adhesion__6(382)).
head(id(78),single_epi_cell_size__4(382)).
head(id(79),bland_chromatin__7(382)).
head(id(80),normal_nucleoli__8(382)).
head(id(81),mitoses__4(382)).
head(id(82),cell_size_uniformity__5(280)).
head(id(83),cell_shape_uniformity__7(280)).
head(id(84),marginal_adhesion__3(280)).
head(id(85),single_epi_cell_size__3(280)).
head(id(86),bare_nuclei__7(280)).
head(id(87),bland_chromatin__3(280)).
head(id(88),normal_nucleoli__3(280)).
head(id(89),mitoses__8(280)).
head(id(90),clump_thickness__5(290)).
head(id(91),cell_size_uniformity__6(290)).
head(id(92),cell_shape_uniformity__6(290)).
head(id(93),marginal_adhesion__8(290)).
head(id(94),single_epi_cell_size__6(290)).
head(id(95),bland_chromatin__4(290)).
head(id(96),mitoses__4(290)).
head(id(97),clump_thickness__5(670)).
head(id(98),marginal_adhesion__8(670)).
head(id(99),single_epi_cell_size__5(670)).
head(id(100),bare_nuclei__5(670)).
head(id(101),bland_chromatin__7(670)).
head(id(102),mitoses__1(670)).
head(id(103),clump_thickness__5(189)).
head(id(104),cell_size_uniformity__8(189)).
head(id(105),cell_shape_uniformity__4(189)).
head(id(106),single_epi_cell_size__5(189)).
head(id(107),bare_nuclei__8(189)).
head(id(108),bland_chromatin__9(189)).
head(id(109),mitoses__1(189)).
head(id(110),clump_thickness__1(203)).
head(id(111),cell_size_uniformity__1(203)).
head(id(112),cell_shape_uniformity__1(203)).
head(id(113),marginal_adhesion__1(203)).
head(id(114),single_epi_cell_size__2(203)).
head(id(115),bare_nuclei__1(203)).
head(id(116),bland_chromatin__3(203)).
head(id(117),normal_nucleoli__1(203)).
head(id(118),mitoses__1(203)).
head(id(119),clump_thickness__2(366)).
head(id(120),cell_size_uniformity__1(366)).
head(id(121),cell_shape_uniformity__1(366)).
head(id(122),marginal_adhesion__1(366)).
head(id(123),single_epi_cell_size__2(366)).
head(id(124),bare_nuclei__1(366)).
head(id(125),bland_chromatin__2(366)).
head(id(126),normal_nucleoli__1(366)).
head(id(127),mitoses__1(366)).
head(id(128),clump_thickness__4(371)).
head(id(129),cell_size_uniformity__3(371)).
head(id(130),cell_shape_uniformity__2(371)).
head(id(131),marginal_adhesion__1(371)).
head(id(132),single_epi_cell_size__3(371)).
head(id(133),bare_nuclei__1(371)).
head(id(134),bland_chromatin__2(371)).
head(id(135),normal_nucleoli__1(371)).
head(id(136),mitoses__1(371)).
head(id(137),clump_thickness__3(651)).
head(id(138),cell_size_uniformity__1(651)).
head(id(139),cell_shape_uniformity__1(651)).
head(id(140),marginal_adhesion__2(651)).
head(id(141),single_epi_cell_size__3(651)).
head(id(142),bare_nuclei__4(651)).
head(id(143),bland_chromatin__1(651)).
head(id(144),normal_nucleoli__1(651)).
head(id(145),mitoses__1(651)).
head(id(146),clump_thickness__3(434)).
head(id(147),cell_size_uniformity__2(434)).
head(id(148),cell_shape_uniformity__2(434)).
head(id(149),marginal_adhesion__3(434)).
head(id(150),single_epi_cell_size__2(434)).
head(id(151),bare_nuclei__1(434)).
head(id(152),bland_chromatin__1(434)).
head(id(153),normal_nucleoli__1(434)).
head(id(154),mitoses__1(434)).
head(id(155),clump_thickness__5(683)).
head(id(156),cell_size_uniformity__1(683)).
head(id(157),cell_shape_uniformity__1(683)).
head(id(158),marginal_adhesion__1(683)).
head(id(159),single_epi_cell_size__2(683)).
head(id(160),bare_nuclei__1(683)).
head(id(161),bland_chromatin__3(683)).
head(id(162),normal_nucleoli__2(683)).
head(id(163),mitoses__1(683)).
head(id(164),clump_thickness__1(486)).
head(id(165),cell_size_uniformity__1(486)).
head(id(166),cell_shape_uniformity__1(486)).
head(id(167),marginal_adhesion__3(486)).
head(id(168),single_epi_cell_size__1(486)).
head(id(169),bare_nuclei__3(486)).
head(id(170),bland_chromatin__1(486)).
head(id(171),normal_nucleoli__1(486)).
head(id(172),mitoses__1(486)).
head(id(173),clump_thickness__5(83)).
head(id(174),cell_size_uniformity__2(83)).
head(id(175),cell_shape_uniformity__1(83)).
head(id(176),marginal_adhesion__1(83)).
head(id(177),single_epi_cell_size__2(83)).
head(id(178),bare_nuclei__1(83)).
head(id(179),bland_chromatin__3(83)).
head(id(180),normal_nucleoli__1(83)).
head(id(181),mitoses__1(83)).
head(id(182),clump_thickness__3(396)).
head(id(183),cell_size_uniformity__1(396)).
head(id(184),cell_shape_uniformity__1(396)).
head(id(185),marginal_adhesion__1(396)).
head(id(186),single_epi_cell_size__2(396)).
head(id(187),bare_nuclei__1(396)).
head(id(188),bland_chromatin__2(396)).
head(id(189),normal_nucleoli__1(396)).
head(id(190),mitoses__1(396)).
head(id(191),clump_thickness__2(80)).
head(id(192),cell_size_uniformity__1(80)).
head(id(193),cell_shape_uniformity__1(80)).
head(id(194),marginal_adhesion__1(80)).
head(id(195),single_epi_cell_size__3(80)).
head(id(196),bare_nuclei__1(80)).
head(id(197),bland_chromatin__2(80)).
head(id(198),normal_nucleoli__1(80)).
head(id(199),mitoses__1(80)).
head(id(200),clump_thickness__1(190)).
head(id(201),cell_size_uniformity__2(190)).
head(id(202),cell_shape_uniformity__3(190)).
head(id(203),marginal_adhesion__1(190)).
head(id(204),single_epi_cell_size__2(190)).
head(id(205),bare_nuclei__1(190)).
head(id(206),bland_chromatin__3(190)).
head(id(207),normal_nucleoli__1(190)).
head(id(208),mitoses__1(190)).
head(id(209),clump_thickness__4(532)).
head(id(210),cell_size_uniformity__2(532)).
head(id(211),cell_shape_uniformity__2(532)).
head(id(212),marginal_adhesion__1(532)).
head(id(213),single_epi_cell_size__2(532)).
head(id(214),bare_nuclei__1(532)).
head(id(215),bland_chromatin__2(532)).
head(id(216),normal_nucleoli__1(532)).
head(id(217),mitoses__1(532)).
head(id(218),clump_thickness__1(431)).
head(id(219),cell_size_uniformity__3(431)).
head(id(220),cell_shape_uniformity__1(431)).
head(id(221),marginal_adhesion__1(431)).
head(id(222),single_epi_cell_size__2(431)).
head(id(223),bare_nuclei__1(431)).
head(id(224),bland_chromatin__2(431)).
head(id(225),normal_nucleoli__2(431)).
head(id(226),mitoses__1(431)).
head(id(227),clump_thickness__5(596)).
head(id(228),cell_size_uniformity__1(596)).
head(id(229),cell_shape_uniformity__1(596)).
head(id(230),marginal_adhesion__1(596)).
head(id(231),single_epi_cell_size__2(596)).
head(id(232),bare_nuclei__1(596)).
head(id(233),bland_chromatin__2(596)).
head(id(234),normal_nucleoli__1(596)).
head(id(235),mitoses__1(596)).
head(id(236),clump_thickness__5(414)).
head(id(237),cell_size_uniformity__1(414)).
head(id(238),cell_shape_uniformity__2(414)).
head(id(239),marginal_adhesion__1(414)).
head(id(240),single_epi_cell_size__2(414)).
head(id(241),bare_nuclei__1(414)).
head(id(242),bland_chromatin__3(414)).
head(id(243),normal_nucleoli__1(414)).
head(id(244),mitoses__1(414)).
head(id(245),clump_thickness__1(552)).
head(id(246),cell_size_uniformity__1(552)).
head(id(247),cell_shape_uniformity__1(552)).
head(id(248),marginal_adhesion__1(552)).
head(id(249),single_epi_cell_size__2(552)).
head(id(250),bare_nuclei__1(552)).
head(id(251),bland_chromatin__3(552)).
head(id(252),normal_nucleoli__1(552)).
head(id(253),mitoses__1(552)).
head(id(254),clump_thickness__3(23)).
head(id(255),cell_size_uniformity__1(23)).
head(id(256),cell_shape_uniformity__1(23)).
head(id(257),marginal_adhesion__1(23)).
head(id(258),single_epi_cell_size__2(23)).
head(id(259),bare_nuclei__1(23)).
head(id(260),bland_chromatin__2(23)).
head(id(261),normal_nucleoli__1(23)).
head(id(262),mitoses__1(23)).
head(id(263),clump_thickness__2(95)).
head(id(264),cell_size_uniformity__1(95)).
head(id(265),cell_shape_uniformity__1(95)).
head(id(266),marginal_adhesion__1(95)).
head(id(267),single_epi_cell_size__2(95)).
head(id(268),bare_nuclei__1(95)).
head(id(269),bland_chromatin__3(95)).
head(id(270),normal_nucleoli__1(95)).
head(id(271),mitoses__1(95)).
head(id(272),clump_thickness__6(38)).
head(id(273),cell_size_uniformity__2(38)).
head(id(274),cell_shape_uniformity__1(38)).
head(id(275),marginal_adhesion__1(38)).
head(id(276),single_epi_cell_size__1(38)).
head(id(277),bare_nuclei__1(38)).
head(id(278),bland_chromatin__7(38)).
head(id(279),normal_nucleoli__1(38)).
head(id(280),mitoses__1(38)).
head(id(281),clump_thickness__1(65)).
head(id(282),cell_size_uniformity__1(65)).
head(id(283),cell_shape_uniformity__1(65)).
head(id(284),marginal_adhesion__1(65)).
head(id(285),single_epi_cell_size__2(65)).
head(id(286),bare_nuclei__1(65)).
head(id(287),bland_chromatin__2(65)).
head(id(288),normal_nucleoli__1(65)).
head(id(289),mitoses__1(65)).
head(id(290),clump_thickness__4(67)).
head(id(291),cell_size_uniformity__1(67)).
head(id(292),cell_shape_uniformity__1(67)).
head(id(293),marginal_adhesion__1(67)).
head(id(294),single_epi_cell_size__2(67)).
head(id(295),bare_nuclei__1(67)).
head(id(296),bland_chromatin__3(67)).
head(id(297),normal_nucleoli__1(67)).
head(id(298),mitoses__1(67)).
head(id(299),clump_thickness__5(475)).
head(id(300),cell_size_uniformity__1(475)).
head(id(301),cell_shape_uniformity__1(475)).
head(id(302),marginal_adhesion__1(475)).
head(id(303),single_epi_cell_size__2(475)).
head(id(304),bare_nuclei__1(475)).
head(id(305),bland_chromatin__1(475)).
head(id(306),normal_nucleoli__1(475)).
head(id(307),mitoses__1(475)).
head(id(308),clump_thickness__1(96)).
head(id(309),cell_size_uniformity__1(96)).
head(id(310),cell_shape_uniformity__1(96)).
head(id(311),marginal_adhesion__1(96)).
head(id(312),single_epi_cell_size__2(96)).
head(id(313),bare_nuclei__1(96)).
head(id(314),bland_chromatin__3(96)).
head(id(315),normal_nucleoli__1(96)).
head(id(316),mitoses__1(96)).
head(id(317),clump_thickness__4(18)).
head(id(318),cell_size_uniformity__1(18)).
head(id(319),cell_shape_uniformity__1(18)).
head(id(320),marginal_adhesion__1(18)).
head(id(321),single_epi_cell_size__2(18)).
head(id(322),bare_nuclei__1(18)).
head(id(323),bland_chromatin__3(18)).
head(id(324),normal_nucleoli__1(18)).
head(id(325),mitoses__1(18)).
head(id(326),clump_thickness__1(687)).
head(id(327),cell_size_uniformity__1(687)).
head(id(328),cell_shape_uniformity__1(687)).
head(id(329),marginal_adhesion__1(687)).
head(id(330),single_epi_cell_size__2(687)).
head(id(331),bare_nuclei__1(687)).
head(id(332),bland_chromatin__1(687)).
head(id(333),normal_nucleoli__1(687)).
head(id(334),mitoses__1(687)).
head(id(1386,A),malignant(A)) :- dom(A).
body(id(1386,A),alpha_1(A)) :- dom(A).
body(id(1386,A),clump_thickness__5(A)) :- dom(A).
head(id(2105,A),malignant(A)) :- dom(A).
body(id(2105,A),clump_thickness__8(A)) :- dom(A).
head(id(3180,A),malignant(A)) :- dom(A).
body(id(3180,A),clump_thickness__7(A)) :- dom(A).
head(id(3898,A),malignant(A)) :- dom(A).
body(id(3898,A),cell_size_uniformity__8(A)) :- dom(A).
head(id(5689,A),malignant(A)) :- dom(A).
body(id(5689,A),cell_size_uniformity__6(A)) :- dom(A).
head(id(7116,A),malignant(A)) :- dom(A).
body(id(7116,A),cell_size_uniformity__5(A)) :- dom(A).
head(id(9605,A),c_alpha_1(A)) :- dom(A).
body(id(9605,A),cell_size_uniformity__2(A)) :- dom(A).
head(id(11030,A),c_alpha_1(A)) :- dom(A).
body(id(11030,A),cell_size_uniformity__1(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).

dom(18).
dom(23).
dom(38).
dom(65).
dom(67).
dom(80).
dom(83).
dom(95).
dom(96).
dom(125).
dom(150).
dom(152).
dom(189).
dom(190).
dom(202).
dom(203).
dom(216).
dom(265).
dom(280).
dom(290).
dom(301).
dom(321).
dom(335).
dom(366).
dom(371).
dom(382).
dom(396).
dom(414).
dom(431).
dom(434).
dom(467).
dom(475).
dom(486).
dom(532).
dom(552).
dom(596).
dom(651).
dom(670).
dom(683).
dom(687).
 :- not supported(malignant(125)).
 :- not supported(malignant(216)).
 :- not supported(malignant(301)).
 :- not supported(malignant(152)).
 :- not supported(malignant(202)).
 :- not supported(malignant(335)).
 :- not supported(malignant(265)).
 :- not supported(malignant(321)).
 :- not supported(malignant(467)).
 :- not supported(malignant(150)).
 :- not supported(malignant(382)).
 :- not supported(malignant(280)).
 :- not supported(malignant(290)).
 :- not supported(malignant(670)).
 :- not supported(malignant(189)).
 :- supported(malignant(203)).
 :- supported(malignant(366)).
 :- supported(malignant(371)).
 :- supported(malignant(651)).
 :- supported(malignant(434)).
 :- supported(malignant(683)).
 :- supported(malignant(486)).
 :- supported(malignant(83)).
 :- supported(malignant(396)).
 :- supported(malignant(80)).
 :- supported(malignant(190)).
 :- supported(malignant(532)).
 :- supported(malignant(431)).
 :- supported(malignant(596)).
 :- supported(malignant(414)).
 :- supported(malignant(552)).
 :- supported(malignant(23)).
 :- supported(malignant(95)).
 :- supported(malignant(38)).
 :- supported(malignant(65)).
 :- supported(malignant(67)).
 :- supported(malignant(475)).
 :- supported(malignant(96)).
 :- supported(malignant(18)).
 :- supported(malignant(687)).
