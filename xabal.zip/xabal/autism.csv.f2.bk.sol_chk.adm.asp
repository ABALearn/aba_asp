head(id(1),a1(434)).
head(id(2),a2(434)).
head(id(3),a3(434)).
head(id(4),a4(434)).
head(id(5),a5(434)).
head(id(6),a6(434)).
head(id(7),a8(434)).
head(id(8),a9(434)).
head(id(9),age3(434)).
head(id(10),female(434)).
head(id(11),white(434)).
head(id(12),self(434)).
head(id(13),a1(529)).
head(id(14),a2(529)).
head(id(15),a3(529)).
head(id(16),a4(529)).
head(id(17),a5(529)).
head(id(18),a6(529)).
head(id(19),a7(529)).
head(id(20),a8(529)).
head(id(21),a9(529)).
head(id(22),a10(529)).
head(id(23),age4(529)).
head(id(24),female(529)).
head(id(25),white(529)).
head(id(26),jaundice(529)).
head(id(27),pdd(529)).
head(id(28),self(529)).
head(id(29),a1(124)).
head(id(30),a4(124)).
head(id(31),a5(124)).
head(id(32),a6(124)).
head(id(33),a7(124)).
head(id(34),a8(124)).
head(id(35),a10(124)).
head(id(36),age3(124)).
head(id(37),asian(124)).
head(id(38),jaundice(124)).
head(id(39),self(124)).
head(id(40),a1(521)).
head(id(41),a2(521)).
head(id(42),a3(521)).
head(id(43),a4(521)).
head(id(44),a5(521)).
head(id(45),a8(521)).
head(id(46),a9(521)).
head(id(47),a10(521)).
head(id(48),age2(521)).
head(id(49),female(521)).
head(id(50),white(521)).
head(id(51),pdd(521)).
head(id(52),self(521)).
head(id(53),a1(654)).
head(id(54),a2(654)).
head(id(55),a3(654)).
head(id(56),a4(654)).
head(id(57),a5(654)).
head(id(58),a6(654)).
head(id(59),a7(654)).
head(id(60),a8(654)).
head(id(61),a9(654)).
head(id(62),a10(654)).
head(id(63),age3(654)).
head(id(64),female(654)).
head(id(65),white(654)).
head(id(66),pdd(654)).
head(id(67),self(654)).
head(id(68),a1(203)).
head(id(69),a2(203)).
head(id(70),a4(203)).
head(id(71),a5(203)).
head(id(72),a8(203)).
head(id(73),a9(203)).
head(id(74),a10(203)).
head(id(75),age2(203)).
head(id(76),female(203)).
head(id(77),white(203)).
head(id(78),self(203)).
head(id(79),a1(224)).
head(id(80),a3(224)).
head(id(81),a4(224)).
head(id(82),a6(224)).
head(id(83),a7(224)).
head(id(84),a8(224)).
head(id(85),a9(224)).
head(id(86),a10(224)).
head(id(87),age2(224)).
head(id(88),white(224)).
head(id(89),self(224)).
head(id(90),a1(189)).
head(id(91),a2(189)).
head(id(92),a4(189)).
head(id(93),a5(189)).
head(id(94),a6(189)).
head(id(95),a8(189)).
head(id(96),a9(189)).
head(id(97),a10(189)).
head(id(98),age5(189)).
head(id(99),female(189)).
head(id(100),white(189)).
head(id(101),pdd(189)).
head(id(102),self(189)).
head(id(103),a1(693)).
head(id(104),a2(693)).
head(id(105),a3(693)).
head(id(106),a5(693)).
head(id(107),a6(693)).
head(id(108),a7(693)).
head(id(109),a8(693)).
head(id(110),a10(693)).
head(id(111),age2(693)).
head(id(112),white(693)).
head(id(113),self(693)).
head(id(114),a1(472)).
head(id(115),a2(472)).
head(id(116),a3(472)).
head(id(117),a4(472)).
head(id(118),a5(472)).
head(id(119),a7(472)).
head(id(120),a8(472)).
head(id(121),age2(472)).
head(id(122),latino(472)).
head(id(123),self(472)).
head(id(124),a1(545)).
head(id(125),a3(545)).
head(id(126),a4(545)).
head(id(127),a5(545)).
head(id(128),a6(545)).
head(id(129),a7(545)).
head(id(130),a8(545)).
head(id(131),a9(545)).
head(id(132),a10(545)).
head(id(133),age3(545)).
head(id(134),female(545)).
head(id(135),white(545)).
head(id(136),jaundice(545)).
head(id(137),self(545)).
head(id(138),a1(494)).
head(id(139),a2(494)).
head(id(140),a3(494)).
head(id(141),a4(494)).
head(id(142),a5(494)).
head(id(143),a6(494)).
head(id(144),a7(494)).
head(id(145),a8(494)).
head(id(146),a9(494)).
head(id(147),a10(494)).
head(id(148),age3(494)).
head(id(149),latino(494)).
head(id(150),self(494)).
head(id(151),a1(638)).
head(id(152),a2(638)).
head(id(153),a3(638)).
head(id(154),a4(638)).
head(id(155),a5(638)).
head(id(156),a6(638)).
head(id(157),a7(638)).
head(id(158),a8(638)).
head(id(159),a9(638)).
head(id(160),a10(638)).
head(id(161),age2(638)).
head(id(162),female(638)).
head(id(163),white(638)).
head(id(164),self(638)).
head(id(165),a1(449)).
head(id(166),a2(449)).
head(id(167),a3(449)).
head(id(168),a4(449)).
head(id(169),a5(449)).
head(id(170),a6(449)).
head(id(171),a7(449)).
head(id(172),a9(449)).
head(id(173),a10(449)).
head(id(174),age5(449)).
head(id(175),white(449)).
head(id(176),self(449)).
head(id(177),a8(304)).
head(id(178),a9(304)).
head(id(179),age3(304)).
head(id(180),female(304)).
head(id(181),others(304)).
head(id(182),self(304)).
head(id(183),a8(608)).
head(id(184),age2(608)).
head(id(185),female(608)).
head(id(186),asian(608)).
head(id(187),jaundice(608)).
head(id(188),self(608)).
head(id(189),a1(64)).
head(id(190),a4(64)).
head(id(191),a5(64)).
head(id(192),a8(64)).
head(id(193),a9(64)).
head(id(194),age1(64)).
head(id(195),white(64)).
head(id(196),parent(64)).
head(id(197),a1(294)).
head(id(198),a5(294)).
head(id(199),a7(294)).
head(id(200),a10(294)).
head(id(201),age2(294)).
head(id(202),female(294)).
head(id(203),white(294)).
head(id(204),pdd(294)).
head(id(205),self(294)).
head(id(206),a1(132)).
head(id(207),a8(132)).
head(id(208),a10(132)).
head(id(209),age2(132)).
head(id(210),black(132)).
head(id(211),self(132)).
head(id(212),a1(600)).
head(id(213),a3(600)).
head(id(214),a4(600)).
head(id(215),a8(600)).
head(id(216),a9(600)).
head(id(217),a10(600)).
head(id(218),age3(600)).
head(id(219),female(600)).
head(id(220),asian(600)).
head(id(221),parent(600)).
head(id(222),age4(295)).
head(id(223),female(295)).
head(id(224),middleeastern(295)).
head(id(225),parent(295)).
head(id(226),a1(133)).
head(id(227),a2(133)).
head(id(228),a8(133)).
head(id(229),age2(133)).
head(id(230),southasian(133)).
head(id(231),self(133)).
head(id(232),a1(88)).
head(id(233),age3(88)).
head(id(234),white(88)).
head(id(235),self(88)).
head(id(236),a1(205)).
head(id(237),a3(205)).
head(id(238),a4(205)).
head(id(239),age3(205)).
head(id(240),white(205)).
head(id(241),pdd(205)).
head(id(242),self(205)).
head(id(243),a1(267)).
head(id(244),a4(267)).
head(id(245),a9(267)).
head(id(246),age2(267)).
head(id(247),asian(267)).
head(id(248),self(267)).
head(id(249),a1(321)).
head(id(250),a2(321)).
head(id(251),age1(321)).
head(id(252),female(321)).
head(id(253),middleeastern(321)).
head(id(254),self(321)).
head(id(255),a4(286)).
head(id(256),a5(286)).
head(id(257),a6(286)).
head(id(258),a7(286)).
head(id(259),a9(286)).
head(id(260),a10(286)).
head(id(261),age3(286)).
head(id(262),female(286)).
head(id(263),a4(527)).
head(id(264),a7(527)).
head(id(265),a8(527)).
head(id(266),a10(527)).
head(id(267),age3(527)).
head(id(268),asian(527)).
head(id(269),self(527)).
head(id(270),a1(110)).
head(id(271),a6(110)).
head(id(272),a7(110)).
head(id(273),age1(110)).
head(id(274),female(110)).
head(id(275),asian(110)).
head(id(276),parent(110)).
head(id(277),a1(342)).
head(id(278),a2(342)).
head(id(279),a3(342)).
head(id(280),a4(342)).
head(id(281),a5(342)).
head(id(282),a8(342)).
head(id(283),age1(342)).
head(id(284),a1(306)).
head(id(285),a2(306)).
head(id(286),a4(306)).
head(id(287),a10(306)).
head(id(288),age3(306)).
head(id(289),female(306)).
head(id(290),white(306)).
head(id(291),self(306)).
head(id(292),a3(581)).
head(id(293),a4(581)).
head(id(294),age4(581)).
head(id(295),black(581)).
head(id(296),self(581)).
head(id(297),a1(617)).
head(id(298),a5(617)).
head(id(299),a7(617)).
head(id(300),age2(617)).
head(id(301),southasian(617)).
head(id(302),self(617)).
head(id(303),a1(676)).
head(id(304),a2(676)).
head(id(305),a3(676)).
head(id(306),a4(676)).
head(id(307),a9(676)).
head(id(308),age2(676)).
head(id(309),female(676)).
head(id(310),white(676)).
head(id(311),jaundice(676)).
head(id(312),self(676)).
head(id(313),a1(157)).
head(id(314),a6(157)).
head(id(315),a8(157)).
head(id(316),a10(157)).
head(id(317),age2(157)).
head(id(318),female(157)).
head(id(319),asian(157)).
head(id(320),self(157)).
head(id(321),a2(44)).
head(id(322),a3(44)).
head(id(323),a4(44)).
head(id(324),a10(44)).
head(id(325),age3(44)).
head(id(326),female(44)).
head(id(327),white(44)).
head(id(328),jaundice(44)).
head(id(329),pdd(44)).
head(id(330),self(44)).
head(id(331),a1(131)).
head(id(332),a2(131)).
head(id(333),a8(131)).
head(id(334),age1(131)).
head(id(335),female(131)).
head(id(336),white(131)).
head(id(337),self(131)).
head(id(338),a1(259)).
head(id(339),a5(259)).
head(id(340),a6(259)).
head(id(341),a8(259)).
head(id(342),a10(259)).
head(id(343),age2(259)).
head(id(344),asian(259)).
head(id(345),self(259)).
head(id(346),a8(470)).
head(id(347),age2(470)).
head(id(348),female(470)).
head(id(349),asian(470)).
head(id(350),jaundice(470)).
head(id(351),self(470)).
head(id(352),a2(489)).
head(id(353),a3(489)).
head(id(354),a7(489)).
head(id(355),a10(489)).
head(id(356),age1(489)).
head(id(357),black(489)).
head(id(358),self(489)).
head(id(359),a1(9)).
head(id(360),a2(9)).
head(id(361),a5(9)).
head(id(362),a8(9)).
head(id(363),a9(9)).
head(id(364),a10(9)).
head(id(365),age2(9)).
head(id(366),white(9)).
head(id(367),self(9)).
head(id(1515,A),autism(A)) :- dom(A).
body(id(1515,A),alpha_1(A)) :- dom(A).
body(id(1515,A),a1(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).

dom(9).
dom(44).
dom(64).
dom(88).
dom(110).
dom(124).
dom(131).
dom(132).
dom(133).
dom(157).
dom(189).
dom(203).
dom(205).
dom(224).
dom(259).
dom(267).
dom(286).
dom(294).
dom(295).
dom(304).
dom(306).
dom(321).
dom(342).
dom(434).
dom(449).
dom(470).
dom(472).
dom(489).
dom(494).
dom(521).
dom(527).
dom(529).
dom(545).
dom(581).
dom(600).
dom(608).
dom(617).
dom(638).
dom(654).
dom(676).
dom(693).
 :- not supported(autism(434)).
 :- not supported(autism(529)).
 :- not supported(autism(124)).
 :- not supported(autism(521)).
 :- not supported(autism(654)).
 :- not supported(autism(203)).
 :- not supported(autism(224)).
 :- not supported(autism(189)).
 :- not supported(autism(693)).
 :- not supported(autism(472)).
 :- not supported(autism(545)).
 :- not supported(autism(494)).
 :- not supported(autism(638)).
 :- not supported(autism(449)).
 :- supported(autism(304)).
 :- supported(autism(608)).
 :- supported(autism(64)).
 :- supported(autism(294)).
 :- supported(autism(132)).
 :- supported(autism(600)).
 :- supported(autism(295)).
 :- supported(autism(133)).
 :- supported(autism(88)).
 :- supported(autism(205)).
 :- supported(autism(267)).
 :- supported(autism(321)).
 :- supported(autism(286)).
 :- supported(autism(527)).
 :- supported(autism(110)).
 :- supported(autism(342)).
 :- supported(autism(306)).
 :- supported(autism(581)).
 :- supported(autism(617)).
 :- supported(autism(676)).
 :- supported(autism(157)).
 :- supported(autism(44)).
 :- supported(autism(131)).
 :- supported(autism(259)).
 :- supported(autism(470)).
 :- supported(autism(489)).
 :- supported(autism(9)).
