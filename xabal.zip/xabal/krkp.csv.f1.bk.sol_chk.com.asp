head(id(1),a11(78)).
head(id(2),a13(78)).
head(id(3),n(78)).
head(id(4),a24(78)).
head(id(5),a26(78)).
head(id(6),a31(78)).
head(id(7),a35(78)).
head(id(8),a5(392)).
head(id(9),a6(392)).
head(id(10),n(392)).
head(id(11),a18(392)).
head(id(12),a26(392)).
head(id(13),a34(392)).
head(id(14),a35(392)).
head(id(15),a12(521)).
head(id(16),a13(521)).
head(id(17),n(521)).
head(id(18),a18(521)).
head(id(19),a26(521)).
head(id(20),a34(521)).
head(id(21),a35(521)).
head(id(22),a6(239)).
head(id(23),a11(239)).
head(id(24),a13(239)).
head(id(25),w(239)).
head(id(26),a24(239)).
head(id(27),a26(239)).
head(id(28),a31(239)).
head(id(29),a35(239)).
head(id(30),a6(551)).
head(id(31),a12(551)).
head(id(32),n(551)).
head(id(33),a18(551)).
head(id(34),a26(551)).
head(id(35),a34(551)).
head(id(36),a35(551)).
head(id(37),a7(107)).
head(id(38),a8(107)).
head(id(39),a9(107)).
head(id(40),a11(107)).
head(id(41),a13(107)).
head(id(42),w(107)).
head(id(43),a18(107)).
head(id(44),a20(107)).
head(id(45),a26(107)).
head(id(46),a34(107)).
head(id(47),a35(107)).
head(id(48),a6(577)).
head(id(49),a7(577)).
head(id(50),a13(577)).
head(id(51),n(577)).
head(id(52),a18(577)).
head(id(53),a26(577)).
head(id(54),a35(577)).
head(id(55),a36(577)).
head(id(56),a1(264)).
head(id(57),a6(264)).
head(id(58),a11(264)).
head(id(59),a13(264)).
head(id(60),n(264)).
head(id(61),a18(264)).
head(id(62),a23(264)).
head(id(63),a26(264)).
head(id(64),a31(264)).
head(id(65),a34(264)).
head(id(66),a35(264)).
head(id(67),a13(270)).
head(id(68),n(270)).
head(id(69),a18(270)).
head(id(70),a24(270)).
head(id(71),a34(270)).
head(id(72),a35(270)).
head(id(73),a12(686)).
head(id(74),a13(686)).
head(id(75),n(686)).
head(id(76),a18(686)).
head(id(77),a26(686)).
head(id(78),a34(686)).
head(id(79),a35(686)).
head(id(80),a36(686)).
head(id(81),a5(312)).
head(id(82),a6(312)).
head(id(83),a9(312)).
head(id(84),a13(312)).
head(id(85),n(312)).
head(id(86),a18(312)).
head(id(87),a22(312)).
head(id(88),a34(312)).
head(id(89),a35(312)).
head(id(90),a5(669)).
head(id(91),n(669)).
head(id(92),a18(669)).
head(id(93),a34(669)).
head(id(94),a35(669)).
head(id(95),a36(669)).
head(id(96),a6(458)).
head(id(97),a7(458)).
head(id(98),a8(458)).
head(id(99),a9(458)).
head(id(100),n(458)).
head(id(101),a18(458)).
head(id(102),a26(458)).
head(id(103),a34(458)).
head(id(104),a35(458)).
head(id(105),a10(880)).
head(id(106),a13(880)).
head(id(107),n(880)).
head(id(108),a21(880)).
head(id(109),a26(880)).
head(id(110),a34(880)).
head(id(111),a35(880)).
head(id(112),a36(880)).
head(id(113),a1(196)).
head(id(114),a6(196)).
head(id(115),a7(196)).
head(id(116),a11(196)).
head(id(117),a13(196)).
head(id(118),b(196)).
head(id(119),a18(196)).
head(id(120),a26(196)).
head(id(121),a34(196)).
head(id(122),a35(196)).
head(id(123),a11(99)).
head(id(124),a13(99)).
head(id(125),w(99)).
head(id(126),a24(99)).
head(id(127),a26(99)).
head(id(128),a34(99)).
head(id(129),a5(427)).
head(id(130),a6(427)).
head(id(131),a7(427)).
head(id(132),a11(427)).
head(id(133),n(427)).
head(id(134),a18(427)).
head(id(135),a24(427)).
head(id(136),a26(427)).
head(id(137),a34(427)).
head(id(138),a35(427)).
head(id(139),a4(408)).
head(id(140),a6(408)).
head(id(141),n(408)).
head(id(142),a18(408)).
head(id(143),a24(408)).
head(id(144),a26(408)).
head(id(145),a35(408)).
head(id(146),a10(852)).
head(id(147),a11(852)).
head(id(148),n(852)).
head(id(149),a18(852)).
head(id(150),a21(852)).
head(id(151),a26(852)).
head(id(152),a33(852)).
head(id(153),a34(852)).
head(id(154),a35(852)).
head(id(155),a5(623)).
head(id(156),a6(623)).
head(id(157),a13(623)).
head(id(158),n(623)).
head(id(159),a18(623)).
head(id(160),a33(623)).
head(id(161),a35(623)).
head(id(162),a36(623)).
head(id(163),a13(298)).
head(id(164),n(298)).
head(id(165),a17(298)).
head(id(166),a18(298)).
head(id(167),a23(298)).
head(id(168),a34(298)).
head(id(169),a35(298)).
head(id(170),a6(582)).
head(id(171),a13(582)).
head(id(172),n(582)).
head(id(173),a26(582)).
head(id(174),a33(582)).
head(id(175),a35(582)).
head(id(176),a36(582)).
head(id(177),a6(257)).
head(id(178),a7(257)).
head(id(179),a8(257)).
head(id(180),a9(257)).
head(id(181),a11(257)).
head(id(182),a13(257)).
head(id(183),n(257)).
head(id(184),a18(257)).
head(id(185),a22(257)).
head(id(186),a26(257)).
head(id(187),a34(257)).
head(id(188),a6(689)).
head(id(189),a12(689)).
head(id(190),a13(689)).
head(id(191),n(689)).
head(id(192),a18(689)).
head(id(193),a26(689)).
head(id(194),a34(689)).
head(id(195),a35(689)).
head(id(196),a36(689)).
head(id(197),a7(109)).
head(id(198),a8(109)).
head(id(199),a9(109)).
head(id(200),a11(109)).
head(id(201),a13(109)).
head(id(202),w(109)).
head(id(203),a18(109)).
head(id(204),a22(109)).
head(id(205),a26(109)).
head(id(206),a34(109)).
head(id(207),a35(109)).
head(id(208),a12(793)).
head(id(209),n(793)).
head(id(210),a18(793)).
head(id(211),a21(793)).
head(id(212),a33(793)).
head(id(213),a34(793)).
head(id(214),a35(793)).
head(id(215),a5(484)).
head(id(216),a7(484)).
head(id(217),n(484)).
head(id(218),a18(484)).
head(id(219),a24(484)).
head(id(220),a34(484)).
head(id(221),a35(484)).
head(id(222),a5(399)).
head(id(223),a6(399)).
head(id(224),n(399)).
head(id(225),a18(399)).
head(id(226),a26(399)).
head(id(227),a33(399)).
head(id(228),a35(399)).
head(id(229),a5(262)).
head(id(230),a6(262)).
head(id(231),a7(262)).
head(id(232),a8(262)).
head(id(233),a9(262)).
head(id(234),a13(262)).
head(id(235),n(262)).
head(id(236),a26(262)).
head(id(237),a35(262)).
head(id(238),a4(416)).
head(id(239),a6(416)).
head(id(240),a11(416)).
head(id(241),n(416)).
head(id(242),a18(416)).
head(id(243),a26(416)).
head(id(244),a35(416)).
head(id(245),a6(724)).
head(id(246),a13(724)).
head(id(247),n(724)).
head(id(248),a21(724)).
head(id(249),a24(724)).
head(id(250),a26(724)).
head(id(251),a35(724)).
head(id(252),a13(278)).
head(id(253),n(278)).
head(id(254),a35(278)).
head(id(255),a6(884)).
head(id(256),a10(884)).
head(id(257),a13(884)).
head(id(258),n(884)).
head(id(259),a21(884)).
head(id(260),a26(884)).
head(id(261),a34(884)).
head(id(262),a35(884)).
head(id(263),a36(884)).
head(id(264),a6(897)).
head(id(265),a10(897)).
head(id(266),a13(897)).
head(id(267),n(897)).
head(id(268),a18(897)).
head(id(269),a21(897)).
head(id(270),a24(897)).
head(id(271),a34(897)).
head(id(272),a35(897)).
head(id(273),a36(897)).
head(id(274),a11(89)).
head(id(275),a13(89)).
head(id(276),w(89)).
head(id(277),a24(89)).
head(id(278),a26(89)).
head(id(279),a34(89)).
head(id(280),a35(89)).
head(id(281),a5(837)).
head(id(282),a10(837)).
head(id(283),a11(837)).
head(id(284),a13(837)).
head(id(285),n(837)).
head(id(286),a20(837)).
head(id(287),a21(837)).
head(id(288),a26(837)).
head(id(289),a34(837)).
head(id(290),a35(837)).
head(id(291),a13(560)).
head(id(292),n(560)).
head(id(293),a18(560)).
head(id(294),a26(560)).
head(id(295),a34(560)).
head(id(296),a35(560)).
head(id(297),a36(560)).
head(id(298),a6(743)).
head(id(299),a13(743)).
head(id(300),n(743)).
head(id(301),a18(743)).
head(id(302),a21(743)).
head(id(303),a33(743)).
head(id(304),a34(743)).
head(id(305),a35(743)).
head(id(306),a11(24)).
head(id(307),a13(24)).
head(id(308),w(24)).
head(id(309),a18(24)).
head(id(310),a26(24)).
head(id(311),a31(24)).
head(id(312),a34(24)).
head(id(313),a35(24)).
head(id(314),a13(613)).
head(id(315),n(613)).
head(id(316),a24(613)).
head(id(317),a33(613)).
head(id(318),a35(613)).
head(id(319),a36(613)).
head(id(320),a5(640)).
head(id(321),a6(640)).
head(id(322),a7(640)).
head(id(323),a13(640)).
head(id(324),n(640)).
head(id(325),a24(640)).
head(id(326),a35(640)).
head(id(327),a36(640)).
head(id(328),a4(457)).
head(id(329),a6(457)).
head(id(330),a11(457)).
head(id(331),n(457)).
head(id(332),a24(457)).
head(id(333),a26(457)).
head(id(334),a35(457)).
head(id(335),a7(370)).
head(id(336),a9(370)).
head(id(337),a11(370)).
head(id(338),n(370)).
head(id(339),a18(370)).
head(id(340),a22(370)).
head(id(341),a24(370)).
head(id(342),a26(370)).
head(id(343),a34(370)).
head(id(344),a35(370)).
head(id(345),a4(137)).
head(id(346),a6(137)).
head(id(347),a11(137)).
head(id(348),a13(137)).
head(id(349),n(137)).
head(id(350),a18(137)).
head(id(351),a26(137)).
head(id(352),a31(137)).
head(id(353),a34(137)).
head(id(354),a35(137)).
head(id(355),a5(482)).
head(id(356),n(482)).
head(id(357),a18(482)).
head(id(358),a24(482)).
head(id(359),a34(482)).
head(id(360),a35(482)).
head(id(361),a13(65)).
head(id(362),n(65)).
head(id(363),a24(65)).
head(id(364),a26(65)).
head(id(365),a35(65)).
head(id(366),a13(740)).
head(id(367),n(740)).
head(id(368),a21(740)).
head(id(369),a24(740)).
head(id(370),a33(740)).
head(id(371),a35(740)).
head(id(372),a7(387)).
head(id(373),a8(387)).
head(id(374),a9(387)).
head(id(375),a11(387)).
head(id(376),n(387)).
head(id(377),a18(387)).
head(id(378),a22(387)).
head(id(379),a24(387)).
head(id(380),a26(387)).
head(id(381),a34(387)).
head(id(382),a35(387)).
head(id(383),n(350)).
head(id(384),a18(350)).
head(id(385),a24(350)).
head(id(386),a26(350)).
head(id(387),a34(350)).
head(id(388),a35(350)).
head(id(389),a6(584)).
head(id(390),a13(584)).
head(id(391),n(584)).
head(id(392),a24(584)).
head(id(393),a26(584)).
head(id(394),a34(584)).
head(id(395),a35(584)).
head(id(396),a36(584)).
head(id(397),a10(836)).
head(id(398),a11(836)).
head(id(399),a13(836)).
head(id(400),n(836)).
head(id(401),a20(836)).
head(id(402),a21(836)).
head(id(403),a26(836)).
head(id(404),a34(836)).
head(id(405),a35(836)).
head(id(406),a6(882)).
head(id(407),a10(882)).
head(id(408),a13(882)).
head(id(409),n(882)).
head(id(410),a18(882)).
head(id(411),a21(882)).
head(id(412),a26(882)).
head(id(413),a34(882)).
head(id(414),a35(882)).
head(id(415),a36(882)).
head(id(416),a6(437)).
head(id(417),a7(437)).
head(id(418),a11(437)).
head(id(419),n(437)).
head(id(420),a18(437)).
head(id(421),a24(437)).
head(id(422),a26(437)).
head(id(423),a34(437)).
head(id(424),a6(840)).
head(id(425),a10(840)).
head(id(426),a13(840)).
head(id(427),n(840)).
head(id(428),a18(840)).
head(id(429),a21(840)).
head(id(430),a24(840)).
head(id(431),a26(840)).
head(id(432),a34(840)).
head(id(433),a35(840)).
head(id(434),a4(495)).
head(id(435),a6(495)).
head(id(436),n(495)).
head(id(437),a18(495)).
head(id(438),a35(495)).
head(id(439),a4(839)).
head(id(440),a5(839)).
head(id(441),a6(839)).
head(id(442),a10(839)).
head(id(443),a13(839)).
head(id(444),n(839)).
head(id(445),a18(839)).
head(id(446),a21(839)).
head(id(447),a26(839)).
head(id(448),a34(839)).
head(id(449),a35(839)).
head(id(450),a6(224)).
head(id(451),a7(224)).
head(id(452),a11(224)).
head(id(453),a13(224)).
head(id(454),n(224)).
head(id(455),a24(224)).
head(id(456),a26(224)).
head(id(457),a35(224)).
head(id(458),a11(31)).
head(id(459),a13(31)).
head(id(460),w(31)).
head(id(461),a18(31)).
head(id(462),a20(31)).
head(id(463),a24(31)).
head(id(464),a26(31)).
head(id(465),a31(31)).
head(id(466),a34(31)).
head(id(467),a35(31)).
head(id(468),a6(791)).
head(id(469),a12(791)).
head(id(470),n(791)).
head(id(471),a18(791)).
head(id(472),a21(791)).
head(id(473),a26(791)).
head(id(474),a33(791)).
head(id(475),a34(791)).
head(id(476),a35(791)).
head(id(477),a5(242)).
head(id(478),a6(242)).
head(id(479),a7(242)).
head(id(480),a11(242)).
head(id(481),a13(242)).
head(id(482),w(242)).
head(id(483),a24(242)).
head(id(484),a26(242)).
head(id(485),a35(242)).
head(id(486),a2(302)).
head(id(487),a4(302)).
head(id(488),a6(302)).
head(id(489),a13(302)).
head(id(490),n(302)).
head(id(491),a18(302)).
head(id(492),a35(302)).
head(id(493),a1(192)).
head(id(494),a5(192)).
head(id(495),a6(192)).
head(id(496),a11(192)).
head(id(497),a13(192)).
head(id(498),b(192)).
head(id(499),a18(192)).
head(id(500),a26(192)).
head(id(501),a35(192)).
head(id(502),a7(93)).
head(id(503),a9(93)).
head(id(504),a11(93)).
head(id(505),a13(93)).
head(id(506),w(93)).
head(id(507),a22(93)).
head(id(508),a24(93)).
head(id(509),a26(93)).
head(id(510),a34(93)).
head(id(511),a35(93)).
head(id(512),a5(430)).
head(id(513),a6(430)).
head(id(514),a7(430)).
head(id(515),a9(430)).
head(id(516),a11(430)).
head(id(517),n(430)).
head(id(518),a18(430)).
head(id(519),a22(430)).
head(id(520),a24(430)).
head(id(521),a26(430)).
head(id(522),a34(430)).
head(id(523),a35(430)).
head(id(524),a6(461)).
head(id(525),a7(461)).
head(id(526),a8(461)).
head(id(527),a9(461)).
head(id(528),n(461)).
head(id(529),a18(461)).
head(id(530),a22(461)).
head(id(531),a26(461)).
head(id(532),a34(461)).
head(id(533),a35(461)).
head(id(534),a6(311)).
head(id(535),a9(311)).
head(id(536),a13(311)).
head(id(537),n(311)).
head(id(538),a18(311)).
head(id(539),a22(311)).
head(id(540),a35(311)).
head(id(541),a5(861)).
head(id(542),a6(861)).
head(id(543),a10(861)).
head(id(544),a11(861)).
head(id(545),n(861)).
head(id(546),a18(861)).
head(id(547),a21(861)).
head(id(548),a26(861)).
head(id(549),a34(861)).
head(id(550),a35(861)).
head(id(551),a6(717)).
head(id(552),a13(717)).
head(id(553),n(717)).
head(id(554),a18(717)).
head(id(555),a21(717)).
head(id(556),a26(717)).
head(id(557),a33(717)).
head(id(558),a34(717)).
head(id(559),a35(717)).
head(id(560),a5(22)).
head(id(561),a9(22)).
head(id(562),a11(22)).
head(id(563),a13(22)).
head(id(564),n(22)).
head(id(565),a18(22)).
head(id(566),a22(22)).
head(id(567),a24(22)).
head(id(568),a26(22)).
head(id(569),a31(22)).
head(id(570),a34(22)).
head(id(571),a35(22)).
head(id(572),a1(58)).
head(id(573),a11(58)).
head(id(574),a13(58)).
head(id(575),b(58)).
head(id(576),a18(58)).
head(id(577),a24(58)).
head(id(578),a26(58)).
head(id(579),a34(58)).
head(id(580),a4(657)).
head(id(581),a6(657)).
head(id(582),n(657)).
head(id(583),a18(657)).
head(id(584),a26(657)).
head(id(585),a35(657)).
head(id(586),a36(657)).
head(id(587),a6(116)).
head(id(588),a13(116)).
head(id(589),n(116)).
head(id(590),a18(116)).
head(id(591),a26(116)).
head(id(592),a34(116)).
head(id(593),a35(116)).
head(id(594),a5(491)).
head(id(595),a7(491)).
head(id(596),a8(491)).
head(id(597),a9(491)).
head(id(598),n(491)).
head(id(599),a18(491)).
head(id(600),a34(491)).
head(id(601),a35(491)).
head(id(602),a1(53)).
head(id(603),a11(53)).
head(id(604),a13(53)).
head(id(605),w(53)).
head(id(606),a18(53)).
head(id(607),a24(53)).
head(id(608),a26(53)).
head(id(609),a34(53)).
head(id(610),a35(53)).
head(id(611),a5(440)).
head(id(612),a6(440)).
head(id(613),a11(440)).
head(id(614),b(440)).
head(id(615),a18(440)).
head(id(616),a26(440)).
head(id(617),a34(440)).
head(id(618),a35(440)).
head(id(619),a5(869)).
head(id(620),a10(869)).
head(id(621),n(869)).
head(id(622),a18(869)).
head(id(623),a21(869)).
head(id(624),a24(869)).
head(id(625),a34(869)).
head(id(626),a35(869)).
head(id(627),a1(371)).
head(id(628),a11(371)).
head(id(629),n(371)).
head(id(630),a18(371)).
head(id(631),a26(371)).
head(id(632),a34(371)).
head(id(633),a35(371)).
head(id(634),a6(471)).
head(id(635),n(471)).
head(id(636),a18(471)).
head(id(637),a23(471)).
head(id(638),a24(471)).
head(id(639),a26(471)).
head(id(640),a34(471)).
head(id(641),a35(471)).
head(id(642),a6(685)).
head(id(643),a9(685)).
head(id(644),n(685)).
head(id(645),a18(685)).
head(id(646),a22(685)).
head(id(647),a24(685)).
head(id(648),a34(685)).
head(id(649),a35(685)).
head(id(650),a36(685)).
head(id(651),a13(730)).
head(id(652),n(730)).
head(id(653),a18(730)).
head(id(654),a21(730)).
head(id(655),a24(730)).
head(id(656),a33(730)).
head(id(657),a34(730)).
head(id(658),a35(730)).
head(id(659),a6(592)).
head(id(660),a7(592)).
head(id(661),a8(592)).
head(id(662),a9(592)).
head(id(663),a13(592)).
head(id(664),n(592)).
head(id(665),a18(592)).
head(id(666),a26(592)).
head(id(667),a35(592)).
head(id(668),a36(592)).
head(id(669),a5(363)).
head(id(670),a9(363)).
head(id(671),a11(363)).
head(id(672),n(363)).
head(id(673),a18(363)).
head(id(674),a22(363)).
head(id(675),a26(363)).
head(id(676),a34(363)).
head(id(677),a35(363)).
head(id(678),a1(55)).
head(id(679),a7(55)).
head(id(680),a11(55)).
head(id(681),a13(55)).
head(id(682),w(55)).
head(id(683),a18(55)).
head(id(684),a24(55)).
head(id(685),a26(55)).
head(id(686),a34(55)).
head(id(687),a35(55)).
head(id(688),a6(230)).
head(id(689),a11(230)).
head(id(690),a13(230)).
head(id(691),n(230)).
head(id(692),a26(230)).
head(id(693),a31(230)).
head(id(694),a33(230)).
head(id(695),a6(325)).
head(id(696),a13(325)).
head(id(697),n(325)).
head(id(698),a35(325)).
head(id(699),a12(694)).
head(id(700),a13(694)).
head(id(701),n(694)).
head(id(702),a18(694)).
head(id(703),a24(694)).
head(id(704),a34(694)).
head(id(705),a35(694)).
head(id(706),a36(694)).
head(id(707),a5(646)).
head(id(708),n(646)).
head(id(709),a18(646)).
head(id(710),a26(646)).
head(id(711),a27(646)).
head(id(712),a34(646)).
head(id(713),a35(646)).
head(id(714),a36(646)).
head(id(715),a6(883)).
head(id(716),a10(883)).
head(id(717),a13(883)).
head(id(718),n(883)).
head(id(719),a18(883)).
head(id(720),a21(883)).
head(id(721),a24(883)).
head(id(722),a26(883)).
head(id(723),a34(883)).
head(id(724),a35(883)).
head(id(725),a36(883)).
head(id(726),n(650)).
head(id(727),a26(650)).
head(id(728),a35(650)).
head(id(729),a36(650)).
head(id(730),a6(873)).
head(id(731),a10(873)).
head(id(732),n(873)).
head(id(733),a18(873)).
head(id(734),a21(873)).
head(id(735),a24(873)).
head(id(736),a34(873)).
head(id(737),a35(873)).
head(id(738),a5(645)).
head(id(739),n(645)).
head(id(740),a18(645)).
head(id(741),a26(645)).
head(id(742),a34(645)).
head(id(743),a35(645)).
head(id(744),a36(645)).
head(id(745),a6(244)).
head(id(746),a7(244)).
head(id(747),a11(244)).
head(id(748),a13(244)).
head(id(749),w(244)).
head(id(750),a24(244)).
head(id(751),a26(244)).
head(id(752),a34(244)).
head(id(753),a5(295)).
head(id(754),a7(295)).
head(id(755),a8(295)).
head(id(756),a9(295)).
head(id(757),a13(295)).
head(id(758),n(295)).
head(id(759),a18(295)).
head(id(760),a22(295)).
head(id(761),a34(295)).
head(id(762),a35(295)).
head(id(763),a6(795)).
head(id(764),a12(795)).
head(id(765),n(795)).
head(id(766),a18(795)).
head(id(767),a21(795)).
head(id(768),a33(795)).
head(id(769),a34(795)).
head(id(770),a35(795)).
head(id(771),a13(569)).
head(id(772),n(569)).
head(id(773),a24(569)).
head(id(774),a26(569)).
head(id(775),a34(569)).
head(id(776),a35(569)).
head(id(777),a36(569)).
head(id(778),a6(149)).
head(id(779),a7(149)).
head(id(780),a11(149)).
head(id(781),a13(149)).
head(id(782),n(149)).
head(id(783),a18(149)).
head(id(784),a20(149)).
head(id(785),a24(149)).
head(id(786),a26(149)).
head(id(787),a31(149)).
head(id(788),a34(149)).
head(id(789),a35(149)).
head(id(790),a13(796)).
head(id(791),n(796)).
head(id(792),a18(796)).
head(id(793),a21(796)).
head(id(794),a26(796)).
head(id(795),a34(796)).
head(id(796),a35(796)).
head(id(797),a36(796)).
head(id(798),a5(433)).
head(id(799),a6(433)).
head(id(800),a7(433)).
head(id(801),a11(433)).
head(id(802),n(433)).
head(id(803),a18(433)).
head(id(804),a26(433)).
head(id(805),a34(433)).
head(id(806),a6(152)).
head(id(807),a11(152)).
head(id(808),a13(152)).
head(id(809),n(152)).
head(id(810),a18(152)).
head(id(811),a26(152)).
head(id(812),a31(152)).
head(id(813),a34(152)).
head(id(814),a5(36)).
head(id(815),a7(36)).
head(id(816),a11(36)).
head(id(817),a13(36)).
head(id(818),w(36)).
head(id(819),a18(36)).
head(id(820),a26(36)).
head(id(821),a34(36)).
head(id(822),a5(361)).
head(id(823),a7(361)).
head(id(824),a11(361)).
head(id(825),n(361)).
head(id(826),a18(361)).
head(id(827),a26(361)).
head(id(828),a34(361)).
head(id(829),a35(361)).
head(id(830),a6(678)).
head(id(831),n(678)).
head(id(832),a18(678)).
head(id(833),a34(678)).
head(id(834),a35(678)).
head(id(835),a36(678)).
head(id(836),a5(308)).
head(id(837),a6(308)).
head(id(838),a7(308)).
head(id(839),a13(308)).
head(id(840),n(308)).
head(id(841),a18(308)).
head(id(842),a35(308)).
head(id(843),a5(397)).
head(id(844),a6(397)).
head(id(845),a7(397)).
head(id(846),n(397)).
head(id(847),a18(397)).
head(id(848),a26(397)).
head(id(849),a34(397)).
head(id(850),a35(397)).
head(id(851),a6(866)).
head(id(852),a10(866)).
head(id(853),n(866)).
head(id(854),a18(866)).
head(id(855),a21(866)).
head(id(856),a23(866)).
head(id(857),a26(866)).
head(id(858),a34(866)).
head(id(859),a35(866)).
head(id(860),a4(254)).
head(id(861),a6(254)).
head(id(862),a7(254)).
head(id(863),a8(254)).
head(id(864),a9(254)).
head(id(865),a11(254)).
head(id(866),a13(254)).
head(id(867),n(254)).
head(id(868),a18(254)).
head(id(869),a26(254)).
head(id(870),a35(254)).
head(id(871),a5(279)).
head(id(872),a13(279)).
head(id(873),n(279)).
head(id(874),a34(279)).
head(id(875),a35(279)).
head(id(876),a9(600)).
head(id(877),a13(600)).
head(id(878),n(600)).
head(id(879),a18(600)).
head(id(880),a22(600)).
head(id(881),a34(600)).
head(id(882),a35(600)).
head(id(883),a36(600)).
head(id(884),a6(662)).
head(id(885),a7(662)).
head(id(886),n(662)).
head(id(887),a18(662)).
head(id(888),a24(662)).
head(id(889),a26(662)).
head(id(890),a34(662)).
head(id(891),a35(662)).
head(id(892),a36(662)).
head(id(893),a2(586)).
head(id(894),a6(586)).
head(id(895),a13(586)).
head(id(896),n(586)).
head(id(897),a24(586)).
head(id(898),a26(586)).
head(id(899),a35(586)).
head(id(900),a36(586)).
head(id(901),a6(472)).
head(id(902),a11(472)).
head(id(903),n(472)).
head(id(904),a18(472)).
head(id(905),a23(472)).
head(id(906),a26(472)).
head(id(907),a34(472)).
head(id(908),a35(472)).
head(id(909),a6(824)).
head(id(910),a13(824)).
head(id(911),n(824)).
head(id(912),a18(824)).
head(id(913),a21(824)).
head(id(914),a24(824)).
head(id(915),a34(824)).
head(id(916),a35(824)).
head(id(917),a36(824)).
head(id(918),a5(347)).
head(id(919),a7(347)).
head(id(920),n(347)).
head(id(921),a18(347)).
head(id(922),a26(347)).
head(id(923),a34(347)).
head(id(924),a35(347)).
head(id(925),a13(59)).
head(id(926),n(59)).
head(id(927),a26(59)).
head(id(928),a34(59)).
head(id(929),a35(59)).
head(id(930),a6(411)).
head(id(931),n(411)).
head(id(932),a18(411)).
head(id(933),a24(411)).
head(id(934),a26(411)).
head(id(935),a33(411)).
head(id(936),a35(411)).
head(id(937),a3(508)).
head(id(938),a6(508)).
head(id(939),n(508)).
head(id(940),a18(508)).
head(id(941),a24(508)).
head(id(942),a35(508)).
head(id(943),a6(658)).
head(id(944),a7(658)).
head(id(945),n(658)).
head(id(946),a18(658)).
head(id(947),a26(658)).
head(id(948),a34(658)).
head(id(949),a35(658)).
head(id(950),a36(658)).
head(id(951),a1(373)).
head(id(952),a11(373)).
head(id(953),n(373)).
head(id(954),a18(373)).
head(id(955),a24(373)).
head(id(956),a26(373)).
head(id(957),a30(373)).
head(id(958),a34(373)).
head(id(959),a35(373)).
head(id(960),a5(177)).
head(id(961),a6(177)).
head(id(962),a7(177)).
head(id(963),a11(177)).
head(id(964),a13(177)).
head(id(965),w(177)).
head(id(966),a18(177)).
head(id(967),a26(177)).
head(id(968),a34(177)).
head(id(969),a6(691)).
head(id(970),a12(691)).
head(id(971),a13(691)).
head(id(972),n(691)).
head(id(973),a24(691)).
head(id(974),a26(691)).
head(id(975),a35(691)).
head(id(976),a36(691)).
head(id(977),a6(617)).
head(id(978),a13(617)).
head(id(979),n(617)).
head(id(980),a18(617)).
head(id(981),a35(617)).
head(id(982),a36(617)).
head(id(983),a5(168)).
head(id(984),a6(168)).
head(id(985),a7(168)).
head(id(986),a11(168)).
head(id(987),a13(168)).
head(id(988),w(168)).
head(id(989),a18(168)).
head(id(990),a26(168)).
head(id(991),a34(168)).
head(id(992),a35(168)).
head(id(993),a1(186)).
head(id(994),a6(186)).
head(id(995),a11(186)).
head(id(996),a13(186)).
head(id(997),n(186)).
head(id(998),a18(186)).
head(id(999),a24(186)).
head(id(1000),a26(186)).
head(id(1001),a31(186)).
head(id(1002),a34(186)).
head(id(1003),a35(186)).
head(id(1004),a6(895)).
head(id(1005),a10(895)).
head(id(1006),a13(895)).
head(id(1007),n(895)).
head(id(1008),a18(895)).
head(id(1009),a21(895)).
head(id(1010),a33(895)).
head(id(1011),a34(895)).
head(id(1012),a35(895)).
head(id(1013),a36(895)).
head(id(1014),a6(163)).
head(id(1015),a11(163)).
head(id(1016),a13(163)).
head(id(1017),w(163)).
head(id(1018),a18(163)).
head(id(1019),a26(163)).
head(id(1020),a31(163)).
head(id(1021),a34(163)).
head(id(1022),a35(163)).
head(id(1023),a13(704)).
head(id(1024),n(704)).
head(id(1025),a18(704)).
head(id(1026),a21(704)).
head(id(1027),a26(704)).
head(id(1028),a33(704)).
head(id(1029),a34(704)).
head(id(1030),a35(704)).
head(id(1031),a5(463)).
head(id(1032),a6(463)).
head(id(1033),a7(463)).
head(id(1034),a8(463)).
head(id(1035),a9(463)).
head(id(1036),n(463)).
head(id(1037),a18(463)).
head(id(1038),a24(463)).
head(id(1039),a26(463)).
head(id(1040),a34(463)).
head(id(1041),a35(463)).
head(id(1042),a5(454)).
head(id(1043),a6(454)).
head(id(1044),n(454)).
head(id(1045),a24(454)).
head(id(1046),a26(454)).
head(id(1047),a35(454)).
head(id(1048),a6(432)).
head(id(1049),a7(432)).
head(id(1050),a11(432)).
head(id(1051),n(432)).
head(id(1052),a18(432)).
head(id(1053),a26(432)).
head(id(1054),a34(432)).
head(id(1055),a9(671)).
head(id(1056),n(671)).
head(id(1057),a18(671)).
head(id(1058),a22(671)).
head(id(1059),a34(671)).
head(id(1060),a35(671)).
head(id(1061),a36(671)).
head(id(1062),a10(847)).
head(id(1063),n(847)).
head(id(1064),a18(847)).
head(id(1065),a21(847)).
head(id(1066),a26(847)).
head(id(1067),a34(847)).
head(id(1068),a35(847)).
head(id(1069),a6(860)).
head(id(1070),a10(860)).
head(id(1071),a11(860)).
head(id(1072),n(860)).
head(id(1073),a18(860)).
head(id(1074),a21(860)).
head(id(1075),a26(860)).
head(id(1076),a34(860)).
head(id(1077),a35(860)).
head(id(1078),a4(336)).
head(id(1079),a5(336)).
head(id(1080),a6(336)).
head(id(1081),a13(336)).
head(id(1082),n(336)).
head(id(1083),a24(336)).
head(id(1084),a35(336)).
head(id(1085),a5(111)).
head(id(1086),a7(111)).
head(id(1087),a8(111)).
head(id(1088),a9(111)).
head(id(1089),a13(111)).
head(id(1090),n(111)).
head(id(1091),a24(111)).
head(id(1092),a26(111)).
head(id(1093),a34(111)).
head(id(1094),a35(111)).
head(id(1095),a5(266)).
head(id(1096),a13(266)).
head(id(1097),n(266)).
head(id(1098),a18(266)).
head(id(1099),a34(266)).
head(id(1100),a35(266)).
head(id(1101),a5(608)).
head(id(1102),a13(608)).
head(id(1103),n(608)).
head(id(1104),a34(608)).
head(id(1105),a35(608)).
head(id(1106),a36(608)).
head(id(1107),a5(211)).
head(id(1108),a6(211)).
head(id(1109),a7(211)).
head(id(1110),a13(211)).
head(id(1111),n(211)).
head(id(1112),a26(211)).
head(id(1113),a35(211)).
head(id(1114),a6(331)).
head(id(1115),a9(331)).
head(id(1116),a13(331)).
head(id(1117),n(331)).
head(id(1118),a22(331)).
head(id(1119),a34(331)).
head(id(1120),a35(331)).
head(id(1121),a6(339)).
head(id(1122),a9(339)).
head(id(1123),a13(339)).
head(id(1124),n(339)).
head(id(1125),a22(339)).
head(id(1126),a24(339)).
head(id(1127),a35(339)).
head(id(1128),a6(746)).
head(id(1129),a13(746)).
head(id(1130),n(746)).
head(id(1131),a18(746)).
head(id(1132),a21(746)).
head(id(1133),a24(746)).
head(id(1134),a34(746)).
head(id(1135),a35(746)).
head(id(1136),a5(886)).
head(id(1137),a10(886)).
head(id(1138),a13(886)).
head(id(1139),n(886)).
head(id(1140),a18(886)).
head(id(1141),a21(886)).
head(id(1142),a34(886)).
head(id(1143),a35(886)).
head(id(1144),a36(886)).
head(id(1145),a11(17)).
head(id(1146),a13(17)).
head(id(1147),n(17)).
head(id(1148),a18(17)).
head(id(1149),a24(17)).
head(id(1150),a26(17)).
head(id(1151),a31(17)).
head(id(1152),a34(17)).
head(id(1153),a35(17)).
head(id(1154),a5(862)).
head(id(1155),a6(862)).
head(id(1156),a7(862)).
head(id(1157),a10(862)).
head(id(1158),a11(862)).
head(id(1159),n(862)).
head(id(1160),a18(862)).
head(id(1161),a21(862)).
head(id(1162),a26(862)).
head(id(1163),a34(862)).
head(id(1164),a35(862)).
head(id(1165),a1(45)).
head(id(1166),a5(45)).
head(id(1167),a7(45)).
head(id(1168),a11(45)).
head(id(1169),a13(45)).
head(id(1170),n(45)).
head(id(1171),a18(45)).
head(id(1172),a20(45)).
head(id(1173),a24(45)).
head(id(1174),a26(45)).
head(id(1175),a34(45)).
head(id(1176),a35(45)).
head(id(1177),a6(774)).
head(id(1178),n(774)).
head(id(1179),a18(774)).
head(id(1180),a21(774)).
head(id(1181),a33(774)).
head(id(1182),a34(774)).
head(id(1183),a35(774)).
head(id(1184),a6(160)).
head(id(1185),a7(160)).
head(id(1186),a9(160)).
head(id(1187),a11(160)).
head(id(1188),a13(160)).
head(id(1189),n(160)).
head(id(1190),a18(160)).
head(id(1191),a22(160)).
head(id(1192),a26(160)).
head(id(1193),a34(160)).
head(id(1194),a5(75)).
head(id(1195),a7(75)).
head(id(1196),a11(75)).
head(id(1197),a13(75)).
head(id(1198),n(75)).
head(id(1199),a26(75)).
head(id(1200),a35(75)).
head(id(1201),a5(674)).
head(id(1202),n(674)).
head(id(1203),a18(674)).
head(id(1204),a24(674)).
head(id(1205),a34(674)).
head(id(1206),a35(674)).
head(id(1207),a36(674)).
head(id(1208),a13(707)).
head(id(1209),n(707)).
head(id(1210),a18(707)).
head(id(1211),a21(707)).
head(id(1212),a24(707)).
head(id(1213),a26(707)).
head(id(1214),a33(707)).
head(id(1215),a34(707)).
head(id(1216),a35(707)).
head(id(1217),a6(625)).
head(id(1218),a9(625)).
head(id(1219),a13(625)).
head(id(1220),n(625)).
head(id(1221),a18(625)).
head(id(1222),a22(625)).
head(id(1223),a35(625)).
head(id(1224),a36(625)).
head(id(1225),a5(871)).
head(id(1226),a6(871)).
head(id(1227),a10(871)).
head(id(1228),n(871)).
head(id(1229),a18(871)).
head(id(1230),a21(871)).
head(id(1231),a34(871)).
head(id(1232),a35(871)).
head(id(1233),a6(842)).
head(id(1234),a10(842)).
head(id(1235),a11(842)).
head(id(1236),a13(842)).
head(id(1237),n(842)).
head(id(1238),a20(842)).
head(id(1239),a21(842)).
head(id(1240),a26(842)).
head(id(1241),a34(842)).
head(id(1242),a35(842)).
head(id(1243),a6(255)).
head(id(1244),a7(255)).
head(id(1245),a8(255)).
head(id(1246),a9(255)).
head(id(1247),a11(255)).
head(id(1248),a13(255)).
head(id(1249),n(255)).
head(id(1250),a18(255)).
head(id(1251),a22(255)).
head(id(1252),a26(255)).
head(id(1253),a34(255)).
head(id(1254),a35(255)).
head(id(1255),a5(2)).
head(id(1256),a13(2)).
head(id(1257),n(2)).
head(id(1258),a18(2)).
head(id(1259),a26(2)).
head(id(1260),a34(2)).
head(id(1261),a35(2)).
head(id(1262),a11(29)).
head(id(1263),a13(29)).
head(id(1264),w(29)).
head(id(1265),a18(29)).
head(id(1266),a24(29)).
head(id(1267),a26(29)).
head(id(1268),a34(29)).
head(id(1269),a35(29)).
head(id(1270),a6(877)).
head(id(1271),a10(877)).
head(id(1272),a12(877)).
head(id(1273),n(877)).
head(id(1274),a18(877)).
head(id(1275),a21(877)).
head(id(1276),a26(877)).
head(id(1277),a34(877)).
head(id(1278),a35(877)).
head(id(1279),a5(459)).
head(id(1280),a6(459)).
head(id(1281),a7(459)).
head(id(1282),a8(459)).
head(id(1283),a9(459)).
head(id(1284),n(459)).
head(id(1285),a18(459)).
head(id(1286),a26(459)).
head(id(1287),a34(459)).
head(id(1288),a35(459)).
head(id(1289),a5(486)).
head(id(1290),a9(486)).
head(id(1291),n(486)).
head(id(1292),a18(486)).
head(id(1293),a22(486)).
head(id(1294),a24(486)).
head(id(1295),a34(486)).
head(id(1296),a35(486)).
head(id(1297),a6(232)).
head(id(1298),a7(232)).
head(id(1299),a11(232)).
head(id(1300),a13(232)).
head(id(1301),n(232)).
head(id(1302),a24(232)).
head(id(1303),a26(232)).
head(id(1304),a5(79)).
head(id(1305),a7(79)).
head(id(1306),a11(79)).
head(id(1307),a13(79)).
head(id(1308),n(79)).
head(id(1309),a24(79)).
head(id(1310),a26(79)).
head(id(1311),a35(79)).
head(id(1312),a11(388)).
head(id(1313),n(388)).
head(id(1314),a17(388)).
head(id(1315),a18(388)).
head(id(1316),a23(388)).
head(id(1317),a26(388)).
head(id(1318),a34(388)).
head(id(1319),a35(388)).
head(id(1320),a6(682)).
head(id(1321),a9(682)).
head(id(1322),n(682)).
head(id(1323),a18(682)).
head(id(1324),a22(682)).
head(id(1325),a34(682)).
head(id(1326),a35(682)).
head(id(1327),a36(682)).
head(id(1328),a5(349)).
head(id(1329),a9(349)).
head(id(1330),n(349)).
head(id(1331),a18(349)).
head(id(1332),a22(349)).
head(id(1333),a26(349)).
head(id(1334),a34(349)).
head(id(1335),a35(349)).
head(id(1336),a6(806)).
head(id(1337),a13(806)).
head(id(1338),n(806)).
head(id(1339),a18(806)).
head(id(1340),a21(806)).
head(id(1341),a26(806)).
head(id(1342),a34(806)).
head(id(1343),a35(806)).
head(id(1344),a36(806)).
head(id(1345),a6(464)).
head(id(1346),a7(464)).
head(id(1347),a8(464)).
head(id(1348),a9(464)).
head(id(1349),a11(464)).
head(id(1350),n(464)).
head(id(1351),a18(464)).
head(id(1352),a26(464)).
head(id(1353),a34(464)).
head(id(1354),a35(464)).
head(id(1355),a7(360)).
head(id(1356),a11(360)).
head(id(1357),n(360)).
head(id(1358),a18(360)).
head(id(1359),a26(360)).
head(id(1360),a34(360)).
head(id(1361),a35(360)).
head(id(1362),a6(330)).
head(id(1363),a13(330)).
head(id(1364),n(330)).
head(id(1365),a33(330)).
head(id(1366),a35(330)).
head(id(1367),a6(151)).
head(id(1368),a7(151)).
head(id(1369),a9(151)).
head(id(1370),a11(151)).
head(id(1371),a13(151)).
head(id(1372),n(151)).
head(id(1373),a18(151)).
head(id(1374),a22(151)).
head(id(1375),a24(151)).
head(id(1376),a26(151)).
head(id(1377),a34(151)).
head(id(1378),a35(151)).
head(id(1379),a5(297)).
head(id(1380),a7(297)).
head(id(1381),a8(297)).
head(id(1382),a9(297)).
head(id(1383),a13(297)).
head(id(1384),n(297)).
head(id(1385),a24(297)).
head(id(1386),a34(297)).
head(id(1387),a35(297)).
head(id(1388),a1(44)).
head(id(1389),a11(44)).
head(id(1390),a13(44)).
head(id(1391),n(44)).
head(id(1392),a18(44)).
head(id(1393),a24(44)).
head(id(1394),a26(44)).
head(id(1395),a30(44)).
head(id(1396),a34(44)).
head(id(1397),a35(44)).
head(id(1398),a6(337)).
head(id(1399),a13(337)).
head(id(1400),n(337)).
head(id(1401),a24(337)).
head(id(1402),a33(337)).
head(id(1403),a35(337)).
head(id(1404),a5(424)).
head(id(1405),a6(424)).
head(id(1406),a7(424)).
head(id(1407),a9(424)).
head(id(1408),a11(424)).
head(id(1409),n(424)).
head(id(1410),a18(424)).
head(id(1411),a22(424)).
head(id(1412),a26(424)).
head(id(1413),a34(424)).
head(id(1414),a35(424)).
head(id(1415),a1(197)).
head(id(1416),a6(197)).
head(id(1417),a11(197)).
head(id(1418),a13(197)).
head(id(1419),b(197)).
head(id(1420),a18(197)).
head(id(1421),a24(197)).
head(id(1422),a26(197)).
head(id(1423),a34(197)).
head(id(1424),a35(197)).
head(id(1425),a6(536)).
head(id(1426),a12(536)).
head(id(1427),a13(536)).
head(id(1428),n(536)).
head(id(1429),a24(536)).
head(id(1430),a26(536)).
head(id(1431),a35(536)).
head(id(1432),a11(30)).
head(id(1433),a13(30)).
head(id(1434),w(30)).
head(id(1435),a18(30)).
head(id(1436),a24(30)).
head(id(1437),a26(30)).
head(id(1438),a31(30)).
head(id(1439),a34(30)).
head(id(1440),a35(30)).
head(id(1441),a13(70)).
head(id(1442),n(70)).
head(id(1443),a24(70)).
head(id(1444),a26(70)).
head(id(1445),a33(70)).
head(id(1446),a35(70)).
head(id(1447),a4(588)).
head(id(1448),a6(588)).
head(id(1449),a13(588)).
head(id(1450),n(588)).
head(id(1451),a24(588)).
head(id(1452),a26(588)).
head(id(1453),a35(588)).
head(id(1454),a36(588)).
head(id(1455),a6(749)).
head(id(1456),a13(749)).
head(id(1457),n(749)).
head(id(1458),a21(749)).
head(id(1459),a35(749)).
head(id(1460),a10(893)).
head(id(1461),a13(893)).
head(id(1462),n(893)).
head(id(1463),a21(893)).
head(id(1464),a35(893)).
head(id(1465),a36(893)).
head(id(1466),a4(359)).
head(id(1467),a5(359)).
head(id(1468),a11(359)).
head(id(1469),n(359)).
head(id(1470),a18(359)).
head(id(1471),a26(359)).
head(id(1472),a34(359)).
head(id(1473),a35(359)).
head(id(1474),a1(43)).
head(id(1475),a11(43)).
head(id(1476),a13(43)).
head(id(1477),n(43)).
head(id(1478),a18(43)).
head(id(1479),a24(43)).
head(id(1480),a26(43)).
head(id(1481),a31(43)).
head(id(1482),a34(43)).
head(id(1483),a35(43)).
head(id(1484),a5(573)).
head(id(1485),a7(573)).
head(id(1486),a8(573)).
head(id(1487),a9(573)).
head(id(1488),a13(573)).
head(id(1489),n(573)).
head(id(1490),a18(573)).
head(id(1491),a26(573)).
head(id(1492),a34(573)).
head(id(1493),a35(573)).
head(id(1494),a36(573)).
head(id(1495),a9(797)).
head(id(1496),a13(797)).
head(id(1497),n(797)).
head(id(1498),a18(797)).
head(id(1499),a21(797)).
head(id(1500),a22(797)).
head(id(1501),a26(797)).
head(id(1502),a33(797)).
head(id(1503),a34(797)).
head(id(1504),a35(797)).
head(id(1505),a36(797)).
head(id(1506),a1(201)).
head(id(1507),a5(201)).
head(id(1508),a6(201)).
head(id(1509),a7(201)).
head(id(1510),a11(201)).
head(id(1511),a13(201)).
head(id(1512),w(201)).
head(id(1513),a18(201)).
head(id(1514),a24(201)).
head(id(1515),a26(201)).
head(id(1516),a34(201)).
head(id(1517),a35(201)).
head(id(1518),a6(807)).
head(id(1519),a9(807)).
head(id(1520),a13(807)).
head(id(1521),n(807)).
head(id(1522),a18(807)).
head(id(1523),a21(807)).
head(id(1524),a22(807)).
head(id(1525),a26(807)).
head(id(1526),a33(807)).
head(id(1527),a34(807)).
head(id(1528),a35(807)).
head(id(1529),a36(807)).
head(id(1530),a1(188)).
head(id(1531),a5(188)).
head(id(1532),a6(188)).
head(id(1533),a7(188)).
head(id(1534),a11(188)).
head(id(1535),a13(188)).
head(id(1536),n(188)).
head(id(1537),a18(188)).
head(id(1538),a24(188)).
head(id(1539),a26(188)).
head(id(1540),a34(188)).
head(id(1541),a35(188)).
head(id(1542),n(675)).
head(id(1543),a18(675)).
head(id(1544),a24(675)).
head(id(1545),a30(675)).
head(id(1546),a34(675)).
head(id(1547),a35(675)).
head(id(1548),a36(675)).
head(id(1549),a6(902)).
head(id(1550),a10(902)).
head(id(1551),n(902)).
head(id(1552),a18(902)).
head(id(1553),a21(902)).
head(id(1554),a34(902)).
head(id(1555),a35(902)).
head(id(1556),a36(902)).
head(id(1557),a5(140)).
head(id(1558),a6(140)).
head(id(1559),a7(140)).
head(id(1560),a11(140)).
head(id(1561),a13(140)).
head(id(1562),n(140)).
head(id(1563),a18(140)).
head(id(1564),a26(140)).
head(id(1565),a34(140)).
head(id(1566),a35(140)).
head(id(1567),a4(138)).
head(id(1568),a6(138)).
head(id(1569),a11(138)).
head(id(1570),a13(138)).
head(id(1571),n(138)).
head(id(1572),a18(138)).
head(id(1573),a26(138)).
head(id(1574),a31(138)).
head(id(1575),a35(138)).
head(id(1576),a13(817)).
head(id(1577),n(817)).
head(id(1578),a18(817)).
head(id(1579),a21(817)).
head(id(1580),a24(817)).
head(id(1581),a33(817)).
head(id(1582),a34(817)).
head(id(1583),a35(817)).
head(id(1584),a36(817)).
head(id(1585),a5(890)).
head(id(1586),a10(890)).
head(id(1587),a13(890)).
head(id(1588),n(890)).
head(id(1589),a18(890)).
head(id(1590),a21(890)).
head(id(1591),a24(890)).
head(id(1592),a34(890)).
head(id(1593),a35(890)).
head(id(1594),a36(890)).
head(id(1595),a13(820)).
head(id(1596),n(820)).
head(id(1597),a21(820)).
head(id(1598),a33(820)).
head(id(1599),a35(820)).
head(id(1600),a36(820)).
head(id(1601),a10(867)).
head(id(1602),n(867)).
head(id(1603),a18(867)).
head(id(1604),a21(867)).
head(id(1605),a34(867)).
head(id(1606),a35(867)).
head(id(1607),a6(813)).
head(id(1608),a13(813)).
head(id(1609),n(813)).
head(id(1610),a21(813)).
head(id(1611),a24(813)).
head(id(1612),a26(813)).
head(id(1613),a33(813)).
head(id(1614),a35(813)).
head(id(1615),a36(813)).
head(id(1616),a13(612)).
head(id(1617),n(612)).
head(id(1618),a24(612)).
head(id(1619),a35(612)).
head(id(1620),a36(612)).
head(id(1621),a4(313)).
head(id(1622),a5(313)).
head(id(1623),a6(313)).
head(id(1624),a9(313)).
head(id(1625),a13(313)).
head(id(1626),n(313)).
head(id(1627),a18(313)).
head(id(1628),a22(313)).
head(id(1629),a34(313)).
head(id(1630),a35(313)).
head(id(1631),a4(205)).
head(id(1632),a6(205)).
head(id(1633),a13(205)).
head(id(1634),n(205)).
head(id(1635),a26(205)).
head(id(1636),a35(205)).
head(id(1637),a6(154)).
head(id(1638),a7(154)).
head(id(1639),a11(154)).
head(id(1640),a13(154)).
head(id(1641),n(154)).
head(id(1642),a18(154)).
head(id(1643),a26(154)).
head(id(1644),a34(154)).
head(id(1645),a10(833)).
head(id(1646),a11(833)).
head(id(1647),a13(833)).
head(id(1648),w(833)).
head(id(1649),a18(833)).
head(id(1650),a21(833)).
head(id(1651),a26(833)).
head(id(1652),a33(833)).
head(id(1653),a34(833)).
head(id(1654),a5(478)).
head(id(1655),a7(478)).
head(id(1656),n(478)).
head(id(1657),a18(478)).
head(id(1658),a34(478)).
head(id(1659),a35(478)).
head(id(1660),a7(102)).
head(id(1661),a8(102)).
head(id(1662),a9(102)).
head(id(1663),a11(102)).
head(id(1664),a13(102)).
head(id(1665),n(102)).
head(id(1666),a18(102)).
head(id(1667),a26(102)).
head(id(1668),a34(102)).
head(id(1669),a35(102)).
head(id(1670),a5(848)).
head(id(1671),a10(848)).
head(id(1672),n(848)).
head(id(1673),a18(848)).
head(id(1674),a21(848)).
head(id(1675),a26(848)).
head(id(1676),a34(848)).
head(id(1677),a35(848)).
head(id(1678),a11(84)).
head(id(1679),a13(84)).
head(id(1680),w(84)).
head(id(1681),a26(84)).
head(id(1682),a34(84)).
head(id(1683),a35(84)).
head(id(1684),a11(90)).
head(id(1685),a13(90)).
head(id(1686),w(90)).
head(id(1687),a24(90)).
head(id(1688),a26(90)).
head(id(1689),a31(90)).
head(id(1690),a35(90)).
head(id(1691),a9(354)).
head(id(1692),n(354)).
head(id(1693),a18(354)).
head(id(1694),a22(354)).
head(id(1695),a24(354)).
head(id(1696),a26(354)).
head(id(1697),a34(354)).
head(id(1698),a35(354)).
head(id(1699),a5(670)).
head(id(1700),a7(670)).
head(id(1701),n(670)).
head(id(1702),a18(670)).
head(id(1703),a34(670)).
head(id(1704),a35(670)).
head(id(1705),a36(670)).
head(id(1706),a3(410)).
head(id(1707),a5(410)).
head(id(1708),a6(410)).
head(id(1709),a7(410)).
head(id(1710),n(410)).
head(id(1711),a18(410)).
head(id(1712),a24(410)).
head(id(1713),a26(410)).
head(id(1714),a35(410)).
head(id(1715),a6(719)).
head(id(1716),a13(719)).
head(id(1717),n(719)).
head(id(1718),a18(719)).
head(id(1719),a21(719)).
head(id(1720),a24(719)).
head(id(1721),a26(719)).
head(id(1722),a34(719)).
head(id(1723),a35(719)).
head(id(1724),a6(418)).
head(id(1725),a7(418)).
head(id(1726),a11(418)).
head(id(1727),n(418)).
head(id(1728),a18(418)).
head(id(1729),a26(418)).
head(id(1730),a34(418)).
head(id(1731),a35(418)).
head(id(1732),a5(346)).
head(id(1733),n(346)).
head(id(1734),a18(346)).
head(id(1735),a26(346)).
head(id(1736),a34(346)).
head(id(1737),a35(346)).
head(id(1738),a6(429)).
head(id(1739),a7(429)).
head(id(1740),a9(429)).
head(id(1741),a11(429)).
head(id(1742),n(429)).
head(id(1743),a18(429)).
head(id(1744),a22(429)).
head(id(1745),a24(429)).
head(id(1746),a26(429)).
head(id(1747),a34(429)).
head(id(1748),a35(429)).
head(id(1749),a13(798)).
head(id(1750),n(798)).
head(id(1751),a18(798)).
head(id(1752),a21(798)).
head(id(1753),a24(798)).
head(id(1754),a26(798)).
head(id(1755),a34(798)).
head(id(1756),a35(798)).
head(id(1757),a36(798)).
head(id(1758),a10(885)).
head(id(1759),a13(885)).
head(id(1760),n(885)).
head(id(1761),a18(885)).
head(id(1762),a21(885)).
head(id(1763),a34(885)).
head(id(1764),a35(885)).
head(id(1765),a36(885)).
head(id(1766),a13(563)).
head(id(1767),n(563)).
head(id(1768),a18(563)).
head(id(1769),a24(563)).
head(id(1770),a26(563)).
head(id(1771),a30(563)).
head(id(1772),a34(563)).
head(id(1773),a35(563)).
head(id(1774),a36(563)).
head(id(1775),n(649)).
head(id(1776),a18(649)).
head(id(1777),a24(649)).
head(id(1778),a26(649)).
head(id(1779),a30(649)).
head(id(1780),a34(649)).
head(id(1781),a35(649)).
head(id(1782),a36(649)).
head(id(1783),a5(597)).
head(id(1784),a13(597)).
head(id(1785),n(597)).
head(id(1786),a18(597)).
head(id(1787),a34(597)).
head(id(1788),a35(597)).
head(id(1789),a36(597)).
head(id(1790),a13(714)).
head(id(1791),n(714)).
head(id(1792),a21(714)).
head(id(1793),a24(714)).
head(id(1794),a26(714)).
head(id(1795),a30(714)).
head(id(1796),a35(714)).
head(id(1797),a5(108)).
head(id(1798),a7(108)).
head(id(1799),a8(108)).
head(id(1800),a9(108)).
head(id(1801),a11(108)).
head(id(1802),a13(108)).
head(id(1803),w(108)).
head(id(1804),a18(108)).
head(id(1805),a26(108)).
head(id(1806),a34(108)).
head(id(1807),a35(108)).
head(id(1808),a5(851)).
head(id(1809),a10(851)).
head(id(1810),a11(851)).
head(id(1811),n(851)).
head(id(1812),a18(851)).
head(id(1813),a21(851)).
head(id(1814),a26(851)).
head(id(1815),a34(851)).
head(id(1816),a35(851)).
head(id(1817),n(476)).
head(id(1818),a18(476)).
head(id(1819),a34(476)).
head(id(1820),a35(476)).
head(id(1821),a13(286)).
head(id(1822),n(286)).
head(id(1823),a24(286)).
head(id(1824),a34(286)).
head(id(1825),a35(286)).
head(id(1826),a5(404)).
head(id(1827),a6(404)).
head(id(1828),a7(404)).
head(id(1829),a9(404)).
head(id(1830),n(404)).
head(id(1831),a18(404)).
head(id(1832),a22(404)).
head(id(1833),a26(404)).
head(id(1834),a34(404)).
head(id(1835),a35(404)).
head(id(1836),n(760)).
head(id(1837),a18(760)).
head(id(1838),a21(760)).
head(id(1839),a24(760)).
head(id(1840),a26(760)).
head(id(1841),a34(760)).
head(id(1842),a35(760)).
head(id(1843),a5(602)).
head(id(1844),a13(602)).
head(id(1845),n(602)).
head(id(1846),a18(602)).
head(id(1847),a24(602)).
head(id(1848),a34(602)).
head(id(1849),a35(602)).
head(id(1850),a36(602)).
head(id(1851),a6(504)).
head(id(1852),a7(504)).
head(id(1853),a9(504)).
head(id(1854),n(504)).
head(id(1855),a18(504)).
head(id(1856),a22(504)).
head(id(1857),a34(504)).
head(id(1858),a35(504)).
head(id(1859),a6(533)).
head(id(1860),a7(533)).
head(id(1861),a11(533)).
head(id(1862),a12(533)).
head(id(1863),a13(533)).
head(id(1864),w(533)).
head(id(1865),a18(533)).
head(id(1866),a26(533)).
head(id(1867),a34(533)).
head(id(1868),a5(748)).
head(id(1869),a6(748)).
head(id(1870),a7(748)).
head(id(1871),a13(748)).
head(id(1872),n(748)).
head(id(1873),a18(748)).
head(id(1874),a21(748)).
head(id(1875),a24(748)).
head(id(1876),a33(748)).
head(id(1877),a34(748)).
head(id(1878),a35(748)).
head(id(1879),a10(903)).
head(id(1880),a12(903)).
head(id(1881),a13(903)).
head(id(1882),n(903)).
head(id(1883),a18(903)).
head(id(1884),a21(903)).
head(id(1885),a26(903)).
head(id(1886),a34(903)).
head(id(1887),a35(903)).
head(id(1888),a36(903)).
head(id(1889),a5(303)).
head(id(1890),a6(303)).
head(id(1891),a13(303)).
head(id(1892),n(303)).
head(id(1893),a18(303)).
head(id(1894),a34(303)).
head(id(1895),a35(303)).
head(id(1896),a9(268)).
head(id(1897),a13(268)).
head(id(1898),n(268)).
head(id(1899),a18(268)).
head(id(1900),a22(268)).
head(id(1901),a34(268)).
head(id(1902),a35(268)).
head(id(1903),a5(835)).
head(id(1904),a10(835)).
head(id(1905),a13(835)).
head(id(1906),n(835)).
head(id(1907),a21(835)).
head(id(1908),a26(835)).
head(id(1909),a34(835)).
head(id(1910),a35(835)).
head(id(1911),a7(276)).
head(id(1912),a9(276)).
head(id(1913),a13(276)).
head(id(1914),n(276)).
head(id(1915),a18(276)).
head(id(1916),a22(276)).
head(id(1917),a24(276)).
head(id(1918),a34(276)).
head(id(1919),a35(276)).
head(id(1920),a5(515)).
head(id(1921),a6(515)).
head(id(1922),a7(515)).
head(id(1923),a8(515)).
head(id(1924),a9(515)).
head(id(1925),n(515)).
head(id(1926),a18(515)).
head(id(1927),a34(515)).
head(id(1928),a35(515)).
head(id(1929),n(769)).
head(id(1930),a18(769)).
head(id(1931),a21(769)).
head(id(1932),a33(769)).
head(id(1933),a34(769)).
head(id(1934),a35(769)).
head(id(1935),a13(596)).
head(id(1936),n(596)).
head(id(1937),a18(596)).
head(id(1938),a34(596)).
head(id(1939),a35(596)).
head(id(1940),a36(596)).
head(id(1941),a6(552)).
head(id(1942),a9(552)).
head(id(1943),a12(552)).
head(id(1944),n(552)).
head(id(1945),a18(552)).
head(id(1946),a22(552)).
head(id(1947),a26(552)).
head(id(1948),a34(552)).
head(id(1949),a35(552)).
head(id(1950),a5(105)).
head(id(1951),a7(105)).
head(id(1952),a8(105)).
head(id(1953),a9(105)).
head(id(1954),a11(105)).
head(id(1955),a13(105)).
head(id(1956),n(105)).
head(id(1957),a18(105)).
head(id(1958),a24(105)).
head(id(1959),a26(105)).
head(id(1960),a34(105)).
head(id(1961),a35(105)).
head(id(1962),a6(129)).
head(id(1963),a13(129)).
head(id(1964),n(129)).
head(id(1965),a18(129)).
head(id(1966),a24(129)).
head(id(1967),a26(129)).
head(id(1968),a35(129)).
head(id(1969),a10(892)).
head(id(1970),a13(892)).
head(id(1971),n(892)).
head(id(1972),a21(892)).
head(id(1973),a34(892)).
head(id(1974),a35(892)).
head(id(1975),a36(892)).
head(id(1976),a5(157)).
head(id(1977),a6(157)).
head(id(1978),a7(157)).
head(id(1979),a11(157)).
head(id(1980),a13(157)).
head(id(1981),n(157)).
head(id(1982),a18(157)).
head(id(1983),a26(157)).
head(id(1984),a6(507)).
head(id(1985),n(507)).
head(id(1986),a18(507)).
head(id(1987),a24(507)).
head(id(1988),a35(507)).
head(id(1989),a5(614)).
head(id(1990),a7(614)).
head(id(1991),a8(614)).
head(id(1992),a9(614)).
head(id(1993),a13(614)).
head(id(1994),n(614)).
head(id(1995),a18(614)).
head(id(1996),a34(614)).
head(id(1997),a35(614)).
head(id(1998),a36(614)).
head(id(1999),a6(626)).
head(id(2000),a7(626)).
head(id(2001),a9(626)).
head(id(2002),a13(626)).
head(id(2003),n(626)).
head(id(2004),a18(626)).
head(id(2005),a22(626)).
head(id(2006),a35(626)).
head(id(2007),a36(626)).
head(id(2008),a4(680)).
head(id(2009),a5(680)).
head(id(2010),a6(680)).
head(id(2011),n(680)).
head(id(2012),a18(680)).
head(id(2013),a34(680)).
head(id(2014),a35(680)).
head(id(2015),a36(680)).
head(id(2016),a12(695)).
head(id(2017),a13(695)).
head(id(2018),n(695)).
head(id(2019),a34(695)).
head(id(2020),a35(695)).
head(id(2021),a36(695)).
head(id(2022),a11(82)).
head(id(2023),a13(82)).
head(id(2024),n(82)).
head(id(2025),a24(82)).
head(id(2026),a26(82)).
head(id(2027),a31(82)).
head(id(2028),a6(179)).
head(id(2029),a7(179)).
head(id(2030),a9(179)).
head(id(2031),a11(179)).
head(id(2032),a13(179)).
head(id(2033),w(179)).
head(id(2034),a18(179)).
head(id(2035),a22(179)).
head(id(2036),a26(179)).
head(id(2037),a34(179)).
head(id(2038),a9(485)).
head(id(2039),n(485)).
head(id(2040),a18(485)).
head(id(2041),a22(485)).
head(id(2042),a24(485)).
head(id(2043),a34(485)).
head(id(2044),a35(485)).
head(id(2045),a5(514)).
head(id(2046),a6(514)).
head(id(2047),n(514)).
head(id(2048),a24(514)).
head(id(2049),a33(514)).
head(id(2050),a35(514)).
head(id(2051),a5(659)).
head(id(2052),a6(659)).
head(id(2053),a7(659)).
head(id(2054),n(659)).
head(id(2055),a18(659)).
head(id(2056),a26(659)).
head(id(2057),a34(659)).
head(id(2058),a35(659)).
head(id(2059),a36(659)).
head(id(2060),a5(329)).
head(id(2061),a6(329)).
head(id(2062),a7(329)).
head(id(2063),a13(329)).
head(id(2064),n(329)).
head(id(2065),a35(329)).
head(id(2066),a6(142)).
head(id(2067),a7(142)).
head(id(2068),a11(142)).
head(id(2069),a13(142)).
head(id(2070),n(142)).
head(id(2071),a18(142)).
head(id(2072),a20(142)).
head(id(2073),a26(142)).
head(id(2074),a31(142)).
head(id(2075),a34(142)).
head(id(2076),a35(142)).
head(id(2077),a5(225)).
head(id(2078),a6(225)).
head(id(2079),a7(225)).
head(id(2080),a11(225)).
head(id(2081),a13(225)).
head(id(2082),n(225)).
head(id(2083),a24(225)).
head(id(2084),a26(225)).
head(id(2085),a35(225)).
head(id(2086),a13(565)).
head(id(2087),n(565)).
head(id(2088),a26(565)).
head(id(2089),a35(565)).
head(id(2090),a36(565)).
head(id(2091),a13(725)).
head(id(2092),n(725)).
head(id(2093),a18(725)).
head(id(2094),a21(725)).
head(id(2095),a34(725)).
head(id(2096),a35(725)).
head(id(2097),a5(736)).
head(id(2098),a13(736)).
head(id(2099),n(736)).
head(id(2100),a21(736)).
head(id(2101),a33(736)).
head(id(2102),a35(736)).
head(id(2103),a5(281)).
head(id(2104),a7(281)).
head(id(2105),a13(281)).
head(id(2106),n(281)).
head(id(2107),a35(281)).
head(id(2108),a12(785)).
head(id(2109),a13(785)).
head(id(2110),n(785)).
head(id(2111),a21(785)).
head(id(2112),a35(785)).
head(id(2113),a13(816)).
head(id(2114),n(816)).
head(id(2115),a18(816)).
head(id(2116),a21(816)).
head(id(2117),a24(816)).
head(id(2118),a34(816)).
head(id(2119),a35(816)).
head(id(2120),a36(816)).
head(id(2121),a5(304)).
head(id(2122),a6(304)).
head(id(2123),a13(304)).
head(id(2124),n(304)).
head(id(2125),a18(304)).
head(id(2126),a35(304)).
head(id(2127),a6(576)).
head(id(2128),a13(576)).
head(id(2129),n(576)).
head(id(2130),a18(576)).
head(id(2131),a26(576)).
head(id(2132),a35(576)).
head(id(2133),a36(576)).
head(id(2134),a4(207)).
head(id(2135),a5(207)).
head(id(2136),a6(207)).
head(id(2137),a13(207)).
head(id(2138),n(207)).
head(id(2139),a26(207)).
head(id(2140),a34(207)).
head(id(2141),a35(207)).
head(id(2142),a6(616)).
head(id(2143),a13(616)).
head(id(2144),n(616)).
head(id(2145),a18(616)).
head(id(2146),a34(616)).
head(id(2147),a35(616)).
head(id(2148),a36(616)).
head(id(2149),a1(181)).
head(id(2150),a5(181)).
head(id(2151),a6(181)).
head(id(2152),a11(181)).
head(id(2153),a13(181)).
head(id(2154),n(181)).
head(id(2155),a18(181)).
head(id(2156),a26(181)).
head(id(2157),a35(181)).
head(id(2158),a9(693)).
head(id(2159),a12(693)).
head(id(2160),a13(693)).
head(id(2161),n(693)).
head(id(2162),a18(693)).
head(id(2163),a22(693)).
head(id(2164),a34(693)).
head(id(2165),a35(693)).
head(id(2166),a36(693)).
head(id(2167),a10(878)).
head(id(2168),a13(878)).
head(id(2169),n(878)).
head(id(2170),a18(878)).
head(id(2171),a21(878)).
head(id(2172),a26(878)).
head(id(2173),a34(878)).
head(id(2174),a35(878)).
head(id(2175),a36(878)).
head(id(2176),a7(113)).
head(id(2177),a8(113)).
head(id(2178),a9(113)).
head(id(2179),a11(113)).
head(id(2180),a13(113)).
head(id(2181),n(113)).
head(id(2182),a26(113)).
head(id(2183),a35(113)).
head(id(2184),a5(480)).
head(id(2185),a9(480)).
head(id(2186),n(480)).
head(id(2187),a18(480)).
head(id(2188),a22(480)).
head(id(2189),a34(480)).
head(id(2190),a35(480)).
head(id(2191),a6(155)).
head(id(2192),a7(155)).
head(id(2193),a11(155)).
head(id(2194),a13(155)).
head(id(2195),n(155)).
head(id(2196),a18(155)).
head(id(2197),a26(155)).
head(id(2198),a5(237)).
head(id(2199),a6(237)).
head(id(2200),a7(237)).
head(id(2201),a11(237)).
head(id(2202),a13(237)).
head(id(2203),w(237)).
head(id(2204),a26(237)).
head(id(2205),a35(237)).
head(id(2206),a12(526)).
head(id(2207),a13(526)).
head(id(2208),n(526)).
head(id(2209),a26(526)).
head(id(2210),a35(526)).
head(id(2211),a6(546)).
head(id(2212),a12(546)).
head(id(2213),a13(546)).
head(id(2214),n(546)).
head(id(2215),a18(546)).
head(id(2216),a24(546)).
head(id(2217),a34(546)).
head(id(2218),a35(546)).
head(id(2219),a9(543)).
head(id(2220),a12(543)).
head(id(2221),a13(543)).
head(id(2222),n(543)).
head(id(2223),a22(543)).
head(id(2224),a34(543)).
head(id(2225),a35(543)).
head(id(2226),a1(378)).
head(id(2227),a7(378)).
head(id(2228),a11(378)).
head(id(2229),b(378)).
head(id(2230),a18(378)).
head(id(2231),a26(378)).
head(id(2232),a34(378)).
head(id(2233),a35(378)).
head(id(2234),n(772)).
head(id(2235),a18(772)).
head(id(2236),a21(772)).
head(id(2237),a24(772)).
head(id(2238),a33(772)).
head(id(2239),a34(772)).
head(id(2240),a35(772)).
head(id(2241),a5(672)).
head(id(2242),a9(672)).
head(id(2243),n(672)).
head(id(2244),a18(672)).
head(id(2245),a22(672)).
head(id(2246),a34(672)).
head(id(2247),a35(672)).
head(id(2248),a36(672)).
head(id(2249),a10(855)).
head(id(2250),n(855)).
head(id(2251),a18(855)).
head(id(2252),a21(855)).
head(id(2253),a23(855)).
head(id(2254),a26(855)).
head(id(2255),a34(855)).
head(id(2256),a35(855)).
head(id(2257),a3(587)).
head(id(2258),a6(587)).
head(id(2259),a13(587)).
head(id(2260),n(587)).
head(id(2261),a24(587)).
head(id(2262),a26(587)).
head(id(2263),a35(587)).
head(id(2264),a36(587)).
head(id(2265),a6(764)).
head(id(2266),n(764)).
head(id(2267),a18(764)).
head(id(2268),a21(764)).
head(id(2269),a26(764)).
head(id(2270),a34(764)).
head(id(2271),a35(764)).
head(id(2272),a13(814)).
head(id(2273),n(814)).
head(id(2274),a18(814)).
head(id(2275),a21(814)).
head(id(2276),a34(814)).
head(id(2277),a35(814)).
head(id(2278),a36(814)).
head(id(2279),a5(512)).
head(id(2280),a6(512)).
head(id(2281),a7(512)).
head(id(2282),a9(512)).
head(id(2283),n(512)).
head(id(2284),a18(512)).
head(id(2285),a22(512)).
head(id(2286),a24(512)).
head(id(2287),a34(512)).
head(id(2288),a35(512)).
head(id(2289),n(761)).
head(id(2290),a18(761)).
head(id(2291),a21(761)).
head(id(2292),a24(761)).
head(id(2293),a26(761)).
head(id(2294),a30(761)).
head(id(2295),a34(761)).
head(id(2296),a35(761)).
head(id(2297),a13(572)).
head(id(2298),n(572)).
head(id(2299),a24(572)).
head(id(2300),a26(572)).
head(id(2301),a33(572)).
head(id(2302),a35(572)).
head(id(2303),a36(572)).
head(id(2304),a6(165)).
head(id(2305),a11(165)).
head(id(2306),a13(165)).
head(id(2307),w(165)).
head(id(2308),a18(165)).
head(id(2309),a20(165)).
head(id(2310),a26(165)).
head(id(2311),a31(165)).
head(id(2312),a34(165)).
head(id(2313),a35(165)).
head(id(2314),a6(502)).
head(id(2315),a9(502)).
head(id(2316),n(502)).
head(id(2317),a18(502)).
head(id(2318),a22(502)).
head(id(2319),a34(502)).
head(id(2320),a35(502)).
head(id(2321),a11(81)).
head(id(2322),a13(81)).
head(id(2323),n(81)).
head(id(2324),a26(81)).
head(id(2325),a31(81)).
head(id(2326),a33(81)).
head(id(2327),a5(97)).
head(id(2328),a7(97)).
head(id(2329),a11(97)).
head(id(2330),a13(97)).
head(id(2331),w(97)).
head(id(2332),a26(97)).
head(id(2333),a7(487)).
head(id(2334),a9(487)).
head(id(2335),n(487)).
head(id(2336),a18(487)).
head(id(2337),a22(487)).
head(id(2338),a24(487)).
head(id(2339),a34(487)).
head(id(2340),a35(487)).
head(id(2341),a5(119)).
head(id(2342),a6(119)).
head(id(2343),a13(119)).
head(id(2344),n(119)).
head(id(2345),a18(119)).
head(id(2346),a26(119)).
head(id(2347),a35(119)).
head(id(2348),a5(858)).
head(id(2349),a6(858)).
head(id(2350),a7(858)).
head(id(2351),a10(858)).
head(id(2352),n(858)).
head(id(2353),a18(858)).
head(id(2354),a21(858)).
head(id(2355),a26(858)).
head(id(2356),a34(858)).
head(id(2357),a35(858)).
head(id(2358),a5(497)).
head(id(2359),a6(497)).
head(id(2360),n(497)).
head(id(2361),a18(497)).
head(id(2362),a35(497)).
head(id(2363),a5(419)).
head(id(2364),a6(419)).
head(id(2365),a7(419)).
head(id(2366),a11(419)).
head(id(2367),n(419)).
head(id(2368),a18(419)).
head(id(2369),a26(419)).
head(id(2370),a34(419)).
head(id(2371),a35(419)).
head(id(2372),a6(683)).
head(id(2373),n(683)).
head(id(2374),a18(683)).
head(id(2375),a24(683)).
head(id(2376),a34(683)).
head(id(2377),a35(683)).
head(id(2378),a36(683)).
head(id(2379),a5(477)).
head(id(2380),n(477)).
head(id(2381),a18(477)).
head(id(2382),a34(477)).
head(id(2383),a35(477)).
head(id(2384),a5(517)).
head(id(2385),a6(517)).
head(id(2386),a7(517)).
head(id(2387),a8(517)).
head(id(2388),a9(517)).
head(id(2389),n(517)).
head(id(2390),a18(517)).
head(id(2391),a24(517)).
head(id(2392),a34(517)).
head(id(2393),a35(517)).
head(id(2394),a9(20)).
head(id(2395),a11(20)).
head(id(2396),a13(20)).
head(id(2397),n(20)).
head(id(2398),a18(20)).
head(id(2399),a22(20)).
head(id(2400),a24(20)).
head(id(2401),a26(20)).
head(id(2402),a31(20)).
head(id(2403),a34(20)).
head(id(2404),a35(20)).
head(id(2405),a9(4)).
head(id(2406),a13(4)).
head(id(2407),n(4)).
head(id(2408),a18(4)).
head(id(2409),a22(4)).
head(id(2410),a26(4)).
head(id(2411),a34(4)).
head(id(2412),a35(4)).
head(id(2413),a5(69)).
head(id(2414),a7(69)).
head(id(2415),a13(69)).
head(id(2416),n(69)).
head(id(2417),a24(69)).
head(id(2418),a26(69)).
head(id(2419),a35(69)).
head(id(2420),a9(555)).
head(id(2421),a12(555)).
head(id(2422),n(555)).
head(id(2423),a18(555)).
head(id(2424),a22(555)).
head(id(2425),a34(555)).
head(id(2426),a35(555)).
head(id(2427),a6(134)).
head(id(2428),a9(134)).
head(id(2429),a13(134)).
head(id(2430),n(134)).
head(id(2431),a18(134)).
head(id(2432),a22(134)).
head(id(2433),a24(134)).
head(id(2434),a26(134)).
head(id(2435),a34(134)).
head(id(2436),a35(134)).
head(id(2437),a7(110)).
head(id(2438),a8(110)).
head(id(2439),a9(110)).
head(id(2440),a11(110)).
head(id(2441),a13(110)).
head(id(2442),w(110)).
head(id(2443),a18(110)).
head(id(2444),a26(110)).
head(id(2445),a34(110)).
head(id(2446),a5(442)).
head(id(2447),a6(442)).
head(id(2448),a9(442)).
head(id(2449),a11(442)).
head(id(2450),b(442)).
head(id(2451),a18(442)).
head(id(2452),a22(442)).
head(id(2453),a26(442)).
head(id(2454),a34(442)).
head(id(2455),a35(442)).
head(id(2456),a6(235)).
head(id(2457),a11(235)).
head(id(2458),a13(235)).
head(id(2459),w(235)).
head(id(2460),a26(235)).
head(id(2461),a31(235)).
head(id(2462),a35(235)).
head(id(2463),a6(843)).
head(id(2464),a10(843)).
head(id(2465),a11(843)).
head(id(2466),a13(843)).
head(id(2467),n(843)).
head(id(2468),a20(843)).
head(id(2469),a21(843)).
head(id(2470),a24(843)).
head(id(2471),a26(843)).
head(id(2472),a34(843)).
head(id(2473),a35(843)).
head(id(2474),a6(159)).
head(id(2475),a9(159)).
head(id(2476),a11(159)).
head(id(2477),a13(159)).
head(id(2478),n(159)).
head(id(2479),a18(159)).
head(id(2480),a22(159)).
head(id(2481),a26(159)).
head(id(2482),a31(159)).
head(id(2483),a34(159)).
head(id(2484),a6(180)).
head(id(2485),a11(180)).
head(id(2486),a13(180)).
head(id(2487),w(180)).
head(id(2488),a18(180)).
head(id(2489),a24(180)).
head(id(2490),a26(180)).
head(id(2491),a31(180)).
head(id(2492),a34(180)).
head(id(2493),a6(518)).
head(id(2494),n(518)).
head(id(2495),a18(518)).
head(id(2496),a23(518)).
head(id(2497),a34(518)).
head(id(2498),a35(518)).
head(id(2499),a5(604)).
head(id(2500),a7(604)).
head(id(2501),a13(604)).
head(id(2502),n(604)).
head(id(2503),a18(604)).
head(id(2504),a24(604)).
head(id(2505),a34(604)).
head(id(2506),a35(604)).
head(id(2507),a36(604)).
head(id(2508),a1(202)).
head(id(2509),a6(202)).
head(id(2510),a7(202)).
head(id(2511),a11(202)).
head(id(2512),a13(202)).
head(id(2513),w(202)).
head(id(2514),a18(202)).
head(id(2515),a26(202)).
head(id(2516),a34(202)).
head(id(2517),a6(332)).
head(id(2518),a7(332)).
head(id(2519),a9(332)).
head(id(2520),a13(332)).
head(id(2521),n(332)).
head(id(2522),a22(332)).
head(id(2523),a34(332)).
head(id(2524),a35(332)).
head(id(2525),a6(170)).
head(id(2526),a7(170)).
head(id(2527),a9(170)).
head(id(2528),a11(170)).
head(id(2529),a13(170)).
head(id(2530),w(170)).
head(id(2531),a18(170)).
head(id(2532),a22(170)).
head(id(2533),a26(170)).
head(id(2534),a34(170)).
head(id(2535),a35(170)).
head(id(2536),a12(525)).
head(id(2537),a13(525)).
head(id(2538),n(525)).
head(id(2539),a26(525)).
head(id(2540),a34(525)).
head(id(2541),a35(525)).
head(id(2542),a6(136)).
head(id(2543),a11(136)).
head(id(2544),a13(136)).
head(id(2545),n(136)).
head(id(2546),a18(136)).
head(id(2547),a26(136)).
head(id(2548),a31(136)).
head(id(2549),a35(136)).
head(id(2550),a6(162)).
head(id(2551),a11(162)).
head(id(2552),a13(162)).
head(id(2553),n(162)).
head(id(2554),a18(162)).
head(id(2555),a24(162)).
head(id(2556),a26(162)).
head(id(2557),a31(162)).
head(id(2558),a34(162)).
head(id(2559),a1(193)).
head(id(2560),a6(193)).
head(id(2561),a11(193)).
head(id(2562),a13(193)).
head(id(2563),w(193)).
head(id(2564),a18(193)).
head(id(2565),a26(193)).
head(id(2566),a31(193)).
head(id(2567),a34(193)).
head(id(2568),a35(193)).
head(id(2569),a6(167)).
head(id(2570),a7(167)).
head(id(2571),a11(167)).
head(id(2572),a13(167)).
head(id(2573),w(167)).
head(id(2574),a18(167)).
head(id(2575),a26(167)).
head(id(2576),a34(167)).
head(id(2577),a35(167)).
head(id(2578),a5(123)).
head(id(2579),a6(123)).
head(id(2580),a7(123)).
head(id(2581),a13(123)).
head(id(2582),n(123)).
head(id(2583),a18(123)).
head(id(2584),a26(123)).
head(id(2585),a34(123)).
head(id(2586),a35(123)).
head(id(2587),a13(712)).
head(id(2588),n(712)).
head(id(2589),a21(712)).
head(id(2590),a24(712)).
head(id(2591),a26(712)).
head(id(2592),a35(712)).
head(id(2593),a6(904)).
head(id(2594),a10(904)).
head(id(2595),a12(904)).
head(id(2596),a13(904)).
head(id(2597),n(904)).
head(id(2598),a18(904)).
head(id(2599),a21(904)).
head(id(2600),a26(904)).
head(id(2601),a34(904)).
head(id(2602),a35(904)).
head(id(2603),a36(904)).
head(id(2604),a13(726)).
head(id(2605),n(726)).
head(id(2606),a18(726)).
head(id(2607),a21(726)).
head(id(2608),a33(726)).
head(id(2609),a34(726)).
head(id(2610),a35(726)).
head(id(2611),a5(367)).
head(id(2612),a7(367)).
head(id(2613),a11(367)).
head(id(2614),n(367)).
head(id(2615),a18(367)).
head(id(2616),a24(367)).
head(id(2617),a26(367)).
head(id(2618),a34(367)).
head(id(2619),a35(367)).
head(id(2620),a5(353)).
head(id(2621),a7(353)).
head(id(2622),n(353)).
head(id(2623),a18(353)).
head(id(2624),a24(353)).
head(id(2625),a26(353)).
head(id(2626),a34(353)).
head(id(2627),a35(353)).
head(id(2628),a5(316)).
head(id(2629),a6(316)).
head(id(2630),a7(316)).
head(id(2631),a9(316)).
head(id(2632),a13(316)).
head(id(2633),n(316)).
head(id(2634),a18(316)).
head(id(2635),a22(316)).
head(id(2636),a34(316)).
head(id(2637),a35(316)).
head(id(2638),a5(335)).
head(id(2639),a6(335)).
head(id(2640),a13(335)).
head(id(2641),n(335)).
head(id(2642),a24(335)).
head(id(2643),a35(335)).
head(id(2644),a11(366)).
head(id(2645),n(366)).
head(id(2646),a18(366)).
head(id(2647),a24(366)).
head(id(2648),a26(366)).
head(id(2649),a30(366)).
head(id(2650),a34(366)).
head(id(2651),a35(366)).
head(id(2652),a5(296)).
head(id(2653),a7(296)).
head(id(2654),a8(296)).
head(id(2655),a9(296)).
head(id(2656),a13(296)).
head(id(2657),n(296)).
head(id(2658),a18(296)).
head(id(2659),a24(296)).
head(id(2660),a34(296)).
head(id(2661),a35(296)).
head(id(2662),a6(214)).
head(id(2663),a13(214)).
head(id(2664),n(214)).
head(id(2665),a24(214)).
head(id(2666),a26(214)).
head(id(2667),a35(214)).
head(id(2668),a6(117)).
head(id(2669),a13(117)).
head(id(2670),n(117)).
head(id(2671),a18(117)).
head(id(2672),a26(117)).
head(id(2673),a35(117)).
head(id(2674),a5(380)).
head(id(2675),a7(380)).
head(id(2676),a8(380)).
head(id(2677),a9(380)).
head(id(2678),n(380)).
head(id(2679),a18(380)).
head(id(2680),a26(380)).
head(id(2681),a34(380)).
head(id(2682),a35(380)).
head(id(2683),a10(879)).
head(id(2684),a13(879)).
head(id(2685),n(879)).
head(id(2686),a18(879)).
head(id(2687),a21(879)).
head(id(2688),a24(879)).
head(id(2689),a26(879)).
head(id(2690),a34(879)).
head(id(2691),a35(879)).
head(id(2692),a36(879)).
head(id(2693),a6(519)).
head(id(2694),a9(519)).
head(id(2695),n(519)).
head(id(2696),a18(519)).
head(id(2697),a22(519)).
head(id(2698),a23(519)).
head(id(2699),a34(519)).
head(id(2700),a35(519)).
head(id(2701),a6(334)).
head(id(2702),a13(334)).
head(id(2703),n(334)).
head(id(2704),a24(334)).
head(id(2705),a35(334)).
head(id(2706),a6(439)).
head(id(2707),a11(439)).
head(id(2708),b(439)).
head(id(2709),a18(439)).
head(id(2710),a26(439)).
head(id(2711),a34(439)).
head(id(2712),a35(439)).
head(id(2713),a3(407)).
head(id(2714),a6(407)).
head(id(2715),n(407)).
head(id(2716),a18(407)).
head(id(2717),a24(407)).
head(id(2718),a26(407)).
head(id(2719),a35(407)).
head(id(2720),a5(583)).
head(id(2721),a6(583)).
head(id(2722),a13(583)).
head(id(2723),n(583)).
head(id(2724),a26(583)).
head(id(2725),a33(583)).
head(id(2726),a35(583)).
head(id(2727),a36(583)).
head(id(2728),a6(870)).
head(id(2729),a10(870)).
head(id(2730),n(870)).
head(id(2731),a18(870)).
head(id(2732),a21(870)).
head(id(2733),a34(870)).
head(id(2734),a35(870)).
head(id(2735),a6(535)).
head(id(2736),a12(535)).
head(id(2737),a13(535)).
head(id(2738),n(535)).
head(id(2739),a26(535)).
head(id(2740),a35(535)).
head(id(2741),a6(808)).
head(id(2742),a13(808)).
head(id(2743),n(808)).
head(id(2744),a18(808)).
head(id(2745),a21(808)).
head(id(2746),a24(808)).
head(id(2747),a26(808)).
head(id(2748),a34(808)).
head(id(2749),a35(808)).
head(id(2750),a36(808)).
head(id(2751),a5(666)).
head(id(2752),a6(666)).
head(id(2753),a7(666)).
head(id(2754),a8(666)).
head(id(2755),a9(666)).
head(id(2756),n(666)).
head(id(2757),a18(666)).
head(id(2758),a26(666)).
head(id(2759),a34(666)).
head(id(2760),a35(666)).
head(id(2761),a36(666)).
head(id(2762),a5(868)).
head(id(2763),a10(868)).
head(id(2764),n(868)).
head(id(2765),a18(868)).
head(id(2766),a21(868)).
head(id(2767),a34(868)).
head(id(2768),a35(868)).
head(id(2769),a6(468)).
head(id(2770),a7(468)).
head(id(2771),a8(468)).
head(id(2772),a9(468)).
head(id(2773),a11(468)).
head(id(2774),n(468)).
head(id(2775),a18(468)).
head(id(2776),a24(468)).
head(id(2777),a26(468)).
head(id(2778),a34(468)).
head(id(2779),a10(901)).
head(id(2780),n(901)).
head(id(2781),a18(901)).
head(id(2782),a21(901)).
head(id(2783),a33(901)).
head(id(2784),a34(901)).
head(id(2785),a35(901)).
head(id(2786),a36(901)).
head(id(2787),a13(272)).
head(id(2788),n(272)).
head(id(2789),a18(272)).
head(id(2790),a24(272)).
head(id(2791),a30(272)).
head(id(2792),a34(272)).
head(id(2793),a35(272)).
head(id(2794),a1(452)).
head(id(2795),a6(452)).
head(id(2796),a7(452)).
head(id(2797),a11(452)).
head(id(2798),b(452)).
head(id(2799),a18(452)).
head(id(2800),a26(452)).
head(id(2801),a34(452)).
head(id(2802),a35(452)).
head(id(2803),a6(898)).
head(id(2804),a10(898)).
head(id(2805),a13(898)).
head(id(2806),n(898)).
head(id(2807),a18(898)).
head(id(2808),a21(898)).
head(id(2809),a24(898)).
head(id(2810),a33(898)).
head(id(2811),a34(898)).
head(id(2812),a35(898)).
head(id(2813),a36(898)).
head(id(2814),a13(5)).
head(id(2815),n(5)).
head(id(2816),a18(5)).
head(id(2817),a24(5)).
head(id(2818),a26(5)).
head(id(2819),a34(5)).
head(id(2820),a35(5)).
head(id(2821),a1(450)).
head(id(2822),a6(450)).
head(id(2823),a11(450)).
head(id(2824),n(450)).
head(id(2825),a18(450)).
head(id(2826),a24(450)).
head(id(2827),a26(450)).
head(id(2828),a34(450)).
head(id(2829),a10(854)).
head(id(2830),a11(854)).
head(id(2831),n(854)).
head(id(2832),a18(854)).
head(id(2833),a21(854)).
head(id(2834),a24(854)).
head(id(2835),a26(854)).
head(id(2836),a33(854)).
head(id(2837),a34(854)).
head(id(2838),a35(854)).
head(id(2839),a4(499)).
head(id(2840),a5(499)).
head(id(2841),a6(499)).
head(id(2842),n(499)).
head(id(2843),a18(499)).
head(id(2844),a35(499)).
head(id(2845),a5(340)).
head(id(2846),a6(340)).
head(id(2847),a7(340)).
head(id(2848),a8(340)).
head(id(2849),a9(340)).
head(id(2850),a13(340)).
head(id(2851),n(340)).
head(id(2852),a18(340)).
head(id(2853),a34(340)).
head(id(2854),a35(340)).
head(id(2855),a10(900)).
head(id(2856),n(900)).
head(id(2857),a18(900)).
head(id(2858),a21(900)).
head(id(2859),a34(900)).
head(id(2860),a35(900)).
head(id(2861),a36(900)).
head(id(2862),a4(421)).
head(id(2863),a6(421)).
head(id(2864),a9(421)).
head(id(2865),a11(421)).
head(id(2866),n(421)).
head(id(2867),a18(421)).
head(id(2868),a22(421)).
head(id(2869),a26(421)).
head(id(2870),a34(421)).
head(id(2871),a35(421)).
head(id(2872),a1(189)).
head(id(2873),a6(189)).
head(id(2874),a11(189)).
head(id(2875),a13(189)).
head(id(2876),n(189)).
head(id(2877),a18(189)).
head(id(2878),a26(189)).
head(id(2879),a31(189)).
head(id(2880),a34(189)).
head(id(2881),a6(322)).
head(id(2882),a9(322)).
head(id(2883),a13(322)).
head(id(2884),n(322)).
head(id(2885),a18(322)).
head(id(2886),a22(322)).
head(id(2887),a24(322)).
head(id(2888),a34(322)).
head(id(2889),a35(322)).
head(id(2890),a4(619)).
head(id(2891),a5(619)).
head(id(2892),a6(619)).
head(id(2893),a13(619)).
head(id(2894),n(619)).
head(id(2895),a18(619)).
head(id(2896),a34(619)).
head(id(2897),a35(619)).
head(id(2898),a36(619)).
head(id(2899),a13(603)).
head(id(2900),n(603)).
head(id(2901),a18(603)).
head(id(2902),a24(603)).
head(id(2903),a30(603)).
head(id(2904),a34(603)).
head(id(2905),a35(603)).
head(id(2906),a36(603)).
head(id(2907),a6(755)).
head(id(2908),a9(755)).
head(id(2909),a13(755)).
head(id(2910),n(755)).
head(id(2911),a21(755)).
head(id(2912),a22(755)).
head(id(2913),a33(755)).
head(id(2914),a34(755)).
head(id(2915),a35(755)).
head(id(2916),a4(723)).
head(id(2917),a5(723)).
head(id(2918),a6(723)).
head(id(2919),a13(723)).
head(id(2920),n(723)).
head(id(2921),a21(723)).
head(id(2922),a26(723)).
head(id(2923),a35(723)).
head(id(2924),a12(548)).
head(id(2925),n(548)).
head(id(2926),a18(548)).
head(id(2927),a26(548)).
head(id(2928),a34(548)).
head(id(2929),a35(548)).
head(id(2930),a5(590)).
head(id(2931),a6(590)).
head(id(2932),a7(590)).
head(id(2933),a13(590)).
head(id(2934),n(590)).
head(id(2935),a24(590)).
head(id(2936),a26(590)).
head(id(2937),a35(590)).
head(id(2938),a36(590)).
head(id(2939),a6(135)).
head(id(2940),a11(135)).
head(id(2941),a13(135)).
head(id(2942),n(135)).
head(id(2943),a18(135)).
head(id(2944),a26(135)).
head(id(2945),a31(135)).
head(id(2946),a34(135)).
head(id(2947),a35(135)).
head(id(2948),a5(579)).
head(id(2949),a6(579)).
head(id(2950),a7(579)).
head(id(2951),a13(579)).
head(id(2952),n(579)).
head(id(2953),a18(579)).
head(id(2954),a26(579)).
head(id(2955),a35(579)).
head(id(2956),a36(579)).
head(id(2957),a5(593)).
head(id(2958),a6(593)).
head(id(2959),a7(593)).
head(id(2960),a8(593)).
head(id(2961),a9(593)).
head(id(2962),a13(593)).
head(id(2963),n(593)).
head(id(2964),a18(593)).
head(id(2965),a26(593)).
head(id(2966),a34(593)).
head(id(2967),a35(593)).
head(id(2968),a36(593)).
head(id(2969),a6(405)).
head(id(2970),n(405)).
head(id(2971),a18(405)).
head(id(2972),a24(405)).
head(id(2973),a26(405)).
head(id(2974),a34(405)).
head(id(2975),a35(405)).
head(id(2976),a5(722)).
head(id(2977),a6(722)).
head(id(2978),a13(722)).
head(id(2979),n(722)).
head(id(2980),a21(722)).
head(id(2981),a26(722)).
head(id(2982),a35(722)).
head(id(2983),a12(696)).
head(id(2984),a13(696)).
head(id(2985),n(696)).
head(id(2986),a33(696)).
head(id(2987),a35(696)).
head(id(2988),a36(696)).
head(id(2989),n(490)).
head(id(2990),a17(490)).
head(id(2991),a18(490)).
head(id(2992),a24(490)).
head(id(2993),a34(490)).
head(id(2994),a35(490)).
head(id(2995),a1(445)).
head(id(2996),a6(445)).
head(id(2997),a11(445)).
head(id(2998),n(445)).
head(id(2999),a18(445)).
head(id(3000),a24(445)).
head(id(3001),a26(445)).
head(id(3002),a34(445)).
head(id(3003),a35(445)).
head(id(3004),a1(375)).
head(id(3005),a11(375)).
head(id(3006),n(375)).
head(id(3007),a18(375)).
head(id(3008),a26(375)).
head(id(3009),a34(375)).
head(id(3010),a5(62)).
head(id(3011),a7(62)).
head(id(3012),a13(62)).
head(id(3013),n(62)).
head(id(3014),a26(62)).
head(id(3015),a34(62)).
head(id(3016),a35(62)).
head(id(3017),a6(208)).
head(id(3018),a7(208)).
head(id(3019),a13(208)).
head(id(3020),n(208)).
head(id(3021),a26(208)).
head(id(3022),a34(208)).
head(id(3023),a35(208)).
head(id(3024),a6(826)).
head(id(3025),a13(826)).
head(id(3026),n(826)).
head(id(3027),a21(826)).
head(id(3028),a35(826)).
head(id(3029),a36(826)).
head(id(3030),a5(676)).
head(id(3031),a7(676)).
head(id(3032),n(676)).
head(id(3033),a18(676)).
head(id(3034),a24(676)).
head(id(3035),a34(676)).
head(id(3036),a35(676)).
head(id(3037),a36(676)).
head(id(3038),a6(532)).
head(id(3039),a9(532)).
head(id(3040),a12(532)).
head(id(3041),a13(532)).
head(id(3042),n(532)).
head(id(3043),a18(532)).
head(id(3044),a22(532)).
head(id(3045),a26(532)).
head(id(3046),a34(532)).
head(id(3047),a35(532)).
head(id(3048),a5(776)).
head(id(3049),a6(776)).
head(id(3050),a7(776)).
head(id(3051),n(776)).
head(id(3052),a18(776)).
head(id(3053),a21(776)).
head(id(3054),a24(776)).
head(id(3055),a34(776)).
head(id(3056),a35(776)).
head(id(3057),a12(702)).
head(id(3058),n(702)).
head(id(3059),a18(702)).
head(id(3060),a24(702)).
head(id(3061),a34(702)).
head(id(3062),a35(702)).
head(id(3063),a36(702)).
head(id(3064),a5(323)).
head(id(3065),a6(323)).
head(id(3066),a7(323)).
head(id(3067),a9(323)).
head(id(3068),a13(323)).
head(id(3069),n(323)).
head(id(3070),a18(323)).
head(id(3071),a22(323)).
head(id(3072),a24(323)).
head(id(3073),a34(323)).
head(id(3074),a35(323)).
head(id(3075),a13(606)).
head(id(3076),n(606)).
head(id(3077),a34(606)).
head(id(3078),a35(606)).
head(id(3079),a36(606)).
head(id(3080),a7(356)).
head(id(3081),a9(356)).
head(id(3082),n(356)).
head(id(3083),a18(356)).
head(id(3084),a22(356)).
head(id(3085),a24(356)).
head(id(3086),a26(356)).
head(id(3087),a34(356)).
head(id(3088),a35(356)).
head(id(3089),a5(127)).
head(id(3090),a6(127)).
head(id(3091),a7(127)).
head(id(3092),a9(127)).
head(id(3093),a13(127)).
head(id(3094),n(127)).
head(id(3095),a18(127)).
head(id(3096),a22(127)).
head(id(3097),a26(127)).
head(id(3098),a34(127)).
head(id(3099),a35(127)).
head(id(3100),n(481)).
head(id(3101),a18(481)).
head(id(3102),a24(481)).
head(id(3103),a34(481)).
head(id(3104),a35(481)).
head(id(3105),a5(594)).
head(id(3106),a6(594)).
head(id(3107),a7(594)).
head(id(3108),a8(594)).
head(id(3109),a9(594)).
head(id(3110),a13(594)).
head(id(3111),n(594)).
head(id(3112),a18(594)).
head(id(3113),a26(594)).
head(id(3114),a35(594)).
head(id(3115),a36(594)).
head(id(3116),a9(92)).
head(id(3117),a11(92)).
head(id(3118),a13(92)).
head(id(3119),w(92)).
head(id(3120),a22(92)).
head(id(3121),a24(92)).
head(id(3122),a26(92)).
head(id(3123),a34(92)).
head(id(3124),a35(92)).
head(id(3125),a5(456)).
head(id(3126),a6(456)).
head(id(3127),n(456)).
head(id(3128),a24(456)).
head(id(3129),a26(456)).
head(id(3130),a33(456)).
head(id(3131),a35(456)).
head(id(3132),a5(288)).
head(id(3133),a13(288)).
head(id(3134),n(288)).
head(id(3135),a24(288)).
head(id(3136),a34(288)).
head(id(3137),a35(288)).
head(id(3138),a2(283)).
head(id(3139),a13(283)).
head(id(3140),n(283)).
head(id(3141),a33(283)).
head(id(3142),a35(283)).
head(id(3143),a9(368)).
head(id(3144),a11(368)).
head(id(3145),n(368)).
head(id(3146),a18(368)).
head(id(3147),a22(368)).
head(id(3148),a24(368)).
head(id(3149),a26(368)).
head(id(3150),a34(368)).
head(id(3151),a35(368)).
head(id(3152),a6(324)).
head(id(3153),a13(324)).
head(id(3154),n(324)).
head(id(3155),a34(324)).
head(id(3156),a35(324)).
head(id(3157),a10(850)).
head(id(3158),a11(850)).
head(id(3159),n(850)).
head(id(3160),a18(850)).
head(id(3161),a21(850)).
head(id(3162),a26(850)).
head(id(3163),a34(850)).
head(id(3164),a35(850)).
head(id(3165),a4(455)).
head(id(3166),a5(455)).
head(id(3167),a6(455)).
head(id(3168),n(455)).
head(id(3169),a24(455)).
head(id(3170),a26(455)).
head(id(3171),a35(455)).
head(id(3172),a5(844)).
head(id(3173),a6(844)).
head(id(3174),a7(844)).
head(id(3175),a8(844)).
head(id(3176),a9(844)).
head(id(3177),a10(844)).
head(id(3178),a13(844)).
head(id(3179),n(844)).
head(id(3180),a18(844)).
head(id(3181),a21(844)).
head(id(3182),a26(844)).
head(id(3183),a34(844)).
head(id(3184),a35(844)).
head(id(3185),a1(48)).
head(id(3186),a11(48)).
head(id(3187),a13(48)).
head(id(3188),n(48)).
head(id(3189),a18(48)).
head(id(3190),a20(48)).
head(id(3191),a24(48)).
head(id(3192),a26(48)).
head(id(3193),a34(48)).
head(id(3194),a13(568)).
head(id(3195),n(568)).
head(id(3196),a26(568)).
head(id(3197),a33(568)).
head(id(3198),a35(568)).
head(id(3199),a36(568)).
head(id(3200),a10(889)).
head(id(3201),a13(889)).
head(id(3202),n(889)).
head(id(3203),a18(889)).
head(id(3204),a21(889)).
head(id(3205),a24(889)).
head(id(3206),a34(889)).
head(id(3207),a35(889)).
head(id(3208),a36(889)).
head(id(3209),a4(618)).
head(id(3210),a6(618)).
head(id(3211),a13(618)).
head(id(3212),n(618)).
head(id(3213),a18(618)).
head(id(3214),a35(618)).
head(id(3215),a36(618)).
head(id(3216),a5(386)).
head(id(3217),a7(386)).
head(id(3218),a8(386)).
head(id(3219),a9(386)).
head(id(3220),a11(386)).
head(id(3221),n(386)).
head(id(3222),a18(386)).
head(id(3223),a24(386)).
head(id(3224),a26(386)).
head(id(3225),a34(386)).
head(id(3226),a35(386)).
head(id(3227),a6(896)).
head(id(3228),a7(896)).
head(id(3229),a10(896)).
head(id(3230),a13(896)).
head(id(3231),n(896)).
head(id(3232),a18(896)).
head(id(3233),a21(896)).
head(id(3234),a33(896)).
head(id(3235),a34(896)).
head(id(3236),a35(896)).
head(id(3237),a36(896)).
head(id(3238),a6(473)).
head(id(3239),a9(473)).
head(id(3240),a11(473)).
head(id(3241),n(473)).
head(id(3242),a18(473)).
head(id(3243),a22(473)).
head(id(3244),a23(473)).
head(id(3245),a26(473)).
head(id(3246),a34(473)).
head(id(3247),a35(473)).
head(id(3248),a13(711)).
head(id(3249),n(711)).
head(id(3250),a21(711)).
head(id(3251),a26(711)).
head(id(3252),a33(711)).
head(id(3253),a35(711)).
head(id(3254),a6(174)).
head(id(3255),a11(174)).
head(id(3256),a13(174)).
head(id(3257),w(174)).
head(id(3258),a18(174)).
head(id(3259),a26(174)).
head(id(3260),a31(174)).
head(id(3261),a34(174)).
head(id(3262),a5(37)).
head(id(3263),a7(37)).
head(id(3264),a11(37)).
head(id(3265),a13(37)).
head(id(3266),w(37)).
head(id(3267),a18(37)).
head(id(3268),a20(37)).
head(id(3269),a26(37)).
head(id(3270),a34(37)).
head(id(3271),a6(591)).
head(id(3272),a13(591)).
head(id(3273),n(591)).
head(id(3274),a24(591)).
head(id(3275),a26(591)).
head(id(3276),a33(591)).
head(id(3277),a35(591)).
head(id(3278),a36(591)).
head(id(3279),a13(564)).
head(id(3280),n(564)).
head(id(3281),a26(564)).
head(id(3282),a34(564)).
head(id(3283),a35(564)).
head(id(3284),a36(564)).
head(id(3285),a10(881)).
head(id(3286),a13(881)).
head(id(3287),n(881)).
head(id(3288),a21(881)).
head(id(3289),a24(881)).
head(id(3290),a26(881)).
head(id(3291),a34(881)).
head(id(3292),a35(881)).
head(id(3293),a36(881)).
head(id(3294),a6(301)).
head(id(3295),a13(301)).
head(id(3296),n(301)).
head(id(3297),a18(301)).
head(id(3298),a35(301)).
head(id(3299),a6(744)).
head(id(3300),a9(744)).
head(id(3301),a13(744)).
head(id(3302),n(744)).
head(id(3303),a18(744)).
head(id(3304),a21(744)).
head(id(3305),a22(744)).
head(id(3306),a34(744)).
head(id(3307),a35(744)).
head(id(3308),a6(426)).
head(id(3309),a7(426)).
head(id(3310),a11(426)).
head(id(3311),n(426)).
head(id(3312),a18(426)).
head(id(3313),a24(426)).
head(id(3314),a26(426)).
head(id(3315),a34(426)).
head(id(3316),a35(426)).
head(id(3317),a1(447)).
head(id(3318),a5(447)).
head(id(3319),a6(447)).
head(id(3320),a7(447)).
head(id(3321),a11(447)).
head(id(3322),n(447)).
head(id(3323),a18(447)).
head(id(3324),a24(447)).
head(id(3325),a26(447)).
head(id(3326),a34(447)).
head(id(3327),a35(447)).
head(id(3328),a6(865)).
head(id(3329),a10(865)).
head(id(3330),a11(865)).
head(id(3331),n(865)).
head(id(3332),a18(865)).
head(id(3333),a21(865)).
head(id(3334),a24(865)).
head(id(3335),a26(865)).
head(id(3336),a34(865)).
head(id(3337),a35(865)).
head(id(3338),a5(88)).
head(id(3339),a7(88)).
head(id(3340),a11(88)).
head(id(3341),a13(88)).
head(id(3342),w(88)).
head(id(3343),a26(88)).
head(id(3344),a35(88)).
head(id(3345),a9(538)).
head(id(3346),a12(538)).
head(id(3347),a13(538)).
head(id(3348),n(538)).
head(id(3349),a18(538)).
head(id(3350),a22(538)).
head(id(3351),a34(538)).
head(id(3352),a35(538)).
head(id(3353),n(763)).
head(id(3354),a18(763)).
head(id(3355),a21(763)).
head(id(3356),a24(763)).
head(id(3357),a26(763)).
head(id(3358),a30(763)).
head(id(3359),a33(763)).
head(id(3360),a34(763)).
head(id(3361),a35(763)).
head(id(3362),a6(864)).
head(id(3363),a7(864)).
head(id(3364),a10(864)).
head(id(3365),a11(864)).
head(id(3366),n(864)).
head(id(3367),a18(864)).
head(id(3368),a21(864)).
head(id(3369),a26(864)).
head(id(3370),a33(864)).
head(id(3371),a34(864)).
head(id(3372),a35(864)).
head(id(3373),a6(143)).
head(id(3374),a9(143)).
head(id(3375),a11(143)).
head(id(3376),a13(143)).
head(id(3377),n(143)).
head(id(3378),a18(143)).
head(id(3379),a22(143)).
head(id(3380),a26(143)).
head(id(3381),a31(143)).
head(id(3382),a34(143)).
head(id(3383),a35(143)).
head(id(3384),a5(16)).
head(id(3385),a11(16)).
head(id(3386),a13(16)).
head(id(3387),n(16)).
head(id(3388),a18(16)).
head(id(3389),a24(16)).
head(id(3390),a26(16)).
head(id(3391),a34(16)).
head(id(3392),a35(16)).
head(id(3393),a6(125)).
head(id(3394),a13(125)).
head(id(3395),n(125)).
head(id(3396),a18(125)).
head(id(3397),a26(125)).
head(id(3398),a33(125)).
head(id(3399),a35(125)).
head(id(3400),a5(77)).
head(id(3401),a11(77)).
head(id(3402),a13(77)).
head(id(3403),n(77)).
head(id(3404),a24(77)).
head(id(3405),a26(77)).
head(id(3406),a35(77)).
head(id(3407),a6(431)).
head(id(3408),a11(431)).
head(id(3409),n(431)).
head(id(3410),a18(431)).
head(id(3411),a26(431)).
head(id(3412),a34(431)).
head(id(3413),a9(799)).
head(id(3414),a13(799)).
head(id(3415),n(799)).
head(id(3416),a18(799)).
head(id(3417),a21(799)).
head(id(3418),a22(799)).
head(id(3419),a24(799)).
head(id(3420),a26(799)).
head(id(3421),a33(799)).
head(id(3422),a34(799)).
head(id(3423),a35(799)).
head(id(3424),a36(799)).
head(id(3425),a5(27)).
head(id(3426),a7(27)).
head(id(3427),a11(27)).
head(id(3428),a13(27)).
head(id(3429),w(27)).
head(id(3430),a18(27)).
head(id(3431),a26(27)).
head(id(3432),a34(27)).
head(id(3433),a35(27)).
head(id(3434),a4(509)).
head(id(3435),a6(509)).
head(id(3436),n(509)).
head(id(3437),a18(509)).
head(id(3438),a24(509)).
head(id(3439),a35(509)).
head(id(3440),a6(122)).
head(id(3441),a7(122)).
head(id(3442),a13(122)).
head(id(3443),n(122)).
head(id(3444),a18(122)).
head(id(3445),a26(122)).
head(id(3446),a35(122)).
head(id(3447),a13(265)).
head(id(3448),n(265)).
head(id(3449),a18(265)).
head(id(3450),a34(265)).
head(id(3451),a35(265)).
head(id(3452),a5(622)).
head(id(3453),a6(622)).
head(id(3454),a7(622)).
head(id(3455),a13(622)).
head(id(3456),n(622)).
head(id(3457),a18(622)).
head(id(3458),a35(622)).
head(id(3459),a36(622)).
head(id(3460),a13(804)).
head(id(3461),n(804)).
head(id(3462),a21(804)).
head(id(3463),a24(804)).
head(id(3464),a26(804)).
head(id(3465),a35(804)).
head(id(3466),a36(804)).
head(id(3467),n(488)).
head(id(3468),a17(488)).
head(id(3469),a18(488)).
head(id(3470),a34(488)).
head(id(3471),a35(488)).
head(id(3472),a6(333)).
head(id(3473),a13(333)).
head(id(3474),n(333)).
head(id(3475),a24(333)).
head(id(3476),a34(333)).
head(id(3477),a35(333)).
head(id(3478),n(648)).
head(id(3479),a18(648)).
head(id(3480),a24(648)).
head(id(3481),a26(648)).
head(id(3482),a34(648)).
head(id(3483),a35(648)).
head(id(3484),a36(648)).
head(id(3485),a9(21)).
head(id(3486),a11(21)).
head(id(3487),a13(21)).
head(id(3488),n(21)).
head(id(3489),a18(21)).
head(id(3490),a20(21)).
head(id(3491),a22(21)).
head(id(3492),a24(21)).
head(id(3493),a26(21)).
head(id(3494),a31(21)).
head(id(3495),a34(21)).
head(id(3496),a35(21)).
head(id(3497),a6(144)).
head(id(3498),a9(144)).
head(id(3499),a11(144)).
head(id(3500),a13(144)).
head(id(3501),n(144)).
head(id(3502),a18(144)).
head(id(3503),a22(144)).
head(id(3504),a26(144)).
head(id(3505),a31(144)).
head(id(3506),a35(144)).
head(id(3507),a5(609)).
head(id(3508),a7(609)).
head(id(3509),a13(609)).
head(id(3510),n(609)).
head(id(3511),a35(609)).
head(id(3512),a36(609)).
head(id(3513),a6(212)).
head(id(3514),a13(212)).
head(id(3515),n(212)).
head(id(3516),a26(212)).
head(id(3517),a33(212)).
head(id(3518),a35(212)).
head(id(3519),a6(390)).
head(id(3520),n(390)).
head(id(3521),a18(390)).
head(id(3522),a26(390)).
head(id(3523),a35(390)).
head(id(3524),a6(248)).
head(id(3525),a7(248)).
head(id(3526),a8(248)).
head(id(3527),a9(248)).
head(id(3528),a13(248)).
head(id(3529),n(248)).
head(id(3530),a18(248)).
head(id(3531),a26(248)).
head(id(3532),a35(248)).
head(id(3533),a9(727)).
head(id(3534),a13(727)).
head(id(3535),n(727)).
head(id(3536),a18(727)).
head(id(3537),a21(727)).
head(id(3538),a22(727)).
head(id(3539),a34(727)).
head(id(3540),a35(727)).
head(id(3541),a5(803)).
head(id(3542),a13(803)).
head(id(3543),n(803)).
head(id(3544),a21(803)).
head(id(3545),a26(803)).
head(id(3546),a33(803)).
head(id(3547),a35(803)).
head(id(3548),a36(803)).
head(id(3549),a6(396)).
head(id(3550),a7(396)).
head(id(3551),n(396)).
head(id(3552),a18(396)).
head(id(3553),a26(396)).
head(id(3554),a34(396)).
head(id(3555),a35(396)).
head(id(3556),a12(784)).
head(id(3557),a13(784)).
head(id(3558),n(784)).
head(id(3559),a18(784)).
head(id(3560),a21(784)).
head(id(3561),a33(784)).
head(id(3562),a34(784)).
head(id(3563),a35(784)).
head(id(3564),a9(731)).
head(id(3565),a13(731)).
head(id(3566),n(731)).
head(id(3567),a18(731)).
head(id(3568),a21(731)).
head(id(3569),a22(731)).
head(id(3570),a24(731)).
head(id(3571),a34(731)).
head(id(3572),a35(731)).
head(id(3573),a10(891)).
head(id(3574),a13(891)).
head(id(3575),n(891)).
head(id(3576),a18(891)).
head(id(3577),a21(891)).
head(id(3578),a24(891)).
head(id(3579),a33(891)).
head(id(3580),a34(891)).
head(id(3581),a35(891)).
head(id(3582),a36(891)).
head(id(3583),a6(781)).
head(id(3584),a12(781)).
head(id(3585),a13(781)).
head(id(3586),n(781)).
head(id(3587),a18(781)).
head(id(3588),a21(781)).
head(id(3589),a26(781)).
head(id(3590),a33(781)).
head(id(3591),a34(781)).
head(id(3592),a35(781)).
head(id(3593),a6(467)).
head(id(3594),a7(467)).
head(id(3595),a8(467)).
head(id(3596),a9(467)).
head(id(3597),a11(467)).
head(id(3598),n(467)).
head(id(3599),a18(467)).
head(id(3600),a26(467)).
head(id(3601),a34(467)).
head(id(3602),a7(96)).
head(id(3603),a11(96)).
head(id(3604),a13(96)).
head(id(3605),w(96)).
head(id(3606),a26(96)).
head(id(3607),a34(96)).
head(id(3608),a6(581)).
head(id(3609),a13(581)).
head(id(3610),n(581)).
head(id(3611),a26(581)).
head(id(3612),a35(581)).
head(id(3613),a36(581)).
head(id(3614),a6(639)).
head(id(3615),a13(639)).
head(id(3616),n(639)).
head(id(3617),a24(639)).
head(id(3618),a35(639)).
head(id(3619),a36(639)).
head(id(3620),a9(293)).
head(id(3621),a13(293)).
head(id(3622),n(293)).
head(id(3623),a22(293)).
head(id(3624),a24(293)).
head(id(3625),a34(293)).
head(id(3626),a35(293)).
head(id(3627),a6(827)).
head(id(3628),a13(827)).
head(id(3629),n(827)).
head(id(3630),a21(827)).
head(id(3631),a33(827)).
head(id(3632),a35(827)).
head(id(3633),a36(827)).
head(id(3634),a5(621)).
head(id(3635),a6(621)).
head(id(3636),a7(621)).
head(id(3637),a13(621)).
head(id(3638),n(621)).
head(id(3639),a18(621)).
head(id(3640),a34(621)).
head(id(3641),a35(621)).
head(id(3642),a36(621)).
head(id(3643),a1(446)).
head(id(3644),a6(446)).
head(id(3645),a7(446)).
head(id(3646),a11(446)).
head(id(3647),n(446)).
head(id(3648),a18(446)).
head(id(3649),a24(446)).
head(id(3650),a26(446)).
head(id(3651),a34(446)).
head(id(3652),a35(446)).
head(id(3653),a5(309)).
head(id(3654),a6(309)).
head(id(3655),a13(309)).
head(id(3656),n(309)).
head(id(3657),a18(309)).
head(id(3658),a33(309)).
head(id(3659),a35(309)).
head(id(3660),a13(733)).
head(id(3661),n(733)).
head(id(3662),a21(733)).
head(id(3663),a35(733)).
head(id(3664),a9(284)).
head(id(3665),a13(284)).
head(id(3666),n(284)).
head(id(3667),a22(284)).
head(id(3668),a34(284)).
head(id(3669),a35(284)).
head(id(3670),a6(436)).
head(id(3671),a11(436)).
head(id(3672),n(436)).
head(id(3673),a18(436)).
head(id(3674),a24(436)).
head(id(3675),a26(436)).
head(id(3676),a34(436)).
head(id(3677),a13(729)).
head(id(3678),n(729)).
head(id(3679),a18(729)).
head(id(3680),a21(729)).
head(id(3681),a24(729)).
head(id(3682),a34(729)).
head(id(3683),a35(729)).
head(id(3684),a6(859)).
head(id(3685),a10(859)).
head(id(3686),n(859)).
head(id(3687),a18(859)).
head(id(3688),a21(859)).
head(id(3689),a24(859)).
head(id(3690),a26(859)).
head(id(3691),a34(859)).
head(id(3692),a35(859)).
head(id(3693),a1(247)).
head(id(3694),a5(247)).
head(id(3695),a6(247)).
head(id(3696),a11(247)).
head(id(3697),a13(247)).
head(id(3698),n(247)).
head(id(3699),a26(247)).
head(id(3700),a35(247)).
head(id(3701),a9(541)).
head(id(3702),a12(541)).
head(id(3703),a13(541)).
head(id(3704),n(541)).
head(id(3705),a18(541)).
head(id(3706),a22(541)).
head(id(3707),a24(541)).
head(id(3708),a34(541)).
head(id(3709),a35(541)).
head(id(3710),a9(7)).
head(id(3711),a13(7)).
head(id(3712),n(7)).
head(id(3713),a18(7)).
head(id(3714),a22(7)).
head(id(3715),a24(7)).
head(id(3716),a26(7)).
head(id(3717),a34(7)).
head(id(3718),a35(7)).
head(id(3719),a9(489)).
head(id(3720),n(489)).
head(id(3721),a17(489)).
head(id(3722),a18(489)).
head(id(3723),a22(489)).
head(id(3724),a34(489)).
head(id(3725),a35(489)).
head(id(3726),a5(271)).
head(id(3727),a13(271)).
head(id(3728),n(271)).
head(id(3729),a18(271)).
head(id(3730),a24(271)).
head(id(3731),a34(271)).
head(id(3732),a35(271)).
head(id(3733),a3(132)).
head(id(3734),a5(132)).
head(id(3735),a6(132)).
head(id(3736),a7(132)).
head(id(3737),a13(132)).
head(id(3738),n(132)).
head(id(3739),a18(132)).
head(id(3740),a24(132)).
head(id(3741),a26(132)).
head(id(3742),a35(132)).
head(id(3743),a5(409)).
head(id(3744),a6(409)).
head(id(3745),a7(409)).
head(id(3746),n(409)).
head(id(3747),a18(409)).
head(id(3748),a24(409)).
head(id(3749),a26(409)).
head(id(3750),a34(409)).
head(id(3751),a35(409)).
head(id(3752),a5(307)).
head(id(3753),a6(307)).
head(id(3754),a7(307)).
head(id(3755),a13(307)).
head(id(3756),n(307)).
head(id(3757),a18(307)).
head(id(3758),a34(307)).
head(id(3759),a35(307)).
head(id(3760),a5(642)).
head(id(3761),a6(642)).
head(id(3762),a13(642)).
head(id(3763),n(642)).
head(id(3764),a24(642)).
head(id(3765),a33(642)).
head(id(3766),a35(642)).
head(id(3767),a36(642)).
head(id(3768),a12(556)).
head(id(3769),n(556)).
head(id(3770),a18(556)).
head(id(3771),a24(556)).
head(id(3772),a34(556)).
head(id(3773),a35(556)).
head(id(3774),a5(513)).
head(id(3775),a6(513)).
head(id(3776),n(513)).
head(id(3777),a24(513)).
head(id(3778),a35(513)).
head(id(3779),a3(661)).
head(id(3780),a6(661)).
head(id(3781),n(661)).
head(id(3782),a18(661)).
head(id(3783),a24(661)).
head(id(3784),a26(661)).
head(id(3785),a35(661)).
head(id(3786),a36(661)).
head(id(3787),a5(73)).
head(id(3788),a11(73)).
head(id(3789),a13(73)).
head(id(3790),n(73)).
head(id(3791),a26(73)).
head(id(3792),a31(73)).
head(id(3793),a35(73)).
head(id(3794),a12(542)).
head(id(3795),a13(542)).
head(id(3796),n(542)).
head(id(3797),a34(542)).
head(id(3798),a35(542)).
head(id(3799),a5(338)).
head(id(3800),a6(338)).
head(id(3801),a13(338)).
head(id(3802),n(338)).
head(id(3803),a24(338)).
head(id(3804),a33(338)).
head(id(3805),a35(338)).
head(id(3806),a5(500)).
head(id(3807),a6(500)).
head(id(3808),a7(500)).
head(id(3809),n(500)).
head(id(3810),a18(500)).
head(id(3811),a34(500)).
head(id(3812),a35(500)).
head(id(3813),a6(398)).
head(id(3814),n(398)).
head(id(3815),a18(398)).
head(id(3816),a26(398)).
head(id(3817),a33(398)).
head(id(3818),a35(398)).
head(id(3819),a5(124)).
head(id(3820),a6(124)).
head(id(3821),a7(124)).
head(id(3822),a13(124)).
head(id(3823),n(124)).
head(id(3824),a18(124)).
head(id(3825),a26(124)).
head(id(3826),a35(124)).
head(id(3827),a6(718)).
head(id(3828),a9(718)).
head(id(3829),a13(718)).
head(id(3830),n(718)).
head(id(3831),a18(718)).
head(id(3832),a21(718)).
head(id(3833),a22(718)).
head(id(3834),a26(718)).
head(id(3835),a34(718)).
head(id(3836),a35(718)).
head(id(3837),a11(33)).
head(id(3838),a13(33)).
head(id(3839),w(33)).
head(id(3840),a18(33)).
head(id(3841),a26(33)).
head(id(3842),a34(33)).
head(id(3843),a5(710)).
head(id(3844),a13(710)).
head(id(3845),n(710)).
head(id(3846),a21(710)).
head(id(3847),a26(710)).
head(id(3848),a35(710)).
head(id(3849),a5(574)).
head(id(3850),a7(574)).
head(id(3851),a8(574)).
head(id(3852),a9(574)).
head(id(3853),a13(574)).
head(id(3854),n(574)).
head(id(3855),a26(574)).
head(id(3856),a35(574)).
head(id(3857),a36(574)).
head(id(3858),a5(615)).
head(id(3859),a7(615)).
head(id(3860),a8(615)).
head(id(3861),a9(615)).
head(id(3862),a13(615)).
head(id(3863),n(615)).
head(id(3864),a18(615)).
head(id(3865),a24(615)).
head(id(3866),a34(615)).
head(id(3867),a35(615)).
head(id(3868),a36(615)).
head(id(3869),a6(756)).
head(id(3870),a13(756)).
head(id(3871),n(756)).
head(id(3872),a21(756)).
head(id(3873),a24(756)).
head(id(3874),a35(756)).
head(id(3875),a5(401)).
head(id(3876),a6(401)).
head(id(3877),a9(401)).
head(id(3878),n(401)).
head(id(3879),a18(401)).
head(id(3880),a22(401)).
head(id(3881),a26(401)).
head(id(3882),a34(401)).
head(id(3883),a35(401)).
head(id(3884),a1(187)).
head(id(3885),a6(187)).
head(id(3886),a7(187)).
head(id(3887),a11(187)).
head(id(3888),a13(187)).
head(id(3889),n(187)).
head(id(3890),a18(187)).
head(id(3891),a24(187)).
head(id(3892),a26(187)).
head(id(3893),a34(187)).
head(id(3894),a35(187)).
head(id(3895),a6(213)).
head(id(3896),a13(213)).
head(id(3897),n(213)).
head(id(3898),a24(213)).
head(id(3899),a26(213)).
head(id(3900),a34(213)).
head(id(3901),a35(213)).
head(id(3902),a11(83)).
head(id(3903),a13(83)).
head(id(3904),n(83)).
head(id(3905),a24(83)).
head(id(3906),a26(83)).
head(id(3907),a31(83)).
head(id(3908),a33(83)).
head(id(3909),a6(787)).
head(id(3910),a12(787)).
head(id(3911),a13(787)).
head(id(3912),n(787)).
head(id(3913),a21(787)).
head(id(3914),a35(787)).
head(id(3915),a5(599)).
head(id(3916),a7(599)).
head(id(3917),a13(599)).
head(id(3918),n(599)).
head(id(3919),a18(599)).
head(id(3920),a34(599)).
head(id(3921),a35(599)).
head(id(3922),a36(599)).
head(id(3923),a6(632)).
head(id(3924),a13(632)).
head(id(3925),n(632)).
head(id(3926),a34(632)).
head(id(3927),a35(632)).
head(id(3928),a36(632)).
head(id(3929),a13(562)).
head(id(3930),n(562)).
head(id(3931),a18(562)).
head(id(3932),a24(562)).
head(id(3933),a26(562)).
head(id(3934),a34(562)).
head(id(3935),a35(562)).
head(id(3936),a36(562)).
head(id(3937),a13(805)).
head(id(3938),n(805)).
head(id(3939),a21(805)).
head(id(3940),a24(805)).
head(id(3941),a26(805)).
head(id(3942),a33(805)).
head(id(3943),a35(805)).
head(id(3944),a36(805)).
head(id(3945),a7(115)).
head(id(3946),a8(115)).
head(id(3947),a9(115)).
head(id(3948),a11(115)).
head(id(3949),a13(115)).
head(id(3950),w(115)).
head(id(3951),a26(115)).
head(id(3952),a35(115)).
head(id(3953),a5(369)).
head(id(3954),a9(369)).
head(id(3955),a11(369)).
head(id(3956),n(369)).
head(id(3957),a18(369)).
head(id(3958),a22(369)).
head(id(3959),a24(369)).
head(id(3960),a26(369)).
head(id(3961),a34(369)).
head(id(3962),a35(369)).
head(id(3963),a6(786)).
head(id(3964),a12(786)).
head(id(3965),a13(786)).
head(id(3966),n(786)).
head(id(3967),a18(786)).
head(id(3968),a21(786)).
head(id(3969),a33(786)).
head(id(3970),a34(786)).
head(id(3971),a35(786)).
head(id(3972),a5(561)).
head(id(3973),a7(561)).
head(id(3974),a13(561)).
head(id(3975),n(561)).
head(id(3976),a18(561)).
head(id(3977),a26(561)).
head(id(3978),a34(561)).
head(id(3979),a35(561)).
head(id(3980),a36(561)).
head(id(3981),a13(818)).
head(id(3982),n(818)).
head(id(3983),a21(818)).
head(id(3984),a35(818)).
head(id(3985),a36(818)).
head(id(3986),n(345)).
head(id(3987),a18(345)).
head(id(3988),a26(345)).
head(id(3989),a34(345)).
head(id(3990),a35(345)).
head(id(3991),a5(344)).
head(id(3992),a6(344)).
head(id(3993),a7(344)).
head(id(3994),a8(344)).
head(id(3995),a9(344)).
head(id(3996),a13(344)).
head(id(3997),n(344)).
head(id(3998),a35(344)).
head(id(3999),a5(462)).
head(id(4000),a6(462)).
head(id(4001),a7(462)).
head(id(4002),a8(462)).
head(id(4003),a9(462)).
head(id(4004),n(462)).
head(id(4005),a18(462)).
head(id(4006),a22(462)).
head(id(4007),a26(462)).
head(id(4008),a34(462)).
head(id(4009),a35(462)).
head(id(4010),a6(389)).
head(id(4011),n(389)).
head(id(4012),a18(389)).
head(id(4013),a26(389)).
head(id(4014),a34(389)).
head(id(4015),a35(389)).
head(id(4016),a1(451)).
head(id(4017),a6(451)).
head(id(4018),a11(451)).
head(id(4019),b(451)).
head(id(4020),a18(451)).
head(id(4021),a26(451)).
head(id(4022),a34(451)).
head(id(4023),a35(451)).
head(id(4024),a6(465)).
head(id(4025),a7(465)).
head(id(4026),a8(465)).
head(id(4027),a9(465)).
head(id(4028),a11(465)).
head(id(4029),n(465)).
head(id(4030),a18(465)).
head(id(4031),a22(465)).
head(id(4032),a26(465)).
head(id(4033),a34(465)).
head(id(4034),a35(465)).
head(id(4035),a5(343)).
head(id(4036),a6(343)).
head(id(4037),a7(343)).
head(id(4038),a8(343)).
head(id(4039),a9(343)).
head(id(4040),a13(343)).
head(id(4041),n(343)).
head(id(4042),a18(343)).
head(id(4043),a24(343)).
head(id(4044),a34(343)).
head(id(4045),a35(343)).
head(id(4046),a6(790)).
head(id(4047),a12(790)).
head(id(4048),n(790)).
head(id(4049),a18(790)).
head(id(4050),a21(790)).
head(id(4051),a26(790)).
head(id(4052),a34(790)).
head(id(4053),a35(790)).
head(id(4054),a11(85)).
head(id(4055),a13(85)).
head(id(4056),w(85)).
head(id(4057),a26(85)).
head(id(4058),a31(85)).
head(id(4059),a35(85)).
head(id(4060),a5(233)).
head(id(4061),a6(233)).
head(id(4062),a7(233)).
head(id(4063),a11(233)).
head(id(4064),a13(233)).
head(id(4065),n(233)).
head(id(4066),a24(233)).
head(id(4067),a26(233)).
head(id(4068),a4(364)).
head(id(4069),a5(364)).
head(id(4070),a9(364)).
head(id(4071),a11(364)).
head(id(4072),n(364)).
head(id(4073),a18(364)).
head(id(4074),a22(364)).
head(id(4075),a26(364)).
head(id(4076),a34(364)).
head(id(4077),a35(364)).
head(id(4078),a9(522)).
head(id(4079),a12(522)).
head(id(4080),a13(522)).
head(id(4081),n(522)).
head(id(4082),a18(522)).
head(id(4083),a22(522)).
head(id(4084),a26(522)).
head(id(4085),a34(522)).
head(id(4086),a35(522)).
head(id(4087),a5(829)).
head(id(4088),a10(829)).
head(id(4089),a13(829)).
head(id(4090),n(829)).
head(id(4091),a18(829)).
head(id(4092),a21(829)).
head(id(4093),a26(829)).
head(id(4094),a34(829)).
head(id(4095),a35(829)).
head(id(4096),a6(234)).
head(id(4097),a11(234)).
head(id(4098),a13(234)).
head(id(4099),n(234)).
head(id(4100),a24(234)).
head(id(4101),a26(234)).
head(id(4102),a31(234)).
head(id(4103),a33(234)).
head(id(4104),a5(422)).
head(id(4105),a6(422)).
head(id(4106),a9(422)).
head(id(4107),a11(422)).
head(id(4108),n(422)).
head(id(4109),a18(422)).
head(id(4110),a22(422)).
head(id(4111),a26(422)).
head(id(4112),a34(422)).
head(id(4113),a35(422)).
head(id(4114),a6(553)).
head(id(4115),a12(553)).
head(id(4116),n(553)).
head(id(4117),a18(553)).
head(id(4118),a24(553)).
head(id(4119),a26(553)).
head(id(4120),a34(553)).
head(id(4121),a35(553)).
head(id(4122),a11(9)).
head(id(4123),a13(9)).
head(id(4124),n(9)).
head(id(4125),a18(9)).
head(id(4126),a26(9)).
head(id(4127),a31(9)).
head(id(4128),a34(9)).
head(id(4129),a35(9)).
head(id(4130),a6(783)).
head(id(4131),a12(783)).
head(id(4132),a13(783)).
head(id(4133),n(783)).
head(id(4134),a21(783)).
head(id(4135),a26(783)).
head(id(4136),a35(783)).
head(id(4137),a12(527)).
head(id(4138),a13(527)).
head(id(4139),n(527)).
head(id(4140),a24(527)).
head(id(4141),a26(527)).
head(id(4142),a35(527)).
head(id(4143),a12(701)).
head(id(4144),n(701)).
head(id(4145),a18(701)).
head(id(4146),a34(701)).
head(id(4147),a35(701)).
head(id(4148),a36(701)).
head(id(4149),a1(46)).
head(id(4150),a11(46)).
head(id(4151),a13(46)).
head(id(4152),n(46)).
head(id(4153),a18(46)).
head(id(4154),a26(46)).
head(id(4155),a31(46)).
head(id(4156),a34(46)).
head(id(4157),a7(26)).
head(id(4158),a11(26)).
head(id(4159),a13(26)).
head(id(4160),w(26)).
head(id(4161),a18(26)).
head(id(4162),a26(26)).
head(id(4163),a34(26)).
head(id(4164),a35(26)).
head(id(4165),a5(637)).
head(id(4166),a6(637)).
head(id(4167),a13(637)).
head(id(4168),n(637)).
head(id(4169),a33(637)).
head(id(4170),a35(637)).
head(id(4171),a36(637)).
head(id(4172),a6(300)).
head(id(4173),a13(300)).
head(id(4174),n(300)).
head(id(4175),a18(300)).
head(id(4176),a34(300)).
head(id(4177),a35(300)).
head(id(4178),a1(449)).
head(id(4179),a6(449)).
head(id(4180),a7(449)).
head(id(4181),a11(449)).
head(id(4182),n(449)).
head(id(4183),a18(449)).
head(id(4184),a26(449)).
head(id(4185),a34(449)).
head(id(4186),a5(246)).
head(id(4187),a6(246)).
head(id(4188),a7(246)).
head(id(4189),a11(246)).
head(id(4190),a13(246)).
head(id(4191),w(246)).
head(id(4192),a24(246)).
head(id(4193),a26(246)).
head(id(4194),a34(246)).
head(id(4195),a5(341)).
head(id(4196),a6(341)).
head(id(4197),a7(341)).
head(id(4198),a8(341)).
head(id(4199),a9(341)).
head(id(4200),a13(341)).
head(id(4201),n(341)).
head(id(4202),a18(341)).
head(id(4203),a35(341)).
head(id(4204),a5(285)).
head(id(4205),a9(285)).
head(id(4206),a13(285)).
head(id(4207),n(285)).
head(id(4208),a22(285)).
head(id(4209),a34(285)).
head(id(4210),a35(285)).
head(id(4211),a6(400)).
head(id(4212),a9(400)).
head(id(4213),n(400)).
head(id(4214),a18(400)).
head(id(4215),a22(400)).
head(id(4216),a26(400)).
head(id(4217),a34(400)).
head(id(4218),a35(400)).
head(id(4219),a7(104)).
head(id(4220),a8(104)).
head(id(4221),a9(104)).
head(id(4222),a11(104)).
head(id(4223),a13(104)).
head(id(4224),n(104)).
head(id(4225),a18(104)).
head(id(4226),a22(104)).
head(id(4227),a26(104)).
head(id(4228),a34(104)).
head(id(4229),a35(104)).
head(id(4230),a5(210)).
head(id(4231),a6(210)).
head(id(4232),a7(210)).
head(id(4233),a13(210)).
head(id(4234),n(210)).
head(id(4235),a26(210)).
head(id(4236),a34(210)).
head(id(4237),a35(210)).
head(id(4238),a5(598)).
head(id(4239),a13(598)).
head(id(4240),n(598)).
head(id(4241),a18(598)).
head(id(4242),a27(598)).
head(id(4243),a34(598)).
head(id(4244),a35(598)).
head(id(4245),a36(598)).
head(id(4246),a5(630)).
head(id(4247),a6(630)).
head(id(4248),a7(630)).
head(id(4249),a13(630)).
head(id(4250),n(630)).
head(id(4251),a18(630)).
head(id(4252),a24(630)).
head(id(4253),a34(630)).
head(id(4254),a35(630)).
head(id(4255),a36(630)).
head(id(4256),a10(875)).
head(id(4257),a12(875)).
head(id(4258),a13(875)).
head(id(4259),n(875)).
head(id(4260),a21(875)).
head(id(4261),a26(875)).
head(id(4262),a34(875)).
head(id(4263),a35(875)).
head(id(4264),a12(688)).
head(id(4265),a13(688)).
head(id(4266),n(688)).
head(id(4267),a24(688)).
head(id(4268),a26(688)).
head(id(4269),a35(688)).
head(id(4270),a36(688)).
head(id(4271),a6(720)).
head(id(4272),a13(720)).
head(id(4273),n(720)).
head(id(4274),a18(720)).
head(id(4275),a21(720)).
head(id(4276),a24(720)).
head(id(4277),a26(720)).
head(id(4278),a33(720)).
head(id(4279),a34(720)).
head(id(4280),a35(720)).
head(id(4281),a11(71)).
head(id(4282),a13(71)).
head(id(4283),n(71)).
head(id(4284),a26(71)).
head(id(4285),a35(71)).
head(id(4286),a5(516)).
head(id(4287),a6(516)).
head(id(4288),a7(516)).
head(id(4289),a8(516)).
head(id(4290),a9(516)).
head(id(4291),n(516)).
head(id(4292),a18(516)).
head(id(4293),a35(516)).
head(id(4294),a6(231)).
head(id(4295),a11(231)).
head(id(4296),a13(231)).
head(id(4297),n(231)).
head(id(4298),a24(231)).
head(id(4299),a26(231)).
head(id(4300),a31(231)).
head(id(4301),a6(754)).
head(id(4302),a7(754)).
head(id(4303),a13(754)).
head(id(4304),n(754)).
head(id(4305),a21(754)).
head(id(4306),a33(754)).
head(id(4307),a35(754)).
head(id(4308),a6(414)).
head(id(4309),a11(414)).
head(id(4310),n(414)).
head(id(4311),a18(414)).
head(id(4312),a26(414)).
head(id(4313),a34(414)).
head(id(4314),a35(414)).
head(id(4315),a5(501)).
head(id(4316),a6(501)).
head(id(4317),n(501)).
head(id(4318),a18(501)).
head(id(4319),a33(501)).
head(id(4320),a35(501)).
head(id(4321),a5(267)).
head(id(4322),a7(267)).
head(id(4323),a13(267)).
head(id(4324),n(267)).
head(id(4325),a18(267)).
head(id(4326),a34(267)).
head(id(4327),a35(267)).
head(id(4328),a2(656)).
head(id(4329),a6(656)).
head(id(4330),n(656)).
head(id(4331),a18(656)).
head(id(4332),a26(656)).
head(id(4333),a35(656)).
head(id(4334),a36(656)).
head(id(4335),a5(830)).
head(id(4336),a10(830)).
head(id(4337),a13(830)).
head(id(4338),n(830)).
head(id(4339),a18(830)).
head(id(4340),a21(830)).
head(id(4341),a24(830)).
head(id(4342),a26(830)).
head(id(4343),a34(830)).
head(id(4344),a35(830)).
head(id(4345),a6(420)).
head(id(4346),a9(420)).
head(id(4347),a11(420)).
head(id(4348),n(420)).
head(id(4349),a18(420)).
head(id(4350),a22(420)).
head(id(4351),a26(420)).
head(id(4352),a34(420)).
head(id(4353),a35(420)).
head(id(4354),a12(788)).
head(id(4355),n(788)).
head(id(4356),a18(788)).
head(id(4357),a21(788)).
head(id(4358),a26(788)).
head(id(4359),a34(788)).
head(id(4360),a35(788)).
head(id(4361),a1(49)).
head(id(4362),a11(49)).
head(id(4363),a13(49)).
head(id(4364),n(49)).
head(id(4365),a18(49)).
head(id(4366),a24(49)).
head(id(4367),a26(49)).
head(id(4368),a31(49)).
head(id(4369),a34(49)).
head(id(4370),a6(698)).
head(id(4371),a12(698)).
head(id(4372),a13(698)).
head(id(4373),n(698)).
head(id(4374),a18(698)).
head(id(4375),a24(698)).
head(id(4376),a34(698)).
head(id(4377),a35(698)).
head(id(4378),a36(698)).
head(id(4379),a11(529)).
head(id(4380),a12(529)).
head(id(4381),a13(529)).
head(id(4382),w(529)).
head(id(4383),a26(529)).
head(id(4384),a34(529)).
head(id(4385),a1(372)).
head(id(4386),a11(372)).
head(id(4387),n(372)).
head(id(4388),a18(372)).
head(id(4389),a24(372)).
head(id(4390),a26(372)).
head(id(4391),a34(372)).
head(id(4392),a35(372)).
head(id(4393),a6(660)).
head(id(4394),n(660)).
head(id(4395),a18(660)).
head(id(4396),a24(660)).
head(id(4397),a26(660)).
head(id(4398),a34(660)).
head(id(4399),a35(660)).
head(id(4400),a36(660)).
head(id(4401),a1(185)).
head(id(4402),a5(185)).
head(id(4403),a6(185)).
head(id(4404),a7(185)).
head(id(4405),a9(185)).
head(id(4406),a11(185)).
head(id(4407),a13(185)).
head(id(4408),n(185)).
head(id(4409),a18(185)).
head(id(4410),a22(185)).
head(id(4411),a26(185)).
head(id(4412),a34(185)).
head(id(4413),a35(185)).
head(id(4414),a1(379)).
head(id(4415),a11(379)).
head(id(4416),b(379)).
head(id(4417),a18(379)).
head(id(4418),a26(379)).
head(id(4419),a34(379)).
head(id(4420),n(758)).
head(id(4421),a18(758)).
head(id(4422),a21(758)).
head(id(4423),a26(758)).
head(id(4424),a34(758)).
head(id(4425),a35(758)).
head(id(4426),a5(3)).
head(id(4427),a7(3)).
head(id(4428),a13(3)).
head(id(4429),n(3)).
head(id(4430),a18(3)).
head(id(4431),a26(3)).
head(id(4432),a34(3)).
head(id(4433),a35(3)).
head(id(4434),a2(636)).
head(id(4435),a6(636)).
head(id(4436),a13(636)).
head(id(4437),n(636)).
head(id(4438),a33(636)).
head(id(4439),a34(636)).
head(id(4440),a35(636)).
head(id(4441),a36(636)).
head(id(4442),a5(684)).
head(id(4443),a6(684)).
head(id(4444),a7(684)).
head(id(4445),n(684)).
head(id(4446),a18(684)).
head(id(4447),a24(684)).
head(id(4448),a34(684)).
head(id(4449),a35(684)).
head(id(4450),a36(684)).
head(id(4451),a5(741)).
head(id(4452),a13(741)).
head(id(4453),n(741)).
head(id(4454),a21(741)).
head(id(4455),a24(741)).
head(id(4456),a33(741)).
head(id(4457),a35(741)).
head(id(4458),a6(635)).
head(id(4459),a13(635)).
head(id(4460),n(635)).
head(id(4461),a33(635)).
head(id(4462),a35(635)).
head(id(4463),a36(635)).
head(id(4464),a13(60)).
head(id(4465),n(60)).
head(id(4466),a26(60)).
head(id(4467),a35(60)).
head(id(4468),a6(547)).
head(id(4469),a12(547)).
head(id(4470),a13(547)).
head(id(4471),n(547)).
head(id(4472),a34(547)).
head(id(4473),a35(547)).
head(id(4474),a9(38)).
head(id(4475),a11(38)).
head(id(4476),a13(38)).
head(id(4477),w(38)).
head(id(4478),a18(38)).
head(id(4479),a22(38)).
head(id(4480),a26(38)).
head(id(4481),a34(38)).
head(id(4482),n(759)).
head(id(4483),a18(759)).
head(id(4484),a21(759)).
head(id(4485),a26(759)).
head(id(4486),a33(759)).
head(id(4487),a34(759)).
head(id(4488),a35(759)).
head(id(4489),a1(183)).
head(id(4490),a6(183)).
head(id(4491),a7(183)).
head(id(4492),a11(183)).
head(id(4493),a13(183)).
head(id(4494),n(183)).
head(id(4495),a18(183)).
head(id(4496),a26(183)).
head(id(4497),a34(183)).
head(id(4498),a35(183)).
head(id(4499),a7(35)).
head(id(4500),a11(35)).
head(id(4501),a13(35)).
head(id(4502),w(35)).
head(id(4503),a18(35)).
head(id(4504),a26(35)).
head(id(4505),a34(35)).
head(id(4506),n(644)).
head(id(4507),a18(644)).
head(id(4508),a26(644)).
head(id(4509),a34(644)).
head(id(4510),a35(644)).
head(id(4511),a36(644)).
head(id(4512),a9(98)).
head(id(4513),a11(98)).
head(id(4514),a13(98)).
head(id(4515),w(98)).
head(id(4516),a22(98)).
head(id(4517),a26(98)).
head(id(4518),a34(98)).
head(id(4519),a6(667)).
head(id(4520),a7(667)).
head(id(4521),a8(667)).
head(id(4522),a9(667)).
head(id(4523),n(667)).
head(id(4524),a18(667)).
head(id(4525),a24(667)).
head(id(4526),a26(667)).
head(id(4527),a34(667)).
head(id(4528),a35(667)).
head(id(4529),a36(667)).
head(id(4530),n(768)).
head(id(4531),a18(768)).
head(id(4532),a21(768)).
head(id(4533),a34(768)).
head(id(4534),a35(768)).
head(id(4535),a6(403)).
head(id(4536),a7(403)).
head(id(4537),a9(403)).
head(id(4538),n(403)).
head(id(4539),a18(403)).
head(id(4540),a22(403)).
head(id(4541),a26(403)).
head(id(4542),a34(403)).
head(id(4543),a35(403)).
head(id(4544),a6(172)).
head(id(4545),a11(172)).
head(id(4546),a13(172)).
head(id(4547),w(172)).
head(id(4548),a18(172)).
head(id(4549),a20(172)).
head(id(4550),a24(172)).
head(id(4551),a26(172)).
head(id(4552),a31(172)).
head(id(4553),a34(172)).
head(id(4554),a35(172)).
head(id(4555),a6(474)).
head(id(4556),a11(474)).
head(id(4557),b(474)).
head(id(4558),a18(474)).
head(id(4559),a23(474)).
head(id(4560),a26(474)).
head(id(4561),a34(474)).
head(id(4562),a35(474)).
head(id(4563),a6(697)).
head(id(4564),a12(697)).
head(id(4565),a13(697)).
head(id(4566),n(697)).
head(id(4567),a18(697)).
head(id(4568),a34(697)).
head(id(4569),a35(697)).
head(id(4570),a36(697)).
head(id(4571),a9(14)).
head(id(4572),a11(14)).
head(id(4573),a13(14)).
head(id(4574),n(14)).
head(id(4575),a18(14)).
head(id(4576),a20(14)).
head(id(4577),a22(14)).
head(id(4578),a26(14)).
head(id(4579),a31(14)).
head(id(4580),a34(14)).
head(id(4581),a35(14)).
head(id(4582),a6(511)).
head(id(4583),a9(511)).
head(id(4584),n(511)).
head(id(4585),a18(511)).
head(id(4586),a22(511)).
head(id(4587),a24(511)).
head(id(4588),a34(511)).
head(id(4589),a35(511)).
head(id(4590),a6(534)).
head(id(4591),a12(534)).
head(id(4592),a13(534)).
head(id(4593),n(534)).
head(id(4594),a26(534)).
head(id(4595),a34(534)).
head(id(4596),a35(534)).
head(id(4597),a9(705)).
head(id(4598),a13(705)).
head(id(4599),n(705)).
head(id(4600),a18(705)).
head(id(4601),a21(705)).
head(id(4602),a22(705)).
head(id(4603),a26(705)).
head(id(4604),a34(705)).
head(id(4605),a35(705)).
head(id(4606),a6(665)).
head(id(4607),a7(665)).
head(id(4608),a8(665)).
head(id(4609),a9(665)).
head(id(4610),n(665)).
head(id(4611),a18(665)).
head(id(4612),a26(665)).
head(id(4613),a34(665)).
head(id(4614),a35(665)).
head(id(4615),a36(665)).
head(id(4616),a6(434)).
head(id(4617),a9(434)).
head(id(4618),a11(434)).
head(id(4619),n(434)).
head(id(4620),a18(434)).
head(id(4621),a22(434)).
head(id(4622),a26(434)).
head(id(4623),a34(434)).
head(id(4624),a6(238)).
head(id(4625),a7(238)).
head(id(4626),a9(238)).
head(id(4627),a11(238)).
head(id(4628),a13(238)).
head(id(4629),w(238)).
head(id(4630),a22(238)).
head(id(4631),a26(238)).
head(id(4632),a34(238)).
head(id(4633),a35(238)).
head(id(4634),a6(226)).
head(id(4635),a9(226)).
head(id(4636),a11(226)).
head(id(4637),a13(226)).
head(id(4638),n(226)).
head(id(4639),a22(226)).
head(id(4640),a24(226)).
head(id(4641),a26(226)).
head(id(4642),a31(226)).
head(id(4643),a35(226)).
head(id(4644),a6(175)).
head(id(4645),a11(175)).
head(id(4646),a13(175)).
head(id(4647),w(175)).
head(id(4648),a18(175)).
head(id(4649),a26(175)).
head(id(4650),a31(175)).
head(id(4651),a1(51)).
head(id(4652),a11(51)).
head(id(4653),a13(51)).
head(id(4654),w(51)).
head(id(4655),a18(51)).
head(id(4656),a26(51)).
head(id(4657),a31(51)).
head(id(4658),a34(51)).
head(id(4659),a35(51)).
head(id(4660),a13(800)).
head(id(4661),n(800)).
head(id(4662),a21(800)).
head(id(4663),a26(800)).
head(id(4664),a34(800)).
head(id(4665),a35(800)).
head(id(4666),a36(800)).
head(id(4667),a6(259)).
head(id(4668),a7(259)).
head(id(4669),a8(259)).
head(id(4670),a9(259)).
head(id(4671),a11(259)).
head(id(4672),a13(259)).
head(id(4673),w(259)).
head(id(4674),a18(259)).
head(id(4675),a22(259)).
head(id(4676),a26(259)).
head(id(4677),a34(259)).
head(id(4678),a35(259)).
head(id(4679),a4(120)).
head(id(4680),a5(120)).
head(id(4681),a6(120)).
head(id(4682),a13(120)).
head(id(4683),n(120)).
head(id(4684),a18(120)).
head(id(4685),a26(120)).
head(id(4686),a34(120)).
head(id(4687),a35(120)).
head(id(4688),a1(50)).
head(id(4689),a11(50)).
head(id(4690),a13(50)).
head(id(4691),b(50)).
head(id(4692),a18(50)).
head(id(4693),a26(50)).
head(id(4694),a34(50)).
head(id(4695),a35(50)).
head(id(4696),a4(634)).
head(id(4697),a5(634)).
head(id(4698),a6(634)).
head(id(4699),a13(634)).
head(id(4700),n(634)).
head(id(4701),a34(634)).
head(id(4702),a35(634)).
head(id(4703),a36(634)).
head(id(4704),a11(72)).
head(id(4705),a13(72)).
head(id(4706),n(72)).
head(id(4707),a26(72)).
head(id(4708),a31(72)).
head(id(4709),a35(72)).
head(id(4710),a9(737)).
head(id(4711),a13(737)).
head(id(4712),n(737)).
head(id(4713),a21(737)).
head(id(4714),a22(737)).
head(id(4715),a33(737)).
head(id(4716),a34(737)).
head(id(4717),a35(737)).
head(id(4718),a4(305)).
head(id(4719),a5(305)).
head(id(4720),a6(305)).
head(id(4721),a13(305)).
head(id(4722),n(305)).
head(id(4723),a18(305)).
head(id(4724),a34(305)).
head(id(4725),a35(305)).
head(id(4726),a3(130)).
head(id(4727),a6(130)).
head(id(4728),a13(130)).
head(id(4729),n(130)).
head(id(4730),a18(130)).
head(id(4731),a24(130)).
head(id(4732),a26(130)).
head(id(4733),a35(130)).
head(id(4734),a12(540)).
head(id(4735),a13(540)).
head(id(4736),n(540)).
head(id(4737),a18(540)).
head(id(4738),a24(540)).
head(id(4739),a30(540)).
head(id(4740),a34(540)).
head(id(4741),a35(540)).
head(id(4742),a6(810)).
head(id(4743),a13(810)).
head(id(4744),n(810)).
head(id(4745),a21(810)).
head(id(4746),a26(810)).
head(id(4747),a34(810)).
head(id(4748),a35(810)).
head(id(4749),a36(810)).
head(id(4750),n(483)).
head(id(4751),a18(483)).
head(id(4752),a24(483)).
head(id(4753),a30(483)).
head(id(4754),a34(483)).
head(id(4755),a35(483)).
head(id(4756),a12(778)).
head(id(4757),a13(778)).
head(id(4758),n(778)).
head(id(4759),a18(778)).
head(id(4760),a21(778)).
head(id(4761),a26(778)).
head(id(4762),a33(778)).
head(id(4763),a34(778)).
head(id(4764),a35(778)).
head(id(4765),a13(709)).
head(id(4766),n(709)).
head(id(4767),a21(709)).
head(id(4768),a26(709)).
head(id(4769),a35(709)).
head(id(4770),a5(355)).
head(id(4771),a9(355)).
head(id(4772),n(355)).
head(id(4773),a18(355)).
head(id(4774),a22(355)).
head(id(4775),a24(355)).
head(id(4776),a26(355)).
head(id(4777),a34(355)).
head(id(4778),a35(355)).
head(id(4779),a1(195)).
head(id(4780),a6(195)).
head(id(4781),a7(195)).
head(id(4782),a11(195)).
head(id(4783),a13(195)).
head(id(4784),w(195)).
head(id(4785),a18(195)).
head(id(4786),a26(195)).
head(id(4787),a34(195)).
head(id(4788),a35(195)).
head(id(4789),a5(510)).
head(id(4790),a6(510)).
head(id(4791),a7(510)).
head(id(4792),n(510)).
head(id(4793),a18(510)).
head(id(4794),a24(510)).
head(id(4795),a34(510)).
head(id(4796),a35(510)).
head(id(4797),a5(291)).
head(id(4798),a7(291)).
head(id(4799),a13(291)).
head(id(4800),n(291)).
head(id(4801),a24(291)).
head(id(4802),a35(291)).
head(id(4803),a6(823)).
head(id(4804),a13(823)).
head(id(4805),n(823)).
head(id(4806),a18(823)).
head(id(4807),a21(823)).
head(id(4808),a33(823)).
head(id(4809),a34(823)).
head(id(4810),a35(823)).
head(id(4811),a36(823)).
head(id(4812),a6(899)).
head(id(4813),a10(899)).
head(id(4814),a13(899)).
head(id(4815),n(899)).
head(id(4816),a21(899)).
head(id(4817),a34(899)).
head(id(4818),a35(899)).
head(id(4819),a36(899)).
head(id(4820),a6(251)).
head(id(4821),a7(251)).
head(id(4822),a8(251)).
head(id(4823),a9(251)).
head(id(4824),a13(251)).
head(id(4825),n(251)).
head(id(4826),a18(251)).
head(id(4827),a22(251)).
head(id(4828),a26(251)).
head(id(4829),a34(251)).
head(id(4830),a35(251)).
head(id(4831),a6(557)).
head(id(4832),a12(557)).
head(id(4833),n(557)).
head(id(4834),a18(557)).
head(id(4835),a34(557)).
head(id(4836),a35(557)).
head(id(4837),a6(203)).
head(id(4838),a13(203)).
head(id(4839),n(203)).
head(id(4840),a26(203)).
head(id(4841),a34(203)).
head(id(4842),a35(203)).
head(id(4843),a2(651)).
head(id(4844),n(651)).
head(id(4845),a26(651)).
head(id(4846),a35(651)).
head(id(4847),a36(651)).
head(id(4848),a11(95)).
head(id(4849),a13(95)).
head(id(4850),w(95)).
head(id(4851),a26(95)).
head(id(4852),a31(95)).
head(id(4853),a13(282)).
head(id(4854),n(282)).
head(id(4855),a33(282)).
head(id(4856),a35(282)).
head(id(4857),a12(780)).
head(id(4858),a13(780)).
head(id(4859),n(780)).
head(id(4860),a21(780)).
head(id(4861),a26(780)).
head(id(4862),a35(780)).
head(id(4863),a11(39)).
head(id(4864),a13(39)).
head(id(4865),w(39)).
head(id(4866),a18(39)).
head(id(4867),a24(39)).
head(id(4868),a26(39)).
head(id(4869),a31(39)).
head(id(4870),a34(39)).
head(id(4871),a6(585)).
head(id(4872),a13(585)).
head(id(4873),n(585)).
head(id(4874),a24(585)).
head(id(4875),a26(585)).
head(id(4876),a35(585)).
head(id(4877),a36(585)).
head(id(4878),a10(845)).
head(id(4879),a13(845)).
head(id(4880),n(845)).
head(id(4881),a21(845)).
head(id(4882),a34(845)).
head(id(4883),a35(845)).
head(id(4884),a6(558)).
head(id(4885),a9(558)).
head(id(4886),a12(558)).
head(id(4887),n(558)).
head(id(4888),a18(558)).
head(id(4889),a22(558)).
head(id(4890),a34(558)).
head(id(4891),a35(558)).
head(id(4892),a9(677)).
head(id(4893),n(677)).
head(id(4894),a18(677)).
head(id(4895),a22(677)).
head(id(4896),a24(677)).
head(id(4897),a34(677)).
head(id(4898),a35(677)).
head(id(4899),a36(677)).
head(id(4900),a5(249)).
head(id(4901),a6(249)).
head(id(4902),a7(249)).
head(id(4903),a8(249)).
head(id(4904),a9(249)).
head(id(4905),a13(249)).
head(id(4906),n(249)).
head(id(4907),a18(249)).
head(id(4908),a26(249)).
head(id(4909),a34(249)).
head(id(4910),a35(249)).
head(id(4911),a6(318)).
head(id(4912),a13(318)).
head(id(4913),n(318)).
head(id(4914),a18(318)).
head(id(4915),a24(318)).
head(id(4916),a34(318)).
head(id(4917),a35(318)).
head(id(4918),a3(218)).
head(id(4919),a5(218)).
head(id(4920),a6(218)).
head(id(4921),a7(218)).
head(id(4922),a13(218)).
head(id(4923),n(218)).
head(id(4924),a24(218)).
head(id(4925),a26(218)).
head(id(4926),a35(218)).
head(id(4927),a1(52)).
head(id(4928),a7(52)).
head(id(4929),a11(52)).
head(id(4930),a13(52)).
head(id(4931),b(52)).
head(id(4932),a18(52)).
head(id(4933),a26(52)).
head(id(4934),a34(52)).
head(id(4935),a35(52)).
head(id(4936),a9(779)).
head(id(4937),a12(779)).
head(id(4938),a13(779)).
head(id(4939),n(779)).
head(id(4940),a18(779)).
head(id(4941),a21(779)).
head(id(4942),a22(779)).
head(id(4943),a26(779)).
head(id(4944),a34(779)).
head(id(4945),a35(779)).
head(id(4946),a5(857)).
head(id(4947),a6(857)).
head(id(4948),a10(857)).
head(id(4949),n(857)).
head(id(4950),a18(857)).
head(id(4951),a21(857)).
head(id(4952),a26(857)).
head(id(4953),a34(857)).
head(id(4954),a35(857)).
head(id(4955),a5(750)).
head(id(4956),a6(750)).
head(id(4957),a13(750)).
head(id(4958),n(750)).
head(id(4959),a21(750)).
head(id(4960),a35(750)).
head(id(4961),a5(280)).
head(id(4962),a7(280)).
head(id(4963),a13(280)).
head(id(4964),n(280)).
head(id(4965),a34(280)).
head(id(4966),a35(280)).
head(id(4967),a6(494)).
head(id(4968),n(494)).
head(id(4969),a18(494)).
head(id(4970),a35(494)).
head(id(4971),a5(273)).
head(id(4972),a7(273)).
head(id(4973),a13(273)).
head(id(4974),n(273)).
head(id(4975),a18(273)).
head(id(4976),a24(273)).
head(id(4977),a34(273)).
head(id(4978),a35(273)).
head(id(4979),a11(76)).
head(id(4980),a13(76)).
head(id(4981),n(76)).
head(id(4982),a24(76)).
head(id(4983),a26(76)).
head(id(4984),a35(76)).
head(id(4985),a5(275)).
head(id(4986),a9(275)).
head(id(4987),a13(275)).
head(id(4988),n(275)).
head(id(4989),a18(275)).
head(id(4990),a22(275)).
head(id(4991),a24(275)).
head(id(4992),a34(275)).
head(id(4993),a35(275)).
head(id(4994),a5(156)).
head(id(4995),a6(156)).
head(id(4996),a7(156)).
head(id(4997),a11(156)).
head(id(4998),a13(156)).
head(id(4999),n(156)).
head(id(5000),a18(156)).
head(id(5001),a26(156)).
head(id(5002),a34(156)).
head(id(5003),a1(261)).
head(id(5004),a5(261)).
head(id(5005),a6(261)).
head(id(5006),a7(261)).
head(id(5007),a8(261)).
head(id(5008),a9(261)).
head(id(5009),a11(261)).
head(id(5010),a13(261)).
head(id(5011),n(261)).
head(id(5012),a18(261)).
head(id(5013),a26(261)).
head(id(5014),a34(261)).
head(id(5015),a35(261)).
head(id(5016),a6(240)).
head(id(5017),a7(240)).
head(id(5018),a11(240)).
head(id(5019),a13(240)).
head(id(5020),w(240)).
head(id(5021),a24(240)).
head(id(5022),a26(240)).
head(id(5023),a35(240)).
head(id(5024),a6(145)).
head(id(5025),a9(145)).
head(id(5026),a11(145)).
head(id(5027),a13(145)).
head(id(5028),n(145)).
head(id(5029),a18(145)).
head(id(5030),a20(145)).
head(id(5031),a22(145)).
head(id(5032),a26(145)).
head(id(5033),a31(145)).
head(id(5034),a34(145)).
head(id(5035),a35(145)).
head(id(5036),a1(198)).
head(id(5037),a6(198)).
head(id(5038),a11(198)).
head(id(5039),a13(198)).
head(id(5040),w(198)).
head(id(5041),a18(198)).
head(id(5042),a24(198)).
head(id(5043),a26(198)).
head(id(5044),a31(198)).
head(id(5045),a34(198)).
head(id(5046),a35(198)).
head(id(5047),a6(128)).
head(id(5048),a13(128)).
head(id(5049),n(128)).
head(id(5050),a18(128)).
head(id(5051),a24(128)).
head(id(5052),a26(128)).
head(id(5053),a34(128)).
head(id(5054),a35(128)).
head(id(5055),a5(101)).
head(id(5056),a7(101)).
head(id(5057),a8(101)).
head(id(5058),a9(101)).
head(id(5059),a13(101)).
head(id(5060),n(101)).
head(id(5061),a18(101)).
head(id(5062),a22(101)).
head(id(5063),a26(101)).
head(id(5064),a34(101)).
head(id(5065),a35(101)).
head(id(5066),a6(222)).
head(id(5067),a11(222)).
head(id(5068),a13(222)).
head(id(5069),n(222)).
head(id(5070),a24(222)).
head(id(5071),a26(222)).
head(id(5072),a31(222)).
head(id(5073),a35(222)).
head(id(5074),a6(721)).
head(id(5075),a13(721)).
head(id(5076),n(721)).
head(id(5077),a21(721)).
head(id(5078),a26(721)).
head(id(5079),a35(721)).
head(id(5080),a5(342)).
head(id(5081),a6(342)).
head(id(5082),a7(342)).
head(id(5083),a8(342)).
head(id(5084),a9(342)).
head(id(5085),a13(342)).
head(id(5086),n(342)).
head(id(5087),a18(342)).
head(id(5088),a22(342)).
head(id(5089),a34(342)).
head(id(5090),a35(342)).
head(id(5091),a5(321)).
head(id(5092),a6(321)).
head(id(5093),a7(321)).
head(id(5094),a13(321)).
head(id(5095),n(321)).
head(id(5096),a18(321)).
head(id(5097),a24(321)).
head(id(5098),a34(321)).
head(id(5099),a35(321)).
head(id(5100),a1(453)).
head(id(5101),a6(453)).
head(id(5102),a11(453)).
head(id(5103),b(453)).
head(id(5104),a18(453)).
head(id(5105),a24(453)).
head(id(5106),a26(453)).
head(id(5107),a34(453)).
head(id(5108),a35(453)).
head(id(5109),a4(394)).
head(id(5110),a5(394)).
head(id(5111),a6(394)).
head(id(5112),n(394)).
head(id(5113),a18(394)).
head(id(5114),a26(394)).
head(id(5115),a34(394)).
head(id(5116),a35(394)).
head(id(5117),a13(611)).
head(id(5118),n(611)).
head(id(5119),a24(611)).
head(id(5120),a34(611)).
head(id(5121),a35(611)).
head(id(5122),a36(611)).
head(id(5123),a6(765)).
head(id(5124),n(765)).
head(id(5125),a18(765)).
head(id(5126),a21(765)).
head(id(5127),a26(765)).
head(id(5128),a33(765)).
head(id(5129),a34(765)).
head(id(5130),a35(765)).
head(id(5131),a12(692)).
head(id(5132),a13(692)).
head(id(5133),n(692)).
head(id(5134),a18(692)).
head(id(5135),a34(692)).
head(id(5136),a35(692)).
head(id(5137),a36(692)).
head(id(5138),a3(628)).
head(id(5139),a6(628)).
head(id(5140),a13(628)).
head(id(5141),n(628)).
head(id(5142),a18(628)).
head(id(5143),a24(628)).
head(id(5144),a35(628)).
head(id(5145),a36(628)).
head(id(5146),a6(314)).
head(id(5147),a7(314)).
head(id(5148),a9(314)).
head(id(5149),a13(314)).
head(id(5150),n(314)).
head(id(5151),a18(314)).
head(id(5152),a22(314)).
head(id(5153),a34(314)).
head(id(5154),a35(314)).
head(id(5155),a5(269)).
head(id(5156),a9(269)).
head(id(5157),a13(269)).
head(id(5158),n(269)).
head(id(5159),a18(269)).
head(id(5160),a22(269)).
head(id(5161),a34(269)).
head(id(5162),a35(269)).
head(id(5163),a1(200)).
head(id(5164),a6(200)).
head(id(5165),a7(200)).
head(id(5166),a11(200)).
head(id(5167),a13(200)).
head(id(5168),b(200)).
head(id(5169),a18(200)).
head(id(5170),a24(200)).
head(id(5171),a26(200)).
head(id(5172),a34(200)).
head(id(5173),a35(200)).
head(id(5174),a1(54)).
head(id(5175),a11(54)).
head(id(5176),a13(54)).
head(id(5177),w(54)).
head(id(5178),a18(54)).
head(id(5179),a24(54)).
head(id(5180),a26(54)).
head(id(5181),a31(54)).
head(id(5182),a34(54)).
head(id(5183),a35(54)).
head(id(5184),a6(809)).
head(id(5185),a9(809)).
head(id(5186),a13(809)).
head(id(5187),n(809)).
head(id(5188),a18(809)).
head(id(5189),a21(809)).
head(id(5190),a22(809)).
head(id(5191),a24(809)).
head(id(5192),a26(809)).
head(id(5193),a33(809)).
head(id(5194),a34(809)).
head(id(5195),a35(809)).
head(id(5196),a36(809)).
head(id(5197),a1(56)).
head(id(5198),a11(56)).
head(id(5199),a13(56)).
head(id(5200),b(56)).
head(id(5201),a18(56)).
head(id(5202),a26(56)).
head(id(5203),a34(56)).
head(id(5204),a11(80)).
head(id(5205),a13(80)).
head(id(5206),n(80)).
head(id(5207),a26(80)).
head(id(5208),a31(80)).
head(id(5209),a5(734)).
head(id(5210),a13(734)).
head(id(5211),n(734)).
head(id(5212),a21(734)).
head(id(5213),a35(734)).
head(id(5214),a6(133)).
head(id(5215),a13(133)).
head(id(5216),n(133)).
head(id(5217),a18(133)).
head(id(5218),a24(133)).
head(id(5219),a26(133)).
head(id(5220),a33(133)).
head(id(5221),a35(133)).
head(id(5222),a6(822)).
head(id(5223),a13(822)).
head(id(5224),n(822)).
head(id(5225),a18(822)).
head(id(5226),a21(822)).
head(id(5227),a34(822)).
head(id(5228),a35(822)).
head(id(5229),a36(822)).
head(id(5230),a13(706)).
head(id(5231),n(706)).
head(id(5232),a18(706)).
head(id(5233),a21(706)).
head(id(5234),a24(706)).
head(id(5235),a26(706)).
head(id(5236),a34(706)).
head(id(5237),a35(706)).
head(id(5238),a1(199)).
head(id(5239),a6(199)).
head(id(5240),a7(199)).
head(id(5241),a11(199)).
head(id(5242),a13(199)).
head(id(5243),w(199)).
head(id(5244),a18(199)).
head(id(5245),a24(199)).
head(id(5246),a26(199)).
head(id(5247),a34(199)).
head(id(5248),a35(199)).
head(id(5249),a6(641)).
head(id(5250),a13(641)).
head(id(5251),n(641)).
head(id(5252),a24(641)).
head(id(5253),a33(641)).
head(id(5254),a35(641)).
head(id(5255),a36(641)).
head(id(5256),a1(42)).
head(id(5257),a11(42)).
head(id(5258),a13(42)).
head(id(5259),n(42)).
head(id(5260),a18(42)).
head(id(5261),a24(42)).
head(id(5262),a26(42)).
head(id(5263),a34(42)).
head(id(5264),a35(42)).
head(id(5265),a6(153)).
head(id(5266),a11(153)).
head(id(5267),a13(153)).
head(id(5268),n(153)).
head(id(5269),a18(153)).
head(id(5270),a26(153)).
head(id(5271),a31(153)).
head(id(5272),a6(846)).
head(id(5273),a10(846)).
head(id(5274),a13(846)).
head(id(5275),n(846)).
head(id(5276),a21(846)).
head(id(5277),a24(846)).
head(id(5278),a34(846)).
head(id(5279),a35(846)).
head(id(5280),a5(503)).
head(id(5281),a6(503)).
head(id(5282),a9(503)).
head(id(5283),n(503)).
head(id(5284),a18(503)).
head(id(5285),a22(503)).
head(id(5286),a34(503)).
head(id(5287),a35(503)).
head(id(5288),a6(633)).
head(id(5289),a13(633)).
head(id(5290),n(633)).
head(id(5291),a35(633)).
head(id(5292),a36(633)).
head(id(5293),a5(206)).
head(id(5294),a6(206)).
head(id(5295),a13(206)).
head(id(5296),n(206)).
head(id(5297),a26(206)).
head(id(5298),a35(206)).
head(id(5299),a13(292)).
head(id(5300),n(292)).
head(id(5301),a24(292)).
head(id(5302),a33(292)).
head(id(5303),a35(292)).
head(id(5304),a5(713)).
head(id(5305),a13(713)).
head(id(5306),n(713)).
head(id(5307),a21(713)).
head(id(5308),a24(713)).
head(id(5309),a26(713)).
head(id(5310),a35(713)).
head(id(5311),a6(315)).
head(id(5312),a7(315)).
head(id(5313),a9(315)).
head(id(5314),a13(315)).
head(id(5315),n(315)).
head(id(5316),a18(315)).
head(id(5317),a22(315)).
head(id(5318),a35(315)).
head(id(5319),a5(317)).
head(id(5320),a6(317)).
head(id(5321),a7(317)).
head(id(5322),a9(317)).
head(id(5323),a13(317)).
head(id(5324),n(317)).
head(id(5325),a18(317)).
head(id(5326),a22(317)).
head(id(5327),a35(317)).
head(id(5328),a6(589)).
head(id(5329),a7(589)).
head(id(5330),a13(589)).
head(id(5331),n(589)).
head(id(5332),a24(589)).
head(id(5333),a26(589)).
head(id(5334),a35(589)).
head(id(5335),a36(589)).
head(id(5336),a6(863)).
head(id(5337),a10(863)).
head(id(5338),a11(863)).
head(id(5339),n(863)).
head(id(5340),a18(863)).
head(id(5341),a21(863)).
head(id(5342),a26(863)).
head(id(5343),a33(863)).
head(id(5344),a34(863)).
head(id(5345),a35(863)).
head(id(5346),a6(690)).
head(id(5347),a12(690)).
head(id(5348),a13(690)).
head(id(5349),n(690)).
head(id(5350),a26(690)).
head(id(5351),a33(690)).
head(id(5352),a35(690)).
head(id(5353),a36(690)).
head(id(5354),a4(131)).
head(id(5355),a6(131)).
head(id(5356),a13(131)).
head(id(5357),n(131)).
head(id(5358),a18(131)).
head(id(5359),a24(131)).
head(id(5360),a26(131)).
head(id(5361),a35(131)).
head(id(5362),a5(141)).
head(id(5363),a6(141)).
head(id(5364),a7(141)).
head(id(5365),a11(141)).
head(id(5366),a13(141)).
head(id(5367),n(141)).
head(id(5368),a18(141)).
head(id(5369),a26(141)).
head(id(5370),a35(141)).
head(id(5371),a9(549)).
head(id(5372),a12(549)).
head(id(5373),n(549)).
head(id(5374),a18(549)).
head(id(5375),a22(549)).
head(id(5376),a26(549)).
head(id(5377),a34(549)).
head(id(5378),a35(549)).
head(id(5379),a6(544)).
head(id(5380),a12(544)).
head(id(5381),a13(544)).
head(id(5382),n(544)).
head(id(5383),a18(544)).
head(id(5384),a34(544)).
head(id(5385),a35(544)).
head(id(5386),a5(382)).
head(id(5387),a7(382)).
head(id(5388),a8(382)).
head(id(5389),a9(382)).
head(id(5390),n(382)).
head(id(5391),a18(382)).
head(id(5392),a24(382)).
head(id(5393),a26(382)).
head(id(5394),a34(382)).
head(id(5395),a35(382)).
head(id(5396),a7(383)).
head(id(5397),a8(383)).
head(id(5398),a9(383)).
head(id(5399),a11(383)).
head(id(5400),n(383)).
head(id(5401),a18(383)).
head(id(5402),a26(383)).
head(id(5403),a34(383)).
head(id(5404),a35(383)).
head(id(5405),a6(428)).
head(id(5406),a9(428)).
head(id(5407),a11(428)).
head(id(5408),n(428)).
head(id(5409),a18(428)).
head(id(5410),a22(428)).
head(id(5411),a24(428)).
head(id(5412),a26(428)).
head(id(5413),a34(428)).
head(id(5414),a35(428)).
head(id(5415),a13(815)).
head(id(5416),n(815)).
head(id(5417),a18(815)).
head(id(5418),a21(815)).
head(id(5419),a33(815)).
head(id(5420),a34(815)).
head(id(5421),a35(815)).
head(id(5422),a36(815)).
head(id(5423),a6(164)).
head(id(5424),a11(164)).
head(id(5425),a13(164)).
head(id(5426),w(164)).
head(id(5427),a18(164)).
head(id(5428),a26(164)).
head(id(5429),a31(164)).
head(id(5430),a35(164)).
head(id(5431),a5(872)).
head(id(5432),a6(872)).
head(id(5433),a7(872)).
head(id(5434),a10(872)).
head(id(5435),n(872)).
head(id(5436),a18(872)).
head(id(5437),a21(872)).
head(id(5438),a34(872)).
head(id(5439),a35(872)).
head(id(5440),a6(856)).
head(id(5441),a10(856)).
head(id(5442),n(856)).
head(id(5443),a18(856)).
head(id(5444),a21(856)).
head(id(5445),a26(856)).
head(id(5446),a34(856)).
head(id(5447),a35(856)).
head(id(5448),a5(147)).
head(id(5449),a6(147)).
head(id(5450),a7(147)).
head(id(5451),a9(147)).
head(id(5452),a11(147)).
head(id(5453),a13(147)).
head(id(5454),n(147)).
head(id(5455),a18(147)).
head(id(5456),a22(147)).
head(id(5457),a26(147)).
head(id(5458),a31(147)).
head(id(5459),a35(147)).
head(id(5460),a12(550)).
head(id(5461),n(550)).
head(id(5462),a18(550)).
head(id(5463),a24(550)).
head(id(5464),a26(550)).
head(id(5465),a34(550)).
head(id(5466),a35(550)).
head(id(5467),a5(328)).
head(id(5468),a6(328)).
head(id(5469),a7(328)).
head(id(5470),a13(328)).
head(id(5471),n(328)).
head(id(5472),a34(328)).
head(id(5473),a35(328)).
head(id(5474),a6(209)).
head(id(5475),a7(209)).
head(id(5476),a13(209)).
head(id(5477),n(209)).
head(id(5478),a26(209)).
head(id(5479),a35(209)).
head(id(5480),a1(190)).
head(id(5481),a6(190)).
head(id(5482),a7(190)).
head(id(5483),a11(190)).
head(id(5484),a13(190)).
head(id(5485),n(190)).
head(id(5486),a18(190)).
head(id(5487),a26(190)).
head(id(5488),a34(190)).
head(id(5489),a13(735)).
head(id(5490),n(735)).
head(id(5491),a21(735)).
head(id(5492),a33(735)).
head(id(5493),a35(735)).
head(id(5494),a6(204)).
head(id(5495),a13(204)).
head(id(5496),n(204)).
head(id(5497),a26(204)).
head(id(5498),a35(204)).
head(id(5499),a9(605)).
head(id(5500),a13(605)).
head(id(5501),n(605)).
head(id(5502),a18(605)).
head(id(5503),a22(605)).
head(id(5504),a24(605)).
head(id(5505),a34(605)).
head(id(5506),a35(605)).
head(id(5507),a36(605)).
head(id(5508),a5(384)).
head(id(5509),a7(384)).
head(id(5510),a8(384)).
head(id(5511),a9(384)).
head(id(5512),a11(384)).
head(id(5513),n(384)).
head(id(5514),a18(384)).
head(id(5515),a26(384)).
head(id(5516),a34(384)).
head(id(5517),a35(384)).
head(id(5518),a5(241)).
head(id(5519),a6(241)).
head(id(5520),a7(241)).
head(id(5521),a11(241)).
head(id(5522),a13(241)).
head(id(5523),w(241)).
head(id(5524),a24(241)).
head(id(5525),a26(241)).
head(id(5526),a34(241)).
head(id(5527),a35(241)).
head(id(5528),a6(245)).
head(id(5529),a7(245)).
head(id(5530),a11(245)).
head(id(5531),a13(245)).
head(id(5532),w(245)).
head(id(5533),a24(245)).
head(id(5534),a26(245)).
head(id(5535),a13(801)).
head(id(5536),n(801)).
head(id(5537),a21(801)).
head(id(5538),a26(801)).
head(id(5539),a35(801)).
head(id(5540),a36(801)).
head(id(5541),a1(191)).
head(id(5542),a6(191)).
head(id(5543),a11(191)).
head(id(5544),a13(191)).
head(id(5545),n(191)).
head(id(5546),a18(191)).
head(id(5547),a24(191)).
head(id(5548),a26(191)).
head(id(5549),a31(191)).
head(id(5550),a34(191)).
head(id(5551),a11(34)).
head(id(5552),a13(34)).
head(id(5553),w(34)).
head(id(5554),a18(34)).
head(id(5555),a26(34)).
head(id(5556),a31(34)).
head(id(5557),a34(34)).
head(id(5558),a13(821)).
head(id(5559),n(821)).
head(id(5560),a21(821)).
head(id(5561),a24(821)).
head(id(5562),a35(821)).
head(id(5563),a36(821)).
head(id(5564),a13(571)).
head(id(5565),n(571)).
head(id(5566),a24(571)).
head(id(5567),a26(571)).
head(id(5568),a30(571)).
head(id(5569),a35(571)).
head(id(5570),a36(571)).
head(id(5571),a1(443)).
head(id(5572),a6(443)).
head(id(5573),a11(443)).
head(id(5574),n(443)).
head(id(5575),a18(443)).
head(id(5576),a26(443)).
head(id(5577),a34(443)).
head(id(5578),a35(443)).
head(id(5579),a6(435)).
head(id(5580),a7(435)).
head(id(5581),a9(435)).
head(id(5582),a11(435)).
head(id(5583),n(435)).
head(id(5584),a18(435)).
head(id(5585),a22(435)).
head(id(5586),a26(435)).
head(id(5587),a34(435)).
head(id(5588),a5(492)).
head(id(5589),a7(492)).
head(id(5590),a8(492)).
head(id(5591),a9(492)).
head(id(5592),n(492)).
head(id(5593),a18(492)).
head(id(5594),a24(492)).
head(id(5595),a34(492)).
head(id(5596),a35(492)).
head(id(5597),a5(663)).
head(id(5598),a6(663)).
head(id(5599),a7(663)).
head(id(5600),n(663)).
head(id(5601),a18(663)).
head(id(5602),a24(663)).
head(id(5603),a26(663)).
head(id(5604),a34(663)).
head(id(5605),a35(663)).
head(id(5606),a36(663)).
head(id(5607),a6(580)).
head(id(5608),a13(580)).
head(id(5609),n(580)).
head(id(5610),a18(580)).
head(id(5611),a24(580)).
head(id(5612),a26(580)).
head(id(5613),a34(580)).
head(id(5614),a35(580)).
head(id(5615),a36(580)).
head(id(5616),a1(182)).
head(id(5617),a6(182)).
head(id(5618),a11(182)).
head(id(5619),a13(182)).
head(id(5620),n(182)).
head(id(5621),a18(182)).
head(id(5622),a26(182)).
head(id(5623),a31(182)).
head(id(5624),a34(182)).
head(id(5625),a35(182)).
head(id(5626),a9(12)).
head(id(5627),a11(12)).
head(id(5628),a13(12)).
head(id(5629),n(12)).
head(id(5630),a18(12)).
head(id(5631),a22(12)).
head(id(5632),a26(12)).
head(id(5633),a34(12)).
head(id(5634),a35(12)).
head(id(5635),a6(469)).
head(id(5636),n(469)).
head(id(5637),a18(469)).
head(id(5638),a23(469)).
head(id(5639),a26(469)).
head(id(5640),a34(469)).
head(id(5641),a35(469)).
head(id(5642),a12(789)).
head(id(5643),n(789)).
head(id(5644),a18(789)).
head(id(5645),a21(789)).
head(id(5646),a26(789)).
head(id(5647),a33(789)).
head(id(5648),a34(789)).
head(id(5649),a35(789)).
head(id(5650),a6(559)).
head(id(5651),a12(559)).
head(id(5652),n(559)).
head(id(5653),a18(559)).
head(id(5654),a24(559)).
head(id(5655),a34(559)).
head(id(5656),a35(559)).
head(id(5657),a4(629)).
head(id(5658),a6(629)).
head(id(5659),a13(629)).
head(id(5660),n(629)).
head(id(5661),a18(629)).
head(id(5662),a24(629)).
head(id(5663),a35(629)).
head(id(5664),a36(629)).
head(id(5665),a6(406)).
head(id(5666),n(406)).
head(id(5667),a18(406)).
head(id(5668),a24(406)).
head(id(5669),a26(406)).
head(id(5670),a35(406)).
head(id(5671),a9(362)).
head(id(5672),a11(362)).
head(id(5673),n(362)).
head(id(5674),a18(362)).
head(id(5675),a22(362)).
head(id(5676),a26(362)).
head(id(5677),a34(362)).
head(id(5678),a35(362)).
head(id(5679),a6(466)).
head(id(5680),a7(466)).
head(id(5681),a8(466)).
head(id(5682),a9(466)).
head(id(5683),a11(466)).
head(id(5684),n(466)).
head(id(5685),a18(466)).
head(id(5686),a24(466)).
head(id(5687),a26(466)).
head(id(5688),a34(466)).
head(id(5689),a35(466)).
head(id(5690),a7(385)).
head(id(5691),a8(385)).
head(id(5692),a9(385)).
head(id(5693),a11(385)).
head(id(5694),n(385)).
head(id(5695),a18(385)).
head(id(5696),a22(385)).
head(id(5697),a26(385)).
head(id(5698),a34(385)).
head(id(5699),a35(385)).
head(id(5700),a1(184)).
head(id(5701),a5(184)).
head(id(5702),a6(184)).
head(id(5703),a9(184)).
head(id(5704),a11(184)).
head(id(5705),a13(184)).
head(id(5706),n(184)).
head(id(5707),a18(184)).
head(id(5708),a22(184)).
head(id(5709),a26(184)).
head(id(5710),a34(184)).
head(id(5711),a35(184)).
head(id(5712),a5(739)).
head(id(5713),a13(739)).
head(id(5714),n(739)).
head(id(5715),a21(739)).
head(id(5716),a24(739)).
head(id(5717),a35(739)).
head(id(5718),a6(425)).
head(id(5719),a11(425)).
head(id(5720),n(425)).
head(id(5721),a18(425)).
head(id(5722),a24(425)).
head(id(5723),a26(425)).
head(id(5724),a34(425)).
head(id(5725),a35(425)).
head(id(5726),a6(742)).
head(id(5727),a13(742)).
head(id(5728),n(742)).
head(id(5729),a18(742)).
head(id(5730),a21(742)).
head(id(5731),a34(742)).
head(id(5732),a35(742)).
head(id(5733),a6(412)).
head(id(5734),a9(412)).
head(id(5735),n(412)).
head(id(5736),a18(412)).
head(id(5737),a22(412)).
head(id(5738),a24(412)).
head(id(5739),a26(412)).
head(id(5740),a34(412)).
head(id(5741),a35(412)).
head(id(5742),a9(728)).
head(id(5743),a13(728)).
head(id(5744),n(728)).
head(id(5745),a18(728)).
head(id(5746),a21(728)).
head(id(5747),a22(728)).
head(id(5748),a33(728)).
head(id(5749),a34(728)).
head(id(5750),a35(728)).
head(id(5751),a9(708)).
head(id(5752),a13(708)).
head(id(5753),n(708)).
head(id(5754),a18(708)).
head(id(5755),a21(708)).
head(id(5756),a22(708)).
head(id(5757),a24(708)).
head(id(5758),a26(708)).
head(id(5759),a34(708)).
head(id(5760),a35(708)).
head(id(5761),a5(505)).
head(id(5762),a6(505)).
head(id(5763),a7(505)).
head(id(5764),a9(505)).
head(id(5765),n(505)).
head(id(5766),a18(505)).
head(id(5767),a22(505)).
head(id(5768),a34(505)).
head(id(5769),a35(505)).
head(id(5770),a2(319)).
head(id(5771),a6(319)).
head(id(5772),a13(319)).
head(id(5773),n(319)).
head(id(5774),a18(319)).
head(id(5775),a24(319)).
head(id(5776),a35(319)).
head(id(5777),a6(470)).
head(id(5778),a9(470)).
head(id(5779),n(470)).
head(id(5780),a18(470)).
head(id(5781),a22(470)).
head(id(5782),a23(470)).
head(id(5783),a26(470)).
head(id(5784),a34(470)).
head(id(5785),a35(470)).
head(id(5786),a5(417)).
head(id(5787),a6(417)).
head(id(5788),a11(417)).
head(id(5789),n(417)).
head(id(5790),a18(417)).
head(id(5791),a26(417)).
head(id(5792),a34(417)).
head(id(5793),a35(417)).
head(id(5794),a9(19)).
head(id(5795),a11(19)).
head(id(5796),a13(19)).
head(id(5797),n(19)).
head(id(5798),a18(19)).
head(id(5799),a22(19)).
head(id(5800),a24(19)).
head(id(5801),a26(19)).
head(id(5802),a34(19)).
head(id(5803),a35(19)).
head(id(5804),a4(118)).
head(id(5805),a6(118)).
head(id(5806),a13(118)).
head(id(5807),n(118)).
head(id(5808),a18(118)).
head(id(5809),a26(118)).
head(id(5810),a35(118)).
head(id(5811),a4(679)).
head(id(5812),a6(679)).
head(id(5813),n(679)).
head(id(5814),a18(679)).
head(id(5815),a35(679)).
head(id(5816),a36(679)).
head(id(5817),a13(715)).
head(id(5818),n(715)).
head(id(5819),a21(715)).
head(id(5820),a24(715)).
head(id(5821),a26(715)).
head(id(5822),a33(715)).
head(id(5823),a35(715)).
head(id(5824),a6(506)).
head(id(5825),n(506)).
head(id(5826),a18(506)).
head(id(5827),a24(506)).
head(id(5828),a34(506)).
head(id(5829),a35(506)).
head(id(5830),a13(287)).
head(id(5831),n(287)).
head(id(5832),a24(287)).
head(id(5833),a35(287)).
head(id(5834),a11(919)).
head(id(5835),a13(919)).
head(id(5836),n(919)).
head(id(5837),a18(919)).
head(id(5838),a20(919)).
head(id(5839),a26(919)).
head(id(5840),a31(919)).
head(id(5841),a34(919)).
head(id(5842),a13(914)).
head(id(5843),n(914)).
head(id(5844),a18(914)).
head(id(5845),a24(914)).
head(id(5846),a26(914)).
head(id(5847),a31(914)).
head(id(5848),a32(914)).
head(id(5849),a34(914)).
head(id(5850),a13(908)).
head(id(5851),n(908)).
head(id(5852),a18(908)).
head(id(5853),a26(908)).
head(id(5854),a32(908)).
head(id(5855),a34(908)).
head(id(5856),a13(909)).
head(id(5857),n(909)).
head(id(5858),a18(909)).
head(id(5859),a26(909)).
head(id(5860),a31(909)).
head(id(5861),a32(909)).
head(id(5862),a34(909)).
head(id(5863),a5(906)).
head(id(5864),a7(906)).
head(id(5865),a13(906)).
head(id(5866),n(906)).
head(id(5867),a18(906)).
head(id(5868),a26(906)).
head(id(5869),a33(906)).
head(id(5870),a34(906)).
head(id(5871),a35(906)).
head(id(5872),a13(905)).
head(id(5873),n(905)).
head(id(5874),a18(905)).
head(id(5875),a26(905)).
head(id(5876),a33(905)).
head(id(5877),a34(905)).
head(id(5878),a35(905)).
head(id(5879),a9(915)).
head(id(5880),a13(915)).
head(id(5881),n(915)).
head(id(5882),a18(915)).
head(id(5883),a22(915)).
head(id(5884),a24(915)).
head(id(5885),a26(915)).
head(id(5886),a32(915)).
head(id(5887),a34(915)).
head(id(5888),a13(912)).
head(id(5889),n(912)).
head(id(5890),a18(912)).
head(id(5891),a24(912)).
head(id(5892),a26(912)).
head(id(5893),a32(912)).
head(id(5894),a34(912)).
head(id(5895),a11(918)).
head(id(5896),a13(918)).
head(id(5897),n(918)).
head(id(5898),a18(918)).
head(id(5899),a26(918)).
head(id(5900),a31(918)).
head(id(5901),a34(918)).
head(id(5902),a5(911)).
head(id(5903),a9(911)).
head(id(5904),a13(911)).
head(id(5905),n(911)).
head(id(5906),a18(911)).
head(id(5907),a22(911)).
head(id(5908),a26(911)).
head(id(5909),a32(911)).
head(id(5910),a34(911)).
head(id(5911),a9(910)).
head(id(5912),a13(910)).
head(id(5913),n(910)).
head(id(5914),a18(910)).
head(id(5915),a22(910)).
head(id(5916),a26(910)).
head(id(5917),a32(910)).
head(id(5918),a34(910)).
head(id(5919),a7(920)).
head(id(5920),a11(920)).
head(id(5921),a13(920)).
head(id(5922),n(920)).
head(id(5923),a18(920)).
head(id(5924),a26(920)).
head(id(5925),a34(920)).
head(id(5926),a5(916)).
head(id(5927),a11(916)).
head(id(5928),a13(916)).
head(id(5929),n(916)).
head(id(5930),a18(916)).
head(id(5931),a26(916)).
head(id(5932),a34(916)).
head(id(5933),a4(917)).
head(id(5934),a5(917)).
head(id(5935),a11(917)).
head(id(5936),a13(917)).
head(id(5937),n(917)).
head(id(5938),a18(917)).
head(id(5939),a26(917)).
head(id(5940),a34(917)).
head(id(19617,A),krkp(A)) :- dom(A).
body(id(19617,A),alpha_1(A)) :- dom(A).
body(id(19617,A),a13(A)) :- dom(A).
body(id(19617,A),a35(A)) :- dom(A).
body(id(19617,A),n(A)) :- dom(A).
head(id(25912,A),krkp(A)) :- dom(A).
body(id(25912,A),a26(A)) :- dom(A).
body(id(25912,A),a35(A)) :- dom(A).
body(id(25912,A),a36(A)) :- dom(A).
body(id(25912,A),n(A)) :- dom(A).
head(id(38294,A),krkp(A)) :- dom(A).
body(id(38294,A),alpha_2(A)) :- dom(A).
body(id(38294,A),a18(A)) :- dom(A).
body(id(38294,A),a34(A)) :- dom(A).
body(id(38294,A),a35(A)) :- dom(A).
body(id(38294,A),n(A)) :- dom(A).
head(id(44409,A),krkp(A)) :- dom(A).
body(id(44409,A),a18(A)) :- dom(A).
body(id(44409,A),a35(A)) :- dom(A).
body(id(44409,A),a6(A)) :- dom(A).
body(id(44409,A),n(A)) :- dom(A).
head(id(50505,A),krkp(A)) :- dom(A).
body(id(50505,A),a24(A)) :- dom(A).
body(id(50505,A),a35(A)) :- dom(A).
body(id(50505,A),a5(A)) :- dom(A).
body(id(50505,A),a6(A)) :- dom(A).
body(id(50505,A),n(A)) :- dom(A).
head(id(56602,A),krkp(A)) :- dom(A).
body(id(56602,A),a11(A)) :- dom(A).
body(id(56602,A),a13(A)) :- dom(A).
body(id(56602,A),a26(A)) :- dom(A).
body(id(56602,A),a31(A)) :- dom(A).
body(id(56602,A),w(A)) :- dom(A).
head(id(68757,A),krkp(A)) :- dom(A).
body(id(68757,A),alpha_3(A)) :- dom(A).
body(id(68757,A),a11(A)) :- dom(A).
body(id(68757,A),a13(A)) :- dom(A).
body(id(68757,A),a26(A)) :- dom(A).
body(id(68757,A),a31(A)) :- dom(A).
body(id(68757,A),n(A)) :- dom(A).
head(id(74840,A),krkp(A)) :- dom(A).
body(id(74840,A),a11(A)) :- dom(A).
body(id(74840,A),a13(A)) :- dom(A).
body(id(74840,A),a24(A)) :- dom(A).
body(id(74840,A),a26(A)) :- dom(A).
body(id(74840,A),a34(A)) :- dom(A).
body(id(74840,A),w(A)) :- dom(A).
head(id(80913,A),krkp(A)) :- dom(A).
body(id(80913,A),a11(A)) :- dom(A).
body(id(80913,A),a13(A)) :- dom(A).
body(id(80913,A),a26(A)) :- dom(A).
body(id(80913,A),a34(A)) :- dom(A).
body(id(80913,A),a35(A)) :- dom(A).
body(id(80913,A),w(A)) :- dom(A).
head(id(86981,A),krkp(A)) :- dom(A).
body(id(86981,A),a11(A)) :- dom(A).
body(id(86981,A),a13(A)) :- dom(A).
body(id(86981,A),a26(A)) :- dom(A).
body(id(86981,A),a5(A)) :- dom(A).
body(id(86981,A),a7(A)) :- dom(A).
body(id(86981,A),w(A)) :- dom(A).
head(id(93049,A),krkp(A)) :- dom(A).
body(id(93049,A),a1(A)) :- dom(A).
body(id(93049,A),a11(A)) :- dom(A).
body(id(93049,A),a18(A)) :- dom(A).
body(id(93049,A),a26(A)) :- dom(A).
body(id(93049,A),a34(A)) :- dom(A).
body(id(93049,A),n(A)) :- dom(A).
head(id(99119,A),krkp(A)) :- dom(A).
body(id(99119,A),a11(A)) :- dom(A).
body(id(99119,A),a18(A)) :- dom(A).
body(id(99119,A),a26(A)) :- dom(A).
body(id(99119,A),a34(A)) :- dom(A).
body(id(99119,A),a6(A)) :- dom(A).
body(id(99119,A),n(A)) :- dom(A).
head(id(105183,A),krkp(A)) :- dom(A).
body(id(105183,A),a11(A)) :- dom(A).
body(id(105183,A),a13(A)) :- dom(A).
body(id(105183,A),a26(A)) :- dom(A).
body(id(105183,A),a34(A)) :- dom(A).
body(id(105183,A),a7(A)) :- dom(A).
body(id(105183,A),w(A)) :- dom(A).
head(id(111248,A),krkp(A)) :- dom(A).
body(id(111248,A),a11(A)) :- dom(A).
body(id(111248,A),a13(A)) :- dom(A).
body(id(111248,A),a18(A)) :- dom(A).
body(id(111248,A),a26(A)) :- dom(A).
body(id(111248,A),a34(A)) :- dom(A).
body(id(111248,A),w(A)) :- dom(A).
head(id(117317,A),krkp(A)) :- dom(A).
body(id(117317,A),a11(A)) :- dom(A).
body(id(117317,A),a12(A)) :- dom(A).
body(id(117317,A),a13(A)) :- dom(A).
body(id(117317,A),a26(A)) :- dom(A).
body(id(117317,A),a34(A)) :- dom(A).
body(id(117317,A),w(A)) :- dom(A).
head(id(123392,A),krkp(A)) :- dom(A).
body(id(123392,A),a1(A)) :- dom(A).
body(id(123392,A),a11(A)) :- dom(A).
body(id(123392,A),a18(A)) :- dom(A).
body(id(123392,A),a26(A)) :- dom(A).
body(id(123392,A),a34(A)) :- dom(A).
body(id(123392,A),b(A)) :- dom(A).
head(id(129462,A),krkp(A)) :- dom(A).
body(id(129462,A),a11(A)) :- dom(A).
body(id(129462,A),a24(A)) :- dom(A).
body(id(129462,A),a26(A)) :- dom(A).
body(id(129462,A),a35(A)) :- dom(A).
body(id(129462,A),a4(A)) :- dom(A).
body(id(129462,A),a6(A)) :- dom(A).
body(id(129462,A),n(A)) :- dom(A).
head(id(135539,A),krkp(A)) :- dom(A).
body(id(135539,A),a11(A)) :- dom(A).
body(id(135539,A),a13(A)) :- dom(A).
body(id(135539,A),a24(A)) :- dom(A).
body(id(135539,A),a26(A)) :- dom(A).
body(id(135539,A),a6(A)) :- dom(A).
body(id(135539,A),a7(A)) :- dom(A).
body(id(135539,A),n(A)) :- dom(A).
head(id(141622,A),krkp(A)) :- dom(A).
body(id(141622,A),a11(A)) :- dom(A).
body(id(141622,A),a13(A)) :- dom(A).
body(id(141622,A),a18(A)) :- dom(A).
body(id(141622,A),a26(A)) :- dom(A).
body(id(141622,A),a6(A)) :- dom(A).
body(id(141622,A),a7(A)) :- dom(A).
body(id(141622,A),n(A)) :- dom(A).
head(id(147711,A),krkp(A)) :- dom(A).
body(id(147711,A),a11(A)) :- dom(A).
body(id(147711,A),a18(A)) :- dom(A).
body(id(147711,A),a26(A)) :- dom(A).
body(id(147711,A),a34(A)) :- dom(A).
body(id(147711,A),a35(A)) :- dom(A).
body(id(147711,A),a6(A)) :- dom(A).
body(id(147711,A),b(A)) :- dom(A).
head(id(153804,A),krkp(A)) :- dom(A).
body(id(153804,A),a11(A)) :- dom(A).
body(id(153804,A),a13(A)) :- dom(A).
body(id(153804,A),a22(A)) :- dom(A).
body(id(153804,A),a26(A)) :- dom(A).
body(id(153804,A),a34(A)) :- dom(A).
body(id(153804,A),a9(A)) :- dom(A).
body(id(153804,A),w(A)) :- dom(A).
head(id(159904,A),krkp(A)) :- dom(A).
body(id(159904,A),a11(A)) :- dom(A).
body(id(159904,A),a13(A)) :- dom(A).
body(id(159904,A),a24(A)) :- dom(A).
body(id(159904,A),a26(A)) :- dom(A).
body(id(159904,A),a6(A)) :- dom(A).
body(id(159904,A),a7(A)) :- dom(A).
body(id(159904,A),w(A)) :- dom(A).
head(id(166010,A),c_alpha_1(A)) :- dom(A).
body(id(166010,A),a13(A)) :- dom(A).
body(id(166010,A),a18(A)) :- dom(A).
body(id(166010,A),a26(A)) :- dom(A).
body(id(166010,A),a33(A)) :- dom(A).
body(id(166010,A),a34(A)) :- dom(A).
body(id(166010,A),a35(A)) :- dom(A).
body(id(166010,A),n(A)) :- dom(A).
head(id(178240,A),c_alpha_2(A)) :- dom(A).
body(id(178240,A),alpha_4(A)) :- dom(A).
body(id(178240,A),a13(A)) :- dom(A).
body(id(178240,A),a18(A)) :- dom(A).
body(id(178240,A),a26(A)) :- dom(A).
body(id(178240,A),a33(A)) :- dom(A).
body(id(178240,A),a34(A)) :- dom(A).
body(id(178240,A),a35(A)) :- dom(A).
body(id(178240,A),n(A)) :- dom(A).
head(id(184370,A),c_alpha_3(A)) :- dom(A).
body(id(184370,A),a11(A)) :- dom(A).
body(id(184370,A),a13(A)) :- dom(A).
body(id(184370,A),a18(A)) :- dom(A).
body(id(184370,A),a26(A)) :- dom(A).
body(id(184370,A),a31(A)) :- dom(A).
body(id(184370,A),a34(A)) :- dom(A).
body(id(184370,A),n(A)) :- dom(A).
head(id(190500,A),krkp(A)) :- dom(A).
body(id(190500,A),a11(A)) :- dom(A).
body(id(190500,A),a13(A)) :- dom(A).
body(id(190500,A),a26(A)) :- dom(A).
body(id(190500,A),a35(A)) :- dom(A).
body(id(190500,A),a7(A)) :- dom(A).
body(id(190500,A),a8(A)) :- dom(A).
body(id(190500,A),a9(A)) :- dom(A).
body(id(190500,A),w(A)) :- dom(A).
head(id(196638,A),c_alpha_4(A)) :- dom(A).
body(id(196638,A),a13(A)) :- dom(A).
body(id(196638,A),a18(A)) :- dom(A).
body(id(196638,A),a21(A)) :- dom(A).
body(id(196638,A),a26(A)) :- dom(A).
body(id(196638,A),a33(A)) :- dom(A).
body(id(196638,A),a34(A)) :- dom(A).
body(id(196638,A),a35(A)) :- dom(A).
body(id(196638,A),n(A)) :- dom(A).
head(id(202782,A),krkp(A)) :- dom(A).
body(id(202782,A),a1(A)) :- dom(A).
body(id(202782,A),a11(A)) :- dom(A).
body(id(202782,A),a13(A)) :- dom(A).
body(id(202782,A),a18(A)) :- dom(A).
body(id(202782,A),a26(A)) :- dom(A).
body(id(202782,A),a35(A)) :- dom(A).
body(id(202782,A),a5(A)) :- dom(A).
body(id(202782,A),a6(A)) :- dom(A).
body(id(202782,A),b(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
assumption(alpha_4(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).
contrary(alpha_4(A),c_alpha_4(A)) :- assumption(alpha_4(A)).

dom(2).
dom(3).
dom(4).
dom(5).
dom(7).
dom(9).
dom(12).
dom(14).
dom(16).
dom(17).
dom(19).
dom(20).
dom(21).
dom(22).
dom(24).
dom(26).
dom(27).
dom(29).
dom(30).
dom(31).
dom(33).
dom(34).
dom(35).
dom(36).
dom(37).
dom(38).
dom(39).
dom(42).
dom(43).
dom(44).
dom(45).
dom(46).
dom(48).
dom(49).
dom(50).
dom(51).
dom(52).
dom(53).
dom(54).
dom(55).
dom(56).
dom(58).
dom(59).
dom(60).
dom(62).
dom(65).
dom(69).
dom(70).
dom(71).
dom(72).
dom(73).
dom(75).
dom(76).
dom(77).
dom(78).
dom(79).
dom(80).
dom(81).
dom(82).
dom(83).
dom(84).
dom(85).
dom(88).
dom(89).
dom(90).
dom(92).
dom(93).
dom(95).
dom(96).
dom(97).
dom(98).
dom(99).
dom(101).
dom(102).
dom(104).
dom(105).
dom(107).
dom(108).
dom(109).
dom(110).
dom(111).
dom(113).
dom(115).
dom(116).
dom(117).
dom(118).
dom(119).
dom(120).
dom(122).
dom(123).
dom(124).
dom(125).
dom(127).
dom(128).
dom(129).
dom(130).
dom(131).
dom(132).
dom(133).
dom(134).
dom(135).
dom(136).
dom(137).
dom(138).
dom(140).
dom(141).
dom(142).
dom(143).
dom(144).
dom(145).
dom(147).
dom(149).
dom(151).
dom(152).
dom(153).
dom(154).
dom(155).
dom(156).
dom(157).
dom(159).
dom(160).
dom(162).
dom(163).
dom(164).
dom(165).
dom(167).
dom(168).
dom(170).
dom(172).
dom(174).
dom(175).
dom(177).
dom(179).
dom(180).
dom(181).
dom(182).
dom(183).
dom(184).
dom(185).
dom(186).
dom(187).
dom(188).
dom(189).
dom(190).
dom(191).
dom(192).
dom(193).
dom(195).
dom(196).
dom(197).
dom(198).
dom(199).
dom(200).
dom(201).
dom(202).
dom(203).
dom(204).
dom(205).
dom(206).
dom(207).
dom(208).
dom(209).
dom(210).
dom(211).
dom(212).
dom(213).
dom(214).
dom(218).
dom(222).
dom(224).
dom(225).
dom(226).
dom(230).
dom(231).
dom(232).
dom(233).
dom(234).
dom(235).
dom(237).
dom(238).
dom(239).
dom(240).
dom(241).
dom(242).
dom(244).
dom(245).
dom(246).
dom(247).
dom(248).
dom(249).
dom(251).
dom(254).
dom(255).
dom(257).
dom(259).
dom(261).
dom(262).
dom(264).
dom(265).
dom(266).
dom(267).
dom(268).
dom(269).
dom(270).
dom(271).
dom(272).
dom(273).
dom(275).
dom(276).
dom(278).
dom(279).
dom(280).
dom(281).
dom(282).
dom(283).
dom(284).
dom(285).
dom(286).
dom(287).
dom(288).
dom(291).
dom(292).
dom(293).
dom(295).
dom(296).
dom(297).
dom(298).
dom(300).
dom(301).
dom(302).
dom(303).
dom(304).
dom(305).
dom(307).
dom(308).
dom(309).
dom(311).
dom(312).
dom(313).
dom(314).
dom(315).
dom(316).
dom(317).
dom(318).
dom(319).
dom(321).
dom(322).
dom(323).
dom(324).
dom(325).
dom(328).
dom(329).
dom(330).
dom(331).
dom(332).
dom(333).
dom(334).
dom(335).
dom(336).
dom(337).
dom(338).
dom(339).
dom(340).
dom(341).
dom(342).
dom(343).
dom(344).
dom(345).
dom(346).
dom(347).
dom(349).
dom(350).
dom(353).
dom(354).
dom(355).
dom(356).
dom(359).
dom(360).
dom(361).
dom(362).
dom(363).
dom(364).
dom(366).
dom(367).
dom(368).
dom(369).
dom(370).
dom(371).
dom(372).
dom(373).
dom(375).
dom(378).
dom(379).
dom(380).
dom(382).
dom(383).
dom(384).
dom(385).
dom(386).
dom(387).
dom(388).
dom(389).
dom(390).
dom(392).
dom(394).
dom(396).
dom(397).
dom(398).
dom(399).
dom(400).
dom(401).
dom(403).
dom(404).
dom(405).
dom(406).
dom(407).
dom(408).
dom(409).
dom(410).
dom(411).
dom(412).
dom(414).
dom(416).
dom(417).
dom(418).
dom(419).
dom(420).
dom(421).
dom(422).
dom(424).
dom(425).
dom(426).
dom(427).
dom(428).
dom(429).
dom(430).
dom(431).
dom(432).
dom(433).
dom(434).
dom(435).
dom(436).
dom(437).
dom(439).
dom(440).
dom(442).
dom(443).
dom(445).
dom(446).
dom(447).
dom(449).
dom(450).
dom(451).
dom(452).
dom(453).
dom(454).
dom(455).
dom(456).
dom(457).
dom(458).
dom(459).
dom(461).
dom(462).
dom(463).
dom(464).
dom(465).
dom(466).
dom(467).
dom(468).
dom(469).
dom(470).
dom(471).
dom(472).
dom(473).
dom(474).
dom(476).
dom(477).
dom(478).
dom(480).
dom(481).
dom(482).
dom(483).
dom(484).
dom(485).
dom(486).
dom(487).
dom(488).
dom(489).
dom(490).
dom(491).
dom(492).
dom(494).
dom(495).
dom(497).
dom(499).
dom(500).
dom(501).
dom(502).
dom(503).
dom(504).
dom(505).
dom(506).
dom(507).
dom(508).
dom(509).
dom(510).
dom(511).
dom(512).
dom(513).
dom(514).
dom(515).
dom(516).
dom(517).
dom(518).
dom(519).
dom(521).
dom(522).
dom(525).
dom(526).
dom(527).
dom(529).
dom(532).
dom(533).
dom(534).
dom(535).
dom(536).
dom(538).
dom(540).
dom(541).
dom(542).
dom(543).
dom(544).
dom(546).
dom(547).
dom(548).
dom(549).
dom(550).
dom(551).
dom(552).
dom(553).
dom(555).
dom(556).
dom(557).
dom(558).
dom(559).
dom(560).
dom(561).
dom(562).
dom(563).
dom(564).
dom(565).
dom(568).
dom(569).
dom(571).
dom(572).
dom(573).
dom(574).
dom(576).
dom(577).
dom(579).
dom(580).
dom(581).
dom(582).
dom(583).
dom(584).
dom(585).
dom(586).
dom(587).
dom(588).
dom(589).
dom(590).
dom(591).
dom(592).
dom(593).
dom(594).
dom(596).
dom(597).
dom(598).
dom(599).
dom(600).
dom(602).
dom(603).
dom(604).
dom(605).
dom(606).
dom(608).
dom(609).
dom(611).
dom(612).
dom(613).
dom(614).
dom(615).
dom(616).
dom(617).
dom(618).
dom(619).
dom(621).
dom(622).
dom(623).
dom(625).
dom(626).
dom(628).
dom(629).
dom(630).
dom(632).
dom(633).
dom(634).
dom(635).
dom(636).
dom(637).
dom(639).
dom(640).
dom(641).
dom(642).
dom(644).
dom(645).
dom(646).
dom(648).
dom(649).
dom(650).
dom(651).
dom(656).
dom(657).
dom(658).
dom(659).
dom(660).
dom(661).
dom(662).
dom(663).
dom(665).
dom(666).
dom(667).
dom(669).
dom(670).
dom(671).
dom(672).
dom(674).
dom(675).
dom(676).
dom(677).
dom(678).
dom(679).
dom(680).
dom(682).
dom(683).
dom(684).
dom(685).
dom(686).
dom(688).
dom(689).
dom(690).
dom(691).
dom(692).
dom(693).
dom(694).
dom(695).
dom(696).
dom(697).
dom(698).
dom(701).
dom(702).
dom(704).
dom(705).
dom(706).
dom(707).
dom(708).
dom(709).
dom(710).
dom(711).
dom(712).
dom(713).
dom(714).
dom(715).
dom(717).
dom(718).
dom(719).
dom(720).
dom(721).
dom(722).
dom(723).
dom(724).
dom(725).
dom(726).
dom(727).
dom(728).
dom(729).
dom(730).
dom(731).
dom(733).
dom(734).
dom(735).
dom(736).
dom(737).
dom(739).
dom(740).
dom(741).
dom(742).
dom(743).
dom(744).
dom(746).
dom(748).
dom(749).
dom(750).
dom(754).
dom(755).
dom(756).
dom(758).
dom(759).
dom(760).
dom(761).
dom(763).
dom(764).
dom(765).
dom(768).
dom(769).
dom(772).
dom(774).
dom(776).
dom(778).
dom(779).
dom(780).
dom(781).
dom(783).
dom(784).
dom(785).
dom(786).
dom(787).
dom(788).
dom(789).
dom(790).
dom(791).
dom(793).
dom(795).
dom(796).
dom(797).
dom(798).
dom(799).
dom(800).
dom(801).
dom(803).
dom(804).
dom(805).
dom(806).
dom(807).
dom(808).
dom(809).
dom(810).
dom(813).
dom(814).
dom(815).
dom(816).
dom(817).
dom(818).
dom(820).
dom(821).
dom(822).
dom(823).
dom(824).
dom(826).
dom(827).
dom(829).
dom(830).
dom(833).
dom(835).
dom(836).
dom(837).
dom(839).
dom(840).
dom(842).
dom(843).
dom(844).
dom(845).
dom(846).
dom(847).
dom(848).
dom(850).
dom(851).
dom(852).
dom(854).
dom(855).
dom(856).
dom(857).
dom(858).
dom(859).
dom(860).
dom(861).
dom(862).
dom(863).
dom(864).
dom(865).
dom(866).
dom(867).
dom(868).
dom(869).
dom(870).
dom(871).
dom(872).
dom(873).
dom(875).
dom(877).
dom(878).
dom(879).
dom(880).
dom(881).
dom(882).
dom(883).
dom(884).
dom(885).
dom(886).
dom(889).
dom(890).
dom(891).
dom(892).
dom(893).
dom(895).
dom(896).
dom(897).
dom(898).
dom(899).
dom(900).
dom(901).
dom(902).
dom(903).
dom(904).
dom(905).
dom(906).
dom(908).
dom(909).
dom(910).
dom(911).
dom(912).
dom(914).
dom(915).
dom(916).
dom(917).
dom(918).
dom(919).
dom(920).
 :- not supported(krkp(78)).
 :- not supported(krkp(392)).
 :- not supported(krkp(521)).
 :- not supported(krkp(239)).
 :- not supported(krkp(551)).
 :- not supported(krkp(107)).
 :- not supported(krkp(577)).
 :- not supported(krkp(264)).
 :- not supported(krkp(270)).
 :- not supported(krkp(686)).
 :- not supported(krkp(312)).
 :- not supported(krkp(669)).
 :- not supported(krkp(458)).
 :- not supported(krkp(880)).
 :- not supported(krkp(196)).
 :- not supported(krkp(99)).
 :- not supported(krkp(427)).
 :- not supported(krkp(408)).
 :- not supported(krkp(852)).
 :- not supported(krkp(623)).
 :- not supported(krkp(298)).
 :- not supported(krkp(582)).
 :- not supported(krkp(257)).
 :- not supported(krkp(689)).
 :- not supported(krkp(109)).
 :- not supported(krkp(793)).
 :- not supported(krkp(484)).
 :- not supported(krkp(399)).
 :- not supported(krkp(262)).
 :- not supported(krkp(416)).
 :- not supported(krkp(724)).
 :- not supported(krkp(278)).
 :- not supported(krkp(884)).
 :- not supported(krkp(897)).
 :- not supported(krkp(89)).
 :- not supported(krkp(837)).
 :- not supported(krkp(560)).
 :- not supported(krkp(743)).
 :- not supported(krkp(24)).
 :- not supported(krkp(613)).
 :- not supported(krkp(640)).
 :- not supported(krkp(457)).
 :- not supported(krkp(370)).
 :- not supported(krkp(137)).
 :- not supported(krkp(482)).
 :- not supported(krkp(65)).
 :- not supported(krkp(740)).
 :- not supported(krkp(387)).
 :- not supported(krkp(350)).
 :- not supported(krkp(584)).
 :- not supported(krkp(836)).
 :- not supported(krkp(882)).
 :- not supported(krkp(437)).
 :- not supported(krkp(840)).
 :- not supported(krkp(495)).
 :- not supported(krkp(839)).
 :- not supported(krkp(224)).
 :- not supported(krkp(31)).
 :- not supported(krkp(791)).
 :- not supported(krkp(242)).
 :- not supported(krkp(302)).
 :- not supported(krkp(192)).
 :- not supported(krkp(93)).
 :- not supported(krkp(430)).
 :- not supported(krkp(461)).
 :- not supported(krkp(311)).
 :- not supported(krkp(861)).
 :- not supported(krkp(717)).
 :- not supported(krkp(22)).
 :- not supported(krkp(58)).
 :- not supported(krkp(657)).
 :- not supported(krkp(116)).
 :- not supported(krkp(491)).
 :- not supported(krkp(53)).
 :- not supported(krkp(440)).
 :- not supported(krkp(869)).
 :- not supported(krkp(371)).
 :- not supported(krkp(471)).
 :- not supported(krkp(685)).
 :- not supported(krkp(730)).
 :- not supported(krkp(592)).
 :- not supported(krkp(363)).
 :- not supported(krkp(55)).
 :- not supported(krkp(230)).
 :- not supported(krkp(325)).
 :- not supported(krkp(694)).
 :- not supported(krkp(646)).
 :- not supported(krkp(883)).
 :- not supported(krkp(650)).
 :- not supported(krkp(873)).
 :- not supported(krkp(645)).
 :- not supported(krkp(244)).
 :- not supported(krkp(295)).
 :- not supported(krkp(795)).
 :- not supported(krkp(569)).
 :- not supported(krkp(149)).
 :- not supported(krkp(796)).
 :- not supported(krkp(433)).
 :- not supported(krkp(152)).
 :- not supported(krkp(36)).
 :- not supported(krkp(361)).
 :- not supported(krkp(678)).
 :- not supported(krkp(308)).
 :- not supported(krkp(397)).
 :- not supported(krkp(866)).
 :- not supported(krkp(254)).
 :- not supported(krkp(279)).
 :- not supported(krkp(600)).
 :- not supported(krkp(662)).
 :- not supported(krkp(586)).
 :- not supported(krkp(472)).
 :- not supported(krkp(824)).
 :- not supported(krkp(347)).
 :- not supported(krkp(59)).
 :- not supported(krkp(411)).
 :- not supported(krkp(508)).
 :- not supported(krkp(658)).
 :- not supported(krkp(373)).
 :- not supported(krkp(177)).
 :- not supported(krkp(691)).
 :- not supported(krkp(617)).
 :- not supported(krkp(168)).
 :- not supported(krkp(186)).
 :- not supported(krkp(895)).
 :- not supported(krkp(163)).
 :- not supported(krkp(704)).
 :- not supported(krkp(463)).
 :- not supported(krkp(454)).
 :- not supported(krkp(432)).
 :- not supported(krkp(671)).
 :- not supported(krkp(847)).
 :- not supported(krkp(860)).
 :- not supported(krkp(336)).
 :- not supported(krkp(111)).
 :- not supported(krkp(266)).
 :- not supported(krkp(608)).
 :- not supported(krkp(211)).
 :- not supported(krkp(331)).
 :- not supported(krkp(339)).
 :- not supported(krkp(746)).
 :- not supported(krkp(886)).
 :- not supported(krkp(17)).
 :- not supported(krkp(862)).
 :- not supported(krkp(45)).
 :- not supported(krkp(774)).
 :- not supported(krkp(160)).
 :- not supported(krkp(75)).
 :- not supported(krkp(674)).
 :- not supported(krkp(707)).
 :- not supported(krkp(625)).
 :- not supported(krkp(871)).
 :- not supported(krkp(842)).
 :- not supported(krkp(255)).
 :- not supported(krkp(2)).
 :- not supported(krkp(29)).
 :- not supported(krkp(877)).
 :- not supported(krkp(459)).
 :- not supported(krkp(486)).
 :- not supported(krkp(232)).
 :- not supported(krkp(79)).
 :- not supported(krkp(388)).
 :- not supported(krkp(682)).
 :- not supported(krkp(349)).
 :- not supported(krkp(806)).
 :- not supported(krkp(464)).
 :- not supported(krkp(360)).
 :- not supported(krkp(330)).
 :- not supported(krkp(151)).
 :- not supported(krkp(297)).
 :- not supported(krkp(44)).
 :- not supported(krkp(337)).
 :- not supported(krkp(424)).
 :- not supported(krkp(197)).
 :- not supported(krkp(536)).
 :- not supported(krkp(30)).
 :- not supported(krkp(70)).
 :- not supported(krkp(588)).
 :- not supported(krkp(749)).
 :- not supported(krkp(893)).
 :- not supported(krkp(359)).
 :- not supported(krkp(43)).
 :- not supported(krkp(573)).
 :- not supported(krkp(797)).
 :- not supported(krkp(201)).
 :- not supported(krkp(807)).
 :- not supported(krkp(188)).
 :- not supported(krkp(675)).
 :- not supported(krkp(902)).
 :- not supported(krkp(140)).
 :- not supported(krkp(138)).
 :- not supported(krkp(817)).
 :- not supported(krkp(890)).
 :- not supported(krkp(820)).
 :- not supported(krkp(867)).
 :- not supported(krkp(813)).
 :- not supported(krkp(612)).
 :- not supported(krkp(313)).
 :- not supported(krkp(205)).
 :- not supported(krkp(154)).
 :- not supported(krkp(833)).
 :- not supported(krkp(478)).
 :- not supported(krkp(102)).
 :- not supported(krkp(848)).
 :- not supported(krkp(84)).
 :- not supported(krkp(90)).
 :- not supported(krkp(354)).
 :- not supported(krkp(670)).
 :- not supported(krkp(410)).
 :- not supported(krkp(719)).
 :- not supported(krkp(418)).
 :- not supported(krkp(346)).
 :- not supported(krkp(429)).
 :- not supported(krkp(798)).
 :- not supported(krkp(885)).
 :- not supported(krkp(563)).
 :- not supported(krkp(649)).
 :- not supported(krkp(597)).
 :- not supported(krkp(714)).
 :- not supported(krkp(108)).
 :- not supported(krkp(851)).
 :- not supported(krkp(476)).
 :- not supported(krkp(286)).
 :- not supported(krkp(404)).
 :- not supported(krkp(760)).
 :- not supported(krkp(602)).
 :- not supported(krkp(504)).
 :- not supported(krkp(533)).
 :- not supported(krkp(748)).
 :- not supported(krkp(903)).
 :- not supported(krkp(303)).
 :- not supported(krkp(268)).
 :- not supported(krkp(835)).
 :- not supported(krkp(276)).
 :- not supported(krkp(515)).
 :- not supported(krkp(769)).
 :- not supported(krkp(596)).
 :- not supported(krkp(552)).
 :- not supported(krkp(105)).
 :- not supported(krkp(129)).
 :- not supported(krkp(892)).
 :- not supported(krkp(157)).
 :- not supported(krkp(507)).
 :- not supported(krkp(614)).
 :- not supported(krkp(626)).
 :- not supported(krkp(680)).
 :- not supported(krkp(695)).
 :- not supported(krkp(82)).
 :- not supported(krkp(179)).
 :- not supported(krkp(485)).
 :- not supported(krkp(514)).
 :- not supported(krkp(659)).
 :- not supported(krkp(329)).
 :- not supported(krkp(142)).
 :- not supported(krkp(225)).
 :- not supported(krkp(565)).
 :- not supported(krkp(725)).
 :- not supported(krkp(736)).
 :- not supported(krkp(281)).
 :- not supported(krkp(785)).
 :- not supported(krkp(816)).
 :- not supported(krkp(304)).
 :- not supported(krkp(576)).
 :- not supported(krkp(207)).
 :- not supported(krkp(616)).
 :- not supported(krkp(181)).
 :- not supported(krkp(693)).
 :- not supported(krkp(878)).
 :- not supported(krkp(113)).
 :- not supported(krkp(480)).
 :- not supported(krkp(155)).
 :- not supported(krkp(237)).
 :- not supported(krkp(526)).
 :- not supported(krkp(546)).
 :- not supported(krkp(543)).
 :- not supported(krkp(378)).
 :- not supported(krkp(772)).
 :- not supported(krkp(672)).
 :- not supported(krkp(855)).
 :- not supported(krkp(587)).
 :- not supported(krkp(764)).
 :- not supported(krkp(814)).
 :- not supported(krkp(512)).
 :- not supported(krkp(761)).
 :- not supported(krkp(572)).
 :- not supported(krkp(165)).
 :- not supported(krkp(502)).
 :- not supported(krkp(81)).
 :- not supported(krkp(97)).
 :- not supported(krkp(487)).
 :- not supported(krkp(119)).
 :- not supported(krkp(858)).
 :- not supported(krkp(497)).
 :- not supported(krkp(419)).
 :- not supported(krkp(683)).
 :- not supported(krkp(477)).
 :- not supported(krkp(517)).
 :- not supported(krkp(20)).
 :- not supported(krkp(4)).
 :- not supported(krkp(69)).
 :- not supported(krkp(555)).
 :- not supported(krkp(134)).
 :- not supported(krkp(110)).
 :- not supported(krkp(442)).
 :- not supported(krkp(235)).
 :- not supported(krkp(843)).
 :- not supported(krkp(159)).
 :- not supported(krkp(180)).
 :- not supported(krkp(518)).
 :- not supported(krkp(604)).
 :- not supported(krkp(202)).
 :- not supported(krkp(332)).
 :- not supported(krkp(170)).
 :- not supported(krkp(525)).
 :- not supported(krkp(136)).
 :- not supported(krkp(162)).
 :- not supported(krkp(193)).
 :- not supported(krkp(167)).
 :- not supported(krkp(123)).
 :- not supported(krkp(712)).
 :- not supported(krkp(904)).
 :- not supported(krkp(726)).
 :- not supported(krkp(367)).
 :- not supported(krkp(353)).
 :- not supported(krkp(316)).
 :- not supported(krkp(335)).
 :- not supported(krkp(366)).
 :- not supported(krkp(296)).
 :- not supported(krkp(214)).
 :- not supported(krkp(117)).
 :- not supported(krkp(380)).
 :- not supported(krkp(879)).
 :- not supported(krkp(519)).
 :- not supported(krkp(334)).
 :- not supported(krkp(439)).
 :- not supported(krkp(407)).
 :- not supported(krkp(583)).
 :- not supported(krkp(870)).
 :- not supported(krkp(535)).
 :- not supported(krkp(808)).
 :- not supported(krkp(666)).
 :- not supported(krkp(868)).
 :- not supported(krkp(468)).
 :- not supported(krkp(901)).
 :- not supported(krkp(272)).
 :- not supported(krkp(452)).
 :- not supported(krkp(898)).
 :- not supported(krkp(5)).
 :- not supported(krkp(450)).
 :- not supported(krkp(854)).
 :- not supported(krkp(499)).
 :- not supported(krkp(340)).
 :- not supported(krkp(900)).
 :- not supported(krkp(421)).
 :- not supported(krkp(189)).
 :- not supported(krkp(322)).
 :- not supported(krkp(619)).
 :- not supported(krkp(603)).
 :- not supported(krkp(755)).
 :- not supported(krkp(723)).
 :- not supported(krkp(548)).
 :- not supported(krkp(590)).
 :- not supported(krkp(135)).
 :- not supported(krkp(579)).
 :- not supported(krkp(593)).
 :- not supported(krkp(405)).
 :- not supported(krkp(722)).
 :- not supported(krkp(696)).
 :- not supported(krkp(490)).
 :- not supported(krkp(445)).
 :- not supported(krkp(375)).
 :- not supported(krkp(62)).
 :- not supported(krkp(208)).
 :- not supported(krkp(826)).
 :- not supported(krkp(676)).
 :- not supported(krkp(532)).
 :- not supported(krkp(776)).
 :- not supported(krkp(702)).
 :- not supported(krkp(323)).
 :- not supported(krkp(606)).
 :- not supported(krkp(356)).
 :- not supported(krkp(127)).
 :- not supported(krkp(481)).
 :- not supported(krkp(594)).
 :- not supported(krkp(92)).
 :- not supported(krkp(456)).
 :- not supported(krkp(288)).
 :- not supported(krkp(283)).
 :- not supported(krkp(368)).
 :- not supported(krkp(324)).
 :- not supported(krkp(850)).
 :- not supported(krkp(455)).
 :- not supported(krkp(844)).
 :- not supported(krkp(48)).
 :- not supported(krkp(568)).
 :- not supported(krkp(889)).
 :- not supported(krkp(618)).
 :- not supported(krkp(386)).
 :- not supported(krkp(896)).
 :- not supported(krkp(473)).
 :- not supported(krkp(711)).
 :- not supported(krkp(174)).
 :- not supported(krkp(37)).
 :- not supported(krkp(591)).
 :- not supported(krkp(564)).
 :- not supported(krkp(881)).
 :- not supported(krkp(301)).
 :- not supported(krkp(744)).
 :- not supported(krkp(426)).
 :- not supported(krkp(447)).
 :- not supported(krkp(865)).
 :- not supported(krkp(88)).
 :- not supported(krkp(538)).
 :- not supported(krkp(763)).
 :- not supported(krkp(864)).
 :- not supported(krkp(143)).
 :- not supported(krkp(16)).
 :- not supported(krkp(125)).
 :- not supported(krkp(77)).
 :- not supported(krkp(431)).
 :- not supported(krkp(799)).
 :- not supported(krkp(27)).
 :- not supported(krkp(509)).
 :- not supported(krkp(122)).
 :- not supported(krkp(265)).
 :- not supported(krkp(622)).
 :- not supported(krkp(804)).
 :- not supported(krkp(488)).
 :- not supported(krkp(333)).
 :- not supported(krkp(648)).
 :- not supported(krkp(21)).
 :- not supported(krkp(144)).
 :- not supported(krkp(609)).
 :- not supported(krkp(212)).
 :- not supported(krkp(390)).
 :- not supported(krkp(248)).
 :- not supported(krkp(727)).
 :- not supported(krkp(803)).
 :- not supported(krkp(396)).
 :- not supported(krkp(784)).
 :- not supported(krkp(731)).
 :- not supported(krkp(891)).
 :- not supported(krkp(781)).
 :- not supported(krkp(467)).
 :- not supported(krkp(96)).
 :- not supported(krkp(581)).
 :- not supported(krkp(639)).
 :- not supported(krkp(293)).
 :- not supported(krkp(827)).
 :- not supported(krkp(621)).
 :- not supported(krkp(446)).
 :- not supported(krkp(309)).
 :- not supported(krkp(733)).
 :- not supported(krkp(284)).
 :- not supported(krkp(436)).
 :- not supported(krkp(729)).
 :- not supported(krkp(859)).
 :- not supported(krkp(247)).
 :- not supported(krkp(541)).
 :- not supported(krkp(7)).
 :- not supported(krkp(489)).
 :- not supported(krkp(271)).
 :- not supported(krkp(132)).
 :- not supported(krkp(409)).
 :- not supported(krkp(307)).
 :- not supported(krkp(642)).
 :- not supported(krkp(556)).
 :- not supported(krkp(513)).
 :- not supported(krkp(661)).
 :- not supported(krkp(73)).
 :- not supported(krkp(542)).
 :- not supported(krkp(338)).
 :- not supported(krkp(500)).
 :- not supported(krkp(398)).
 :- not supported(krkp(124)).
 :- not supported(krkp(718)).
 :- not supported(krkp(33)).
 :- not supported(krkp(710)).
 :- not supported(krkp(574)).
 :- not supported(krkp(615)).
 :- not supported(krkp(756)).
 :- not supported(krkp(401)).
 :- not supported(krkp(187)).
 :- not supported(krkp(213)).
 :- not supported(krkp(83)).
 :- not supported(krkp(787)).
 :- not supported(krkp(599)).
 :- not supported(krkp(632)).
 :- not supported(krkp(562)).
 :- not supported(krkp(805)).
 :- not supported(krkp(115)).
 :- not supported(krkp(369)).
 :- not supported(krkp(786)).
 :- not supported(krkp(561)).
 :- not supported(krkp(818)).
 :- not supported(krkp(345)).
 :- not supported(krkp(344)).
 :- not supported(krkp(462)).
 :- not supported(krkp(389)).
 :- not supported(krkp(451)).
 :- not supported(krkp(465)).
 :- not supported(krkp(343)).
 :- not supported(krkp(790)).
 :- not supported(krkp(85)).
 :- not supported(krkp(233)).
 :- not supported(krkp(364)).
 :- not supported(krkp(522)).
 :- not supported(krkp(829)).
 :- not supported(krkp(234)).
 :- not supported(krkp(422)).
 :- not supported(krkp(553)).
 :- not supported(krkp(9)).
 :- not supported(krkp(783)).
 :- not supported(krkp(527)).
 :- not supported(krkp(701)).
 :- not supported(krkp(46)).
 :- not supported(krkp(26)).
 :- not supported(krkp(637)).
 :- not supported(krkp(300)).
 :- not supported(krkp(449)).
 :- not supported(krkp(246)).
 :- not supported(krkp(341)).
 :- not supported(krkp(285)).
 :- not supported(krkp(400)).
 :- not supported(krkp(104)).
 :- not supported(krkp(210)).
 :- not supported(krkp(598)).
 :- not supported(krkp(630)).
 :- not supported(krkp(875)).
 :- not supported(krkp(688)).
 :- not supported(krkp(720)).
 :- not supported(krkp(71)).
 :- not supported(krkp(516)).
 :- not supported(krkp(231)).
 :- not supported(krkp(754)).
 :- not supported(krkp(414)).
 :- not supported(krkp(501)).
 :- not supported(krkp(267)).
 :- not supported(krkp(656)).
 :- not supported(krkp(830)).
 :- not supported(krkp(420)).
 :- not supported(krkp(788)).
 :- not supported(krkp(49)).
 :- not supported(krkp(698)).
 :- not supported(krkp(529)).
 :- not supported(krkp(372)).
 :- not supported(krkp(660)).
 :- not supported(krkp(185)).
 :- not supported(krkp(379)).
 :- not supported(krkp(758)).
 :- not supported(krkp(3)).
 :- not supported(krkp(636)).
 :- not supported(krkp(684)).
 :- not supported(krkp(741)).
 :- not supported(krkp(635)).
 :- not supported(krkp(60)).
 :- not supported(krkp(547)).
 :- not supported(krkp(38)).
 :- not supported(krkp(759)).
 :- not supported(krkp(183)).
 :- not supported(krkp(35)).
 :- not supported(krkp(644)).
 :- not supported(krkp(98)).
 :- not supported(krkp(667)).
 :- not supported(krkp(768)).
 :- not supported(krkp(403)).
 :- not supported(krkp(172)).
 :- not supported(krkp(474)).
 :- not supported(krkp(697)).
 :- not supported(krkp(14)).
 :- not supported(krkp(511)).
 :- not supported(krkp(534)).
 :- not supported(krkp(705)).
 :- not supported(krkp(665)).
 :- not supported(krkp(434)).
 :- not supported(krkp(238)).
 :- not supported(krkp(226)).
 :- not supported(krkp(175)).
 :- not supported(krkp(51)).
 :- not supported(krkp(800)).
 :- not supported(krkp(259)).
 :- not supported(krkp(120)).
 :- not supported(krkp(50)).
 :- not supported(krkp(634)).
 :- not supported(krkp(72)).
 :- not supported(krkp(737)).
 :- not supported(krkp(305)).
 :- not supported(krkp(130)).
 :- not supported(krkp(540)).
 :- not supported(krkp(810)).
 :- not supported(krkp(483)).
 :- not supported(krkp(778)).
 :- not supported(krkp(709)).
 :- not supported(krkp(355)).
 :- not supported(krkp(195)).
 :- not supported(krkp(510)).
 :- not supported(krkp(291)).
 :- not supported(krkp(823)).
 :- not supported(krkp(899)).
 :- not supported(krkp(251)).
 :- not supported(krkp(557)).
 :- not supported(krkp(203)).
 :- not supported(krkp(651)).
 :- not supported(krkp(95)).
 :- not supported(krkp(282)).
 :- not supported(krkp(780)).
 :- not supported(krkp(39)).
 :- not supported(krkp(585)).
 :- not supported(krkp(845)).
 :- not supported(krkp(558)).
 :- not supported(krkp(677)).
 :- not supported(krkp(249)).
 :- not supported(krkp(318)).
 :- not supported(krkp(218)).
 :- not supported(krkp(52)).
 :- not supported(krkp(779)).
 :- not supported(krkp(857)).
 :- not supported(krkp(750)).
 :- not supported(krkp(280)).
 :- not supported(krkp(494)).
 :- not supported(krkp(273)).
 :- not supported(krkp(76)).
 :- not supported(krkp(275)).
 :- not supported(krkp(156)).
 :- not supported(krkp(261)).
 :- not supported(krkp(240)).
 :- not supported(krkp(145)).
 :- not supported(krkp(198)).
 :- not supported(krkp(128)).
 :- not supported(krkp(101)).
 :- not supported(krkp(222)).
 :- not supported(krkp(721)).
 :- not supported(krkp(342)).
 :- not supported(krkp(321)).
 :- not supported(krkp(453)).
 :- not supported(krkp(394)).
 :- not supported(krkp(611)).
 :- not supported(krkp(765)).
 :- not supported(krkp(692)).
 :- not supported(krkp(628)).
 :- not supported(krkp(314)).
 :- not supported(krkp(269)).
 :- not supported(krkp(200)).
 :- not supported(krkp(54)).
 :- not supported(krkp(809)).
 :- not supported(krkp(56)).
 :- not supported(krkp(80)).
 :- not supported(krkp(734)).
 :- not supported(krkp(133)).
 :- not supported(krkp(822)).
 :- not supported(krkp(706)).
 :- not supported(krkp(199)).
 :- not supported(krkp(641)).
 :- not supported(krkp(42)).
 :- not supported(krkp(153)).
 :- not supported(krkp(846)).
 :- not supported(krkp(503)).
 :- not supported(krkp(633)).
 :- not supported(krkp(206)).
 :- not supported(krkp(292)).
 :- not supported(krkp(713)).
 :- not supported(krkp(315)).
 :- not supported(krkp(317)).
 :- not supported(krkp(589)).
 :- not supported(krkp(863)).
 :- not supported(krkp(690)).
 :- not supported(krkp(131)).
 :- not supported(krkp(141)).
 :- not supported(krkp(549)).
 :- not supported(krkp(544)).
 :- not supported(krkp(382)).
 :- not supported(krkp(383)).
 :- not supported(krkp(428)).
 :- not supported(krkp(815)).
 :- not supported(krkp(164)).
 :- not supported(krkp(872)).
 :- not supported(krkp(856)).
 :- not supported(krkp(147)).
 :- not supported(krkp(550)).
 :- not supported(krkp(328)).
 :- not supported(krkp(209)).
 :- not supported(krkp(190)).
 :- not supported(krkp(735)).
 :- not supported(krkp(204)).
 :- not supported(krkp(605)).
 :- not supported(krkp(384)).
 :- not supported(krkp(241)).
 :- not supported(krkp(245)).
 :- not supported(krkp(801)).
 :- not supported(krkp(191)).
 :- not supported(krkp(34)).
 :- not supported(krkp(821)).
 :- not supported(krkp(571)).
 :- not supported(krkp(443)).
 :- not supported(krkp(435)).
 :- not supported(krkp(492)).
 :- not supported(krkp(663)).
 :- not supported(krkp(580)).
 :- not supported(krkp(182)).
 :- not supported(krkp(12)).
 :- not supported(krkp(469)).
 :- not supported(krkp(789)).
 :- not supported(krkp(559)).
 :- not supported(krkp(629)).
 :- not supported(krkp(406)).
 :- not supported(krkp(362)).
 :- not supported(krkp(466)).
 :- not supported(krkp(385)).
 :- not supported(krkp(184)).
 :- not supported(krkp(739)).
 :- not supported(krkp(425)).
 :- not supported(krkp(742)).
 :- not supported(krkp(412)).
 :- not supported(krkp(728)).
 :- not supported(krkp(708)).
 :- not supported(krkp(505)).
 :- not supported(krkp(319)).
 :- not supported(krkp(470)).
 :- not supported(krkp(417)).
 :- not supported(krkp(19)).
 :- not supported(krkp(118)).
 :- not supported(krkp(679)).
 :- not supported(krkp(715)).
 :- not supported(krkp(506)).
 :- not supported(krkp(287)).
 :- supported(krkp(919)).
 :- supported(krkp(914)).
 :- supported(krkp(908)).
 :- supported(krkp(909)).
 :- supported(krkp(906)).
 :- supported(krkp(905)).
 :- supported(krkp(915)).
 :- supported(krkp(912)).
 :- supported(krkp(918)).
 :- supported(krkp(911)).
 :- supported(krkp(910)).
 :- supported(krkp(920)).
 :- supported(krkp(916)).
 :- supported(krkp(917)).
