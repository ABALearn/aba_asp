head(id(1),a1(434)).
head(id(2),a2(434)).
head(id(3),a3(434)).
head(id(4),a4(434)).
head(id(5),a5(434)).
head(id(6),a6(434)).
head(id(7),a8(434)).
head(id(8),a9(434)).
head(id(9),age3(434)).
head(id(10),female(434)).
head(id(11),white(434)).
head(id(12),self(434)).
head(id(13),a1(529)).
head(id(14),a2(529)).
head(id(15),a3(529)).
head(id(16),a4(529)).
head(id(17),a5(529)).
head(id(18),a6(529)).
head(id(19),a7(529)).
head(id(20),a8(529)).
head(id(21),a9(529)).
head(id(22),a10(529)).
head(id(23),age4(529)).
head(id(24),female(529)).
head(id(25),white(529)).
head(id(26),jaundice(529)).
head(id(27),pdd(529)).
head(id(28),self(529)).
head(id(29),a1(124)).
head(id(30),a4(124)).
head(id(31),a5(124)).
head(id(32),a6(124)).
head(id(33),a7(124)).
head(id(34),a8(124)).
head(id(35),a10(124)).
head(id(36),age3(124)).
head(id(37),asian(124)).
head(id(38),jaundice(124)).
head(id(39),self(124)).
head(id(40),a1(509)).
head(id(41),a2(509)).
head(id(42),a3(509)).
head(id(43),a4(509)).
head(id(44),a5(509)).
head(id(45),a6(509)).
head(id(46),a7(509)).
head(id(47),a8(509)).
head(id(48),a9(509)).
head(id(49),a10(509)).
head(id(50),age4(509)).
head(id(51),female(509)).
head(id(52),white(509)).
head(id(53),jaundice(509)).
head(id(54),pdd(509)).
head(id(55),self(509)).
head(id(56),a1(660)).
head(id(57),a2(660)).
head(id(58),a3(660)).
head(id(59),a4(660)).
head(id(60),a5(660)).
head(id(61),a6(660)).
head(id(62),a9(660)).
head(id(63),a10(660)).
head(id(64),age4(660)).
head(id(65),a1(559)).
head(id(66),a2(559)).
head(id(67),a3(559)).
head(id(68),a4(559)).
head(id(69),a5(559)).
head(id(70),a6(559)).
head(id(71),a7(559)).
head(id(72),a8(559)).
head(id(73),a10(559)).
head(id(74),age2(559)).
head(id(75),female(559)).
head(id(76),white(559)).
head(id(77),self(559)).
head(id(78),a1(224)).
head(id(79),a3(224)).
head(id(80),a4(224)).
head(id(81),a6(224)).
head(id(82),a7(224)).
head(id(83),a8(224)).
head(id(84),a9(224)).
head(id(85),a10(224)).
head(id(86),age2(224)).
head(id(87),white(224)).
head(id(88),self(224)).
head(id(89),a1(189)).
head(id(90),a2(189)).
head(id(91),a4(189)).
head(id(92),a5(189)).
head(id(93),a6(189)).
head(id(94),a8(189)).
head(id(95),a9(189)).
head(id(96),a10(189)).
head(id(97),age5(189)).
head(id(98),female(189)).
head(id(99),white(189)).
head(id(100),pdd(189)).
head(id(101),self(189)).
head(id(102),a1(693)).
head(id(103),a2(693)).
head(id(104),a3(693)).
head(id(105),a5(693)).
head(id(106),a6(693)).
head(id(107),a7(693)).
head(id(108),a8(693)).
head(id(109),a10(693)).
head(id(110),age2(693)).
head(id(111),white(693)).
head(id(112),self(693)).
head(id(113),a1(472)).
head(id(114),a2(472)).
head(id(115),a3(472)).
head(id(116),a4(472)).
head(id(117),a5(472)).
head(id(118),a7(472)).
head(id(119),a8(472)).
head(id(120),age2(472)).
head(id(121),latino(472)).
head(id(122),self(472)).
head(id(123),a1(545)).
head(id(124),a3(545)).
head(id(125),a4(545)).
head(id(126),a5(545)).
head(id(127),a6(545)).
head(id(128),a7(545)).
head(id(129),a8(545)).
head(id(130),a9(545)).
head(id(131),a10(545)).
head(id(132),age3(545)).
head(id(133),female(545)).
head(id(134),white(545)).
head(id(135),jaundice(545)).
head(id(136),self(545)).
head(id(137),a1(494)).
head(id(138),a2(494)).
head(id(139),a3(494)).
head(id(140),a4(494)).
head(id(141),a5(494)).
head(id(142),a6(494)).
head(id(143),a7(494)).
head(id(144),a8(494)).
head(id(145),a9(494)).
head(id(146),a10(494)).
head(id(147),age3(494)).
head(id(148),latino(494)).
head(id(149),self(494)).
head(id(150),a1(638)).
head(id(151),a2(638)).
head(id(152),a3(638)).
head(id(153),a4(638)).
head(id(154),a5(638)).
head(id(155),a6(638)).
head(id(156),a7(638)).
head(id(157),a8(638)).
head(id(158),a9(638)).
head(id(159),a10(638)).
head(id(160),age2(638)).
head(id(161),female(638)).
head(id(162),white(638)).
head(id(163),self(638)).
head(id(164),a1(449)).
head(id(165),a2(449)).
head(id(166),a3(449)).
head(id(167),a4(449)).
head(id(168),a5(449)).
head(id(169),a6(449)).
head(id(170),a7(449)).
head(id(171),a9(449)).
head(id(172),a10(449)).
head(id(173),age5(449)).
head(id(174),white(449)).
head(id(175),self(449)).
head(id(176),a8(304)).
head(id(177),a9(304)).
head(id(178),age3(304)).
head(id(179),female(304)).
head(id(180),others(304)).
head(id(181),self(304)).
head(id(182),a8(608)).
head(id(183),age2(608)).
head(id(184),female(608)).
head(id(185),asian(608)).
head(id(186),jaundice(608)).
head(id(187),self(608)).
head(id(188),a1(64)).
head(id(189),a4(64)).
head(id(190),a5(64)).
head(id(191),a8(64)).
head(id(192),a9(64)).
head(id(193),age1(64)).
head(id(194),white(64)).
head(id(195),parent(64)).
head(id(196),a1(294)).
head(id(197),a5(294)).
head(id(198),a7(294)).
head(id(199),a10(294)).
head(id(200),age2(294)).
head(id(201),female(294)).
head(id(202),white(294)).
head(id(203),pdd(294)).
head(id(204),self(294)).
head(id(205),a1(132)).
head(id(206),a8(132)).
head(id(207),a10(132)).
head(id(208),age2(132)).
head(id(209),black(132)).
head(id(210),self(132)).
head(id(211),a1(600)).
head(id(212),a3(600)).
head(id(213),a4(600)).
head(id(214),a8(600)).
head(id(215),a9(600)).
head(id(216),a10(600)).
head(id(217),age3(600)).
head(id(218),female(600)).
head(id(219),asian(600)).
head(id(220),parent(600)).
head(id(221),a1(215)).
head(id(222),a2(215)).
head(id(223),a3(215)).
head(id(224),a4(215)).
head(id(225),a10(215)).
head(id(226),age4(215)).
head(id(227),white(215)).
head(id(228),self(215)).
head(id(229),a3(633)).
head(id(230),a8(633)).
head(id(231),age2(633)).
head(id(232),female(633)).
head(id(233),asian(633)).
head(id(234),parent(633)).
head(id(235),a1(202)).
head(id(236),a2(202)).
head(id(237),a4(202)).
head(id(238),a5(202)).
head(id(239),a9(202)).
head(id(240),a10(202)).
head(id(241),age2(202)).
head(id(242),female(202)).
head(id(243),white(202)).
head(id(244),self(202)).
head(id(245),a1(113)).
head(id(246),a5(113)).
head(id(247),a10(113)).
head(id(248),age3(113)).
head(id(249),asian(113)).
head(id(250),parent(113)).
head(id(251),a3(520)).
head(id(252),a4(520)).
head(id(253),a10(520)).
head(id(254),age3(520)).
head(id(255),middleeastern(520)).
head(id(256),self(520)).
head(id(257),a1(160)).
head(id(258),a7(160)).
head(id(259),a8(160)).
head(id(260),age3(160)).
head(id(261),asian(160)).
head(id(262),self(160)).
head(id(263),a4(527)).
head(id(264),a7(527)).
head(id(265),a8(527)).
head(id(266),a10(527)).
head(id(267),age3(527)).
head(id(268),asian(527)).
head(id(269),self(527)).
head(id(270),a1(110)).
head(id(271),a6(110)).
head(id(272),a7(110)).
head(id(273),age1(110)).
head(id(274),female(110)).
head(id(275),asian(110)).
head(id(276),parent(110)).
head(id(277),a1(342)).
head(id(278),a2(342)).
head(id(279),a3(342)).
head(id(280),a4(342)).
head(id(281),a5(342)).
head(id(282),a8(342)).
head(id(283),age1(342)).
head(id(284),a1(306)).
head(id(285),a2(306)).
head(id(286),a4(306)).
head(id(287),a10(306)).
head(id(288),age3(306)).
head(id(289),female(306)).
head(id(290),white(306)).
head(id(291),self(306)).
head(id(292),a3(581)).
head(id(293),a4(581)).
head(id(294),age4(581)).
head(id(295),black(581)).
head(id(296),self(581)).
head(id(297),a1(617)).
head(id(298),a5(617)).
head(id(299),a7(617)).
head(id(300),age2(617)).
head(id(301),southasian(617)).
head(id(302),self(617)).
head(id(303),a1(676)).
head(id(304),a2(676)).
head(id(305),a3(676)).
head(id(306),a4(676)).
head(id(307),a9(676)).
head(id(308),age2(676)).
head(id(309),female(676)).
head(id(310),white(676)).
head(id(311),jaundice(676)).
head(id(312),self(676)).
head(id(313),a1(157)).
head(id(314),a6(157)).
head(id(315),a8(157)).
head(id(316),a10(157)).
head(id(317),age2(157)).
head(id(318),female(157)).
head(id(319),asian(157)).
head(id(320),self(157)).
head(id(321),a2(44)).
head(id(322),a3(44)).
head(id(323),a4(44)).
head(id(324),a10(44)).
head(id(325),age3(44)).
head(id(326),female(44)).
head(id(327),white(44)).
head(id(328),jaundice(44)).
head(id(329),pdd(44)).
head(id(330),self(44)).
head(id(331),a1(131)).
head(id(332),a2(131)).
head(id(333),a8(131)).
head(id(334),age1(131)).
head(id(335),female(131)).
head(id(336),white(131)).
head(id(337),self(131)).
head(id(338),a1(259)).
head(id(339),a5(259)).
head(id(340),a6(259)).
head(id(341),a8(259)).
head(id(342),a10(259)).
head(id(343),age2(259)).
head(id(344),asian(259)).
head(id(345),self(259)).
head(id(346),a8(470)).
head(id(347),age2(470)).
head(id(348),female(470)).
head(id(349),asian(470)).
head(id(350),jaundice(470)).
head(id(351),self(470)).
head(id(352),a2(489)).
head(id(353),a3(489)).
head(id(354),a7(489)).
head(id(355),a10(489)).
head(id(356),age1(489)).
head(id(357),black(489)).
head(id(358),self(489)).
head(id(359),a1(9)).
head(id(360),a2(9)).
head(id(361),a5(9)).
head(id(362),a8(9)).
head(id(363),a9(9)).
head(id(364),a10(9)).
head(id(365),age2(9)).
head(id(366),white(9)).
head(id(367),self(9)).
head(id(1515,A),autism(A)) :- dom(A).
body(id(1515,A),alpha_1(A)) :- dom(A).
body(id(1515,A),a1(A)) :- dom(A).
head(id(8618,A),c_alpha_1(A)) :- dom(A).
body(id(8618,A),alpha_2(A)) :- dom(A).
body(id(8618,A),a2(A)) :- dom(A).
head(id(10648,A),c_alpha_1(A)) :- dom(A).
body(id(10648,A),alpha_3(A)) :- dom(A).
body(id(10648,A),a4(A)) :- dom(A).
head(id(12763,A),c_alpha_1(A)) :- dom(A).
body(id(12763,A),alpha_4(A)) :- dom(A).
body(id(12763,A),a6(A)) :- dom(A).
head(id(14963,A),c_alpha_1(A)) :- dom(A).
body(id(14963,A),alpha_5(A)) :- dom(A).
body(id(14963,A),a5(A)) :- dom(A).
head(id(17698,A),c_alpha_1(A)) :- dom(A).
body(id(17698,A),alpha_6(A)) :- dom(A).
body(id(17698,A),a8(A)) :- dom(A).
head(id(23734,A),c_alpha_2(A)) :- dom(A).
body(id(23734,A),a1(A)) :- dom(A).
head(id(30999,A),c_alpha_3(A)) :- dom(A).
body(id(30999,A),a5(A)) :- dom(A).
head(id(33707,A),c_alpha_3(A)) :- dom(A).
body(id(33707,A),alpha_7(A)) :- dom(A).
body(id(33707,A),a3(A)) :- dom(A).
head(id(40014,A),c_alpha_4(A)) :- dom(A).
body(id(40014,A),a4(A)) :- dom(A).
head(id(46625,A),c_alpha_4(A)) :- dom(A).
body(id(46625,A),a2(A)) :- dom(A).
head(id(50136,A),c_alpha_5(A)) :- dom(A).
body(id(50136,A),a6(A)) :- dom(A).
head(id(54067,A),c_alpha_5(A)) :- dom(A).
body(id(54067,A),a3(A)) :- dom(A).
head(id(60966,A),c_alpha_6(A)) :- dom(A).
body(id(60966,A),a6(A)) :- dom(A).
head(id(67815,A),c_alpha_6(A)) :- dom(A).
body(id(67815,A),alpha_8(A)) :- dom(A).
body(id(67815,A),a7(A)) :- dom(A).
head(id(72515,A),c_alpha_7(A)) :- dom(A).
body(id(72515,A),a2(A)) :- dom(A).
head(id(76347,A),c_alpha_8(A)) :- dom(A).
body(id(76347,A),age3(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
assumption(alpha_4(A)) :- dom(A).
assumption(alpha_5(A)) :- dom(A).
assumption(alpha_6(A)) :- dom(A).
assumption(alpha_7(A)) :- dom(A).
assumption(alpha_8(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).
contrary(alpha_4(A),c_alpha_4(A)) :- assumption(alpha_4(A)).
contrary(alpha_5(A),c_alpha_5(A)) :- assumption(alpha_5(A)).
contrary(alpha_6(A),c_alpha_6(A)) :- assumption(alpha_6(A)).
contrary(alpha_7(A),c_alpha_7(A)) :- assumption(alpha_7(A)).
contrary(alpha_8(A),c_alpha_8(A)) :- assumption(alpha_8(A)).

dom(9).
dom(44).
dom(64).
dom(110).
dom(113).
dom(124).
dom(131).
dom(132).
dom(157).
dom(160).
dom(189).
dom(202).
dom(215).
dom(224).
dom(259).
dom(294).
dom(304).
dom(306).
dom(342).
dom(434).
dom(449).
dom(470).
dom(472).
dom(489).
dom(494).
dom(509).
dom(520).
dom(527).
dom(529).
dom(545).
dom(559).
dom(581).
dom(600).
dom(608).
dom(617).
dom(633).
dom(638).
dom(660).
dom(676).
dom(693).
 :- not supported(autism(434)).
 :- not supported(autism(529)).
 :- not supported(autism(124)).
 :- not supported(autism(509)).
 :- not supported(autism(660)).
 :- not supported(autism(559)).
 :- not supported(autism(224)).
 :- not supported(autism(189)).
 :- not supported(autism(693)).
 :- not supported(autism(472)).
 :- not supported(autism(545)).
 :- not supported(autism(494)).
 :- not supported(autism(638)).
 :- not supported(autism(449)).
 :- supported(autism(304)).
 :- supported(autism(608)).
 :- supported(autism(64)).
 :- supported(autism(294)).
 :- supported(autism(132)).
 :- supported(autism(600)).
 :- supported(autism(215)).
 :- supported(autism(633)).
 :- supported(autism(202)).
 :- supported(autism(113)).
 :- supported(autism(520)).
 :- supported(autism(160)).
 :- supported(autism(527)).
 :- supported(autism(110)).
 :- supported(autism(342)).
 :- supported(autism(306)).
 :- supported(autism(581)).
 :- supported(autism(617)).
 :- supported(autism(676)).
 :- supported(autism(157)).
 :- supported(autism(44)).
 :- supported(autism(131)).
 :- supported(autism(259)).
 :- supported(autism(470)).
 :- supported(autism(489)).
 :- supported(autism(9)).
