head(id(1),cap_shapek(7794)).
head(id(2),cap_surfaces(7794)).
head(id(3),cap_colorn(7794)).
head(id(4),gill_spacing(7794)).
head(id(5),gill_size(7794)).
head(id(6),gill_colorb(7794)).
head(id(7),stalk_surface_above_ringk(7794)).
head(id(8),stalk_surface_below_rings(7794)).
head(id(9),stalk_color_above_ringw(7794)).
head(id(10),stalk_color_below_ringp(7794)).
head(id(11),veil_colorw(7794)).
head(id(12),ring_numbero(7794)).
head(id(13),ring_typee(7794)).
head(id(14),spore_print_colorw(7794)).
head(id(15),populationv(7794)).
head(id(16),habitatp(7794)).
head(id(17),cap_shapex(1100)).
head(id(18),cap_colorn(1100)).
head(id(19),bruises(1100)).
head(id(20),odorp(1100)).
head(id(21),gill_spacing(1100)).
head(id(22),gill_size(1100)).
head(id(23),gill_colorn(1100)).
head(id(24),stalk_roote(1100)).
head(id(25),stalk_surface_above_rings(1100)).
head(id(26),stalk_surface_below_rings(1100)).
head(id(27),stalk_color_above_ringw(1100)).
head(id(28),stalk_color_below_ringw(1100)).
head(id(29),veil_colorw(1100)).
head(id(30),ring_numbero(1100)).
head(id(31),spore_print_colorn(1100)).
head(id(32),populations(1100)).
head(id(33),habitatg(1100)).
head(id(34),cap_shapek(7102)).
head(id(35),cap_colore(7102)).
head(id(36),odors(7102)).
head(id(37),gill_spacing(7102)).
head(id(38),gill_size(7102)).
head(id(39),gill_colorb(7102)).
head(id(40),stalk_surface_above_ringk(7102)).
head(id(41),stalk_surface_below_ringk(7102)).
head(id(42),stalk_color_above_ringw(7102)).
head(id(43),stalk_color_below_ringp(7102)).
head(id(44),veil_colorw(7102)).
head(id(45),ring_numbero(7102)).
head(id(46),ring_typee(7102)).
head(id(47),spore_print_colorw(7102)).
head(id(48),populationv(7102)).
head(id(49),habitatp(7102)).
head(id(50),cap_shapex(3470)).
head(id(51),cap_surfaces(3470)).
head(id(52),cap_colorp(3470)).
head(id(53),odorc(3470)).
head(id(54),gill_spacing(3470)).
head(id(55),gill_size(3470)).
head(id(56),gill_colorn(3470)).
head(id(57),stalk_rootb(3470)).
head(id(58),stalk_surface_above_rings(3470)).
head(id(59),stalk_surface_below_rings(3470)).
head(id(60),stalk_color_above_ringw(3470)).
head(id(61),stalk_color_below_ringw(3470)).
head(id(62),veil_colorw(3470)).
head(id(63),ring_numbero(3470)).
head(id(64),spore_print_colorn(3470)).
head(id(65),populationv(3470)).
head(id(66),habitatd(3470)).
head(id(67),cap_shapex(5772)).
head(id(68),cap_colorn(5772)).
head(id(69),gill_spacing(5772)).
head(id(70),gill_size(5772)).
head(id(71),gill_colorb(5772)).
head(id(72),stalk_surface_above_ringk(5772)).
head(id(73),stalk_surface_below_ringk(5772)).
head(id(74),stalk_color_above_ringp(5772)).
head(id(75),stalk_color_below_ringp(5772)).
head(id(76),veil_colorw(5772)).
head(id(77),ring_numbero(5772)).
head(id(78),ring_typee(5772)).
head(id(79),spore_print_colorw(5772)).
head(id(80),populationv(5772)).
head(id(81),habitatl(5772)).
head(id(82),cap_shapec(5509)).
head(id(83),cap_colorw(5509)).
head(id(84),bruises(5509)).
head(id(85),odorn(5509)).
head(id(86),gill_size(5509)).
head(id(87),gill_colorw(5509)).
head(id(88),stalk_rootb(5509)).
head(id(89),stalk_surface_above_rings(5509)).
head(id(90),stalk_surface_below_rings(5509)).
head(id(91),stalk_color_above_ringw(5509)).
head(id(92),stalk_color_below_ringw(5509)).
head(id(93),veil_colorw(5509)).
head(id(94),ring_numbero(5509)).
head(id(95),spore_print_colorw(5509)).
head(id(96),populationc(5509)).
head(id(97),habitatl(5509)).
head(id(98),cap_shapef(6946)).
head(id(99),cap_colore(6946)).
head(id(100),odorm(6946)).
head(id(101),gill_attachment(6946)).
head(id(102),gill_spacing(6946)).
head(id(103),gill_colorw(6946)).
head(id(104),stalk_rootc(6946)).
head(id(105),stalk_surface_above_ringk(6946)).
head(id(106),stalk_color_above_ringc(6946)).
head(id(107),stalk_color_below_ringc(6946)).
head(id(108),veil_colorw(6946)).
head(id(109),ring_numbern(6946)).
head(id(110),ring_typen(6946)).
head(id(111),spore_print_colorw(6946)).
head(id(112),populationc(6946)).
head(id(113),habitatd(6946)).
head(id(114),cap_shapex(3338)).
head(id(115),cap_surfacef(3338)).
head(id(116),cap_colorw(3338)).
head(id(117),odorc(3338)).
head(id(118),gill_size(3338)).
head(id(119),gill_colorg(3338)).
head(id(120),stalk_rootb(3338)).
head(id(121),stalk_surface_above_rings(3338)).
head(id(122),stalk_surface_below_rings(3338)).
head(id(123),stalk_color_above_ringw(3338)).
head(id(124),stalk_color_below_ringw(3338)).
head(id(125),veil_colorw(3338)).
head(id(126),ring_numbero(3338)).
head(id(127),spore_print_colork(3338)).
head(id(128),populationv(3338)).
head(id(129),habitatd(3338)).
head(id(130),cap_shapef(6507)).
head(id(131),cap_colore(6507)).
head(id(132),odorf(6507)).
head(id(133),gill_spacing(6507)).
head(id(134),gill_size(6507)).
head(id(135),gill_colorb(6507)).
head(id(136),stalk_surface_above_rings(6507)).
head(id(137),stalk_surface_below_rings(6507)).
head(id(138),stalk_color_above_ringp(6507)).
head(id(139),stalk_color_below_ringp(6507)).
head(id(140),veil_colorw(6507)).
head(id(141),ring_numbero(6507)).
head(id(142),ring_typee(6507)).
head(id(143),spore_print_colorw(6507)).
head(id(144),populationv(6507)).
head(id(145),habitatp(6507)).
head(id(146),cap_shapef(6341)).
head(id(147),cap_colore(6341)).
head(id(148),odorf(6341)).
head(id(149),gill_spacing(6341)).
head(id(150),gill_size(6341)).
head(id(151),gill_colorb(6341)).
head(id(152),stalk_surface_above_rings(6341)).
head(id(153),stalk_surface_below_ringk(6341)).
head(id(154),stalk_color_above_ringp(6341)).
head(id(155),stalk_color_below_ringw(6341)).
head(id(156),veil_colorw(6341)).
head(id(157),ring_numbero(6341)).
head(id(158),ring_typee(6341)).
head(id(159),spore_print_colorw(6341)).
head(id(160),populationv(6341)).
head(id(161),habitatd(6341)).
head(id(162),cap_shapek(7422)).
head(id(163),cap_colorn(7422)).
head(id(164),odors(7422)).
head(id(165),gill_spacing(7422)).
head(id(166),gill_size(7422)).
head(id(167),gill_colorb(7422)).
head(id(168),stalk_surface_above_rings(7422)).
head(id(169),stalk_surface_below_rings(7422)).
head(id(170),stalk_color_above_ringp(7422)).
head(id(171),stalk_color_below_ringw(7422)).
head(id(172),veil_colorw(7422)).
head(id(173),ring_numbero(7422)).
head(id(174),ring_typee(7422)).
head(id(175),spore_print_colorw(7422)).
head(id(176),populationv(7422)).
head(id(177),habitatd(7422)).
head(id(178),cap_shapex(4595)).
head(id(179),cap_surfacef(4595)).
head(id(180),odorf(4595)).
head(id(181),gill_spacing(4595)).
head(id(182),gill_colorh(4595)).
head(id(183),stalk_rootb(4595)).
head(id(184),stalk_surface_above_ringk(4595)).
head(id(185),stalk_surface_below_ringk(4595)).
head(id(186),stalk_color_above_ringb(4595)).
head(id(187),stalk_color_below_ringp(4595)).
head(id(188),veil_colorw(4595)).
head(id(189),ring_numbero(4595)).
head(id(190),ring_typel(4595)).
head(id(191),spore_print_colorh(4595)).
head(id(192),populationv(4595)).
head(id(193),habitatd(4595)).
head(id(194),cap_shapex(6456)).
head(id(195),cap_surfaces(6456)).
head(id(196),cap_colorn(6456)).
head(id(197),odorf(6456)).
head(id(198),gill_spacing(6456)).
head(id(199),gill_size(6456)).
head(id(200),gill_colorb(6456)).
head(id(201),stalk_surface_above_ringk(6456)).
head(id(202),stalk_surface_below_ringk(6456)).
head(id(203),stalk_color_above_ringp(6456)).
head(id(204),stalk_color_below_ringp(6456)).
head(id(205),veil_colorw(6456)).
head(id(206),ring_numbero(6456)).
head(id(207),ring_typee(6456)).
head(id(208),spore_print_colorw(6456)).
head(id(209),populationv(6456)).
head(id(210),habitatp(6456)).
head(id(211),cap_shapef(4513)).
head(id(212),cap_surfacef(4513)).
head(id(213),odorf(4513)).
head(id(214),gill_spacing(4513)).
head(id(215),gill_colorh(4513)).
head(id(216),stalk_rootb(4513)).
head(id(217),stalk_surface_above_ringk(4513)).
head(id(218),stalk_surface_below_ringk(4513)).
head(id(219),stalk_color_above_ringb(4513)).
head(id(220),stalk_color_below_ringp(4513)).
head(id(221),veil_colorw(4513)).
head(id(222),ring_numbero(4513)).
head(id(223),ring_typel(4513)).
head(id(224),spore_print_colorh(4513)).
head(id(225),habitatp(4513)).
head(id(226),cap_shapex(3436)).
head(id(227),cap_surfacef(3436)).
head(id(228),cap_colorg(3436)).
head(id(229),odorc(3436)).
head(id(230),gill_size(3436)).
head(id(231),gill_colorg(3436)).
head(id(232),stalk_rootb(3436)).
head(id(233),stalk_surface_above_rings(3436)).
head(id(234),stalk_surface_below_rings(3436)).
head(id(235),stalk_color_above_ringw(3436)).
head(id(236),stalk_color_below_ringw(3436)).
head(id(237),veil_colorw(3436)).
head(id(238),ring_numbero(3436)).
head(id(239),spore_print_colorn(3436)).
head(id(240),populationv(3436)).
head(id(241),habitatd(3436)).
head(id(242),cap_shapex(4725)).
head(id(243),cap_surfacef(4725)).
head(id(244),odorf(4725)).
head(id(245),gill_spacing(4725)).
head(id(246),gill_colorp(4725)).
head(id(247),stalk_rootb(4725)).
head(id(248),stalk_surface_above_ringk(4725)).
head(id(249),stalk_surface_below_ringk(4725)).
head(id(250),stalk_color_above_ringb(4725)).
head(id(251),stalk_color_below_ringp(4725)).
head(id(252),veil_colorw(4725)).
head(id(253),ring_numbero(4725)).
head(id(254),ring_typel(4725)).
head(id(255),spore_print_colorh(4725)).
head(id(256),habitatd(4725)).
head(id(257),cap_shapex(4341)).
head(id(258),cap_colorg(4341)).
head(id(259),odorf(4341)).
head(id(260),gill_spacing(4341)).
head(id(261),gill_colorg(4341)).
head(id(262),stalk_rootb(4341)).
head(id(263),stalk_surface_above_ringk(4341)).
head(id(264),stalk_surface_below_ringk(4341)).
head(id(265),stalk_color_above_ringp(4341)).
head(id(266),stalk_color_below_ringn(4341)).
head(id(267),veil_colorw(4341)).
head(id(268),ring_numbero(4341)).
head(id(269),ring_typel(4341)).
head(id(270),spore_print_colorh(4341)).
head(id(271),habitatg(4341)).
head(id(272),cap_shapef(4195)).
head(id(273),cap_surfaces(4195)).
head(id(274),cap_colorb(4195)).
head(id(275),bruises(4195)).
head(id(276),odorf(4195)).
head(id(277),gill_spacing(4195)).
head(id(278),gill_colorw(4195)).
head(id(279),stalk_rootb(4195)).
head(id(280),stalk_surface_above_ringf(4195)).
head(id(281),stalk_surface_below_ringf(4195)).
head(id(282),stalk_color_above_ringw(4195)).
head(id(283),stalk_color_below_ringw(4195)).
head(id(284),veil_colorw(4195)).
head(id(285),ring_numbero(4195)).
head(id(286),spore_print_colorh(4195)).
head(id(287),populations(4195)).
head(id(288),habitatu(4195)).
head(id(289),cap_shapex(4477)).
head(id(290),odorf(4477)).
head(id(291),gill_spacing(4477)).
head(id(292),gill_colorp(4477)).
head(id(293),stalk_rootb(4477)).
head(id(294),stalk_surface_above_ringk(4477)).
head(id(295),stalk_surface_below_ringk(4477)).
head(id(296),stalk_color_above_ringb(4477)).
head(id(297),stalk_color_below_ringn(4477)).
head(id(298),veil_colorw(4477)).
head(id(299),ring_numbero(4477)).
head(id(300),ring_typel(4477)).
head(id(301),spore_print_colorh(4477)).
head(id(302),populationv(4477)).
head(id(303),habitatp(4477)).
head(id(304),cap_shapex(5816)).
head(id(305),cap_colorn(5816)).
head(id(306),odors(5816)).
head(id(307),gill_spacing(5816)).
head(id(308),gill_size(5816)).
head(id(309),gill_colorb(5816)).
head(id(310),stalk_surface_above_ringk(5816)).
head(id(311),stalk_surface_below_ringk(5816)).
head(id(312),stalk_color_above_ringp(5816)).
head(id(313),stalk_color_below_ringp(5816)).
head(id(314),veil_colorw(5816)).
head(id(315),ring_numbero(5816)).
head(id(316),ring_typee(5816)).
head(id(317),spore_print_colorw(5816)).
head(id(318),populationv(5816)).
head(id(319),habitatl(5816)).
head(id(320),cap_shapex(6443)).
head(id(321),cap_surfaces(6443)).
head(id(322),cap_colorn(6443)).
head(id(323),gill_spacing(6443)).
head(id(324),gill_size(6443)).
head(id(325),gill_colorb(6443)).
head(id(326),stalk_surface_above_rings(6443)).
head(id(327),stalk_surface_below_rings(6443)).
head(id(328),stalk_color_above_ringw(6443)).
head(id(329),stalk_color_below_ringw(6443)).
head(id(330),veil_colorw(6443)).
head(id(331),ring_numbero(6443)).
head(id(332),ring_typee(6443)).
head(id(333),spore_print_colorw(6443)).
head(id(334),populationv(6443)).
head(id(335),habitatl(6443)).
head(id(336),cap_surfaces(170)).
head(id(337),cap_colorw(170)).
head(id(338),bruises(170)).
head(id(339),odora(170)).
head(id(340),gill_spacing(170)).
head(id(341),gill_colork(170)).
head(id(342),stalk_rootc(170)).
head(id(343),stalk_surface_above_rings(170)).
head(id(344),stalk_surface_below_rings(170)).
head(id(345),stalk_color_above_ringw(170)).
head(id(346),stalk_color_below_ringw(170)).
head(id(347),veil_colorw(170)).
head(id(348),ring_numbero(170)).
head(id(349),spore_print_colork(170)).
head(id(350),populations(170)).
head(id(351),habitatg(170)).
head(id(352),cap_shapex(646)).
head(id(353),cap_surfaces(646)).
head(id(354),bruises(646)).
head(id(355),odorl(646)).
head(id(356),gill_size(646)).
head(id(357),gill_colorn(646)).
head(id(358),stalk_rootb(646)).
head(id(359),stalk_surface_above_rings(646)).
head(id(360),stalk_surface_below_rings(646)).
head(id(361),stalk_color_above_ringw(646)).
head(id(362),stalk_color_below_ringw(646)).
head(id(363),veil_colorw(646)).
head(id(364),ring_numbero(646)).
head(id(365),spore_print_coloru(646)).
head(id(366),populationv(646)).
head(id(367),habitatd(646)).
head(id(368),cap_shapef(1757)).
head(id(369),cap_surfacef(1757)).
head(id(370),cap_colorg(1757)).
head(id(371),odorn(1757)).
head(id(372),gill_colork(1757)).
head(id(373),stalk_roote(1757)).
head(id(374),stalk_surface_above_rings(1757)).
head(id(375),stalk_surface_below_rings(1757)).
head(id(376),stalk_color_above_ringw(1757)).
head(id(377),stalk_color_below_ringw(1757)).
head(id(378),veil_colorw(1757)).
head(id(379),ring_numbero(1757)).
head(id(380),ring_typee(1757)).
head(id(381),spore_print_colorn(1757)).
head(id(382),populations(1757)).
head(id(383),habitatg(1757)).
head(id(384),cap_shapex(2418)).
head(id(385),cap_colorn(2418)).
head(id(386),bruises(2418)).
head(id(387),odorn(2418)).
head(id(388),gill_spacing(2418)).
head(id(389),gill_coloru(2418)).
head(id(390),stalk_rootb(2418)).
head(id(391),stalk_surface_above_rings(2418)).
head(id(392),stalk_surface_below_rings(2418)).
head(id(393),stalk_color_above_ringg(2418)).
head(id(394),stalk_color_below_ringw(2418)).
head(id(395),veil_colorw(2418)).
head(id(396),ring_numbero(2418)).
head(id(397),spore_print_colork(2418)).
head(id(398),habitatd(2418)).
head(id(399),cap_shapex(751)).
head(id(400),cap_colorn(751)).
head(id(401),bruises(751)).
head(id(402),odora(751)).
head(id(403),gill_spacing(751)).
head(id(404),gill_colorn(751)).
head(id(405),stalk_rootr(751)).
head(id(406),stalk_surface_above_rings(751)).
head(id(407),stalk_color_above_ringw(751)).
head(id(408),stalk_color_below_ringw(751)).
head(id(409),veil_colorw(751)).
head(id(410),ring_numbero(751)).
head(id(411),spore_print_colorn(751)).
head(id(412),populations(751)).
head(id(413),habitatp(751)).
head(id(414),cap_shapek(6763)).
head(id(415),cap_surfacef(6763)).
head(id(416),cap_colorg(6763)).
head(id(417),odorn(6763)).
head(id(418),gill_colorp(6763)).
head(id(419),stalk_surface_above_ringk(6763)).
head(id(420),stalk_surface_below_rings(6763)).
head(id(421),stalk_color_above_ringw(6763)).
head(id(422),stalk_color_below_ringw(6763)).
head(id(423),veil_colorw(6763)).
head(id(424),spore_print_colorw(6763)).
head(id(425),populations(6763)).
head(id(426),habitatg(6763)).
head(id(427),cap_shapex(2011)).
head(id(428),cap_surfaces(2011)).
head(id(429),cap_colorn(2011)).
head(id(430),odorn(2011)).
head(id(431),gill_colork(2011)).
head(id(432),stalk_roote(2011)).
head(id(433),stalk_surface_above_ringf(2011)).
head(id(434),stalk_surface_below_ringf(2011)).
head(id(435),stalk_color_above_ringw(2011)).
head(id(436),stalk_color_below_ringw(2011)).
head(id(437),veil_colorw(2011)).
head(id(438),ring_numbero(2011)).
head(id(439),ring_typee(2011)).
head(id(440),spore_print_colorn(2011)).
head(id(441),populationa(2011)).
head(id(442),habitatg(2011)).
head(id(443),cap_shapek(7571)).
head(id(444),cap_surfaces(7571)).
head(id(445),cap_colorn(7571)).
head(id(446),odorn(7571)).
head(id(447),gill_spacing(7571)).
head(id(448),gill_colorw(7571)).
head(id(449),stalk_rootb(7571)).
head(id(450),stalk_color_above_ringn(7571)).
head(id(451),stalk_color_below_ringn(7571)).
head(id(452),veil_colorw(7571)).
head(id(453),spore_print_colorw(7571)).
head(id(454),habitatp(7571)).
head(id(455),cap_shapef(1328)).
head(id(456),cap_surfaces(1328)).
head(id(457),cap_colorg(1328)).
head(id(458),odorn(1328)).
head(id(459),gill_colork(1328)).
head(id(460),stalk_roote(1328)).
head(id(461),stalk_surface_above_ringf(1328)).
head(id(462),stalk_surface_below_ringf(1328)).
head(id(463),stalk_color_above_ringw(1328)).
head(id(464),stalk_color_below_ringw(1328)).
head(id(465),veil_colorw(1328)).
head(id(466),ring_numbero(1328)).
head(id(467),ring_typee(1328)).
head(id(468),spore_print_colorn(1328)).
head(id(469),populationa(1328)).
head(id(470),habitatg(1328)).
head(id(471),cap_shapef(4912)).
head(id(472),cap_surfaces(4912)).
head(id(473),cap_colore(4912)).
head(id(474),bruises(4912)).
head(id(475),odorn(4912)).
head(id(476),gill_spacing(4912)).
head(id(477),gill_colorw(4912)).
head(id(478),stalk_surface_above_rings(4912)).
head(id(479),stalk_surface_below_rings(4912)).
head(id(480),stalk_color_above_ringw(4912)).
head(id(481),stalk_color_below_ringe(4912)).
head(id(482),veil_colorw(4912)).
head(id(483),ring_typee(4912)).
head(id(484),spore_print_colorw(4912)).
head(id(485),populationc(4912)).
head(id(486),cap_shapef(2681)).
head(id(487),cap_surfacef(2681)).
head(id(488),cap_colorn(2681)).
head(id(489),bruises(2681)).
head(id(490),odorn(2681)).
head(id(491),gill_spacing(2681)).
head(id(492),gill_colorp(2681)).
head(id(493),stalk_rootb(2681)).
head(id(494),stalk_surface_above_rings(2681)).
head(id(495),stalk_surface_below_rings(2681)).
head(id(496),stalk_color_above_ringp(2681)).
head(id(497),stalk_color_below_ringp(2681)).
head(id(498),veil_colorw(2681)).
head(id(499),ring_numbero(2681)).
head(id(500),spore_print_colorn(2681)).
head(id(501),populationv(2681)).
head(id(502),habitatd(2681)).
head(id(503),cap_shapes(782)).
head(id(504),cap_surfacef(782)).
head(id(505),cap_colorn(782)).
head(id(506),odorn(782)).
head(id(507),gill_spacing(782)).
head(id(508),gill_size(782)).
head(id(509),gill_colorg(782)).
head(id(510),stalk_roote(782)).
head(id(511),stalk_surface_above_rings(782)).
head(id(512),stalk_surface_below_rings(782)).
head(id(513),stalk_color_above_ringw(782)).
head(id(514),stalk_color_below_ringw(782)).
head(id(515),veil_colorw(782)).
head(id(516),ring_numbero(782)).
head(id(517),spore_print_colork(782)).
head(id(518),habitatu(782)).
head(id(519),cap_shapex(1331)).
head(id(520),cap_surfacef(1331)).
head(id(521),cap_colorg(1331)).
head(id(522),odorn(1331)).
head(id(523),gill_colork(1331)).
head(id(524),stalk_roote(1331)).
head(id(525),stalk_surface_above_rings(1331)).
head(id(526),stalk_surface_below_rings(1331)).
head(id(527),stalk_color_above_ringw(1331)).
head(id(528),stalk_color_below_ringw(1331)).
head(id(529),veil_colorw(1331)).
head(id(530),ring_numbero(1331)).
head(id(531),ring_typee(1331)).
head(id(532),spore_print_colork(1331)).
head(id(533),populations(1331)).
head(id(534),habitatg(1331)).
head(id(535),cap_shapex(2137)).
head(id(536),cap_colorg(2137)).
head(id(537),bruises(2137)).
head(id(538),odorn(2137)).
head(id(539),gill_spacing(2137)).
head(id(540),gill_colorw(2137)).
head(id(541),stalk_rootb(2137)).
head(id(542),stalk_surface_above_rings(2137)).
head(id(543),stalk_surface_below_rings(2137)).
head(id(544),stalk_color_above_ringg(2137)).
head(id(545),stalk_color_below_ringw(2137)).
head(id(546),veil_colorw(2137)).
head(id(547),ring_numbero(2137)).
head(id(548),spore_print_colorn(2137)).
head(id(549),populationv(2137)).
head(id(550),habitatd(2137)).
head(id(551),cap_shapex(2472)).
head(id(552),cap_surfacef(2472)).
head(id(553),cap_colorg(2472)).
head(id(554),bruises(2472)).
head(id(555),odorn(2472)).
head(id(556),gill_spacing(2472)).
head(id(557),gill_colorp(2472)).
head(id(558),stalk_rootb(2472)).
head(id(559),stalk_surface_above_rings(2472)).
head(id(560),stalk_surface_below_rings(2472)).
head(id(561),stalk_color_above_ringw(2472)).
head(id(562),stalk_color_below_ringg(2472)).
head(id(563),veil_colorw(2472)).
head(id(564),ring_numbero(2472)).
head(id(565),spore_print_colorn(2472)).
head(id(566),populationv(2472)).
head(id(567),habitatd(2472)).
head(id(568),cap_shapef(3143)).
head(id(569),cap_colorg(3143)).
head(id(570),bruises(3143)).
head(id(571),odorn(3143)).
head(id(572),gill_spacing(3143)).
head(id(573),gill_colorw(3143)).
head(id(574),stalk_rootb(3143)).
head(id(575),stalk_surface_above_rings(3143)).
head(id(576),stalk_surface_below_rings(3143)).
head(id(577),stalk_color_above_ringp(3143)).
head(id(578),stalk_color_below_ringp(3143)).
head(id(579),veil_colorw(3143)).
head(id(580),ring_numbero(3143)).
head(id(581),spore_print_colork(3143)).
head(id(582),habitatd(3143)).
head(id(583),cap_shapef(3635)).
head(id(584),cap_colorn(3635)).
head(id(585),bruises(3635)).
head(id(586),odorn(3635)).
head(id(587),gill_spacing(3635)).
head(id(588),gill_colorn(3635)).
head(id(589),stalk_rootb(3635)).
head(id(590),stalk_surface_above_rings(3635)).
head(id(591),stalk_surface_below_rings(3635)).
head(id(592),stalk_color_above_ringw(3635)).
head(id(593),stalk_color_below_ringp(3635)).
head(id(594),veil_colorw(3635)).
head(id(595),ring_numbero(3635)).
head(id(596),spore_print_colorn(3635)).
head(id(597),populationv(3635)).
head(id(598),habitatd(3635)).
head(id(599),cap_shapex(1530)).
head(id(600),cap_surfaces(1530)).
head(id(601),cap_colorw(1530)).
head(id(602),odorn(1530)).
head(id(603),gill_colorn(1530)).
head(id(604),stalk_roote(1530)).
head(id(605),stalk_surface_above_ringf(1530)).
head(id(606),stalk_surface_below_ringf(1530)).
head(id(607),stalk_color_above_ringw(1530)).
head(id(608),stalk_color_below_ringw(1530)).
head(id(609),veil_colorw(1530)).
head(id(610),ring_numbero(1530)).
head(id(611),ring_typee(1530)).
head(id(612),spore_print_colork(1530)).
head(id(613),populationa(1530)).
head(id(614),habitatg(1530)).
head(id(615),cap_shapex(7538)).
head(id(616),cap_surfaces(7538)).
head(id(617),cap_colorn(7538)).
head(id(618),odorn(7538)).
head(id(619),gill_attachment(7538)).
head(id(620),gill_spacing(7538)).
head(id(621),stalk_surface_above_rings(7538)).
head(id(622),stalk_surface_below_rings(7538)).
head(id(623),stalk_color_above_ringo(7538)).
head(id(624),stalk_color_below_ringo(7538)).
head(id(625),veil_coloro(7538)).
head(id(626),ring_numbero(7538)).
head(id(627),populationc(7538)).
head(id(628),habitatl(7538)).
head(id(629),cap_shapex(2575)).
head(id(630),cap_colorn(2575)).
head(id(631),bruises(2575)).
head(id(632),odorn(2575)).
head(id(633),gill_spacing(2575)).
head(id(634),gill_colorp(2575)).
head(id(635),stalk_rootb(2575)).
head(id(636),stalk_surface_above_rings(2575)).
head(id(637),stalk_surface_below_rings(2575)).
head(id(638),stalk_color_above_ringg(2575)).
head(id(639),stalk_color_below_ringw(2575)).
head(id(640),veil_colorw(2575)).
head(id(641),ring_numbero(2575)).
head(id(642),spore_print_colork(2575)).
head(id(643),populationv(2575)).
head(id(644),habitatd(2575)).
head(id(2644,A),poisoned(A)) :- dom(A).
body(id(2644,A),alpha_1(A)) :- dom(A).
body(id(2644,A),cap_shapek(A)) :- dom(A).
head(id(4662,A),poisoned(A)) :- dom(A).
body(id(4662,A),alpha_2(A)) :- dom(A).
body(id(4662,A),cap_shapex(A)) :- dom(A).
head(id(8081,A),poisoned(A)) :- dom(A).
body(id(8081,A),cap_shapec(A)) :- dom(A).
head(id(10132,A),poisoned(A)) :- dom(A).
body(id(10132,A),alpha_3(A)) :- dom(A).
body(id(10132,A),cap_shapef(A)) :- dom(A).
head(id(22467,A),c_alpha_1(A)) :- dom(A).
body(id(22467,A),cap_surfacef(A)) :- dom(A).
head(id(25874,A),c_alpha_1(A)) :- dom(A).
body(id(25874,A),alpha_4(A)) :- dom(A).
body(id(25874,A),cap_surfaces(A)) :- dom(A).
head(id(30684,A),c_alpha_2(A)) :- dom(A).
body(id(30684,A),alpha_5(A)) :- dom(A).
body(id(30684,A),bruises(A)) :- dom(A).
head(id(34829,A),c_alpha_2(A)) :- dom(A).
body(id(34829,A),alpha_6(A)) :- dom(A).
body(id(34829,A),cap_surfacef(A)) :- dom(A).
head(id(39723,A),c_alpha_2(A)) :- dom(A).
body(id(39723,A),alpha_7(A)) :- dom(A).
body(id(39723,A),cap_colorw(A)) :- dom(A).
head(id(44652,A),c_alpha_2(A)) :- dom(A).
body(id(44652,A),alpha_8(A)) :- dom(A).
body(id(44652,A),cap_colorn(A)) :- dom(A).
head(id(52446,A),c_alpha_3(A)) :- dom(A).
body(id(52446,A),cap_colorg(A)) :- dom(A).
head(id(57399,A),c_alpha_3(A)) :- dom(A).
body(id(57399,A),cap_colorn(A)) :- dom(A).
head(id(63759,A),c_alpha_3(A)) :- dom(A).
body(id(63759,A),alpha_9(A)) :- dom(A).
body(id(63759,A),cap_colore(A)) :- dom(A).
head(id(65900,A),c_alpha_4(A)) :- dom(A).
body(id(65900,A),alpha_1(A)) :- dom(A).
body(id(65900,A),cap_shapek(A)) :- dom(A).
head(id(68044,A),c_alpha_5(A)) :- dom(A).
body(id(68044,A),alpha_2(A)) :- dom(A).
body(id(68044,A),cap_shapex(A)) :- dom(A).
head(id(70194,A),c_alpha_6(A)) :- dom(A).
body(id(70194,A),alpha_2(A)) :- dom(A).
body(id(70194,A),cap_shapex(A)) :- dom(A).
head(id(74492,A),c_alpha_7(A)) :- dom(A).
body(id(74492,A),alpha_2(A)) :- dom(A).
body(id(74492,A),cap_shapex(A)) :- dom(A).
head(id(76645,A),c_alpha_8(A)) :- dom(A).
body(id(76645,A),alpha_2(A)) :- dom(A).
body(id(76645,A),cap_shapex(A)) :- dom(A).
head(id(81662,A),c_alpha_9(A)) :- dom(A).
body(id(81662,A),alpha_3(A)) :- dom(A).
body(id(81662,A),cap_shapef(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
assumption(alpha_4(A)) :- dom(A).
assumption(alpha_5(A)) :- dom(A).
assumption(alpha_6(A)) :- dom(A).
assumption(alpha_7(A)) :- dom(A).
assumption(alpha_8(A)) :- dom(A).
assumption(alpha_9(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).
contrary(alpha_4(A),c_alpha_4(A)) :- assumption(alpha_4(A)).
contrary(alpha_5(A),c_alpha_5(A)) :- assumption(alpha_5(A)).
contrary(alpha_6(A),c_alpha_6(A)) :- assumption(alpha_6(A)).
contrary(alpha_7(A),c_alpha_7(A)) :- assumption(alpha_7(A)).
contrary(alpha_8(A),c_alpha_8(A)) :- assumption(alpha_8(A)).
contrary(alpha_9(A),c_alpha_9(A)) :- assumption(alpha_9(A)).

dom(170).
dom(646).
dom(751).
dom(782).
dom(1100).
dom(1328).
dom(1331).
dom(1530).
dom(1757).
dom(2011).
dom(2137).
dom(2418).
dom(2472).
dom(2575).
dom(2681).
dom(3143).
dom(3338).
dom(3436).
dom(3470).
dom(3635).
dom(4195).
dom(4341).
dom(4477).
dom(4513).
dom(4595).
dom(4725).
dom(4912).
dom(5509).
dom(5772).
dom(5816).
dom(6341).
dom(6443).
dom(6456).
dom(6507).
dom(6763).
dom(6946).
dom(7102).
dom(7422).
dom(7538).
dom(7571).
dom(7794).
 :- not supported(poisoned(7794)).
 :- not supported(poisoned(1100)).
 :- not supported(poisoned(7102)).
 :- not supported(poisoned(3470)).
 :- not supported(poisoned(5772)).
 :- not supported(poisoned(5509)).
 :- not supported(poisoned(6946)).
 :- not supported(poisoned(3338)).
 :- not supported(poisoned(6507)).
 :- not supported(poisoned(6341)).
 :- not supported(poisoned(7422)).
 :- not supported(poisoned(4595)).
 :- not supported(poisoned(6456)).
 :- not supported(poisoned(4513)).
 :- not supported(poisoned(3436)).
 :- not supported(poisoned(4725)).
 :- not supported(poisoned(4341)).
 :- not supported(poisoned(4195)).
 :- not supported(poisoned(4477)).
 :- not supported(poisoned(5816)).
 :- not supported(poisoned(6443)).
 :- supported(poisoned(170)).
 :- supported(poisoned(646)).
 :- supported(poisoned(1757)).
 :- supported(poisoned(2418)).
 :- supported(poisoned(751)).
 :- supported(poisoned(6763)).
 :- supported(poisoned(2011)).
 :- supported(poisoned(7571)).
 :- supported(poisoned(1328)).
 :- supported(poisoned(4912)).
 :- supported(poisoned(2681)).
 :- supported(poisoned(782)).
 :- supported(poisoned(1331)).
 :- supported(poisoned(2137)).
 :- supported(poisoned(2472)).
 :- supported(poisoned(3143)).
 :- supported(poisoned(3635)).
 :- supported(poisoned(1530)).
 :- supported(poisoned(7538)).
 :- supported(poisoned(2575)).
