% training data:
% no. positive ex.: 23
% no. negative ex.: 24
% query: 
train :- aba_asp('./xabal/acute.csv.f5.bk',[acute(11),acute(54),acute(37),acute(84),acute(80),acute(47),acute(7),acute(48),acute(59),acute(52),acute(19),acute(14),acute(89),acute(21),acute(100),acute(71),acute(9),acute(85),acute(22),acute(26),acute(30),acute(57),acute(17)],[acute(66),acute(64),acute(82),acute(78),acute(96),acute(110),acute(58),acute(69),acute(33),acute(74),acute(51),acute(20),acute(95),acute(113),acute(88),acute(53),acute(23),acute(16),acute(3),acute(68),acute(5),acute(87),acute(75),acute(114)]).
% test data:
% no. positive ex.: 6
% no. negative ex.: 7
% query: 
test :- test_abaf('./xabal/acute.csv.f5.bk.sol',[pos(acute(50),[lo(50),a4(50),a5(50)]),pos(acute(99),[hi(99),a2(99),a3(99),a4(99),a5(99)]),pos(acute(90),[hi(90),a2(90),a3(90),a4(90),a5(90),a6(90)]),pos(acute(49),[lo(49),a4(49),a5(49)]),pos(acute(44),[lo(44),a4(44)]),pos(acute(40),[lo(40),a4(40),a5(40)])],[neg(acute(1),[a3(1)]),neg(acute(38),[lo(38),a3(38)]),neg(acute(76),[hi(76),a2(76),a3(76),a5(76)]),neg(acute(8),[a3(8)]),neg(acute(97),[hi(97),a3(97),a4(97),a6(97)]),neg(acute(35),[lo(35),a3(35)]),neg(acute(103),[hi(103)])]).
