head(id(1),cap_shapef(535)).
head(id(2),cap_surfaces(535)).
head(id(3),cap_colorn(535)).
head(id(4),gill_spacing(535)).
head(id(5),gill_size(535)).
head(id(6),gill_colork(535)).
head(id(7),stalk_roote(535)).
head(id(8),stalk_surface_above_rings(535)).
head(id(9),stalk_surface_below_rings(535)).
head(id(10),stalk_color_above_ringw(535)).
head(id(11),stalk_color_below_ringw(535)).
head(id(12),veil_colorw(535)).
head(id(13),ring_numbero(535)).
head(id(14),cap_shapex(14)).
head(id(15),cap_colorw(14)).
head(id(16),gill_spacing(14)).
head(id(17),gill_size(14)).
head(id(18),gill_colork(14)).
head(id(19),stalk_roote(14)).
head(id(20),stalk_surface_above_rings(14)).
head(id(21),stalk_surface_below_rings(14)).
head(id(22),stalk_color_above_ringw(14)).
head(id(23),stalk_color_below_ringw(14)).
head(id(24),veil_colorw(14)).
head(id(25),ring_numbero(14)).
head(id(26),cap_shapex(20)).
head(id(27),cap_surfaces(20)).
head(id(28),cap_colorn(20)).
head(id(29),gill_spacing(20)).
head(id(30),gill_size(20)).
head(id(31),gill_colork(20)).
head(id(32),stalk_roote(20)).
head(id(33),stalk_surface_above_rings(20)).
head(id(34),stalk_surface_below_rings(20)).
head(id(35),stalk_color_above_ringw(20)).
head(id(36),stalk_color_below_ringw(20)).
head(id(37),veil_colorw(20)).
head(id(38),ring_numbero(20)).
head(id(39),cap_shapex(300)).
head(id(40),cap_colorw(300)).
head(id(41),gill_spacing(300)).
head(id(42),gill_size(300)).
head(id(43),gill_colorp(300)).
head(id(44),stalk_roote(300)).
head(id(45),stalk_surface_above_rings(300)).
head(id(46),stalk_surface_below_rings(300)).
head(id(47),stalk_color_above_ringw(300)).
head(id(48),stalk_color_below_ringw(300)).
head(id(49),veil_colorw(300)).
head(id(50),ring_numbero(300)).
head(id(51),cap_shapex(252)).
head(id(52),cap_surfaces(252)).
head(id(53),cap_colorn(252)).
head(id(54),gill_spacing(252)).
head(id(55),gill_size(252)).
head(id(56),gill_colorp(252)).
head(id(57),stalk_roote(252)).
head(id(58),stalk_surface_above_rings(252)).
head(id(59),stalk_surface_below_rings(252)).
head(id(60),stalk_color_above_ringw(252)).
head(id(61),stalk_color_below_ringw(252)).
head(id(62),veil_colorw(252)).
head(id(63),ring_numbero(252)).
head(id(64),cap_shapex(181)).
head(id(65),cap_colorw(181)).
head(id(66),gill_spacing(181)).
head(id(67),gill_size(181)).
head(id(68),gill_colorp(181)).
head(id(69),stalk_roote(181)).
head(id(70),stalk_surface_above_rings(181)).
head(id(71),stalk_surface_below_rings(181)).
head(id(72),stalk_color_above_ringw(181)).
head(id(73),stalk_color_below_ringw(181)).
head(id(74),veil_colorw(181)).
head(id(75),ring_numbero(181)).
head(id(76),cap_shapex(232)).
head(id(77),cap_colorw(232)).
head(id(78),gill_spacing(232)).
head(id(79),gill_size(232)).
head(id(80),gill_colork(232)).
head(id(81),stalk_roote(232)).
head(id(82),stalk_surface_above_rings(232)).
head(id(83),stalk_surface_below_rings(232)).
head(id(84),stalk_color_above_ringw(232)).
head(id(85),stalk_color_below_ringw(232)).
head(id(86),veil_colorw(232)).
head(id(87),ring_numbero(232)).
head(id(88),cap_shapex(1)).
head(id(89),cap_surfaces(1)).
head(id(90),cap_colorn(1)).
head(id(91),gill_spacing(1)).
head(id(92),gill_size(1)).
head(id(93),gill_colork(1)).
head(id(94),stalk_roote(1)).
head(id(95),stalk_surface_above_rings(1)).
head(id(96),stalk_surface_below_rings(1)).
head(id(97),stalk_color_above_ringw(1)).
head(id(98),stalk_color_below_ringw(1)).
head(id(99),veil_colorw(1)).
head(id(100),ring_numbero(1)).
head(id(101),cap_shapex(386)).
head(id(102),cap_surfaces(386)).
head(id(103),cap_colorn(386)).
head(id(104),gill_spacing(386)).
head(id(105),gill_size(386)).
head(id(106),gill_colorw(386)).
head(id(107),stalk_roote(386)).
head(id(108),stalk_surface_above_rings(386)).
head(id(109),stalk_surface_below_rings(386)).
head(id(110),stalk_color_above_ringw(386)).
head(id(111),stalk_color_below_ringw(386)).
head(id(112),veil_colorw(386)).
head(id(113),ring_numbero(386)).
head(id(114),cap_shapex(139)).
head(id(115),cap_surfaces(139)).
head(id(116),cap_colorn(139)).
head(id(117),gill_spacing(139)).
head(id(118),gill_size(139)).
head(id(119),gill_colorp(139)).
head(id(120),stalk_roote(139)).
head(id(121),stalk_surface_above_rings(139)).
head(id(122),stalk_surface_below_rings(139)).
head(id(123),stalk_color_above_ringw(139)).
head(id(124),stalk_color_below_ringw(139)).
head(id(125),veil_colorw(139)).
head(id(126),ring_numbero(139)).
head(id(127),cap_shapex(121)).
head(id(128),cap_surfaces(121)).
head(id(129),cap_colorw(121)).
head(id(130),gill_spacing(121)).
head(id(131),gill_size(121)).
head(id(132),gill_colork(121)).
head(id(133),stalk_roote(121)).
head(id(134),stalk_surface_above_rings(121)).
head(id(135),stalk_surface_below_rings(121)).
head(id(136),stalk_color_above_ringw(121)).
head(id(137),stalk_color_below_ringw(121)).
head(id(138),veil_colorw(121)).
head(id(139),ring_numbero(121)).
head(id(140),cap_shapex(328)).
head(id(141),cap_colorn(328)).
head(id(142),gill_spacing(328)).
head(id(143),gill_size(328)).
head(id(144),gill_colorn(328)).
head(id(145),stalk_roote(328)).
head(id(146),stalk_surface_above_rings(328)).
head(id(147),stalk_surface_below_rings(328)).
head(id(148),stalk_color_above_ringw(328)).
head(id(149),stalk_color_below_ringw(328)).
head(id(150),veil_colorw(328)).
head(id(151),ring_numbero(328)).
head(id(152),cap_shapex(136)).
head(id(153),cap_colorw(136)).
head(id(154),gill_spacing(136)).
head(id(155),gill_size(136)).
head(id(156),gill_colorw(136)).
head(id(157),stalk_roote(136)).
head(id(158),stalk_surface_above_rings(136)).
head(id(159),stalk_surface_below_rings(136)).
head(id(160),stalk_color_above_ringw(136)).
head(id(161),stalk_color_below_ringw(136)).
head(id(162),veil_colorw(136)).
head(id(163),ring_numbero(136)).
head(id(164),cap_shapex(55)).
head(id(165),cap_surfaces(55)).
head(id(166),cap_colorw(55)).
head(id(167),gill_spacing(55)).
head(id(168),gill_size(55)).
head(id(169),gill_colork(55)).
head(id(170),stalk_roote(55)).
head(id(171),stalk_surface_above_rings(55)).
head(id(172),stalk_surface_below_rings(55)).
head(id(173),stalk_color_above_ringw(55)).
head(id(174),stalk_color_below_ringw(55)).
head(id(175),veil_colorw(55)).
head(id(176),ring_numbero(55)).
head(id(177),cap_shapex(38)).
head(id(178),cap_colorn(38)).
head(id(179),gill_spacing(38)).
head(id(180),gill_size(38)).
head(id(181),gill_colorw(38)).
head(id(182),stalk_roote(38)).
head(id(183),stalk_surface_above_rings(38)).
head(id(184),stalk_surface_below_rings(38)).
head(id(185),stalk_color_above_ringw(38)).
head(id(186),stalk_color_below_ringw(38)).
head(id(187),veil_colorw(38)).
head(id(188),ring_numbero(38)).
head(id(189),cap_shapex(79)).
head(id(190),cap_colorn(79)).
head(id(191),gill_spacing(79)).
head(id(192),gill_size(79)).
head(id(193),gill_colorw(79)).
head(id(194),stalk_roote(79)).
head(id(195),stalk_surface_above_rings(79)).
head(id(196),stalk_surface_below_rings(79)).
head(id(197),stalk_color_above_ringw(79)).
head(id(198),stalk_color_below_ringw(79)).
head(id(199),veil_colorw(79)).
head(id(200),ring_numbero(79)).
head(id(201),cap_shapex(244)).
head(id(202),cap_surfaces(244)).
head(id(203),cap_colorw(244)).
head(id(204),gill_spacing(244)).
head(id(205),gill_size(244)).
head(id(206),gill_colorn(244)).
head(id(207),stalk_roote(244)).
head(id(208),stalk_surface_above_rings(244)).
head(id(209),stalk_surface_below_rings(244)).
head(id(210),stalk_color_above_ringw(244)).
head(id(211),stalk_color_below_ringw(244)).
head(id(212),veil_colorw(244)).
head(id(213),ring_numbero(244)).
head(id(214),cap_shapex(54)).
head(id(215),cap_colorn(54)).
head(id(216),gill_spacing(54)).
head(id(217),gill_size(54)).
head(id(218),gill_colork(54)).
head(id(219),stalk_roote(54)).
head(id(220),stalk_surface_above_rings(54)).
head(id(221),stalk_surface_below_rings(54)).
head(id(222),stalk_color_above_ringw(54)).
head(id(223),stalk_color_below_ringw(54)).
head(id(224),veil_colorw(54)).
head(id(225),ring_numbero(54)).
head(id(226),cap_shapex(82)).
head(id(227),cap_colorw(82)).
head(id(228),gill_spacing(82)).
head(id(229),gill_size(82)).
head(id(230),gill_colorw(82)).
head(id(231),stalk_roote(82)).
head(id(232),stalk_surface_above_rings(82)).
head(id(233),stalk_surface_below_rings(82)).
head(id(234),stalk_color_above_ringw(82)).
head(id(235),stalk_color_below_ringw(82)).
head(id(236),veil_colorw(82)).
head(id(237),ring_numbero(82)).
head(id(238),cap_shapef(492)).
head(id(239),cap_surfaces(492)).
head(id(240),cap_colorn(492)).
head(id(241),gill_spacing(492)).
head(id(242),gill_size(492)).
head(id(243),gill_colorp(492)).
head(id(244),stalk_roote(492)).
head(id(245),stalk_surface_above_rings(492)).
head(id(246),stalk_surface_below_rings(492)).
head(id(247),stalk_color_above_ringw(492)).
head(id(248),stalk_color_below_ringw(492)).
head(id(249),veil_colorw(492)).
head(id(250),ring_numbero(492)).
head(id(251),cap_shapex(423)).
head(id(252),cap_colorn(423)).
head(id(253),gill_spacing(423)).
head(id(254),gill_size(423)).
head(id(255),gill_colorp(423)).
head(id(256),stalk_roote(423)).
head(id(257),stalk_surface_above_rings(423)).
head(id(258),stalk_surface_below_rings(423)).
head(id(259),stalk_color_above_ringw(423)).
head(id(260),stalk_color_below_ringw(423)).
head(id(261),veil_colorw(423)).
head(id(262),ring_numbero(423)).
head(id(263),cap_shapef(270)).
head(id(264),cap_colorn(270)).
head(id(265),gill_spacing(270)).
head(id(266),gill_size(270)).
head(id(267),gill_colorw(270)).
head(id(268),stalk_roote(270)).
head(id(269),stalk_surface_above_rings(270)).
head(id(270),stalk_surface_below_rings(270)).
head(id(271),stalk_color_above_ringw(270)).
head(id(272),stalk_color_below_ringw(270)).
head(id(273),veil_colorw(270)).
head(id(274),ring_numbero(270)).
head(id(275),cap_shapex(415)).
head(id(276),cap_colorn(415)).
head(id(277),gill_spacing(415)).
head(id(278),gill_size(415)).
head(id(279),gill_colork(415)).
head(id(280),stalk_roote(415)).
head(id(281),stalk_surface_above_rings(415)).
head(id(282),stalk_surface_below_rings(415)).
head(id(283),stalk_color_above_ringw(415)).
head(id(284),stalk_color_below_ringw(415)).
head(id(285),veil_colorw(415)).
head(id(286),ring_numbero(415)).
head(id(287),cap_shapex(9)).
head(id(288),cap_colorw(9)).
head(id(289),gill_spacing(9)).
head(id(290),gill_size(9)).
head(id(291),gill_colorp(9)).
head(id(292),stalk_roote(9)).
head(id(293),stalk_surface_above_rings(9)).
head(id(294),stalk_surface_below_rings(9)).
head(id(295),stalk_color_above_ringw(9)).
head(id(296),stalk_color_below_ringw(9)).
head(id(297),veil_colorw(9)).
head(id(298),ring_numbero(9)).
head(id(299),cap_shapex(381)).
head(id(300),cap_colorn(381)).
head(id(301),gill_spacing(381)).
head(id(302),gill_size(381)).
head(id(303),gill_colorp(381)).
head(id(304),stalk_roote(381)).
head(id(305),stalk_surface_above_rings(381)).
head(id(306),stalk_surface_below_rings(381)).
head(id(307),stalk_color_above_ringw(381)).
head(id(308),stalk_color_below_ringw(381)).
head(id(309),veil_colorw(381)).
head(id(310),ring_numbero(381)).
head(id(311),cap_shapex(312)).
head(id(312),cap_colorw(312)).
head(id(313),gill_spacing(312)).
head(id(314),gill_size(312)).
head(id(315),gill_colorn(312)).
head(id(316),stalk_roote(312)).
head(id(317),stalk_surface_above_rings(312)).
head(id(318),stalk_surface_below_rings(312)).
head(id(319),stalk_color_above_ringw(312)).
head(id(320),stalk_color_below_ringw(312)).
head(id(321),veil_colorw(312)).
head(id(322),ring_numbero(312)).
head(id(323),cap_shapex(262)).
head(id(324),cap_colorw(262)).
head(id(325),gill_spacing(262)).
head(id(326),gill_size(262)).
head(id(327),gill_colork(262)).
head(id(328),stalk_roote(262)).
head(id(329),stalk_surface_above_rings(262)).
head(id(330),stalk_surface_below_rings(262)).
head(id(331),stalk_color_above_ringw(262)).
head(id(332),stalk_color_below_ringw(262)).
head(id(333),veil_colorw(262)).
head(id(334),ring_numbero(262)).
head(id(335),cap_shapex(331)).
head(id(336),cap_colorn(331)).
head(id(337),gill_spacing(331)).
head(id(338),gill_size(331)).
head(id(339),gill_colorw(331)).
head(id(340),stalk_roote(331)).
head(id(341),stalk_surface_above_rings(331)).
head(id(342),stalk_surface_below_rings(331)).
head(id(343),stalk_color_above_ringw(331)).
head(id(344),stalk_color_below_ringw(331)).
head(id(345),veil_colorw(331)).
head(id(346),ring_numbero(331)).
head(id(347),cap_shapex(281)).
head(id(348),cap_colorw(281)).
head(id(349),gill_spacing(281)).
head(id(350),gill_size(281)).
head(id(351),gill_colorw(281)).
head(id(352),stalk_roote(281)).
head(id(353),stalk_surface_above_rings(281)).
head(id(354),stalk_surface_below_rings(281)).
head(id(355),stalk_color_above_ringw(281)).
head(id(356),stalk_color_below_ringw(281)).
head(id(357),veil_colorw(281)).
head(id(358),ring_numbero(281)).
head(id(359),cap_shapef(272)).
head(id(360),cap_surfaces(272)).
head(id(361),cap_colorn(272)).
head(id(362),gill_spacing(272)).
head(id(363),gill_size(272)).
head(id(364),gill_colorw(272)).
head(id(365),stalk_roote(272)).
head(id(366),stalk_surface_above_rings(272)).
head(id(367),stalk_surface_below_rings(272)).
head(id(368),stalk_color_above_ringw(272)).
head(id(369),stalk_color_below_ringw(272)).
head(id(370),veil_colorw(272)).
head(id(371),ring_numbero(272)).
head(id(372),cap_shapex(493)).
head(id(373),cap_surfaces(493)).
head(id(374),cap_colorn(493)).
head(id(375),gill_spacing(493)).
head(id(376),gill_size(493)).
head(id(377),gill_colork(493)).
head(id(378),stalk_roote(493)).
head(id(379),stalk_surface_above_rings(493)).
head(id(380),stalk_surface_below_rings(493)).
head(id(381),stalk_color_above_ringw(493)).
head(id(382),stalk_color_below_ringw(493)).
head(id(383),veil_colorw(493)).
head(id(384),ring_numbero(493)).
head(id(385),cap_shapex(115)).
head(id(386),cap_colorw(115)).
head(id(387),gill_spacing(115)).
head(id(388),gill_size(115)).
head(id(389),gill_colorn(115)).
head(id(390),stalk_roote(115)).
head(id(391),stalk_surface_above_rings(115)).
head(id(392),stalk_surface_below_rings(115)).
head(id(393),stalk_color_above_ringw(115)).
head(id(394),stalk_color_below_ringw(115)).
head(id(395),veil_colorw(115)).
head(id(396),ring_numbero(115)).
head(id(397),cap_shapex(524)).
head(id(398),cap_surfaces(524)).
head(id(399),cap_colorn(524)).
head(id(400),gill_spacing(524)).
head(id(401),gill_size(524)).
head(id(402),gill_colorn(524)).
head(id(403),stalk_roote(524)).
head(id(404),stalk_surface_above_rings(524)).
head(id(405),stalk_surface_below_rings(524)).
head(id(406),stalk_color_above_ringw(524)).
head(id(407),stalk_color_below_ringw(524)).
head(id(408),veil_colorw(524)).
head(id(409),ring_numbero(524)).
head(id(410),cap_shapex(186)).
head(id(411),cap_colorw(186)).
head(id(412),gill_spacing(186)).
head(id(413),gill_size(186)).
head(id(414),gill_colork(186)).
head(id(415),stalk_roote(186)).
head(id(416),stalk_surface_above_rings(186)).
head(id(417),stalk_surface_below_rings(186)).
head(id(418),stalk_color_above_ringw(186)).
head(id(419),stalk_color_below_ringw(186)).
head(id(420),veil_colorw(186)).
head(id(421),ring_numbero(186)).
head(id(422),cap_shapex(403)).
head(id(423),cap_colorn(403)).
head(id(424),gill_spacing(403)).
head(id(425),gill_size(403)).
head(id(426),gill_colorp(403)).
head(id(427),stalk_roote(403)).
head(id(428),stalk_surface_above_rings(403)).
head(id(429),stalk_surface_below_rings(403)).
head(id(430),stalk_color_above_ringw(403)).
head(id(431),stalk_color_below_ringw(403)).
head(id(432),veil_colorw(403)).
head(id(433),ring_numbero(403)).
head(id(434),cap_shapex(418)).
head(id(435),cap_surfaces(418)).
head(id(436),cap_colorn(418)).
head(id(437),gill_spacing(418)).
head(id(438),gill_size(418)).
head(id(439),gill_colorw(418)).
head(id(440),stalk_roote(418)).
head(id(441),stalk_surface_above_rings(418)).
head(id(442),stalk_surface_below_rings(418)).
head(id(443),stalk_color_above_ringw(418)).
head(id(444),stalk_color_below_ringw(418)).
head(id(445),veil_colorw(418)).
head(id(446),ring_numbero(418)).
head(id(447),cap_shapex(400)).
head(id(448),cap_surfaces(400)).
head(id(449),cap_colorn(400)).
head(id(450),gill_spacing(400)).
head(id(451),gill_size(400)).
head(id(452),gill_colorp(400)).
head(id(453),stalk_roote(400)).
head(id(454),stalk_surface_above_rings(400)).
head(id(455),stalk_surface_below_rings(400)).
head(id(456),stalk_color_above_ringw(400)).
head(id(457),stalk_color_below_ringw(400)).
head(id(458),veil_colorw(400)).
head(id(459),ring_numbero(400)).
head(id(460),cap_shapef(26)).
head(id(461),cap_surfaces(26)).
head(id(462),cap_colorw(26)).
head(id(463),gill_spacing(26)).
head(id(464),gill_size(26)).
head(id(465),gill_colorn(26)).
head(id(466),stalk_roote(26)).
head(id(467),stalk_surface_above_rings(26)).
head(id(468),stalk_surface_below_rings(26)).
head(id(469),stalk_color_above_ringw(26)).
head(id(470),stalk_color_below_ringw(26)).
head(id(471),veil_colorw(26)).
head(id(472),ring_numbero(26)).
head(id(473),cap_shapex(44)).
head(id(474),cap_colorw(44)).
head(id(475),gill_spacing(44)).
head(id(476),gill_size(44)).
head(id(477),gill_colorp(44)).
head(id(478),stalk_roote(44)).
head(id(479),stalk_surface_above_rings(44)).
head(id(480),stalk_surface_below_rings(44)).
head(id(481),stalk_color_above_ringw(44)).
head(id(482),stalk_color_below_ringw(44)).
head(id(483),veil_colorw(44)).
head(id(484),ring_numbero(44)).
head(id(485),cap_shapex(358)).
head(id(486),cap_colorn(358)).
head(id(487),gill_spacing(358)).
head(id(488),gill_size(358)).
head(id(489),gill_colork(358)).
head(id(490),stalk_roote(358)).
head(id(491),stalk_surface_above_rings(358)).
head(id(492),stalk_surface_below_rings(358)).
head(id(493),stalk_color_above_ringw(358)).
head(id(494),stalk_color_below_ringw(358)).
head(id(495),veil_colorw(358)).
head(id(496),ring_numbero(358)).
head(id(497),cap_shapex(32)).
head(id(498),cap_colorw(32)).
head(id(499),gill_spacing(32)).
head(id(500),gill_size(32)).
head(id(501),gill_colork(32)).
head(id(502),stalk_roote(32)).
head(id(503),stalk_surface_above_rings(32)).
head(id(504),stalk_surface_below_rings(32)).
head(id(505),stalk_color_above_ringw(32)).
head(id(506),stalk_color_below_ringw(32)).
head(id(507),veil_colorw(32)).
head(id(508),ring_numbero(32)).
head(id(509),cap_shapex(19)).
head(id(510),cap_colorw(19)).
head(id(511),gill_spacing(19)).
head(id(512),gill_size(19)).
head(id(513),gill_colorn(19)).
head(id(514),stalk_roote(19)).
head(id(515),stalk_surface_above_rings(19)).
head(id(516),stalk_surface_below_rings(19)).
head(id(517),stalk_color_above_ringw(19)).
head(id(518),stalk_color_below_ringw(19)).
head(id(519),veil_colorw(19)).
head(id(520),ring_numbero(19)).
head(id(521),cap_shapex(339)).
head(id(522),cap_surfacef(339)).
head(id(523),cap_colorg(339)).
head(id(524),gill_spacing(339)).
head(id(525),gill_size(339)).
head(id(526),gill_colorg(339)).
head(id(527),stalk_roote(339)).
head(id(528),stalk_surface_above_rings(339)).
head(id(529),stalk_surface_below_rings(339)).
head(id(530),stalk_color_above_ringw(339)).
head(id(531),stalk_color_below_ringw(339)).
head(id(532),veil_colorw(339)).
head(id(533),ring_numbero(339)).
head(id(534),cap_shapex(390)).
head(id(535),cap_surfaces(390)).
head(id(536),gill_spacing(390)).
head(id(537),gill_colorw(390)).
head(id(538),stalk_rootc(390)).
head(id(539),stalk_surface_above_rings(390)).
head(id(540),stalk_surface_below_rings(390)).
head(id(541),stalk_color_above_ringw(390)).
head(id(542),stalk_color_below_ringw(390)).
head(id(543),veil_colorw(390)).
head(id(544),ring_numbero(390)).
head(id(545),cap_shapex(516)).
head(id(546),cap_surfacef(516)).
head(id(547),cap_colorw(516)).
head(id(548),gill_colorh(516)).
head(id(549),stalk_roote(516)).
head(id(550),stalk_surface_above_ringf(516)).
head(id(551),stalk_surface_below_rings(516)).
head(id(552),stalk_color_above_ringw(516)).
head(id(553),stalk_color_below_ringw(516)).
head(id(554),veil_colorw(516)).
head(id(555),ring_numbero(516)).
head(id(556),cap_surfaces(384)).
head(id(557),cap_colorw(384)).
head(id(558),gill_spacing(384)).
head(id(559),gill_colorg(384)).
head(id(560),stalk_rootc(384)).
head(id(561),stalk_surface_above_rings(384)).
head(id(562),stalk_surface_below_rings(384)).
head(id(563),stalk_color_above_ringw(384)).
head(id(564),stalk_color_below_ringw(384)).
head(id(565),veil_colorw(384)).
head(id(566),ring_numbero(384)).
head(id(567),cap_surfaces(216)).
head(id(568),cap_colorw(216)).
head(id(569),gill_spacing(216)).
head(id(570),gill_colorn(216)).
head(id(571),stalk_rootc(216)).
head(id(572),stalk_surface_above_rings(216)).
head(id(573),stalk_surface_below_rings(216)).
head(id(574),stalk_color_above_ringw(216)).
head(id(575),stalk_color_below_ringw(216)).
head(id(576),veil_colorw(216)).
head(id(577),ring_numbero(216)).
head(id(578),cap_surfaces(332)).
head(id(579),cap_colorw(332)).
head(id(580),gill_spacing(332)).
head(id(581),gill_colorn(332)).
head(id(582),stalk_rootc(332)).
head(id(583),stalk_surface_above_rings(332)).
head(id(584),stalk_surface_below_rings(332)).
head(id(585),stalk_color_above_ringw(332)).
head(id(586),stalk_color_below_ringw(332)).
head(id(587),veil_colorw(332)).
head(id(588),ring_numbero(332)).
head(id(589),cap_shapex(472)).
head(id(590),cap_colorw(472)).
head(id(591),gill_spacing(472)).
head(id(592),gill_colorw(472)).
head(id(593),stalk_rootc(472)).
head(id(594),stalk_surface_above_rings(472)).
head(id(595),stalk_surface_below_rings(472)).
head(id(596),stalk_color_above_ringw(472)).
head(id(597),stalk_color_below_ringw(472)).
head(id(598),veil_colorw(472)).
head(id(599),ring_numbero(472)).
head(id(600),cap_surfaces(25)).
head(id(601),cap_colorw(25)).
head(id(602),gill_spacing(25)).
head(id(603),gill_colorg(25)).
head(id(604),stalk_rootc(25)).
head(id(605),stalk_surface_above_rings(25)).
head(id(606),stalk_surface_below_rings(25)).
head(id(607),stalk_color_above_ringw(25)).
head(id(608),stalk_color_below_ringw(25)).
head(id(609),veil_colorw(25)).
head(id(610),ring_numbero(25)).
head(id(611),cap_shapex(341)).
head(id(612),cap_surfaces(341)).
head(id(613),cap_colorw(341)).
head(id(614),gill_spacing(341)).
head(id(615),gill_colork(341)).
head(id(616),stalk_rootc(341)).
head(id(617),stalk_surface_above_rings(341)).
head(id(618),stalk_surface_below_rings(341)).
head(id(619),stalk_color_above_ringw(341)).
head(id(620),stalk_color_below_ringw(341)).
head(id(621),veil_colorw(341)).
head(id(622),ring_numbero(341)).
head(id(623),cap_shapef(249)).
head(id(624),gill_spacing(249)).
head(id(625),gill_colorw(249)).
head(id(626),stalk_rootr(249)).
head(id(627),stalk_surface_above_rings(249)).
head(id(628),stalk_color_above_ringw(249)).
head(id(629),stalk_color_below_ringw(249)).
head(id(630),veil_colorw(249)).
head(id(631),ring_numbero(249)).
head(id(632),gill_spacing(142)).
head(id(633),gill_colorg(142)).
head(id(634),stalk_rootc(142)).
head(id(635),stalk_surface_above_rings(142)).
head(id(636),stalk_surface_below_rings(142)).
head(id(637),stalk_color_above_ringw(142)).
head(id(638),stalk_color_below_ringw(142)).
head(id(639),veil_colorw(142)).
head(id(640),ring_numbero(142)).
head(id(641),cap_shapex(346)).
head(id(642),cap_surfacef(346)).
head(id(643),cap_colorn(346)).
head(id(644),gill_colorn(346)).
head(id(645),stalk_roote(346)).
head(id(646),stalk_surface_above_rings(346)).
head(id(647),stalk_surface_below_ringf(346)).
head(id(648),stalk_color_above_ringw(346)).
head(id(649),stalk_color_below_ringw(346)).
head(id(650),veil_colorw(346)).
head(id(651),ring_numbero(346)).
head(id(652),cap_shapex(539)).
head(id(653),gill_spacing(539)).
head(id(654),gill_colorg(539)).
head(id(655),stalk_rootc(539)).
head(id(656),stalk_surface_above_rings(539)).
head(id(657),stalk_surface_below_rings(539)).
head(id(658),stalk_color_above_ringw(539)).
head(id(659),stalk_color_below_ringw(539)).
head(id(660),veil_colorw(539)).
head(id(661),ring_numbero(539)).
head(id(662),cap_shapef(17)).
head(id(663),cap_surfacef(17)).
head(id(664),cap_colorw(17)).
head(id(665),gill_colork(17)).
head(id(666),stalk_roote(17)).
head(id(667),stalk_surface_above_rings(17)).
head(id(668),stalk_surface_below_rings(17)).
head(id(669),stalk_color_above_ringw(17)).
head(id(670),stalk_color_below_ringw(17)).
head(id(671),veil_colorw(17)).
head(id(672),ring_numbero(17)).
head(id(673),cap_shapex(155)).
head(id(674),cap_surfaces(155)).
head(id(675),cap_colorw(155)).
head(id(676),gill_size(155)).
head(id(677),gill_colorw(155)).
head(id(678),stalk_rootb(155)).
head(id(679),stalk_surface_above_rings(155)).
head(id(680),stalk_surface_below_rings(155)).
head(id(681),stalk_color_above_ringw(155)).
head(id(682),stalk_color_below_ringw(155)).
head(id(683),veil_colorw(155)).
head(id(684),ring_numbero(155)).
head(id(685),cap_shapex(350)).
head(id(686),cap_surfacef(350)).
head(id(687),cap_colorn(350)).
head(id(688),gill_spacing(350)).
head(id(689),gill_size(350)).
head(id(690),gill_colorg(350)).
head(id(691),stalk_roote(350)).
head(id(692),stalk_surface_above_rings(350)).
head(id(693),stalk_surface_below_rings(350)).
head(id(694),stalk_color_above_ringw(350)).
head(id(695),stalk_color_below_ringw(350)).
head(id(696),veil_colorw(350)).
head(id(697),ring_numbero(350)).
head(id(698),cap_surfaces(436)).
head(id(699),cap_colorw(436)).
head(id(700),gill_spacing(436)).
head(id(701),gill_colorw(436)).
head(id(702),stalk_rootc(436)).
head(id(703),stalk_surface_above_rings(436)).
head(id(704),stalk_surface_below_rings(436)).
head(id(705),stalk_color_above_ringw(436)).
head(id(706),stalk_color_below_ringw(436)).
head(id(707),veil_colorw(436)).
head(id(708),ring_numbero(436)).
head(id(709),gill_spacing(482)).
head(id(710),gill_colorg(482)).
head(id(711),stalk_rootc(482)).
head(id(712),stalk_surface_above_rings(482)).
head(id(713),stalk_surface_below_rings(482)).
head(id(714),stalk_color_above_ringw(482)).
head(id(715),stalk_color_below_ringw(482)).
head(id(716),veil_colorw(482)).
head(id(717),ring_numbero(482)).
head(id(718),cap_shapes(474)).
head(id(719),cap_surfacef(474)).
head(id(720),cap_colorg(474)).
head(id(721),gill_spacing(474)).
head(id(722),gill_size(474)).
head(id(723),gill_colork(474)).
head(id(724),stalk_roote(474)).
head(id(725),stalk_surface_above_rings(474)).
head(id(726),stalk_surface_below_rings(474)).
head(id(727),stalk_color_above_ringw(474)).
head(id(728),stalk_color_below_ringw(474)).
head(id(729),veil_colorw(474)).
head(id(730),ring_numbero(474)).
head(id(731),cap_shapef(194)).
head(id(732),cap_surfaces(194)).
head(id(733),gill_size(194)).
head(id(734),gill_colorw(194)).
head(id(735),stalk_rootb(194)).
head(id(736),stalk_surface_above_rings(194)).
head(id(737),stalk_surface_below_rings(194)).
head(id(738),stalk_color_above_ringw(194)).
head(id(739),stalk_color_below_ringw(194)).
head(id(740),veil_colorw(194)).
head(id(741),ring_numbero(194)).
head(id(742),cap_shapex(398)).
head(id(743),gill_spacing(398)).
head(id(744),gill_colorw(398)).
head(id(745),stalk_rootc(398)).
head(id(746),stalk_surface_above_rings(398)).
head(id(747),stalk_surface_below_rings(398)).
head(id(748),stalk_color_above_ringw(398)).
head(id(749),stalk_color_below_ringw(398)).
head(id(750),veil_colorw(398)).
head(id(751),ring_numbero(398)).
head(id(752),cap_shapex(93)).
head(id(753),gill_spacing(93)).
head(id(754),gill_colorg(93)).
head(id(755),stalk_rootc(93)).
head(id(756),stalk_surface_above_rings(93)).
head(id(757),stalk_surface_below_rings(93)).
head(id(758),stalk_color_above_ringw(93)).
head(id(759),stalk_color_below_ringw(93)).
head(id(760),veil_colorw(93)).
head(id(761),ring_numbero(93)).
head(id(762),cap_surfaces(140)).
head(id(763),gill_spacing(140)).
head(id(764),gill_colorw(140)).
head(id(765),stalk_rootc(140)).
head(id(766),stalk_surface_above_rings(140)).
head(id(767),stalk_surface_below_rings(140)).
head(id(768),stalk_color_above_ringw(140)).
head(id(769),stalk_color_below_ringw(140)).
head(id(770),veil_colorw(140)).
head(id(771),ring_numbero(140)).
head(id(772),cap_surfaces(315)).
head(id(773),gill_spacing(315)).
head(id(774),gill_colorg(315)).
head(id(775),stalk_rootc(315)).
head(id(776),stalk_surface_above_rings(315)).
head(id(777),stalk_surface_below_rings(315)).
head(id(778),stalk_color_above_ringw(315)).
head(id(779),stalk_color_below_ringw(315)).
head(id(780),veil_colorw(315)).
head(id(781),ring_numbero(315)).
head(id(782),cap_shapex(85)).
head(id(783),gill_spacing(85)).
head(id(784),gill_colorw(85)).
head(id(785),stalk_rootr(85)).
head(id(786),stalk_surface_above_rings(85)).
head(id(787),stalk_color_above_ringw(85)).
head(id(788),stalk_color_below_ringw(85)).
head(id(789),veil_colorw(85)).
head(id(790),ring_numbero(85)).
head(id(791),cap_shapex(528)).
head(id(792),cap_surfaces(528)).
head(id(793),gill_spacing(528)).
head(id(794),gill_colork(528)).
head(id(795),stalk_rootc(528)).
head(id(796),stalk_surface_above_rings(528)).
head(id(797),stalk_surface_below_rings(528)).
head(id(798),stalk_color_above_ringw(528)).
head(id(799),stalk_color_below_ringw(528)).
head(id(800),veil_colorw(528)).
head(id(801),ring_numbero(528)).
head(id(802),cap_shapex(246)).
head(id(803),cap_surfaces(246)).
head(id(804),cap_colorw(246)).
head(id(805),gill_spacing(246)).
head(id(806),gill_colorw(246)).
head(id(807),stalk_rootc(246)).
head(id(808),stalk_surface_above_rings(246)).
head(id(809),stalk_surface_below_rings(246)).
head(id(810),stalk_color_above_ringw(246)).
head(id(811),stalk_color_below_ringw(246)).
head(id(812),veil_colorw(246)).
head(id(813),ring_numbero(246)).
head(id(814),cap_shapef(486)).
head(id(815),gill_spacing(486)).
head(id(816),gill_colorp(486)).
head(id(817),stalk_rootr(486)).
head(id(818),stalk_surface_above_rings(486)).
head(id(819),stalk_color_above_ringw(486)).
head(id(820),stalk_color_below_ringw(486)).
head(id(821),veil_colorw(486)).
head(id(822),ring_numbero(486)).
head(id(823),gill_spacing(56)).
head(id(824),gill_colorw(56)).
head(id(825),stalk_rootc(56)).
head(id(826),stalk_surface_above_rings(56)).
head(id(827),stalk_surface_below_rings(56)).
head(id(828),stalk_color_above_ringw(56)).
head(id(829),stalk_color_below_ringw(56)).
head(id(830),veil_colorw(56)).
head(id(831),ring_numbero(56)).
head(id(832),cap_shapex(6)).
head(id(833),gill_spacing(6)).
head(id(834),gill_colorn(6)).
head(id(835),stalk_rootc(6)).
head(id(836),stalk_surface_above_rings(6)).
head(id(837),stalk_surface_below_rings(6)).
head(id(838),stalk_color_above_ringw(6)).
head(id(839),stalk_color_below_ringw(6)).
head(id(840),veil_colorw(6)).
head(id(841),ring_numbero(6)).
head(id(842),cap_colorw(72)).
head(id(843),gill_spacing(72)).
head(id(844),gill_colorg(72)).
head(id(845),stalk_rootc(72)).
head(id(846),stalk_surface_above_rings(72)).
head(id(847),stalk_surface_below_rings(72)).
head(id(848),stalk_color_above_ringw(72)).
head(id(849),stalk_color_below_ringw(72)).
head(id(850),veil_colorw(72)).
head(id(851),ring_numbero(72)).
head(id(852),gill_spacing(505)).
head(id(853),gill_colorw(505)).
head(id(854),stalk_rootc(505)).
head(id(855),stalk_surface_above_rings(505)).
head(id(856),stalk_surface_below_rings(505)).
head(id(857),stalk_color_above_ringw(505)).
head(id(858),stalk_color_below_ringw(505)).
head(id(859),veil_colorw(505)).
head(id(860),ring_numbero(505)).
head(id(861),cap_shapex(289)).
head(id(862),cap_colorn(289)).
head(id(863),gill_spacing(289)).
head(id(864),gill_colorn(289)).
head(id(865),stalk_rootr(289)).
head(id(866),stalk_surface_above_rings(289)).
head(id(867),stalk_color_above_ringw(289)).
head(id(868),stalk_color_below_ringw(289)).
head(id(869),veil_colorw(289)).
head(id(870),ring_numbero(289)).
head(id(871),cap_shapex(169)).
head(id(872),cap_colorn(169)).
head(id(873),gill_spacing(169)).
head(id(874),gill_colorw(169)).
head(id(875),stalk_rootr(169)).
head(id(876),stalk_surface_above_rings(169)).
head(id(877),stalk_color_above_ringw(169)).
head(id(878),stalk_color_below_ringw(169)).
head(id(879),veil_colorw(169)).
head(id(880),ring_numbero(169)).
head(id(881),cap_shapex(521)).
head(id(882),cap_surfaces(521)).
head(id(883),cap_colorw(521)).
head(id(884),gill_spacing(521)).
head(id(885),gill_colorw(521)).
head(id(886),stalk_rootc(521)).
head(id(887),stalk_surface_above_rings(521)).
head(id(888),stalk_surface_below_rings(521)).
head(id(889),stalk_color_above_ringw(521)).
head(id(890),stalk_color_below_ringw(521)).
head(id(891),veil_colorw(521)).
head(id(892),ring_numbero(521)).
head(id(893),cap_surfaces(102)).
head(id(894),gill_spacing(102)).
head(id(895),gill_colorn(102)).
head(id(896),stalk_rootc(102)).
head(id(897),stalk_surface_above_rings(102)).
head(id(898),stalk_surface_below_rings(102)).
head(id(899),stalk_color_above_ringw(102)).
head(id(900),stalk_color_below_ringw(102)).
head(id(901),veil_colorw(102)).
head(id(902),ring_numbero(102)).
head(id(903),cap_shapex(43)).
head(id(904),cap_surfacef(43)).
head(id(905),cap_colorn(43)).
head(id(906),gill_spacing(43)).
head(id(907),gill_size(43)).
head(id(908),gill_colorg(43)).
head(id(909),stalk_roote(43)).
head(id(910),stalk_surface_above_rings(43)).
head(id(911),stalk_surface_below_rings(43)).
head(id(912),stalk_color_above_ringw(43)).
head(id(913),stalk_color_below_ringw(43)).
head(id(914),veil_colorw(43)).
head(id(915),ring_numbero(43)).
head(id(916),cap_shapef(241)).
head(id(917),gill_spacing(241)).
head(id(918),gill_colorw(241)).
head(id(919),stalk_rootr(241)).
head(id(920),stalk_surface_above_rings(241)).
head(id(921),stalk_color_above_ringw(241)).
head(id(922),stalk_color_below_ringw(241)).
head(id(923),veil_colorw(241)).
head(id(924),ring_numbero(241)).
head(id(925),cap_shapex(368)).
head(id(926),cap_surfacef(368)).
head(id(927),gill_size(368)).
head(id(928),gill_colorp(368)).
head(id(929),stalk_rootb(368)).
head(id(930),stalk_surface_above_rings(368)).
head(id(931),stalk_surface_below_rings(368)).
head(id(932),stalk_color_above_ringw(368)).
head(id(933),stalk_color_below_ringw(368)).
head(id(934),veil_colorw(368)).
head(id(935),ring_numbero(368)).
head(id(936),cap_shapex(444)).
head(id(937),cap_colorw(444)).
head(id(938),gill_spacing(444)).
head(id(939),gill_colorn(444)).
head(id(940),stalk_rootc(444)).
head(id(941),stalk_surface_above_rings(444)).
head(id(942),stalk_surface_below_rings(444)).
head(id(943),stalk_color_above_ringw(444)).
head(id(944),stalk_color_below_ringw(444)).
head(id(945),veil_colorw(444)).
head(id(946),ring_numbero(444)).
head(id(947),cap_shapef(164)).
head(id(948),cap_colorn(164)).
head(id(949),gill_spacing(164)).
head(id(950),gill_colorn(164)).
head(id(951),stalk_rootr(164)).
head(id(952),stalk_surface_above_rings(164)).
head(id(953),stalk_color_above_ringw(164)).
head(id(954),stalk_color_below_ringw(164)).
head(id(955),veil_colorw(164)).
head(id(956),ring_numbero(164)).
head(id(957),cap_shapex(191)).
head(id(958),cap_surfacef(191)).
head(id(959),cap_colorw(191)).
head(id(960),gill_colorp(191)).
head(id(961),stalk_roote(191)).
head(id(962),stalk_surface_above_rings(191)).
head(id(963),stalk_surface_below_ringf(191)).
head(id(964),stalk_color_above_ringw(191)).
head(id(965),stalk_color_below_ringw(191)).
head(id(966),veil_colorw(191)).
head(id(967),ring_numbero(191)).
head(id(968),cap_shapex(396)).
head(id(969),cap_surfacef(396)).
head(id(970),cap_colorg(396)).
head(id(971),gill_colorh(396)).
head(id(972),stalk_roote(396)).
head(id(973),stalk_surface_above_ringf(396)).
head(id(974),stalk_surface_below_ringf(396)).
head(id(975),stalk_color_above_ringw(396)).
head(id(976),stalk_color_below_ringw(396)).
head(id(977),veil_colorw(396)).
head(id(978),ring_numbero(396)).
head(id(979),cap_colorw(24)).
head(id(980),gill_spacing(24)).
head(id(981),gill_colorw(24)).
head(id(982),stalk_rootc(24)).
head(id(983),stalk_surface_above_rings(24)).
head(id(984),stalk_surface_below_rings(24)).
head(id(985),stalk_color_above_ringw(24)).
head(id(986),stalk_color_below_ringw(24)).
head(id(987),veil_colorw(24)).
head(id(988),ring_numbero(24)).
head(id(989),cap_colorw(159)).
head(id(990),gill_spacing(159)).
head(id(991),gill_colorn(159)).
head(id(992),stalk_rootc(159)).
head(id(993),stalk_surface_above_rings(159)).
head(id(994),stalk_surface_below_rings(159)).
head(id(995),stalk_color_above_ringw(159)).
head(id(996),stalk_color_below_ringw(159)).
head(id(997),veil_colorw(159)).
head(id(998),ring_numbero(159)).
head(id(999),cap_shapex(425)).
head(id(1000),cap_surfaces(425)).
head(id(1001),cap_colorw(425)).
head(id(1002),gill_spacing(425)).
head(id(1003),gill_colorn(425)).
head(id(1004),stalk_rootc(425)).
head(id(1005),stalk_surface_above_rings(425)).
head(id(1006),stalk_surface_below_rings(425)).
head(id(1007),stalk_color_above_ringw(425)).
head(id(1008),stalk_color_below_ringw(425)).
head(id(1009),veil_colorw(425)).
head(id(1010),ring_numbero(425)).
head(id(1011),cap_shapex(382)).
head(id(1012),cap_surfaces(382)).
head(id(1013),cap_colorw(382)).
head(id(1014),gill_colork(382)).
head(id(1015),stalk_roote(382)).
head(id(1016),stalk_surface_above_ringf(382)).
head(id(1017),stalk_surface_below_rings(382)).
head(id(1018),stalk_color_above_ringw(382)).
head(id(1019),stalk_color_below_ringw(382)).
head(id(1020),veil_colorw(382)).
head(id(1021),ring_numbero(382)).
head(id(1022),cap_shapex(122)).
head(id(1023),cap_colorw(122)).
head(id(1024),gill_spacing(122)).
head(id(1025),gill_colorg(122)).
head(id(1026),stalk_rootc(122)).
head(id(1027),stalk_surface_above_rings(122)).
head(id(1028),stalk_surface_below_rings(122)).
head(id(1029),stalk_color_above_ringw(122)).
head(id(1030),stalk_color_below_ringw(122)).
head(id(1031),veil_colorw(122)).
head(id(1032),ring_numbero(122)).
head(id(1033),cap_shapex(438)).
head(id(1034),cap_colorw(438)).
head(id(1035),gill_spacing(438)).
head(id(1036),gill_colorg(438)).
head(id(1037),stalk_rootc(438)).
head(id(1038),stalk_surface_above_rings(438)).
head(id(1039),stalk_surface_below_rings(438)).
head(id(1040),stalk_color_above_ringw(438)).
head(id(1041),stalk_color_below_ringw(438)).
head(id(1042),veil_colorw(438)).
head(id(1043),ring_numbero(438)).
head(id(1044),gill_spacing(324)).
head(id(1045),gill_colorn(324)).
head(id(1046),stalk_rootc(324)).
head(id(1047),stalk_surface_above_rings(324)).
head(id(1048),stalk_surface_below_rings(324)).
head(id(1049),stalk_color_above_ringw(324)).
head(id(1050),stalk_color_below_ringw(324)).
head(id(1051),veil_colorw(324)).
head(id(1052),ring_numbero(324)).
head(id(1053),cap_shapex(126)).
head(id(1054),cap_surfaces(126)).
head(id(1055),cap_colorw(126)).
head(id(1056),gill_colorn(126)).
head(id(1057),stalk_roote(126)).
head(id(1058),stalk_surface_above_rings(126)).
head(id(1059),stalk_surface_below_ringf(126)).
head(id(1060),stalk_color_above_ringw(126)).
head(id(1061),stalk_color_below_ringw(126)).
head(id(1062),veil_colorw(126)).
head(id(1063),ring_numbero(126)).
head(id(1064),cap_shapef(277)).
head(id(1065),cap_colorn(277)).
head(id(1066),gill_spacing(277)).
head(id(1067),gill_colorw(277)).
head(id(1068),stalk_rootr(277)).
head(id(1069),stalk_surface_above_rings(277)).
head(id(1070),stalk_color_above_ringw(277)).
head(id(1071),stalk_color_below_ringw(277)).
head(id(1072),veil_colorw(277)).
head(id(1073),ring_numbero(277)).
head(id(1074),cap_shapex(111)).
head(id(1075),cap_surfaces(111)).
head(id(1076),gill_spacing(111)).
head(id(1077),gill_colorw(111)).
head(id(1078),stalk_rootc(111)).
head(id(1079),stalk_surface_above_rings(111)).
head(id(1080),stalk_surface_below_rings(111)).
head(id(1081),stalk_color_above_ringw(111)).
head(id(1082),stalk_color_below_ringw(111)).
head(id(1083),veil_colorw(111)).
head(id(1084),ring_numbero(111)).
head(id(1085),cap_shapex(95)).
head(id(1086),cap_surfaces(95)).
head(id(1087),cap_colorn(95)).
head(id(1088),gill_colorn(95)).
head(id(1089),stalk_roote(95)).
head(id(1090),stalk_surface_above_rings(95)).
head(id(1091),stalk_surface_below_rings(95)).
head(id(1092),stalk_color_above_ringw(95)).
head(id(1093),stalk_color_below_ringw(95)).
head(id(1094),veil_colorw(95)).
head(id(1095),ring_numbero(95)).
head(id(1096),cap_shapex(370)).
head(id(1097),cap_surfacef(370)).
head(id(1098),cap_colorg(370)).
head(id(1099),gill_colorn(370)).
head(id(1100),stalk_roote(370)).
head(id(1101),stalk_surface_above_rings(370)).
head(id(1102),stalk_surface_below_rings(370)).
head(id(1103),stalk_color_above_ringw(370)).
head(id(1104),stalk_color_below_ringw(370)).
head(id(1105),veil_colorw(370)).
head(id(1106),ring_numbero(370)).
head(id(1107),cap_shapex(431)).
head(id(1108),cap_colorw(431)).
head(id(1109),gill_spacing(431)).
head(id(1110),gill_colorg(431)).
head(id(1111),stalk_rootc(431)).
head(id(1112),stalk_surface_above_rings(431)).
head(id(1113),stalk_surface_below_rings(431)).
head(id(1114),stalk_color_above_ringw(431)).
head(id(1115),stalk_color_below_ringw(431)).
head(id(1116),veil_colorw(431)).
head(id(1117),ring_numbero(431)).
head(id(1118),cap_shapex(410)).
head(id(1119),cap_colorn(410)).
head(id(1120),gill_spacing(410)).
head(id(1121),gill_colorw(410)).
head(id(1122),stalk_rootr(410)).
head(id(1123),stalk_surface_above_rings(410)).
head(id(1124),stalk_color_above_ringw(410)).
head(id(1125),stalk_color_below_ringw(410)).
head(id(1126),veil_colorw(410)).
head(id(1127),ring_numbero(410)).
head(id(1128),cap_surfaces(522)).
head(id(1129),cap_colorw(522)).
head(id(1130),gill_spacing(522)).
head(id(1131),gill_colorn(522)).
head(id(1132),stalk_rootc(522)).
head(id(1133),stalk_surface_above_rings(522)).
head(id(1134),stalk_surface_below_rings(522)).
head(id(1135),stalk_color_above_ringw(522)).
head(id(1136),stalk_color_below_ringw(522)).
head(id(1137),veil_colorw(522)).
head(id(1138),ring_numbero(522)).
head(id(1139),cap_colorw(304)).
head(id(1140),gill_spacing(304)).
head(id(1141),gill_colorn(304)).
head(id(1142),stalk_rootc(304)).
head(id(1143),stalk_surface_above_rings(304)).
head(id(1144),stalk_surface_below_rings(304)).
head(id(1145),stalk_color_above_ringw(304)).
head(id(1146),stalk_color_below_ringw(304)).
head(id(1147),veil_colorw(304)).
head(id(1148),ring_numbero(304)).
head(id(1149),cap_shapex(412)).
head(id(1150),cap_surfaces(412)).
head(id(1151),cap_colorn(412)).
head(id(1152),gill_colorn(412)).
head(id(1153),stalk_roote(412)).
head(id(1154),stalk_surface_above_ringf(412)).
head(id(1155),stalk_surface_below_ringf(412)).
head(id(1156),stalk_color_above_ringw(412)).
head(id(1157),stalk_color_below_ringw(412)).
head(id(1158),veil_colorw(412)).
head(id(1159),ring_numbero(412)).
head(id(1160),cap_shapex(239)).
head(id(1161),gill_spacing(239)).
head(id(1162),gill_colorn(239)).
head(id(1163),stalk_rootr(239)).
head(id(1164),stalk_surface_above_rings(239)).
head(id(1165),stalk_color_above_ringw(239)).
head(id(1166),stalk_color_below_ringw(239)).
head(id(1167),veil_colorw(239)).
head(id(1168),ring_numbero(239)).
head(id(1169),cap_shapef(133)).
head(id(1170),cap_surfaces(133)).
head(id(1171),cap_colorw(133)).
head(id(1172),gill_size(133)).
head(id(1173),gill_colorw(133)).
head(id(1174),stalk_rootb(133)).
head(id(1175),stalk_surface_above_rings(133)).
head(id(1176),stalk_surface_below_rings(133)).
head(id(1177),stalk_color_above_ringw(133)).
head(id(1178),stalk_color_below_ringw(133)).
head(id(1179),veil_colorw(133)).
head(id(1180),ring_numbero(133)).
head(id(1181),cap_shapex(101)).
head(id(1182),cap_surfacef(101)).
head(id(1183),cap_colorn(101)).
head(id(1184),gill_colorp(101)).
head(id(1185),stalk_roote(101)).
head(id(1186),stalk_surface_above_ringf(101)).
head(id(1187),stalk_surface_below_rings(101)).
head(id(1188),stalk_color_above_ringw(101)).
head(id(1189),stalk_color_below_ringw(101)).
head(id(1190),veil_colorw(101)).
head(id(1191),ring_numbero(101)).
head(id(1192),cap_shapef(485)).
head(id(1193),cap_surfaces(485)).
head(id(1194),cap_colorw(485)).
head(id(1195),gill_size(485)).
head(id(1196),gill_colorw(485)).
head(id(1197),stalk_rootb(485)).
head(id(1198),stalk_surface_above_rings(485)).
head(id(1199),stalk_surface_below_rings(485)).
head(id(1200),stalk_color_above_ringw(485)).
head(id(1201),stalk_color_below_ringw(485)).
head(id(1202),veil_colorw(485)).
head(id(1203),ring_numbero(485)).
head(id(1204),cap_shapes(143)).
head(id(1205),cap_surfacef(143)).
head(id(1206),cap_colorn(143)).
head(id(1207),gill_spacing(143)).
head(id(1208),gill_size(143)).
head(id(1209),gill_colork(143)).
head(id(1210),stalk_roote(143)).
head(id(1211),stalk_surface_above_rings(143)).
head(id(1212),stalk_surface_below_rings(143)).
head(id(1213),stalk_color_above_ringw(143)).
head(id(1214),stalk_color_below_ringw(143)).
head(id(1215),veil_colorw(143)).
head(id(1216),ring_numbero(143)).
head(id(1217),cap_shapex(268)).
head(id(1218),gill_spacing(268)).
head(id(1219),gill_colorg(268)).
head(id(1220),stalk_rootc(268)).
head(id(1221),stalk_surface_above_rings(268)).
head(id(1222),stalk_surface_below_rings(268)).
head(id(1223),stalk_color_above_ringw(268)).
head(id(1224),stalk_color_below_ringw(268)).
head(id(1225),veil_colorw(268)).
head(id(1226),ring_numbero(268)).
head(id(1227),gill_spacing(35)).
head(id(1228),gill_colorn(35)).
head(id(1229),stalk_rootc(35)).
head(id(1230),stalk_surface_above_rings(35)).
head(id(1231),stalk_surface_below_rings(35)).
head(id(1232),stalk_color_above_ringw(35)).
head(id(1233),stalk_color_below_ringw(35)).
head(id(1234),veil_colorw(35)).
head(id(1235),ring_numbero(35)).
head(id(1236),cap_shapef(364)).
head(id(1237),cap_colorn(364)).
head(id(1238),gill_spacing(364)).
head(id(1239),gill_colorn(364)).
head(id(1240),stalk_rootr(364)).
head(id(1241),stalk_surface_above_rings(364)).
head(id(1242),stalk_color_above_ringw(364)).
head(id(1243),stalk_color_below_ringw(364)).
head(id(1244),veil_colorw(364)).
head(id(1245),ring_numbero(364)).
head(id(1246),cap_surfaces(170)).
head(id(1247),cap_colorw(170)).
head(id(1248),gill_spacing(170)).
head(id(1249),gill_colork(170)).
head(id(1250),stalk_rootc(170)).
head(id(1251),stalk_surface_above_rings(170)).
head(id(1252),stalk_surface_below_rings(170)).
head(id(1253),stalk_color_above_ringw(170)).
head(id(1254),stalk_color_below_ringw(170)).
head(id(1255),veil_colorw(170)).
head(id(1256),ring_numbero(170)).
head(id(1257),cap_shapex(118)).
head(id(1258),gill_spacing(118)).
head(id(1259),gill_colorw(118)).
head(id(1260),stalk_rootr(118)).
head(id(1261),stalk_surface_above_rings(118)).
head(id(1262),stalk_color_above_ringw(118)).
head(id(1263),stalk_color_below_ringw(118)).
head(id(1264),veil_colorw(118)).
head(id(1265),ring_numbero(118)).
head(id(1266),cap_shapex(308)).
head(id(1267),cap_surfaces(308)).
head(id(1268),gill_spacing(308)).
head(id(1269),gill_colorg(308)).
head(id(1270),stalk_rootc(308)).
head(id(1271),stalk_surface_above_rings(308)).
head(id(1272),stalk_surface_below_rings(308)).
head(id(1273),stalk_color_above_ringw(308)).
head(id(1274),stalk_color_below_ringw(308)).
head(id(1275),veil_colorw(308)).
head(id(1276),ring_numbero(308)).
head(id(1277),cap_colorw(330)).
head(id(1278),gill_spacing(330)).
head(id(1279),gill_colorg(330)).
head(id(1280),stalk_rootc(330)).
head(id(1281),stalk_surface_above_rings(330)).
head(id(1282),stalk_surface_below_rings(330)).
head(id(1283),stalk_color_above_ringw(330)).
head(id(1284),stalk_color_below_ringw(330)).
head(id(1285),veil_colorw(330)).
head(id(1286),ring_numbero(330)).
head(id(1287),gill_spacing(369)).
head(id(1288),gill_colorg(369)).
head(id(1289),stalk_rootc(369)).
head(id(1290),stalk_surface_above_rings(369)).
head(id(1291),stalk_surface_below_rings(369)).
head(id(1292),stalk_color_above_ringw(369)).
head(id(1293),stalk_color_below_ringw(369)).
head(id(1294),veil_colorw(369)).
head(id(1295),ring_numbero(369)).
head(id(1296),cap_shapex(223)).
head(id(1297),gill_spacing(223)).
head(id(1298),gill_colorn(223)).
head(id(1299),stalk_rootr(223)).
head(id(1300),stalk_surface_above_rings(223)).
head(id(1301),stalk_color_above_ringw(223)).
head(id(1302),stalk_color_below_ringw(223)).
head(id(1303),veil_colorw(223)).
head(id(1304),ring_numbero(223)).
head(id(1305),cap_shapex(443)).
head(id(1306),gill_spacing(443)).
head(id(1307),gill_colorp(443)).
head(id(1308),stalk_rootr(443)).
head(id(1309),stalk_surface_above_rings(443)).
head(id(1310),stalk_color_above_ringw(443)).
head(id(1311),stalk_color_below_ringw(443)).
head(id(1312),veil_colorw(443)).
head(id(1313),ring_numbero(443)).
head(id(1314),cap_surfaces(160)).
head(id(1315),gill_spacing(160)).
head(id(1316),gill_colorg(160)).
head(id(1317),stalk_rootc(160)).
head(id(1318),stalk_surface_above_rings(160)).
head(id(1319),stalk_surface_below_rings(160)).
head(id(1320),stalk_color_above_ringw(160)).
head(id(1321),stalk_color_below_ringw(160)).
head(id(1322),veil_colorw(160)).
head(id(1323),ring_numbero(160)).
head(id(1324),cap_surfaces(180)).
head(id(1325),gill_spacing(180)).
head(id(1326),gill_colorg(180)).
head(id(1327),stalk_rootc(180)).
head(id(1328),stalk_surface_above_rings(180)).
head(id(1329),stalk_surface_below_rings(180)).
head(id(1330),stalk_color_above_ringw(180)).
head(id(1331),stalk_color_below_ringw(180)).
head(id(1332),veil_colorw(180)).
head(id(1333),ring_numbero(180)).
head(id(1334),cap_shapex(419)).
head(id(1335),gill_spacing(419)).
head(id(1336),gill_colork(419)).
head(id(1337),stalk_rootc(419)).
head(id(1338),stalk_surface_above_rings(419)).
head(id(1339),stalk_surface_below_rings(419)).
head(id(1340),stalk_color_above_ringw(419)).
head(id(1341),stalk_color_below_ringw(419)).
head(id(1342),veil_colorw(419)).
head(id(1343),ring_numbero(419)).
head(id(1344),cap_shapes(61)).
head(id(1345),cap_surfacef(61)).
head(id(1346),cap_colorg(61)).
head(id(1347),gill_spacing(61)).
head(id(1348),gill_size(61)).
head(id(1349),gill_colork(61)).
head(id(1350),stalk_roote(61)).
head(id(1351),stalk_surface_above_rings(61)).
head(id(1352),stalk_surface_below_rings(61)).
head(id(1353),stalk_color_above_ringw(61)).
head(id(1354),stalk_color_below_ringw(61)).
head(id(1355),veil_colorw(61)).
head(id(1356),ring_numbero(61)).
head(id(1357),cap_shapes(283)).
head(id(1358),cap_surfacef(283)).
head(id(1359),cap_colorn(283)).
head(id(1360),gill_spacing(283)).
head(id(1361),gill_size(283)).
head(id(1362),gill_colorp(283)).
head(id(1363),stalk_roote(283)).
head(id(1364),stalk_surface_above_rings(283)).
head(id(1365),stalk_surface_below_rings(283)).
head(id(1366),stalk_color_above_ringw(283)).
head(id(1367),stalk_color_below_ringw(283)).
head(id(1368),veil_colorw(283)).
head(id(1369),ring_numbero(283)).
head(id(1370),cap_shapex(313)).
head(id(1371),gill_spacing(313)).
head(id(1372),gill_colorn(313)).
head(id(1373),stalk_rootc(313)).
head(id(1374),stalk_surface_above_rings(313)).
head(id(1375),stalk_surface_below_rings(313)).
head(id(1376),stalk_color_above_ringw(313)).
head(id(1377),stalk_color_below_ringw(313)).
head(id(1378),veil_colorw(313)).
head(id(1379),ring_numbero(313)).
head(id(1380),cap_shapex(184)).
head(id(1381),cap_surfaces(184)).
head(id(1382),gill_spacing(184)).
head(id(1383),gill_colorg(184)).
head(id(1384),stalk_rootc(184)).
head(id(1385),stalk_surface_above_rings(184)).
head(id(1386),stalk_surface_below_rings(184)).
head(id(1387),stalk_color_above_ringw(184)).
head(id(1388),stalk_color_below_ringw(184)).
head(id(1389),veil_colorw(184)).
head(id(1390),ring_numbero(184)).
head(id(1391),cap_shapef(448)).
head(id(1392),cap_colorn(448)).
head(id(1393),gill_spacing(448)).
head(id(1394),gill_colorn(448)).
head(id(1395),stalk_rootr(448)).
head(id(1396),stalk_surface_above_rings(448)).
head(id(1397),stalk_color_above_ringw(448)).
head(id(1398),stalk_color_below_ringw(448)).
head(id(1399),veil_colorw(448)).
head(id(1400),ring_numbero(448)).
head(id(1401),cap_shapex(447)).
head(id(1402),cap_surfaces(447)).
head(id(1403),cap_colorw(447)).
head(id(1404),gill_spacing(447)).
head(id(1405),gill_colorn(447)).
head(id(1406),stalk_rootc(447)).
head(id(1407),stalk_surface_above_rings(447)).
head(id(1408),stalk_surface_below_rings(447)).
head(id(1409),stalk_color_above_ringw(447)).
head(id(1410),stalk_color_below_ringw(447)).
head(id(1411),veil_colorw(447)).
head(id(1412),ring_numbero(447)).
head(id(1413),cap_shapex(70)).
head(id(1414),cap_surfacef(70)).
head(id(1415),cap_colorg(70)).
head(id(1416),gill_spacing(70)).
head(id(1417),gill_size(70)).
head(id(1418),gill_colorp(70)).
head(id(1419),stalk_roote(70)).
head(id(1420),stalk_surface_above_rings(70)).
head(id(1421),stalk_surface_below_rings(70)).
head(id(1422),stalk_color_above_ringw(70)).
head(id(1423),stalk_color_below_ringw(70)).
head(id(1424),veil_colorw(70)).
head(id(1425),ring_numbero(70)).
head(id(1426),cap_shapex(387)).
head(id(1427),cap_colorn(387)).
head(id(1428),gill_spacing(387)).
head(id(1429),gill_colorw(387)).
head(id(1430),stalk_rootr(387)).
head(id(1431),stalk_surface_above_rings(387)).
head(id(1432),stalk_color_above_ringw(387)).
head(id(1433),stalk_color_below_ringw(387)).
head(id(1434),veil_colorw(387)).
head(id(1435),ring_numbero(387)).
head(id(1436),cap_shapex(503)).
head(id(1437),cap_surfaces(503)).
head(id(1438),cap_colorw(503)).
head(id(1439),gill_spacing(503)).
head(id(1440),gill_colorg(503)).
head(id(1441),stalk_rootc(503)).
head(id(1442),stalk_surface_above_rings(503)).
head(id(1443),stalk_surface_below_rings(503)).
head(id(1444),stalk_color_above_ringw(503)).
head(id(1445),stalk_color_below_ringw(503)).
head(id(1446),veil_colorw(503)).
head(id(1447),ring_numbero(503)).
head(id(1448),cap_shapex(461)).
head(id(1449),cap_surfaces(461)).
head(id(1450),cap_colorw(461)).
head(id(1451),gill_spacing(461)).
head(id(1452),gill_colork(461)).
head(id(1453),stalk_rootc(461)).
head(id(1454),stalk_surface_above_rings(461)).
head(id(1455),stalk_surface_below_rings(461)).
head(id(1456),stalk_color_above_ringw(461)).
head(id(1457),stalk_color_below_ringw(461)).
head(id(1458),veil_colorw(461)).
head(id(1459),ring_numbero(461)).
head(id(1460),cap_surfaces(391)).
head(id(1461),gill_spacing(391)).
head(id(1462),gill_colorn(391)).
head(id(1463),stalk_rootc(391)).
head(id(1464),stalk_surface_above_rings(391)).
head(id(1465),stalk_surface_below_rings(391)).
head(id(1466),stalk_color_above_ringw(391)).
head(id(1467),stalk_color_below_ringw(391)).
head(id(1468),veil_colorw(391)).
head(id(1469),ring_numbero(391)).
head(id(1470),cap_shapef(424)).
head(id(1471),cap_colorn(424)).
head(id(1472),gill_spacing(424)).
head(id(1473),gill_colorw(424)).
head(id(1474),stalk_rootr(424)).
head(id(1475),stalk_surface_above_rings(424)).
head(id(1476),stalk_color_above_ringw(424)).
head(id(1477),stalk_color_below_ringw(424)).
head(id(1478),veil_colorw(424)).
head(id(1479),ring_numbero(424)).
head(id(1480),cap_shapex(417)).
head(id(1481),cap_surfacef(417)).
head(id(1482),cap_colorw(417)).
head(id(1483),gill_size(417)).
head(id(1484),gill_colorp(417)).
head(id(1485),stalk_rootb(417)).
head(id(1486),stalk_surface_above_rings(417)).
head(id(1487),stalk_surface_below_rings(417)).
head(id(1488),stalk_color_above_ringw(417)).
head(id(1489),stalk_color_below_ringw(417)).
head(id(1490),veil_colorw(417)).
head(id(1491),ring_numbero(417)).
head(id(1492),cap_shapes(16)).
head(id(1493),cap_surfacef(16)).
head(id(1494),cap_colorg(16)).
head(id(1495),gill_spacing(16)).
head(id(1496),gill_size(16)).
head(id(1497),gill_colork(16)).
head(id(1498),stalk_roote(16)).
head(id(1499),stalk_surface_above_rings(16)).
head(id(1500),stalk_surface_below_rings(16)).
head(id(1501),stalk_color_above_ringw(16)).
head(id(1502),stalk_color_below_ringw(16)).
head(id(1503),veil_colorw(16)).
head(id(1504),ring_numbero(16)).
head(id(1505),cap_shapex(441)).
head(id(1506),cap_colorw(441)).
head(id(1507),gill_spacing(441)).
head(id(1508),gill_colorn(441)).
head(id(1509),stalk_rootc(441)).
head(id(1510),stalk_surface_above_rings(441)).
head(id(1511),stalk_surface_below_rings(441)).
head(id(1512),stalk_color_above_ringw(441)).
head(id(1513),stalk_color_below_ringw(441)).
head(id(1514),veil_colorw(441)).
head(id(1515),ring_numbero(441)).
head(id(1516),cap_shapef(309)).
head(id(1517),cap_colorn(309)).
head(id(1518),gill_spacing(309)).
head(id(1519),gill_colorp(309)).
head(id(1520),stalk_rootr(309)).
head(id(1521),stalk_surface_above_rings(309)).
head(id(1522),stalk_color_above_ringw(309)).
head(id(1523),stalk_color_below_ringw(309)).
head(id(1524),veil_colorw(309)).
head(id(1525),ring_numbero(309)).
head(id(1526),cap_surfaces(526)).
head(id(1527),gill_spacing(526)).
head(id(1528),gill_colorw(526)).
head(id(1529),stalk_rootc(526)).
head(id(1530),stalk_surface_above_rings(526)).
head(id(1531),stalk_surface_below_rings(526)).
head(id(1532),stalk_color_above_ringw(526)).
head(id(1533),stalk_color_below_ringw(526)).
head(id(1534),veil_colorw(526)).
head(id(1535),ring_numbero(526)).
head(id(1536),cap_shapex(163)).
head(id(1537),cap_surfacef(163)).
head(id(1538),cap_colorn(163)).
head(id(1539),gill_spacing(163)).
head(id(1540),gill_size(163)).
head(id(1541),gill_colork(163)).
head(id(1542),stalk_roote(163)).
head(id(1543),stalk_surface_above_rings(163)).
head(id(1544),stalk_surface_below_rings(163)).
head(id(1545),stalk_color_above_ringw(163)).
head(id(1546),stalk_color_below_ringw(163)).
head(id(1547),veil_colorw(163)).
head(id(1548),ring_numbero(163)).
head(id(1549),cap_surfaces(208)).
head(id(1550),cap_colorw(208)).
head(id(1551),gill_spacing(208)).
head(id(1552),gill_colork(208)).
head(id(1553),stalk_rootc(208)).
head(id(1554),stalk_surface_above_rings(208)).
head(id(1555),stalk_surface_below_rings(208)).
head(id(1556),stalk_color_above_ringw(208)).
head(id(1557),stalk_color_below_ringw(208)).
head(id(1558),veil_colorw(208)).
head(id(1559),ring_numbero(208)).
head(id(1560),cap_shapex(517)).
head(id(1561),cap_colorn(517)).
head(id(1562),gill_spacing(517)).
head(id(1563),gill_colorn(517)).
head(id(1564),stalk_rootr(517)).
head(id(1565),stalk_surface_above_rings(517)).
head(id(1566),stalk_color_above_ringw(517)).
head(id(1567),stalk_color_below_ringw(517)).
head(id(1568),veil_colorw(517)).
head(id(1569),ring_numbero(517)).
head(id(1570),cap_shapex(227)).
head(id(1571),cap_surfaces(227)).
head(id(1572),cap_colorw(227)).
head(id(1573),gill_spacing(227)).
head(id(1574),gill_colorg(227)).
head(id(1575),stalk_rootc(227)).
head(id(1576),stalk_surface_above_rings(227)).
head(id(1577),stalk_surface_below_rings(227)).
head(id(1578),stalk_color_above_ringw(227)).
head(id(1579),stalk_color_below_ringw(227)).
head(id(1580),veil_colorw(227)).
head(id(1581),ring_numbero(227)).
head(id(1582),cap_shapef(470)).
head(id(1583),gill_spacing(470)).
head(id(1584),gill_colorw(470)).
head(id(1585),stalk_rootr(470)).
head(id(1586),stalk_surface_above_rings(470)).
head(id(1587),stalk_color_above_ringw(470)).
head(id(1588),stalk_color_below_ringw(470)).
head(id(1589),veil_colorw(470)).
head(id(1590),ring_numbero(470)).
head(id(1591),cap_shapef(175)).
head(id(1592),gill_spacing(175)).
head(id(1593),gill_colorp(175)).
head(id(1594),stalk_rootr(175)).
head(id(1595),stalk_surface_above_rings(175)).
head(id(1596),stalk_color_above_ringw(175)).
head(id(1597),stalk_color_below_ringw(175)).
head(id(1598),veil_colorw(175)).
head(id(1599),ring_numbero(175)).
head(id(1600),cap_surfaces(13)).
head(id(1601),gill_spacing(13)).
head(id(1602),gill_colorw(13)).
head(id(1603),stalk_rootc(13)).
head(id(1604),stalk_surface_above_rings(13)).
head(id(1605),stalk_surface_below_rings(13)).
head(id(1606),stalk_color_above_ringw(13)).
head(id(1607),stalk_color_below_ringw(13)).
head(id(1608),veil_colorw(13)).
head(id(1609),ring_numbero(13)).
head(id(1610),cap_shapex(360)).
head(id(1611),gill_spacing(360)).
head(id(1612),gill_colorw(360)).
head(id(1613),stalk_rootc(360)).
head(id(1614),stalk_surface_above_rings(360)).
head(id(1615),stalk_surface_below_rings(360)).
head(id(1616),stalk_color_above_ringw(360)).
head(id(1617),stalk_color_below_ringw(360)).
head(id(1618),veil_colorw(360)).
head(id(1619),ring_numbero(360)).
head(id(1620),cap_shapex(429)).
head(id(1621),cap_surfaces(429)).
head(id(1622),cap_colorw(429)).
head(id(1623),gill_colorp(429)).
head(id(1624),stalk_roote(429)).
head(id(1625),stalk_surface_above_ringf(429)).
head(id(1626),stalk_surface_below_ringf(429)).
head(id(1627),stalk_color_above_ringw(429)).
head(id(1628),stalk_color_below_ringw(429)).
head(id(1629),veil_colorw(429)).
head(id(1630),ring_numbero(429)).
head(id(1631),gill_spacing(333)).
head(id(1632),gill_colorw(333)).
head(id(1633),stalk_rootc(333)).
head(id(1634),stalk_surface_above_rings(333)).
head(id(1635),stalk_surface_below_rings(333)).
head(id(1636),stalk_color_above_ringw(333)).
head(id(1637),stalk_color_below_ringw(333)).
head(id(1638),veil_colorw(333)).
head(id(1639),ring_numbero(333)).
head(id(1640),cap_shapef(462)).
head(id(1641),gill_spacing(462)).
head(id(1642),gill_colorn(462)).
head(id(1643),stalk_rootr(462)).
head(id(1644),stalk_surface_above_rings(462)).
head(id(1645),stalk_color_above_ringw(462)).
head(id(1646),stalk_color_below_ringw(462)).
head(id(1647),veil_colorw(462)).
head(id(1648),ring_numbero(462)).
head(id(1649),cap_shapes(120)).
head(id(1650),cap_surfacef(120)).
head(id(1651),cap_colorn(120)).
head(id(1652),gill_spacing(120)).
head(id(1653),gill_size(120)).
head(id(1654),gill_colork(120)).
head(id(1655),stalk_roote(120)).
head(id(1656),stalk_surface_above_rings(120)).
head(id(1657),stalk_surface_below_rings(120)).
head(id(1658),stalk_color_above_ringw(120)).
head(id(1659),stalk_color_below_ringw(120)).
head(id(1660),veil_colorw(120)).
head(id(1661),ring_numbero(120)).
head(id(1662),cap_shapex(59)).
head(id(1663),cap_surfaces(59)).
head(id(1664),gill_spacing(59)).
head(id(1665),gill_colork(59)).
head(id(1666),stalk_rootc(59)).
head(id(1667),stalk_surface_above_rings(59)).
head(id(1668),stalk_surface_below_rings(59)).
head(id(1669),stalk_color_above_ringw(59)).
head(id(1670),stalk_color_below_ringw(59)).
head(id(1671),veil_colorw(59)).
head(id(1672),ring_numbero(59)).
head(id(1673),cap_shapex(15)).
head(id(1674),cap_surfacef(15)).
head(id(1675),cap_colorn(15)).
head(id(1676),gill_colorn(15)).
head(id(1677),stalk_roote(15)).
head(id(1678),stalk_surface_above_rings(15)).
head(id(1679),stalk_surface_below_ringf(15)).
head(id(1680),stalk_color_above_ringw(15)).
head(id(1681),stalk_color_below_ringw(15)).
head(id(1682),veil_colorw(15)).
head(id(1683),ring_numbero(15)).
head(id(1684),cap_shapex(211)).
head(id(1685),cap_surfaces(211)).
head(id(1686),gill_spacing(211)).
head(id(1687),gill_colorw(211)).
head(id(1688),stalk_rootc(211)).
head(id(1689),stalk_surface_above_rings(211)).
head(id(1690),stalk_surface_below_rings(211)).
head(id(1691),stalk_color_above_ringw(211)).
head(id(1692),stalk_color_below_ringw(211)).
head(id(1693),veil_colorw(211)).
head(id(1694),ring_numbero(211)).
head(id(1695),cap_surfaces(433)).
head(id(1696),gill_spacing(433)).
head(id(1697),gill_colorg(433)).
head(id(1698),stalk_rootc(433)).
head(id(1699),stalk_surface_above_rings(433)).
head(id(1700),stalk_surface_below_rings(433)).
head(id(1701),stalk_color_above_ringw(433)).
head(id(1702),stalk_color_below_ringw(433)).
head(id(1703),veil_colorw(433)).
head(id(1704),ring_numbero(433)).
head(id(1705),cap_shapex(520)).
head(id(1706),gill_spacing(520)).
head(id(1707),gill_colork(520)).
head(id(1708),stalk_rootc(520)).
head(id(1709),stalk_surface_above_rings(520)).
head(id(1710),stalk_surface_below_rings(520)).
head(id(1711),stalk_color_above_ringw(520)).
head(id(1712),stalk_color_below_ringw(520)).
head(id(1713),veil_colorw(520)).
head(id(1714),ring_numbero(520)).
head(id(1715),cap_shapex(69)).
head(id(1716),gill_spacing(69)).
head(id(1717),gill_colorw(69)).
head(id(1718),stalk_rootc(69)).
head(id(1719),stalk_surface_above_rings(69)).
head(id(1720),stalk_surface_below_rings(69)).
head(id(1721),stalk_color_above_ringw(69)).
head(id(1722),stalk_color_below_ringw(69)).
head(id(1723),veil_colorw(69)).
head(id(1724),ring_numbero(69)).
head(id(1725),cap_colorw(302)).
head(id(1726),gill_spacing(302)).
head(id(1727),gill_colorw(302)).
head(id(1728),stalk_rootc(302)).
head(id(1729),stalk_surface_above_rings(302)).
head(id(1730),stalk_surface_below_rings(302)).
head(id(1731),stalk_color_above_ringw(302)).
head(id(1732),stalk_color_below_ringw(302)).
head(id(1733),veil_colorw(302)).
head(id(1734),ring_numbero(302)).
head(id(1735),gill_spacing(23)).
head(id(1736),gill_colork(23)).
head(id(1737),stalk_rootc(23)).
head(id(1738),stalk_surface_above_rings(23)).
head(id(1739),stalk_surface_below_rings(23)).
head(id(1740),stalk_color_above_ringw(23)).
head(id(1741),stalk_color_below_ringw(23)).
head(id(1742),veil_colorw(23)).
head(id(1743),ring_numbero(23)).
head(id(1744),cap_shapef(29)).
head(id(1745),cap_surfacef(29)).
head(id(1746),cap_colorn(29)).
head(id(1747),gill_spacing(29)).
head(id(1748),gill_size(29)).
head(id(1749),gill_colork(29)).
head(id(1750),stalk_roote(29)).
head(id(1751),stalk_surface_above_rings(29)).
head(id(1752),stalk_surface_below_rings(29)).
head(id(1753),stalk_color_above_ringw(29)).
head(id(1754),stalk_color_below_ringw(29)).
head(id(1755),veil_colorw(29)).
head(id(1756),ring_numbero(29)).
head(id(1757),cap_shapex(152)).
head(id(1758),cap_surfaces(152)).
head(id(1759),cap_colorn(152)).
head(id(1760),gill_colorp(152)).
head(id(1761),stalk_roote(152)).
head(id(1762),stalk_surface_above_ringf(152)).
head(id(1763),stalk_surface_below_rings(152)).
head(id(1764),stalk_color_above_ringw(152)).
head(id(1765),stalk_color_below_ringw(152)).
head(id(1766),veil_colorw(152)).
head(id(1767),ring_numbero(152)).
head(id(1768),cap_shapef(349)).
head(id(1769),cap_surfaces(349)).
head(id(1770),cap_colorg(349)).
head(id(1771),gill_colorn(349)).
head(id(1772),stalk_roote(349)).
head(id(1773),stalk_surface_above_rings(349)).
head(id(1774),stalk_surface_below_ringf(349)).
head(id(1775),stalk_color_above_ringw(349)).
head(id(1776),stalk_color_below_ringw(349)).
head(id(1777),veil_colorw(349)).
head(id(1778),ring_numbero(349)).
head(id(1779),cap_shapex(348)).
head(id(1780),cap_surfaces(348)).
head(id(1781),gill_spacing(348)).
head(id(1782),gill_colorn(348)).
head(id(1783),stalk_rootc(348)).
head(id(1784),stalk_surface_above_rings(348)).
head(id(1785),stalk_surface_below_rings(348)).
head(id(1786),stalk_color_above_ringw(348)).
head(id(1787),stalk_color_below_ringw(348)).
head(id(1788),veil_colorw(348)).
head(id(1789),ring_numbero(348)).
head(id(1790),cap_shapef(68)).
head(id(1791),gill_spacing(68)).
head(id(1792),gill_colorw(68)).
head(id(1793),stalk_rootr(68)).
head(id(1794),stalk_surface_above_rings(68)).
head(id(1795),stalk_color_above_ringw(68)).
head(id(1796),stalk_color_below_ringw(68)).
head(id(1797),veil_colorw(68)).
head(id(1798),ring_numbero(68)).
head(id(1799),cap_shapex(138)).
head(id(1800),gill_spacing(138)).
head(id(1801),gill_colorn(138)).
head(id(1802),stalk_rootc(138)).
head(id(1803),stalk_surface_above_rings(138)).
head(id(1804),stalk_surface_below_rings(138)).
head(id(1805),stalk_color_above_ringw(138)).
head(id(1806),stalk_color_below_ringw(138)).
head(id(1807),veil_colorw(138)).
head(id(1808),ring_numbero(138)).
head(id(1809),cap_shapex(327)).
head(id(1810),cap_surfaces(327)).
head(id(1811),gill_spacing(327)).
head(id(1812),gill_colorn(327)).
head(id(1813),stalk_rootc(327)).
head(id(1814),stalk_surface_above_rings(327)).
head(id(1815),stalk_surface_below_rings(327)).
head(id(1816),stalk_color_above_ringw(327)).
head(id(1817),stalk_color_below_ringw(327)).
head(id(1818),veil_colorw(327)).
head(id(1819),ring_numbero(327)).
head(id(1820),cap_shapex(399)).
head(id(1821),cap_surfacef(399)).
head(id(1822),cap_colorg(399)).
head(id(1823),gill_spacing(399)).
head(id(1824),gill_size(399)).
head(id(1825),gill_colorn(399)).
head(id(1826),stalk_roote(399)).
head(id(1827),stalk_surface_above_rings(399)).
head(id(1828),stalk_surface_below_rings(399)).
head(id(1829),stalk_color_above_ringw(399)).
head(id(1830),stalk_color_below_ringw(399)).
head(id(1831),veil_colorw(399)).
head(id(1832),ring_numbero(399)).
head(id(1833),cap_shapex(310)).
head(id(1834),cap_surfacef(310)).
head(id(1835),cap_colorw(310)).
head(id(1836),gill_colorn(310)).
head(id(1837),stalk_roote(310)).
head(id(1838),stalk_surface_above_rings(310)).
head(id(1839),stalk_surface_below_rings(310)).
head(id(1840),stalk_color_above_ringw(310)).
head(id(1841),stalk_color_below_ringw(310)).
head(id(1842),veil_colorw(310)).
head(id(1843),ring_numbero(310)).
head(id(1844),cap_shapex(365)).
head(id(1845),cap_surfaces(365)).
head(id(1846),gill_spacing(365)).
head(id(1847),gill_colorw(365)).
head(id(1848),stalk_rootc(365)).
head(id(1849),stalk_surface_above_rings(365)).
head(id(1850),stalk_surface_below_rings(365)).
head(id(1851),stalk_color_above_ringw(365)).
head(id(1852),stalk_color_below_ringw(365)).
head(id(1853),veil_colorw(365)).
head(id(1854),ring_numbero(365)).
head(id(1855),cap_shapef(534)).
head(id(1856),cap_colorn(534)).
head(id(1857),gill_spacing(534)).
head(id(1858),gill_colorw(534)).
head(id(1859),stalk_rootr(534)).
head(id(1860),stalk_surface_above_rings(534)).
head(id(1861),stalk_color_above_ringw(534)).
head(id(1862),stalk_color_below_ringw(534)).
head(id(1863),veil_colorw(534)).
head(id(1864),ring_numbero(534)).
head(id(1865),cap_shapex(487)).
head(id(1866),cap_colorw(487)).
head(id(1867),gill_spacing(487)).
head(id(1868),gill_colorw(487)).
head(id(1869),stalk_rootc(487)).
head(id(1870),stalk_surface_above_rings(487)).
head(id(1871),stalk_surface_below_rings(487)).
head(id(1872),stalk_color_above_ringw(487)).
head(id(1873),stalk_color_below_ringw(487)).
head(id(1874),veil_colorw(487)).
head(id(1875),ring_numbero(487)).
head(id(1876),cap_shapex(12)).
head(id(1877),gill_spacing(12)).
head(id(1878),gill_colorn(12)).
head(id(1879),stalk_rootc(12)).
head(id(1880),stalk_surface_above_rings(12)).
head(id(1881),stalk_surface_below_rings(12)).
head(id(1882),stalk_color_above_ringw(12)).
head(id(1883),stalk_color_below_ringw(12)).
head(id(1884),veil_colorw(12)).
head(id(1885),ring_numbero(12)).
head(id(1886),cap_colorw(177)).
head(id(1887),gill_spacing(177)).
head(id(1888),gill_colork(177)).
head(id(1889),stalk_rootc(177)).
head(id(1890),stalk_surface_above_rings(177)).
head(id(1891),stalk_surface_below_rings(177)).
head(id(1892),stalk_color_above_ringw(177)).
head(id(1893),stalk_color_below_ringw(177)).
head(id(1894),veil_colorw(177)).
head(id(1895),ring_numbero(177)).
head(id(1896),cap_shapex(225)).
head(id(1897),cap_colorw(225)).
head(id(1898),gill_spacing(225)).
head(id(1899),gill_colorg(225)).
head(id(1900),stalk_rootc(225)).
head(id(1901),stalk_surface_above_rings(225)).
head(id(1902),stalk_surface_below_rings(225)).
head(id(1903),stalk_color_above_ringw(225)).
head(id(1904),stalk_color_below_ringw(225)).
head(id(1905),veil_colorw(225)).
head(id(1906),ring_numbero(225)).
head(id(1907),cap_shapex(437)).
head(id(1908),cap_surfacef(437)).
head(id(1909),gill_size(437)).
head(id(1910),gill_colorn(437)).
head(id(1911),stalk_rootb(437)).
head(id(1912),stalk_surface_above_rings(437)).
head(id(1913),stalk_surface_below_rings(437)).
head(id(1914),stalk_color_above_ringw(437)).
head(id(1915),stalk_color_below_ringw(437)).
head(id(1916),veil_colorw(437)).
head(id(1917),ring_numbero(437)).
head(id(1918),gill_spacing(480)).
head(id(1919),gill_colorn(480)).
head(id(1920),stalk_rootc(480)).
head(id(1921),stalk_surface_above_rings(480)).
head(id(1922),stalk_surface_below_rings(480)).
head(id(1923),stalk_color_above_ringw(480)).
head(id(1924),stalk_color_below_ringw(480)).
head(id(1925),veil_colorw(480)).
head(id(1926),ring_numbero(480)).
head(id(1927),cap_shapef(83)).
head(id(1928),cap_surfacef(83)).
head(id(1929),cap_colorg(83)).
head(id(1930),gill_spacing(83)).
head(id(1931),gill_size(83)).
head(id(1932),gill_colorn(83)).
head(id(1933),stalk_roote(83)).
head(id(1934),stalk_surface_above_rings(83)).
head(id(1935),stalk_surface_below_rings(83)).
head(id(1936),stalk_color_above_ringw(83)).
head(id(1937),stalk_color_below_ringw(83)).
head(id(1938),veil_colorw(83)).
head(id(1939),ring_numbero(83)).
head(id(1940),cap_shapex(477)).
head(id(1941),cap_surfacef(477)).
head(id(1942),cap_colorn(477)).
head(id(1943),gill_spacing(477)).
head(id(1944),gill_size(477)).
head(id(1945),gill_colorp(477)).
head(id(1946),stalk_roote(477)).
head(id(1947),stalk_surface_above_rings(477)).
head(id(1948),stalk_surface_below_rings(477)).
head(id(1949),stalk_color_above_ringw(477)).
head(id(1950),stalk_color_below_ringw(477)).
head(id(1951),veil_colorw(477)).
head(id(1952),ring_numbero(477)).
head(id(1953),cap_shapex(171)).
head(id(1954),cap_surfacef(171)).
head(id(1955),cap_colorg(171)).
head(id(1956),gill_spacing(171)).
head(id(1957),gill_size(171)).
head(id(1958),gill_colorg(171)).
head(id(1959),stalk_roote(171)).
head(id(1960),stalk_surface_above_rings(171)).
head(id(1961),stalk_surface_below_rings(171)).
head(id(1962),stalk_color_above_ringw(171)).
head(id(1963),stalk_color_below_ringw(171)).
head(id(1964),veil_colorw(171)).
head(id(1965),ring_numbero(171)).
head(id(1966),cap_shapex(219)).
head(id(1967),cap_colorw(219)).
head(id(1968),gill_spacing(219)).
head(id(1969),gill_colorw(219)).
head(id(1970),stalk_rootc(219)).
head(id(1971),stalk_surface_above_rings(219)).
head(id(1972),stalk_surface_below_rings(219)).
head(id(1973),stalk_color_above_ringw(219)).
head(id(1974),stalk_color_below_ringw(219)).
head(id(1975),veil_colorw(219)).
head(id(1976),ring_numbero(219)).
head(id(1977),cap_shapex(456)).
head(id(1978),cap_surfaces(456)).
head(id(1979),cap_colorg(456)).
head(id(1980),gill_colorh(456)).
head(id(1981),stalk_roote(456)).
head(id(1982),stalk_surface_above_rings(456)).
head(id(1983),stalk_surface_below_ringf(456)).
head(id(1984),stalk_color_above_ringw(456)).
head(id(1985),stalk_color_below_ringw(456)).
head(id(1986),veil_colorw(456)).
head(id(1987),ring_numbero(456)).
head(id(1988),cap_shapex(247)).
head(id(1989),cap_surfaces(247)).
head(id(1990),cap_colorw(247)).
head(id(1991),gill_size(247)).
head(id(1992),gill_colorp(247)).
head(id(1993),stalk_rootb(247)).
head(id(1994),stalk_surface_above_rings(247)).
head(id(1995),stalk_surface_below_rings(247)).
head(id(1996),stalk_color_above_ringw(247)).
head(id(1997),stalk_color_below_ringw(247)).
head(id(1998),veil_colorw(247)).
head(id(1999),ring_numbero(247)).
head(id(2000),cap_shapex(258)).
head(id(2001),cap_surfaces(258)).
head(id(2002),cap_colorw(258)).
head(id(2003),gill_spacing(258)).
head(id(2004),gill_colorw(258)).
head(id(2005),stalk_rootc(258)).
head(id(2006),stalk_surface_above_rings(258)).
head(id(2007),stalk_surface_below_rings(258)).
head(id(2008),stalk_color_above_ringw(258)).
head(id(2009),stalk_color_below_ringw(258)).
head(id(2010),veil_colorw(258)).
head(id(2011),ring_numbero(258)).
head(id(2012),cap_shapex(125)).
head(id(2013),cap_surfaces(125)).
head(id(2014),gill_spacing(125)).
head(id(2015),gill_colorg(125)).
head(id(2016),stalk_rootc(125)).
head(id(2017),stalk_surface_above_rings(125)).
head(id(2018),stalk_surface_below_rings(125)).
head(id(2019),stalk_color_above_ringw(125)).
head(id(2020),stalk_color_below_ringw(125)).
head(id(2021),veil_colorw(125)).
head(id(2022),ring_numbero(125)).
head(id(2023),cap_shapef(476)).
head(id(2024),cap_surfacef(476)).
head(id(2025),cap_colorg(476)).
head(id(2026),gill_spacing(476)).
head(id(2027),gill_size(476)).
head(id(2028),gill_colork(476)).
head(id(2029),stalk_roote(476)).
head(id(2030),stalk_surface_above_rings(476)).
head(id(2031),stalk_surface_below_rings(476)).
head(id(2032),stalk_color_above_ringw(476)).
head(id(2033),stalk_color_below_ringw(476)).
head(id(2034),veil_colorw(476)).
head(id(2035),ring_numbero(476)).
head(id(2036),cap_shapex(11)).
head(id(2037),gill_spacing(11)).
head(id(2038),gill_colorg(11)).
head(id(2039),stalk_rootc(11)).
head(id(2040),stalk_surface_above_rings(11)).
head(id(2041),stalk_surface_below_rings(11)).
head(id(2042),stalk_color_above_ringw(11)).
head(id(2043),stalk_color_below_ringw(11)).
head(id(2044),veil_colorw(11)).
head(id(2045),ring_numbero(11)).
head(id(2046),cap_shapex(86)).
head(id(2047),cap_surfaces(86)).
head(id(2048),cap_colorn(86)).
head(id(2049),gill_colork(86)).
head(id(2050),stalk_roote(86)).
head(id(2051),stalk_surface_above_rings(86)).
head(id(2052),stalk_surface_below_rings(86)).
head(id(2053),stalk_color_above_ringw(86)).
head(id(2054),stalk_color_below_ringw(86)).
head(id(2055),veil_colorw(86)).
head(id(2056),ring_numbero(86)).
head(id(2057),cap_shapex(214)).
head(id(2058),cap_surfacef(214)).
head(id(2059),cap_colorg(214)).
head(id(2060),gill_spacing(214)).
head(id(2061),gill_size(214)).
head(id(2062),gill_colorn(214)).
head(id(2063),stalk_roote(214)).
head(id(2064),stalk_surface_above_rings(214)).
head(id(2065),stalk_surface_below_rings(214)).
head(id(2066),stalk_color_above_ringw(214)).
head(id(2067),stalk_color_below_ringw(214)).
head(id(2068),veil_colorw(214)).
head(id(2069),ring_numbero(214)).
head(id(2070),cap_shapex(81)).
head(id(2071),cap_surfaces(81)).
head(id(2072),cap_colorn(81)).
head(id(2073),gill_colork(81)).
head(id(2074),stalk_roote(81)).
head(id(2075),stalk_surface_above_ringf(81)).
head(id(2076),stalk_surface_below_rings(81)).
head(id(2077),stalk_color_above_ringw(81)).
head(id(2078),stalk_color_below_ringw(81)).
head(id(2079),veil_colorw(81)).
head(id(2080),ring_numbero(81)).
head(id(2081),cap_shapef(89)).
head(id(2082),cap_colorn(89)).
head(id(2083),gill_spacing(89)).
head(id(2084),gill_colorw(89)).
head(id(2085),stalk_rootr(89)).
head(id(2086),stalk_surface_above_rings(89)).
head(id(2087),stalk_color_above_ringw(89)).
head(id(2088),stalk_color_below_ringw(89)).
head(id(2089),veil_colorw(89)).
head(id(2090),ring_numbero(89)).
head(id(2091),cap_shapef(196)).
head(id(2092),cap_surfacef(196)).
head(id(2093),cap_colorg(196)).
head(id(2094),gill_spacing(196)).
head(id(2095),gill_size(196)).
head(id(2096),gill_colorg(196)).
head(id(2097),stalk_roote(196)).
head(id(2098),stalk_surface_above_rings(196)).
head(id(2099),stalk_surface_below_rings(196)).
head(id(2100),stalk_color_above_ringw(196)).
head(id(2101),stalk_color_below_ringw(196)).
head(id(2102),veil_colorw(196)).
head(id(2103),ring_numbero(196)).
head(id(2104),cap_shapex(104)).
head(id(2105),gill_spacing(104)).
head(id(2106),gill_colorn(104)).
head(id(2107),stalk_rootr(104)).
head(id(2108),stalk_surface_above_rings(104)).
head(id(2109),stalk_color_above_ringw(104)).
head(id(2110),stalk_color_below_ringw(104)).
head(id(2111),veil_colorw(104)).
head(id(2112),ring_numbero(104)).
head(id(2113),cap_shapef(128)).
head(id(2114),cap_surfacef(128)).
head(id(2115),cap_colorg(128)).
head(id(2116),gill_colorh(128)).
head(id(2117),stalk_roote(128)).
head(id(2118),stalk_surface_above_rings(128)).
head(id(2119),stalk_surface_below_rings(128)).
head(id(2120),stalk_color_above_ringw(128)).
head(id(2121),stalk_color_below_ringw(128)).
head(id(2122),veil_colorw(128)).
head(id(2123),ring_numbero(128)).
head(id(2124),cap_shapex(509)).
head(id(2125),cap_surfacef(509)).
head(id(2126),cap_colorw(509)).
head(id(2127),gill_size(509)).
head(id(2128),gill_colorn(509)).
head(id(2129),stalk_rootb(509)).
head(id(2130),stalk_surface_above_rings(509)).
head(id(2131),stalk_surface_below_rings(509)).
head(id(2132),stalk_color_above_ringw(509)).
head(id(2133),stalk_color_below_ringw(509)).
head(id(2134),veil_colorw(509)).
head(id(2135),ring_numbero(509)).
head(id(2136),gill_spacing(157)).
head(id(2137),gill_colork(157)).
head(id(2138),stalk_rootc(157)).
head(id(2139),stalk_surface_above_rings(157)).
head(id(2140),stalk_surface_below_rings(157)).
head(id(2141),stalk_color_above_ringw(157)).
head(id(2142),stalk_color_below_ringw(157)).
head(id(2143),veil_colorw(157)).
head(id(2144),ring_numbero(157)).
head(id(2145),cap_shapex(28)).
head(id(2146),cap_colorw(28)).
head(id(2147),gill_spacing(28)).
head(id(2148),gill_colorw(28)).
head(id(2149),stalk_rootc(28)).
head(id(2150),stalk_surface_above_rings(28)).
head(id(2151),stalk_surface_below_rings(28)).
head(id(2152),stalk_color_above_ringw(28)).
head(id(2153),stalk_color_below_ringw(28)).
head(id(2154),veil_colorw(28)).
head(id(2155),ring_numbero(28)).
head(id(2156),gill_spacing(238)).
head(id(2157),gill_colorn(238)).
head(id(2158),stalk_rootc(238)).
head(id(2159),stalk_surface_above_rings(238)).
head(id(2160),stalk_surface_below_rings(238)).
head(id(2161),stalk_color_above_ringw(238)).
head(id(2162),stalk_color_below_ringw(238)).
head(id(2163),veil_colorw(238)).
head(id(2164),ring_numbero(238)).
head(id(2165),cap_shapex(145)).
head(id(2166),gill_spacing(145)).
head(id(2167),gill_colork(145)).
head(id(2168),stalk_rootc(145)).
head(id(2169),stalk_surface_above_rings(145)).
head(id(2170),stalk_surface_below_rings(145)).
head(id(2171),stalk_color_above_ringw(145)).
head(id(2172),stalk_color_below_ringw(145)).
head(id(2173),veil_colorw(145)).
head(id(2174),ring_numbero(145)).
head(id(2175),cap_shapex(45)).
head(id(2176),cap_surfaces(45)).
head(id(2177),gill_spacing(45)).
head(id(2178),gill_colorw(45)).
head(id(2179),stalk_rootc(45)).
head(id(2180),stalk_surface_above_rings(45)).
head(id(2181),stalk_surface_below_rings(45)).
head(id(2182),stalk_color_above_ringw(45)).
head(id(2183),stalk_color_below_ringw(45)).
head(id(2184),veil_colorw(45)).
head(id(2185),ring_numbero(45)).
head(id(2186),gill_spacing(162)).
head(id(2187),gill_colorn(162)).
head(id(2188),stalk_rootc(162)).
head(id(2189),stalk_surface_above_rings(162)).
head(id(2190),stalk_surface_below_rings(162)).
head(id(2191),stalk_color_above_ringw(162)).
head(id(2192),stalk_color_below_ringw(162)).
head(id(2193),veil_colorw(162)).
head(id(2194),ring_numbero(162)).
head(id(2195),gill_spacing(287)).
head(id(2196),gill_colorg(287)).
head(id(2197),stalk_rootc(287)).
head(id(2198),stalk_surface_above_rings(287)).
head(id(2199),stalk_surface_below_rings(287)).
head(id(2200),stalk_color_above_ringw(287)).
head(id(2201),stalk_color_below_ringw(287)).
head(id(2202),veil_colorw(287)).
head(id(2203),ring_numbero(287)).
head(id(2204),cap_shapex(77)).
head(id(2205),cap_surfaces(77)).
head(id(2206),cap_colorw(77)).
head(id(2207),gill_size(77)).
head(id(2208),gill_colorn(77)).
head(id(2209),stalk_rootb(77)).
head(id(2210),stalk_surface_above_rings(77)).
head(id(2211),stalk_surface_below_rings(77)).
head(id(2212),stalk_color_above_ringw(77)).
head(id(2213),stalk_color_below_ringw(77)).
head(id(2214),veil_colorw(77)).
head(id(2215),ring_numbero(77)).
head(id(2216),cap_shapex(291)).
head(id(2217),cap_surfacef(291)).
head(id(2218),cap_colorg(291)).
head(id(2219),gill_spacing(291)).
head(id(2220),gill_size(291)).
head(id(2221),gill_colorg(291)).
head(id(2222),stalk_roote(291)).
head(id(2223),stalk_surface_above_rings(291)).
head(id(2224),stalk_surface_below_rings(291)).
head(id(2225),stalk_color_above_ringw(291)).
head(id(2226),stalk_color_below_ringw(291)).
head(id(2227),veil_colorw(291)).
head(id(2228),ring_numbero(291)).
head(id(2229),cap_shapex(367)).
head(id(2230),gill_spacing(367)).
head(id(2231),gill_colorw(367)).
head(id(2232),stalk_rootr(367)).
head(id(2233),stalk_surface_above_rings(367)).
head(id(2234),stalk_color_above_ringw(367)).
head(id(2235),stalk_color_below_ringw(367)).
head(id(2236),veil_colorw(367)).
head(id(2237),ring_numbero(367)).
head(id(2238),cap_colorw(65)).
head(id(2239),gill_spacing(65)).
head(id(2240),gill_colorn(65)).
head(id(2241),stalk_rootc(65)).
head(id(2242),stalk_surface_above_rings(65)).
head(id(2243),stalk_surface_below_rings(65)).
head(id(2244),stalk_color_above_ringw(65)).
head(id(2245),stalk_color_below_ringw(65)).
head(id(2246),veil_colorw(65)).
head(id(2247),ring_numbero(65)).
head(id(2248),cap_shapex(199)).
head(id(2249),cap_colorw(199)).
head(id(2250),gill_spacing(199)).
head(id(2251),gill_colorn(199)).
head(id(2252),stalk_rootc(199)).
head(id(2253),stalk_surface_above_rings(199)).
head(id(2254),stalk_surface_below_rings(199)).
head(id(2255),stalk_color_above_ringw(199)).
head(id(2256),stalk_color_below_ringw(199)).
head(id(2257),veil_colorw(199)).
head(id(2258),ring_numbero(199)).
head(id(2259),cap_colorw(307)).
head(id(2260),gill_spacing(307)).
head(id(2261),gill_colork(307)).
head(id(2262),stalk_rootc(307)).
head(id(2263),stalk_surface_above_rings(307)).
head(id(2264),stalk_surface_below_rings(307)).
head(id(2265),stalk_color_above_ringw(307)).
head(id(2266),stalk_color_below_ringw(307)).
head(id(2267),veil_colorw(307)).
head(id(2268),ring_numbero(307)).
head(id(2269),cap_shapex(375)).
head(id(2270),cap_surfaces(375)).
head(id(2271),cap_colorw(375)).
head(id(2272),gill_spacing(375)).
head(id(2273),gill_colork(375)).
head(id(2274),stalk_rootc(375)).
head(id(2275),stalk_surface_above_rings(375)).
head(id(2276),stalk_surface_below_rings(375)).
head(id(2277),stalk_color_above_ringw(375)).
head(id(2278),stalk_color_below_ringw(375)).
head(id(2279),veil_colorw(375)).
head(id(2280),ring_numbero(375)).
head(id(2281),cap_shapex(51)).
head(id(2282),cap_colorn(51)).
head(id(2283),gill_spacing(51)).
head(id(2284),gill_colorw(51)).
head(id(2285),stalk_rootr(51)).
head(id(2286),stalk_surface_above_rings(51)).
head(id(2287),stalk_color_above_ringw(51)).
head(id(2288),stalk_color_below_ringw(51)).
head(id(2289),veil_colorw(51)).
head(id(2290),ring_numbero(51)).
head(id(2291),cap_surfaces(63)).
head(id(2292),gill_spacing(63)).
head(id(2293),gill_colorg(63)).
head(id(2294),stalk_rootc(63)).
head(id(2295),stalk_surface_above_rings(63)).
head(id(2296),stalk_surface_below_rings(63)).
head(id(2297),stalk_color_above_ringw(63)).
head(id(2298),stalk_color_below_ringw(63)).
head(id(2299),veil_colorw(63)).
head(id(2300),ring_numbero(63)).
head(id(2301),cap_surfaces(127)).
head(id(2302),gill_spacing(127)).
head(id(2303),gill_colorw(127)).
head(id(2304),stalk_rootc(127)).
head(id(2305),stalk_surface_above_rings(127)).
head(id(2306),stalk_surface_below_rings(127)).
head(id(2307),stalk_color_above_ringw(127)).
head(id(2308),stalk_color_below_ringw(127)).
head(id(2309),veil_colorw(127)).
head(id(2310),ring_numbero(127)).
head(id(2311),cap_shapex(301)).
head(id(2312),cap_surfacef(301)).
head(id(2313),cap_colorw(301)).
head(id(2314),gill_colork(301)).
head(id(2315),stalk_roote(301)).
head(id(2316),stalk_surface_above_ringf(301)).
head(id(2317),stalk_surface_below_rings(301)).
head(id(2318),stalk_color_above_ringw(301)).
head(id(2319),stalk_color_below_ringw(301)).
head(id(2320),veil_colorw(301)).
head(id(2321),ring_numbero(301)).
head(id(2322),cap_shapex(179)).
head(id(2323),gill_spacing(179)).
head(id(2324),gill_colorg(179)).
head(id(2325),stalk_rootc(179)).
head(id(2326),stalk_surface_above_rings(179)).
head(id(2327),stalk_surface_below_rings(179)).
head(id(2328),stalk_color_above_ringw(179)).
head(id(2329),stalk_color_below_ringw(179)).
head(id(2330),veil_colorw(179)).
head(id(2331),ring_numbero(179)).
head(id(2332),cap_shapex(218)).
head(id(2333),gill_spacing(218)).
head(id(2334),gill_colork(218)).
head(id(2335),stalk_rootc(218)).
head(id(2336),stalk_surface_above_rings(218)).
head(id(2337),stalk_surface_below_rings(218)).
head(id(2338),stalk_color_above_ringw(218)).
head(id(2339),stalk_color_below_ringw(218)).
head(id(2340),veil_colorw(218)).
head(id(2341),ring_numbero(218)).
head(id(2342),cap_shapex(263)).
head(id(2343),cap_surfaces(263)).
head(id(2344),cap_colorw(263)).
head(id(2345),gill_spacing(263)).
head(id(2346),gill_colorn(263)).
head(id(2347),stalk_rootc(263)).
head(id(2348),stalk_surface_above_rings(263)).
head(id(2349),stalk_surface_below_rings(263)).
head(id(2350),stalk_color_above_ringw(263)).
head(id(2351),stalk_color_below_ringw(263)).
head(id(2352),veil_colorw(263)).
head(id(2353),ring_numbero(263)).
head(id(2354),cap_shapef(205)).
head(id(2355),cap_colorn(205)).
head(id(2356),gill_spacing(205)).
head(id(2357),gill_colorn(205)).
head(id(2358),stalk_rootr(205)).
head(id(2359),stalk_surface_above_rings(205)).
head(id(2360),stalk_color_above_ringw(205)).
head(id(2361),stalk_color_below_ringw(205)).
head(id(2362),veil_colorw(205)).
head(id(2363),ring_numbero(205)).
head(id(2364),cap_shapex(248)).
head(id(2365),cap_colorw(248)).
head(id(2366),gill_spacing(248)).
head(id(2367),gill_colorn(248)).
head(id(2368),stalk_rootc(248)).
head(id(2369),stalk_surface_above_rings(248)).
head(id(2370),stalk_surface_below_rings(248)).
head(id(2371),stalk_color_above_ringw(248)).
head(id(2372),stalk_color_below_ringw(248)).
head(id(2373),veil_colorw(248)).
head(id(2374),ring_numbero(248)).
head(id(2375),cap_surfaces(329)).
head(id(2376),gill_spacing(329)).
head(id(2377),gill_colorw(329)).
head(id(2378),stalk_rootc(329)).
head(id(2379),stalk_surface_above_rings(329)).
head(id(2380),stalk_surface_below_rings(329)).
head(id(2381),stalk_color_above_ringw(329)).
head(id(2382),stalk_color_below_ringw(329)).
head(id(2383),veil_colorw(329)).
head(id(2384),ring_numbero(329)).
head(id(2385),cap_shapef(215)).
head(id(2386),gill_spacing(215)).
head(id(2387),gill_colorn(215)).
head(id(2388),stalk_rootr(215)).
head(id(2389),stalk_surface_above_rings(215)).
head(id(2390),stalk_color_above_ringw(215)).
head(id(2391),stalk_color_below_ringw(215)).
head(id(2392),veil_colorw(215)).
head(id(2393),ring_numbero(215)).
head(id(2394),cap_shapes(117)).
head(id(2395),cap_surfacef(117)).
head(id(2396),cap_colorg(117)).
head(id(2397),gill_spacing(117)).
head(id(2398),gill_size(117)).
head(id(2399),gill_colorp(117)).
head(id(2400),stalk_roote(117)).
head(id(2401),stalk_surface_above_rings(117)).
head(id(2402),stalk_surface_below_rings(117)).
head(id(2403),stalk_color_above_ringw(117)).
head(id(2404),stalk_color_below_ringw(117)).
head(id(2405),veil_colorw(117)).
head(id(2406),ring_numbero(117)).
head(id(2407),gill_spacing(512)).
head(id(2408),gill_colork(512)).
head(id(2409),stalk_rootc(512)).
head(id(2410),stalk_surface_above_rings(512)).
head(id(2411),stalk_surface_below_rings(512)).
head(id(2412),stalk_color_above_ringw(512)).
head(id(2413),stalk_color_below_ringw(512)).
head(id(2414),veil_colorw(512)).
head(id(2415),ring_numbero(512)).
head(id(2416),cap_shapex(490)).
head(id(2417),cap_colorn(490)).
head(id(2418),gill_spacing(490)).
head(id(2419),gill_colorn(490)).
head(id(2420),stalk_rootr(490)).
head(id(2421),stalk_surface_above_rings(490)).
head(id(2422),stalk_color_above_ringw(490)).
head(id(2423),stalk_color_below_ringw(490)).
head(id(2424),veil_colorw(490)).
head(id(2425),ring_numbero(490)).
head(id(2426),cap_shapex(5)).
head(id(2427),cap_surfaces(5)).
head(id(2428),cap_colorg(5)).
head(id(2429),gill_colork(5)).
head(id(2430),stalk_roote(5)).
head(id(2431),stalk_surface_above_rings(5)).
head(id(2432),stalk_surface_below_rings(5)).
head(id(2433),stalk_color_above_ringw(5)).
head(id(2434),stalk_color_below_ringw(5)).
head(id(2435),veil_colorw(5)).
head(id(2436),ring_numbero(5)).
head(id(2437),cap_shapex(30)).
head(id(2438),cap_surfaces(30)).
head(id(2439),gill_size(30)).
head(id(2440),gill_colorn(30)).
head(id(2441),stalk_rootb(30)).
head(id(2442),stalk_surface_above_rings(30)).
head(id(2443),stalk_surface_below_rings(30)).
head(id(2444),stalk_color_above_ringw(30)).
head(id(2445),stalk_color_below_ringw(30)).
head(id(2446),veil_colorw(30)).
head(id(2447),ring_numbero(30)).
head(id(2448),cap_shapex(446)).
head(id(2449),cap_colorn(446)).
head(id(2450),gill_spacing(446)).
head(id(2451),gill_colorp(446)).
head(id(2452),stalk_rootr(446)).
head(id(2453),stalk_surface_above_rings(446)).
head(id(2454),stalk_color_above_ringw(446)).
head(id(2455),stalk_color_below_ringw(446)).
head(id(2456),veil_colorw(446)).
head(id(2457),ring_numbero(446)).
head(id(2458),gill_spacing(481)).
head(id(2459),gill_colork(481)).
head(id(2460),stalk_rootc(481)).
head(id(2461),stalk_surface_above_rings(481)).
head(id(2462),stalk_surface_below_rings(481)).
head(id(2463),stalk_color_above_ringw(481)).
head(id(2464),stalk_color_below_ringw(481)).
head(id(2465),veil_colorw(481)).
head(id(2466),ring_numbero(481)).
head(id(2467),cap_shapef(71)).
head(id(2468),cap_surfacef(71)).
head(id(2469),gill_size(71)).
head(id(2470),gill_colorp(71)).
head(id(2471),stalk_rootb(71)).
head(id(2472),stalk_surface_above_rings(71)).
head(id(2473),stalk_surface_below_rings(71)).
head(id(2474),stalk_color_above_ringw(71)).
head(id(2475),stalk_color_below_ringw(71)).
head(id(2476),veil_colorw(71)).
head(id(2477),ring_numbero(71)).
head(id(2478),cap_shapex(409)).
head(id(2479),cap_surfaces(409)).
head(id(2480),cap_colorw(409)).
head(id(2481),gill_spacing(409)).
head(id(2482),gill_colorg(409)).
head(id(2483),stalk_rootc(409)).
head(id(2484),stalk_surface_above_rings(409)).
head(id(2485),stalk_surface_below_rings(409)).
head(id(2486),stalk_color_above_ringw(409)).
head(id(2487),stalk_color_below_ringw(409)).
head(id(2488),veil_colorw(409)).
head(id(2489),ring_numbero(409)).
head(id(2490),cap_surfaces(230)).
head(id(2491),gill_spacing(230)).
head(id(2492),gill_colorn(230)).
head(id(2493),stalk_rootc(230)).
head(id(2494),stalk_surface_above_rings(230)).
head(id(2495),stalk_surface_below_rings(230)).
head(id(2496),stalk_color_above_ringw(230)).
head(id(2497),stalk_color_below_ringw(230)).
head(id(2498),veil_colorw(230)).
head(id(2499),ring_numbero(230)).
head(id(2500),gill_spacing(378)).
head(id(2501),gill_colorn(378)).
head(id(2502),stalk_rootc(378)).
head(id(2503),stalk_surface_above_rings(378)).
head(id(2504),stalk_surface_below_rings(378)).
head(id(2505),stalk_color_above_ringw(378)).
head(id(2506),stalk_color_below_ringw(378)).
head(id(2507),veil_colorw(378)).
head(id(2508),ring_numbero(378)).
head(id(2509),cap_surfaces(376)).
head(id(2510),cap_colorw(376)).
head(id(2511),gill_spacing(376)).
head(id(2512),gill_colorn(376)).
head(id(2513),stalk_rootc(376)).
head(id(2514),stalk_surface_above_rings(376)).
head(id(2515),stalk_surface_below_rings(376)).
head(id(2516),stalk_color_above_ringw(376)).
head(id(2517),stalk_color_below_ringw(376)).
head(id(2518),veil_colorw(376)).
head(id(2519),ring_numbero(376)).
head(id(2520),cap_shapex(113)).
head(id(2521),cap_surfacef(113)).
head(id(2522),cap_colorw(113)).
head(id(2523),gill_size(113)).
head(id(2524),gill_colorw(113)).
head(id(2525),stalk_rootb(113)).
head(id(2526),stalk_surface_above_rings(113)).
head(id(2527),stalk_surface_below_rings(113)).
head(id(2528),stalk_color_above_ringw(113)).
head(id(2529),stalk_color_below_ringw(113)).
head(id(2530),veil_colorw(113)).
head(id(2531),ring_numbero(113)).
head(id(2532),gill_spacing(380)).
head(id(2533),gill_colork(380)).
head(id(2534),stalk_rootc(380)).
head(id(2535),stalk_surface_above_rings(380)).
head(id(2536),stalk_surface_below_rings(380)).
head(id(2537),stalk_color_above_ringw(380)).
head(id(2538),stalk_color_below_ringw(380)).
head(id(2539),veil_colorw(380)).
head(id(2540),ring_numbero(380)).
head(id(2541),cap_shapex(91)).
head(id(2542),cap_surfacef(91)).
head(id(2543),cap_colorn(91)).
head(id(2544),gill_spacing(91)).
head(id(2545),gill_size(91)).
head(id(2546),gill_colorn(91)).
head(id(2547),stalk_roote(91)).
head(id(2548),stalk_surface_above_rings(91)).
head(id(2549),stalk_surface_below_rings(91)).
head(id(2550),stalk_color_above_ringw(91)).
head(id(2551),stalk_color_below_ringw(91)).
head(id(2552),veil_colorw(91)).
head(id(2553),ring_numbero(91)).
head(id(2554),cap_colorw(109)).
head(id(2555),gill_spacing(109)).
head(id(2556),gill_colorg(109)).
head(id(2557),stalk_rootc(109)).
head(id(2558),stalk_surface_above_rings(109)).
head(id(2559),stalk_surface_below_rings(109)).
head(id(2560),stalk_color_above_ringw(109)).
head(id(2561),stalk_color_below_ringw(109)).
head(id(2562),veil_colorw(109)).
head(id(2563),ring_numbero(109)).
head(id(2564),cap_surfaces(21)).
head(id(2565),gill_spacing(21)).
head(id(2566),gill_colork(21)).
head(id(2567),stalk_rootc(21)).
head(id(2568),stalk_surface_above_rings(21)).
head(id(2569),stalk_surface_below_rings(21)).
head(id(2570),stalk_color_above_ringw(21)).
head(id(2571),stalk_color_below_ringw(21)).
head(id(2572),veil_colorw(21)).
head(id(2573),ring_numbero(21)).
head(id(2574),cap_shapef(290)).
head(id(2575),cap_surfacef(290)).
head(id(2576),cap_colorg(290)).
head(id(2577),gill_spacing(290)).
head(id(2578),gill_size(290)).
head(id(2579),gill_colorp(290)).
head(id(2580),stalk_roote(290)).
head(id(2581),stalk_surface_above_rings(290)).
head(id(2582),stalk_surface_below_rings(290)).
head(id(2583),stalk_color_above_ringw(290)).
head(id(2584),stalk_color_below_ringw(290)).
head(id(2585),veil_colorw(290)).
head(id(2586),ring_numbero(290)).
head(id(2587),cap_surfaces(161)).
head(id(2588),gill_spacing(161)).
head(id(2589),gill_colorg(161)).
head(id(2590),stalk_rootc(161)).
head(id(2591),stalk_surface_above_rings(161)).
head(id(2592),stalk_surface_below_rings(161)).
head(id(2593),stalk_color_above_ringw(161)).
head(id(2594),stalk_color_below_ringw(161)).
head(id(2595),veil_colorw(161)).
head(id(2596),ring_numbero(161)).
head(id(2597),cap_colorw(422)).
head(id(2598),gill_spacing(422)).
head(id(2599),gill_colorw(422)).
head(id(2600),stalk_rootc(422)).
head(id(2601),stalk_surface_above_rings(422)).
head(id(2602),stalk_surface_below_rings(422)).
head(id(2603),stalk_color_above_ringw(422)).
head(id(2604),stalk_color_below_ringw(422)).
head(id(2605),veil_colorw(422)).
head(id(2606),ring_numbero(422)).
head(id(2607),cap_shapex(311)).
head(id(2608),cap_surfaces(311)).
head(id(2609),gill_spacing(311)).
head(id(2610),gill_colorw(311)).
head(id(2611),stalk_rootc(311)).
head(id(2612),stalk_surface_above_rings(311)).
head(id(2613),stalk_surface_below_rings(311)).
head(id(2614),stalk_color_above_ringw(311)).
head(id(2615),stalk_color_below_ringw(311)).
head(id(2616),veil_colorw(311)).
head(id(2617),ring_numbero(311)).
head(id(2618),cap_shapef(73)).
head(id(2619),cap_surfacef(73)).
head(id(2620),gill_size(73)).
head(id(2621),gill_colorw(73)).
head(id(2622),stalk_rootb(73)).
head(id(2623),stalk_surface_above_rings(73)).
head(id(2624),stalk_surface_below_rings(73)).
head(id(2625),stalk_color_above_ringw(73)).
head(id(2626),stalk_color_below_ringw(73)).
head(id(2627),veil_colorw(73)).
head(id(2628),ring_numbero(73)).
head(id(2629),cap_shapex(408)).
head(id(2630),cap_surfaces(408)).
head(id(2631),cap_colorw(408)).
head(id(2632),gill_spacing(408)).
head(id(2633),gill_colorg(408)).
head(id(2634),stalk_rootc(408)).
head(id(2635),stalk_surface_above_rings(408)).
head(id(2636),stalk_surface_below_rings(408)).
head(id(2637),stalk_color_above_ringw(408)).
head(id(2638),stalk_color_below_ringw(408)).
head(id(2639),veil_colorw(408)).
head(id(2640),ring_numbero(408)).
head(id(2641),cap_shapex(468)).
head(id(2642),cap_surfaces(468)).
head(id(2643),gill_spacing(468)).
head(id(2644),gill_colorg(468)).
head(id(2645),stalk_rootc(468)).
head(id(2646),stalk_surface_above_rings(468)).
head(id(2647),stalk_surface_below_rings(468)).
head(id(2648),stalk_color_above_ringw(468)).
head(id(2649),stalk_color_below_ringw(468)).
head(id(2650),veil_colorw(468)).
head(id(2651),ring_numbero(468)).
head(id(2652),cap_shapex(406)).
head(id(2653),gill_spacing(406)).
head(id(2654),gill_colorn(406)).
head(id(2655),stalk_rootc(406)).
head(id(2656),stalk_surface_above_rings(406)).
head(id(2657),stalk_surface_below_rings(406)).
head(id(2658),stalk_color_above_ringw(406)).
head(id(2659),stalk_color_below_ringw(406)).
head(id(2660),veil_colorw(406)).
head(id(2661),ring_numbero(406)).
head(id(2662),cap_colorw(288)).
head(id(2663),gill_spacing(288)).
head(id(2664),gill_colorg(288)).
head(id(2665),stalk_rootc(288)).
head(id(2666),stalk_surface_above_rings(288)).
head(id(2667),stalk_surface_below_rings(288)).
head(id(2668),stalk_color_above_ringw(288)).
head(id(2669),stalk_color_below_ringw(288)).
head(id(2670),veil_colorw(288)).
head(id(2671),ring_numbero(288)).
head(id(2672),cap_shapex(192)).
head(id(2673),cap_surfaces(192)).
head(id(2674),cap_colorw(192)).
head(id(2675),gill_size(192)).
head(id(2676),gill_colorw(192)).
head(id(2677),stalk_rootb(192)).
head(id(2678),stalk_surface_above_rings(192)).
head(id(2679),stalk_surface_below_rings(192)).
head(id(2680),stalk_color_above_ringw(192)).
head(id(2681),stalk_color_below_ringw(192)).
head(id(2682),veil_colorw(192)).
head(id(2683),ring_numbero(192)).
head(id(2684),cap_surfaces(130)).
head(id(2685),cap_colorw(130)).
head(id(2686),gill_spacing(130)).
head(id(2687),gill_colorn(130)).
head(id(2688),stalk_rootc(130)).
head(id(2689),stalk_surface_above_rings(130)).
head(id(2690),stalk_surface_below_rings(130)).
head(id(2691),stalk_color_above_ringw(130)).
head(id(2692),stalk_color_below_ringw(130)).
head(id(2693),veil_colorw(130)).
head(id(2694),ring_numbero(130)).
head(id(2695),cap_shapex(156)).
head(id(2696),cap_colorn(156)).
head(id(2697),gill_spacing(156)).
head(id(2698),gill_colorw(156)).
head(id(2699),stalk_rootr(156)).
head(id(2700),stalk_surface_above_rings(156)).
head(id(2701),stalk_color_above_ringw(156)).
head(id(2702),stalk_color_below_ringw(156)).
head(id(2703),veil_colorw(156)).
head(id(2704),ring_numbero(156)).
head(id(2705),cap_shapef(363)).
head(id(2706),cap_surfaces(363)).
head(id(2707),cap_colorn(363)).
head(id(2708),gill_colork(363)).
head(id(2709),stalk_roote(363)).
head(id(2710),stalk_surface_above_ringf(363)).
head(id(2711),stalk_surface_below_rings(363)).
head(id(2712),stalk_color_above_ringw(363)).
head(id(2713),stalk_color_below_ringw(363)).
head(id(2714),veil_colorw(363)).
head(id(2715),ring_numbero(363)).
head(id(2716),cap_shapex(465)).
head(id(2717),cap_surfacef(465)).
head(id(2718),cap_colorn(465)).
head(id(2719),gill_spacing(465)).
head(id(2720),gill_size(465)).
head(id(2721),gill_colork(465)).
head(id(2722),stalk_roote(465)).
head(id(2723),stalk_surface_above_rings(465)).
head(id(2724),stalk_surface_below_rings(465)).
head(id(2725),stalk_color_above_ringw(465)).
head(id(2726),stalk_color_below_ringw(465)).
head(id(2727),veil_colorw(465)).
head(id(2728),ring_numbero(465)).
head(id(2729),cap_shapef(166)).
head(id(2730),gill_spacing(166)).
head(id(2731),gill_colorw(166)).
head(id(2732),stalk_rootr(166)).
head(id(2733),stalk_surface_above_rings(166)).
head(id(2734),stalk_color_above_ringw(166)).
head(id(2735),stalk_color_below_ringw(166)).
head(id(2736),veil_colorw(166)).
head(id(2737),ring_numbero(166)).
head(id(2738),cap_shapex(27)).
head(id(2739),gill_spacing(27)).
head(id(2740),gill_colorn(27)).
head(id(2741),stalk_rootc(27)).
head(id(2742),stalk_surface_above_rings(27)).
head(id(2743),stalk_surface_below_rings(27)).
head(id(2744),stalk_color_above_ringw(27)).
head(id(2745),stalk_color_below_ringw(27)).
head(id(2746),veil_colorw(27)).
head(id(2747),ring_numbero(27)).
head(id(2748),cap_shapef(251)).
head(id(2749),gill_spacing(251)).
head(id(2750),gill_colorw(251)).
head(id(2751),stalk_rootr(251)).
head(id(2752),stalk_surface_above_rings(251)).
head(id(2753),stalk_color_above_ringw(251)).
head(id(2754),stalk_color_below_ringw(251)).
head(id(2755),veil_colorw(251)).
head(id(2756),ring_numbero(251)).
head(id(2757),cap_shapef(97)).
head(id(2758),cap_colorn(97)).
head(id(2759),gill_spacing(97)).
head(id(2760),gill_colorp(97)).
head(id(2761),stalk_rootr(97)).
head(id(2762),stalk_surface_above_rings(97)).
head(id(2763),stalk_color_above_ringw(97)).
head(id(2764),stalk_color_below_ringw(97)).
head(id(2765),veil_colorw(97)).
head(id(2766),ring_numbero(97)).
head(id(2767),cap_shapex(306)).
head(id(2768),cap_surfacef(306)).
head(id(2769),cap_colorn(306)).
head(id(2770),gill_spacing(306)).
head(id(2771),gill_colorp(306)).
head(id(2772),stalk_rootb(306)).
head(id(2773),stalk_surface_above_rings(306)).
head(id(2774),stalk_surface_below_rings(306)).
head(id(2775),stalk_color_above_ringg(306)).
head(id(2776),stalk_color_below_ringp(306)).
head(id(2777),veil_colorw(306)).
head(id(2778),ring_numbero(306)).
head(id(2779),cap_colorw(353)).
head(id(2780),gill_spacing(353)).
head(id(2781),gill_colork(353)).
head(id(2782),stalk_rootc(353)).
head(id(2783),stalk_surface_above_rings(353)).
head(id(2784),stalk_surface_below_rings(353)).
head(id(2785),stalk_color_above_ringw(353)).
head(id(2786),stalk_color_below_ringw(353)).
head(id(2787),veil_colorw(353)).
head(id(2788),ring_numbero(353)).
head(id(2789),cap_shapes(253)).
head(id(2790),cap_surfacef(253)).
head(id(2791),cap_colorn(253)).
head(id(2792),gill_spacing(253)).
head(id(2793),gill_size(253)).
head(id(2794),gill_colorg(253)).
head(id(2795),stalk_roote(253)).
head(id(2796),stalk_surface_above_rings(253)).
head(id(2797),stalk_surface_below_rings(253)).
head(id(2798),stalk_color_above_ringw(253)).
head(id(2799),stalk_color_below_ringw(253)).
head(id(2800),veil_colorw(253)).
head(id(2801),ring_numbero(253)).
head(id(2802),cap_colorw(105)).
head(id(2803),gill_spacing(105)).
head(id(2804),gill_colorg(105)).
head(id(2805),stalk_rootc(105)).
head(id(2806),stalk_surface_above_rings(105)).
head(id(2807),stalk_surface_below_rings(105)).
head(id(2808),stalk_color_above_ringw(105)).
head(id(2809),stalk_color_below_ringw(105)).
head(id(2810),veil_colorw(105)).
head(id(2811),ring_numbero(105)).
head(id(2812),cap_shapex(371)).
head(id(2813),gill_spacing(371)).
head(id(2814),gill_colorw(371)).
head(id(2815),stalk_rootr(371)).
head(id(2816),stalk_surface_above_rings(371)).
head(id(2817),stalk_color_above_ringw(371)).
head(id(2818),stalk_color_below_ringw(371)).
head(id(2819),veil_colorw(371)).
head(id(2820),ring_numbero(371)).
head(id(2821),cap_shapex(284)).
head(id(2822),cap_surfaces(284)).
head(id(2823),gill_spacing(284)).
head(id(2824),gill_colork(284)).
head(id(2825),stalk_rootc(284)).
head(id(2826),stalk_surface_above_rings(284)).
head(id(2827),stalk_surface_below_rings(284)).
head(id(2828),stalk_color_above_ringw(284)).
head(id(2829),stalk_color_below_ringw(284)).
head(id(2830),veil_colorw(284)).
head(id(2831),ring_numbero(284)).
head(id(2832),cap_surfaces(463)).
head(id(2833),cap_colorw(463)).
head(id(2834),gill_spacing(463)).
head(id(2835),gill_colorg(463)).
head(id(2836),stalk_rootc(463)).
head(id(2837),stalk_surface_above_rings(463)).
head(id(2838),stalk_surface_below_rings(463)).
head(id(2839),stalk_color_above_ringw(463)).
head(id(2840),stalk_color_below_ringw(463)).
head(id(2841),veil_colorw(463)).
head(id(2842),ring_numbero(463)).
head(id(2843),cap_surfaces(193)).
head(id(2844),cap_colorw(193)).
head(id(2845),gill_spacing(193)).
head(id(2846),gill_colorw(193)).
head(id(2847),stalk_rootc(193)).
head(id(2848),stalk_surface_above_rings(193)).
head(id(2849),stalk_surface_below_rings(193)).
head(id(2850),stalk_color_above_ringw(193)).
head(id(2851),stalk_color_below_ringw(193)).
head(id(2852),veil_colorw(193)).
head(id(2853),ring_numbero(193)).
head(id(2854),cap_shapex(426)).
head(id(2855),cap_surfaces(426)).
head(id(2856),cap_colorw(426)).
head(id(2857),gill_size(426)).
head(id(2858),gill_colorn(426)).
head(id(2859),stalk_rootb(426)).
head(id(2860),stalk_surface_above_rings(426)).
head(id(2861),stalk_surface_below_rings(426)).
head(id(2862),stalk_color_above_ringw(426)).
head(id(2863),stalk_color_below_ringw(426)).
head(id(2864),veil_colorw(426)).
head(id(2865),ring_numbero(426)).
head(id(2866),cap_shapex(34)).
head(id(2867),cap_colorn(34)).
head(id(2868),gill_spacing(34)).
head(id(2869),gill_colorp(34)).
head(id(2870),stalk_rootr(34)).
head(id(2871),stalk_surface_above_rings(34)).
head(id(2872),stalk_color_above_ringw(34)).
head(id(2873),stalk_color_below_ringw(34)).
head(id(2874),veil_colorw(34)).
head(id(2875),ring_numbero(34)).
head(id(2876),cap_shapex(231)).
head(id(2877),cap_surfacef(231)).
head(id(2878),cap_colorg(231)).
head(id(2879),gill_spacing(231)).
head(id(2880),gill_size(231)).
head(id(2881),gill_colorn(231)).
head(id(2882),stalk_roote(231)).
head(id(2883),stalk_surface_above_rings(231)).
head(id(2884),stalk_surface_below_rings(231)).
head(id(2885),stalk_color_above_ringw(231)).
head(id(2886),stalk_color_below_ringw(231)).
head(id(2887),veil_colorw(231)).
head(id(2888),ring_numbero(231)).
head(id(2889),cap_shapef(511)).
head(id(2890),cap_surfacef(511)).
head(id(2891),cap_colorn(511)).
head(id(2892),gill_spacing(511)).
head(id(2893),gill_size(511)).
head(id(2894),gill_colork(511)).
head(id(2895),stalk_roote(511)).
head(id(2896),stalk_surface_above_rings(511)).
head(id(2897),stalk_surface_below_rings(511)).
head(id(2898),stalk_color_above_ringw(511)).
head(id(2899),stalk_color_below_ringw(511)).
head(id(2900),veil_colorw(511)).
head(id(2901),ring_numbero(511)).
head(id(2902),cap_shapex(221)).
head(id(2903),cap_surfaces(221)).
head(id(2904),cap_colorw(221)).
head(id(2905),gill_spacing(221)).
head(id(2906),gill_colorn(221)).
head(id(2907),stalk_rootc(221)).
head(id(2908),stalk_surface_above_rings(221)).
head(id(2909),stalk_surface_below_rings(221)).
head(id(2910),stalk_color_above_ringw(221)).
head(id(2911),stalk_color_below_ringw(221)).
head(id(2912),veil_colorw(221)).
head(id(2913),ring_numbero(221)).
head(id(2914),gill_spacing(345)).
head(id(2915),gill_colorg(345)).
head(id(2916),stalk_rootc(345)).
head(id(2917),stalk_surface_above_rings(345)).
head(id(2918),stalk_surface_below_rings(345)).
head(id(2919),stalk_color_above_ringw(345)).
head(id(2920),stalk_color_below_ringw(345)).
head(id(2921),veil_colorw(345)).
head(id(2922),ring_numbero(345)).
head(id(2923),cap_shapex(243)).
head(id(2924),cap_surfaces(243)).
head(id(2925),cap_colorw(243)).
head(id(2926),gill_spacing(243)).
head(id(2927),gill_colorw(243)).
head(id(2928),stalk_rootc(243)).
head(id(2929),stalk_surface_above_rings(243)).
head(id(2930),stalk_surface_below_rings(243)).
head(id(2931),stalk_color_above_ringw(243)).
head(id(2932),stalk_color_below_ringw(243)).
head(id(2933),veil_colorw(243)).
head(id(2934),ring_numbero(243)).
head(id(2935),cap_surfaces(149)).
head(id(2936),gill_spacing(149)).
head(id(2937),gill_colork(149)).
head(id(2938),stalk_rootc(149)).
head(id(2939),stalk_surface_above_rings(149)).
head(id(2940),stalk_surface_below_rings(149)).
head(id(2941),stalk_color_above_ringw(149)).
head(id(2942),stalk_color_below_ringw(149)).
head(id(2943),veil_colorw(149)).
head(id(2944),ring_numbero(149)).
head(id(2945),gill_spacing(469)).
head(id(2946),gill_colorg(469)).
head(id(2947),stalk_rootc(469)).
head(id(2948),stalk_surface_above_rings(469)).
head(id(2949),stalk_surface_below_rings(469)).
head(id(2950),stalk_color_above_ringw(469)).
head(id(2951),stalk_color_below_ringw(469)).
head(id(2952),veil_colorw(469)).
head(id(2953),ring_numbero(469)).
head(id(2954),cap_shapex(151)).
head(id(2955),cap_colorw(151)).
head(id(2956),gill_spacing(151)).
head(id(2957),gill_colorw(151)).
head(id(2958),stalk_rootc(151)).
head(id(2959),stalk_surface_above_rings(151)).
head(id(2960),stalk_surface_below_rings(151)).
head(id(2961),stalk_color_above_ringw(151)).
head(id(2962),stalk_color_below_ringw(151)).
head(id(2963),veil_colorw(151)).
head(id(2964),ring_numbero(151)).
head(id(2965),cap_colorw(294)).
head(id(2966),gill_spacing(294)).
head(id(2967),gill_colork(294)).
head(id(2968),stalk_rootc(294)).
head(id(2969),stalk_surface_above_rings(294)).
head(id(2970),stalk_surface_below_rings(294)).
head(id(2971),stalk_color_above_ringw(294)).
head(id(2972),stalk_color_below_ringw(294)).
head(id(2973),veil_colorw(294)).
head(id(2974),ring_numbero(294)).
head(id(2975),cap_shapex(536)).
head(id(2976),cap_surfacef(536)).
head(id(2977),cap_colorw(536)).
head(id(2978),gill_colork(536)).
head(id(2979),stalk_roote(536)).
head(id(2980),stalk_surface_above_ringf(536)).
head(id(2981),stalk_surface_below_rings(536)).
head(id(2982),stalk_color_above_ringw(536)).
head(id(2983),stalk_color_below_ringw(536)).
head(id(2984),veil_colorw(536)).
head(id(2985),ring_numbero(536)).
head(id(2986),cap_shapex(340)).
head(id(2987),cap_colorn(340)).
head(id(2988),gill_spacing(340)).
head(id(2989),gill_colorn(340)).
head(id(2990),stalk_rootr(340)).
head(id(2991),stalk_surface_above_rings(340)).
head(id(2992),stalk_color_above_ringw(340)).
head(id(2993),stalk_color_below_ringw(340)).
head(id(2994),veil_colorw(340)).
head(id(2995),ring_numbero(340)).
head(id(2996),cap_shapex(347)).
head(id(2997),cap_surfacef(347)).
head(id(2998),gill_size(347)).
head(id(2999),gill_colorn(347)).
head(id(3000),stalk_rootb(347)).
head(id(3001),stalk_surface_above_rings(347)).
head(id(3002),stalk_surface_below_rings(347)).
head(id(3003),stalk_color_above_ringw(347)).
head(id(3004),stalk_color_below_ringw(347)).
head(id(3005),veil_colorw(347)).
head(id(3006),ring_numbero(347)).
head(id(3007),cap_surfaces(202)).
head(id(3008),cap_colorw(202)).
head(id(3009),gill_spacing(202)).
head(id(3010),gill_colorw(202)).
head(id(3011),stalk_rootc(202)).
head(id(3012),stalk_surface_above_rings(202)).
head(id(3013),stalk_surface_below_rings(202)).
head(id(3014),stalk_color_above_ringw(202)).
head(id(3015),stalk_color_below_ringw(202)).
head(id(3016),veil_colorw(202)).
head(id(3017),ring_numbero(202)).
head(id(3018),cap_shapef(530)).
head(id(3019),gill_spacing(530)).
head(id(3020),gill_colorw(530)).
head(id(3021),stalk_rootr(530)).
head(id(3022),stalk_surface_above_rings(530)).
head(id(3023),stalk_color_above_ringw(530)).
head(id(3024),stalk_color_below_ringw(530)).
head(id(3025),veil_colorw(530)).
head(id(3026),ring_numbero(530)).
head(id(3027),cap_shapef(525)).
head(id(3028),cap_surfacef(525)).
head(id(3029),cap_colorg(525)).
head(id(3030),gill_spacing(525)).
head(id(3031),gill_size(525)).
head(id(3032),gill_colorn(525)).
head(id(3033),stalk_roote(525)).
head(id(3034),stalk_surface_above_rings(525)).
head(id(3035),stalk_surface_below_rings(525)).
head(id(3036),stalk_color_above_ringw(525)).
head(id(3037),stalk_color_below_ringw(525)).
head(id(3038),veil_colorw(525)).
head(id(3039),ring_numbero(525)).
head(id(3040),cap_surfaces(449)).
head(id(3041),cap_colorw(449)).
head(id(3042),gill_spacing(449)).
head(id(3043),gill_colorw(449)).
head(id(3044),stalk_rootc(449)).
head(id(3045),stalk_surface_above_rings(449)).
head(id(3046),stalk_surface_below_rings(449)).
head(id(3047),stalk_color_above_ringw(449)).
head(id(3048),stalk_color_below_ringw(449)).
head(id(3049),veil_colorw(449)).
head(id(3050),ring_numbero(449)).
head(id(3051),gill_spacing(178)).
head(id(3052),gill_colorg(178)).
head(id(3053),stalk_rootc(178)).
head(id(3054),stalk_surface_above_rings(178)).
head(id(3055),stalk_surface_below_rings(178)).
head(id(3056),stalk_color_above_ringw(178)).
head(id(3057),stalk_color_below_ringw(178)).
head(id(3058),veil_colorw(178)).
head(id(3059),ring_numbero(178)).
head(id(3060),cap_shapex(305)).
head(id(3061),cap_colorw(305)).
head(id(3062),gill_spacing(305)).
head(id(3063),gill_colorg(305)).
head(id(3064),stalk_rootc(305)).
head(id(3065),stalk_surface_above_rings(305)).
head(id(3066),stalk_surface_below_rings(305)).
head(id(3067),stalk_color_above_ringw(305)).
head(id(3068),stalk_color_below_ringw(305)).
head(id(3069),veil_colorw(305)).
head(id(3070),ring_numbero(305)).
head(id(3071),cap_colorw(393)).
head(id(3072),gill_spacing(393)).
head(id(3073),gill_colorn(393)).
head(id(3074),stalk_rootc(393)).
head(id(3075),stalk_surface_above_rings(393)).
head(id(3076),stalk_surface_below_rings(393)).
head(id(3077),stalk_color_above_ringw(393)).
head(id(3078),stalk_color_below_ringw(393)).
head(id(3079),veil_colorw(393)).
head(id(3080),ring_numbero(393)).
head(id(3081),cap_shapef(50)).
head(id(3082),gill_spacing(50)).
head(id(3083),gill_colorw(50)).
head(id(3084),stalk_rootr(50)).
head(id(3085),stalk_surface_above_rings(50)).
head(id(3086),stalk_color_above_ringw(50)).
head(id(3087),stalk_color_below_ringw(50)).
head(id(3088),veil_colorw(50)).
head(id(3089),ring_numbero(50)).
head(id(3090),cap_shapef(103)).
head(id(3091),gill_spacing(103)).
head(id(3092),gill_colorw(103)).
head(id(3093),stalk_rootr(103)).
head(id(3094),stalk_surface_above_rings(103)).
head(id(3095),stalk_color_above_ringw(103)).
head(id(3096),stalk_color_below_ringw(103)).
head(id(3097),veil_colorw(103)).
head(id(3098),ring_numbero(103)).
head(id(3099),cap_shapex(388)).
head(id(3100),cap_surfaces(388)).
head(id(3101),cap_colorn(388)).
head(id(3102),gill_colorn(388)).
head(id(3103),stalk_roote(388)).
head(id(3104),stalk_surface_above_rings(388)).
head(id(3105),stalk_surface_below_rings(388)).
head(id(3106),stalk_color_above_ringw(388)).
head(id(3107),stalk_color_below_ringw(388)).
head(id(3108),veil_colorw(388)).
head(id(3109),ring_numbero(388)).
head(id(3110),cap_surfaces(518)).
head(id(3111),gill_spacing(518)).
head(id(3112),gill_colork(518)).
head(id(3113),stalk_rootc(518)).
head(id(3114),stalk_surface_above_rings(518)).
head(id(3115),stalk_surface_below_rings(518)).
head(id(3116),stalk_color_above_ringw(518)).
head(id(3117),stalk_color_below_ringw(518)).
head(id(3118),veil_colorw(518)).
head(id(3119),ring_numbero(518)).
head(id(3120),cap_shapex(451)).
head(id(3121),cap_colorw(451)).
head(id(3122),gill_spacing(451)).
head(id(3123),gill_colork(451)).
head(id(3124),stalk_rootc(451)).
head(id(3125),stalk_surface_above_rings(451)).
head(id(3126),stalk_surface_below_rings(451)).
head(id(3127),stalk_color_above_ringw(451)).
head(id(3128),stalk_color_below_ringw(451)).
head(id(3129),veil_colorw(451)).
head(id(3130),ring_numbero(451)).
head(id(3131),cap_colorw(260)).
head(id(3132),gill_spacing(260)).
head(id(3133),gill_colorg(260)).
head(id(3134),stalk_rootc(260)).
head(id(3135),stalk_surface_above_rings(260)).
head(id(3136),stalk_surface_below_rings(260)).
head(id(3137),stalk_color_above_ringw(260)).
head(id(3138),stalk_color_below_ringw(260)).
head(id(3139),veil_colorw(260)).
head(id(3140),ring_numbero(260)).
head(id(3141),cap_surfaces(92)).
head(id(3142),cap_colorw(92)).
head(id(3143),gill_spacing(92)).
head(id(3144),gill_colork(92)).
head(id(3145),stalk_rootc(92)).
head(id(3146),stalk_surface_above_rings(92)).
head(id(3147),stalk_surface_below_rings(92)).
head(id(3148),stalk_color_above_ringw(92)).
head(id(3149),stalk_color_below_ringw(92)).
head(id(3150),veil_colorw(92)).
head(id(3151),ring_numbero(92)).
head(id(3152),cap_shapes(538)).
head(id(3153),cap_surfacef(538)).
head(id(3154),cap_colorn(538)).
head(id(3155),gill_spacing(538)).
head(id(3156),gill_size(538)).
head(id(3157),gill_colorp(538)).
head(id(3158),stalk_roote(538)).
head(id(3159),stalk_surface_above_rings(538)).
head(id(3160),stalk_surface_below_rings(538)).
head(id(3161),stalk_color_above_ringw(538)).
head(id(3162),stalk_color_below_ringw(538)).
head(id(3163),veil_colorw(538)).
head(id(3164),ring_numbero(538)).
head(id(3165),cap_shapef(352)).
head(id(3166),cap_colorn(352)).
head(id(3167),gill_spacing(352)).
head(id(3168),gill_colorp(352)).
head(id(3169),stalk_rootr(352)).
head(id(3170),stalk_surface_above_rings(352)).
head(id(3171),stalk_color_above_ringw(352)).
head(id(3172),stalk_color_below_ringw(352)).
head(id(3173),veil_colorw(352)).
head(id(3174),ring_numbero(352)).
head(id(3175),cap_surfaces(452)).
head(id(3176),cap_colorw(452)).
head(id(3177),gill_spacing(452)).
head(id(3178),gill_colorg(452)).
head(id(3179),stalk_rootc(452)).
head(id(3180),stalk_surface_above_rings(452)).
head(id(3181),stalk_surface_below_rings(452)).
head(id(3182),stalk_color_above_ringw(452)).
head(id(3183),stalk_color_below_ringw(452)).
head(id(3184),veil_colorw(452)).
head(id(3185),ring_numbero(452)).
head(id(3186),cap_shapef(57)).
head(id(3187),cap_surfacef(57)).
head(id(3188),cap_colorg(57)).
head(id(3189),gill_colorn(57)).
head(id(3190),stalk_roote(57)).
head(id(3191),stalk_surface_above_rings(57)).
head(id(3192),stalk_surface_below_rings(57)).
head(id(3193),stalk_color_above_ringw(57)).
head(id(3194),stalk_color_below_ringw(57)).
head(id(3195),veil_colorw(57)).
head(id(3196),ring_numbero(57)).
head(id(3197),cap_shapex(405)).
head(id(3198),cap_surfaces(405)).
head(id(3199),cap_colorw(405)).
head(id(3200),gill_spacing(405)).
head(id(3201),gill_colork(405)).
head(id(3202),stalk_rootc(405)).
head(id(3203),stalk_surface_above_rings(405)).
head(id(3204),stalk_surface_below_rings(405)).
head(id(3205),stalk_color_above_ringw(405)).
head(id(3206),stalk_color_below_ringw(405)).
head(id(3207),veil_colorw(405)).
head(id(3208),ring_numbero(405)).
head(id(3209),cap_shapex(515)).
head(id(3210),cap_surfacef(515)).
head(id(3211),cap_colorn(515)).
head(id(3212),gill_spacing(515)).
head(id(3213),gill_size(515)).
head(id(3214),gill_colork(515)).
head(id(3215),stalk_roote(515)).
head(id(3216),stalk_surface_above_rings(515)).
head(id(3217),stalk_surface_below_rings(515)).
head(id(3218),stalk_color_above_ringw(515)).
head(id(3219),stalk_color_below_ringw(515)).
head(id(3220),veil_colorw(515)).
head(id(3221),ring_numbero(515)).
head(id(3222),cap_surfaces(496)).
head(id(3223),gill_spacing(496)).
head(id(3224),gill_colork(496)).
head(id(3225),stalk_rootc(496)).
head(id(3226),stalk_surface_above_rings(496)).
head(id(3227),stalk_surface_below_rings(496)).
head(id(3228),stalk_color_above_ringw(496)).
head(id(3229),stalk_color_below_ringw(496)).
head(id(3230),veil_colorw(496)).
head(id(3231),ring_numbero(496)).
head(id(3232),cap_shapex(295)).
head(id(3233),cap_surfaces(295)).
head(id(3234),cap_colorw(295)).
head(id(3235),gill_spacing(295)).
head(id(3236),gill_colorg(295)).
head(id(3237),stalk_rootc(295)).
head(id(3238),stalk_surface_above_rings(295)).
head(id(3239),stalk_surface_below_rings(295)).
head(id(3240),stalk_color_above_ringw(295)).
head(id(3241),stalk_color_below_ringw(295)).
head(id(3242),veil_colorw(295)).
head(id(3243),ring_numbero(295)).
head(id(3244),cap_colorw(285)).
head(id(3245),gill_spacing(285)).
head(id(3246),gill_colorn(285)).
head(id(3247),stalk_rootc(285)).
head(id(3248),stalk_surface_above_rings(285)).
head(id(3249),stalk_surface_below_rings(285)).
head(id(3250),stalk_color_above_ringw(285)).
head(id(3251),stalk_color_below_ringw(285)).
head(id(3252),veil_colorw(285)).
head(id(3253),ring_numbero(285)).
head(id(3254),cap_shapex(276)).
head(id(3255),cap_colorn(276)).
head(id(3256),gill_spacing(276)).
head(id(3257),gill_colorw(276)).
head(id(3258),stalk_rootr(276)).
head(id(3259),stalk_surface_above_rings(276)).
head(id(3260),stalk_color_above_ringw(276)).
head(id(3261),stalk_color_below_ringw(276)).
head(id(3262),veil_colorw(276)).
head(id(3263),ring_numbero(276)).
head(id(3264),cap_colorw(402)).
head(id(3265),gill_spacing(402)).
head(id(3266),gill_colorn(402)).
head(id(3267),stalk_rootc(402)).
head(id(3268),stalk_surface_above_rings(402)).
head(id(3269),stalk_surface_below_rings(402)).
head(id(3270),stalk_color_above_ringw(402)).
head(id(3271),stalk_color_below_ringw(402)).
head(id(3272),veil_colorw(402)).
head(id(3273),ring_numbero(402)).
head(id(3274),cap_shapex(52)).
head(id(3275),cap_surfaces(52)).
head(id(3276),cap_colorw(52)).
head(id(3277),gill_spacing(52)).
head(id(3278),gill_colork(52)).
head(id(3279),stalk_rootc(52)).
head(id(3280),stalk_surface_above_rings(52)).
head(id(3281),stalk_surface_below_rings(52)).
head(id(3282),stalk_color_above_ringw(52)).
head(id(3283),stalk_color_below_ringw(52)).
head(id(3284),veil_colorw(52)).
head(id(3285),ring_numbero(52)).
head(id(3286),cap_shapef(240)).
head(id(3287),gill_spacing(240)).
head(id(3288),gill_colorp(240)).
head(id(3289),stalk_rootr(240)).
head(id(3290),stalk_surface_above_rings(240)).
head(id(3291),stalk_color_above_ringw(240)).
head(id(3292),stalk_color_below_ringw(240)).
head(id(3293),veil_colorw(240)).
head(id(3294),ring_numbero(240)).
head(id(3295),cap_shapes(220)).
head(id(3296),cap_surfacef(220)).
head(id(3297),cap_colorg(220)).
head(id(3298),gill_spacing(220)).
head(id(3299),gill_size(220)).
head(id(3300),gill_colorp(220)).
head(id(3301),stalk_roote(220)).
head(id(3302),stalk_surface_above_rings(220)).
head(id(3303),stalk_surface_below_rings(220)).
head(id(3304),stalk_color_above_ringw(220)).
head(id(3305),stalk_color_below_ringw(220)).
head(id(3306),veil_colorw(220)).
head(id(3307),ring_numbero(220)).
head(id(3308),cap_surfaces(10)).
head(id(3309),gill_spacing(10)).
head(id(3310),gill_colorg(10)).
head(id(3311),stalk_rootc(10)).
head(id(3312),stalk_surface_above_rings(10)).
head(id(3313),stalk_surface_below_rings(10)).
head(id(3314),stalk_color_above_ringw(10)).
head(id(3315),stalk_color_below_ringw(10)).
head(id(3316),veil_colorw(10)).
head(id(3317),ring_numbero(10)).
head(id(3318),cap_shapef(257)).
head(id(3319),cap_surfacef(257)).
head(id(3320),cap_colorn(257)).
head(id(3321),gill_spacing(257)).
head(id(3322),gill_size(257)).
head(id(3323),gill_colork(257)).
head(id(3324),stalk_roote(257)).
head(id(3325),stalk_surface_above_rings(257)).
head(id(3326),stalk_surface_below_rings(257)).
head(id(3327),stalk_color_above_ringw(257)).
head(id(3328),stalk_color_below_ringw(257)).
head(id(3329),veil_colorw(257)).
head(id(3330),ring_numbero(257)).
head(id(3331),cap_shapex(228)).
head(id(3332),cap_surfaces(228)).
head(id(3333),gill_spacing(228)).
head(id(3334),gill_colorg(228)).
head(id(3335),stalk_rootc(228)).
head(id(3336),stalk_surface_above_rings(228)).
head(id(3337),stalk_surface_below_rings(228)).
head(id(3338),stalk_color_above_ringw(228)).
head(id(3339),stalk_color_below_ringw(228)).
head(id(3340),veil_colorw(228)).
head(id(3341),ring_numbero(228)).
head(id(3342),cap_shapef(80)).
head(id(3343),cap_colorn(80)).
head(id(3344),gill_spacing(80)).
head(id(3345),gill_colorn(80)).
head(id(3346),stalk_rootr(80)).
head(id(3347),stalk_surface_above_rings(80)).
head(id(3348),stalk_color_above_ringw(80)).
head(id(3349),stalk_color_below_ringw(80)).
head(id(3350),veil_colorw(80)).
head(id(3351),ring_numbero(80)).
head(id(3352),cap_shapex(467)).
head(id(3353),cap_surfaces(467)).
head(id(3354),cap_colorw(467)).
head(id(3355),gill_spacing(467)).
head(id(3356),gill_colorg(467)).
head(id(3357),stalk_rootc(467)).
head(id(3358),stalk_surface_above_rings(467)).
head(id(3359),stalk_surface_below_rings(467)).
head(id(3360),stalk_color_above_ringw(467)).
head(id(3361),stalk_color_below_ringw(467)).
head(id(3362),veil_colorw(467)).
head(id(3363),ring_numbero(467)).
head(id(3364),cap_shapex(116)).
head(id(3365),gill_spacing(116)).
head(id(3366),gill_colorp(116)).
head(id(3367),stalk_rootr(116)).
head(id(3368),stalk_surface_above_rings(116)).
head(id(3369),stalk_color_above_ringw(116)).
head(id(3370),stalk_color_below_ringw(116)).
head(id(3371),veil_colorw(116)).
head(id(3372),ring_numbero(116)).
head(id(3373),cap_surfaces(187)).
head(id(3374),cap_colorw(187)).
head(id(3375),gill_spacing(187)).
head(id(3376),gill_colorg(187)).
head(id(3377),stalk_rootc(187)).
head(id(3378),stalk_surface_above_rings(187)).
head(id(3379),stalk_surface_below_rings(187)).
head(id(3380),stalk_color_above_ringw(187)).
head(id(3381),stalk_color_below_ringw(187)).
head(id(3382),veil_colorw(187)).
head(id(3383),ring_numbero(187)).
head(id(3384),cap_shapex(318)).
head(id(3385),cap_colorw(318)).
head(id(3386),gill_spacing(318)).
head(id(3387),gill_colork(318)).
head(id(3388),stalk_rootc(318)).
head(id(3389),stalk_surface_above_rings(318)).
head(id(3390),stalk_surface_below_rings(318)).
head(id(3391),stalk_color_above_ringw(318)).
head(id(3392),stalk_color_below_ringw(318)).
head(id(3393),veil_colorw(318)).
head(id(3394),ring_numbero(318)).
head(id(3395),cap_shapex(489)).
head(id(3396),cap_colorn(489)).
head(id(3397),gill_spacing(489)).
head(id(3398),gill_colorn(489)).
head(id(3399),stalk_rootr(489)).
head(id(3400),stalk_surface_above_rings(489)).
head(id(3401),stalk_color_above_ringw(489)).
head(id(3402),stalk_color_below_ringw(489)).
head(id(3403),veil_colorw(489)).
head(id(3404),ring_numbero(489)).
head(id(3405),cap_shapef(491)).
head(id(3406),cap_surfacef(491)).
head(id(3407),gill_size(491)).
head(id(3408),gill_colorn(491)).
head(id(3409),stalk_rootb(491)).
head(id(3410),stalk_surface_above_rings(491)).
head(id(3411),stalk_surface_below_rings(491)).
head(id(3412),stalk_color_above_ringw(491)).
head(id(3413),stalk_color_below_ringw(491)).
head(id(3414),veil_colorw(491)).
head(id(3415),ring_numbero(491)).
head(id(3416),cap_shapex(237)).
head(id(3417),cap_colorw(237)).
head(id(3418),gill_spacing(237)).
head(id(3419),gill_colorw(237)).
head(id(3420),stalk_rootc(237)).
head(id(3421),stalk_surface_above_rings(237)).
head(id(3422),stalk_surface_below_rings(237)).
head(id(3423),stalk_color_above_ringw(237)).
head(id(3424),stalk_color_below_ringw(237)).
head(id(3425),veil_colorw(237)).
head(id(3426),ring_numbero(237)).
head(id(3427),cap_shapex(394)).
head(id(3428),cap_surfacef(394)).
head(id(3429),cap_colorg(394)).
head(id(3430),gill_spacing(394)).
head(id(3431),gill_size(394)).
head(id(3432),gill_colork(394)).
head(id(3433),stalk_roote(394)).
head(id(3434),stalk_surface_above_rings(394)).
head(id(3435),stalk_surface_below_rings(394)).
head(id(3436),stalk_color_above_ringw(394)).
head(id(3437),stalk_color_below_ringw(394)).
head(id(3438),veil_colorw(394)).
head(id(3439),ring_numbero(394)).
head(id(3440),cap_surfaces(255)).
head(id(3441),cap_colorw(255)).
head(id(3442),gill_spacing(255)).
head(id(3443),gill_colorn(255)).
head(id(3444),stalk_rootc(255)).
head(id(3445),stalk_surface_above_rings(255)).
head(id(3446),stalk_surface_below_rings(255)).
head(id(3447),stalk_color_above_ringw(255)).
head(id(3448),stalk_color_below_ringw(255)).
head(id(3449),veil_colorw(255)).
head(id(3450),ring_numbero(255)).
head(id(3451),gill_spacing(282)).
head(id(3452),gill_colorn(282)).
head(id(3453),stalk_rootc(282)).
head(id(3454),stalk_surface_above_rings(282)).
head(id(3455),stalk_surface_below_rings(282)).
head(id(3456),stalk_color_above_ringw(282)).
head(id(3457),stalk_color_below_ringw(282)).
head(id(3458),veil_colorw(282)).
head(id(3459),ring_numbero(282)).
head(id(3460),cap_shapef(320)).
head(id(3461),cap_surfaces(320)).
head(id(3462),cap_colorw(320)).
head(id(3463),gill_size(320)).
head(id(3464),gill_colorw(320)).
head(id(3465),stalk_rootb(320)).
head(id(3466),stalk_surface_above_rings(320)).
head(id(3467),stalk_surface_below_rings(320)).
head(id(3468),stalk_color_above_ringw(320)).
head(id(3469),stalk_color_below_ringw(320)).
head(id(3470),veil_colorw(320)).
head(id(3471),ring_numbero(320)).
head(id(3472),cap_shapex(445)).
head(id(3473),cap_surfaces(445)).
head(id(3474),gill_spacing(445)).
head(id(3475),gill_colorw(445)).
head(id(3476),stalk_rootc(445)).
head(id(3477),stalk_surface_above_rings(445)).
head(id(3478),stalk_surface_below_rings(445)).
head(id(3479),stalk_color_above_ringw(445)).
head(id(3480),stalk_color_below_ringw(445)).
head(id(3481),veil_colorw(445)).
head(id(3482),ring_numbero(445)).
head(id(3483),cap_shapex(201)).
head(id(3484),gill_spacing(201)).
head(id(3485),gill_colorw(201)).
head(id(3486),stalk_rootc(201)).
head(id(3487),stalk_surface_above_rings(201)).
head(id(3488),stalk_surface_below_rings(201)).
head(id(3489),stalk_color_above_ringw(201)).
head(id(3490),stalk_color_below_ringw(201)).
head(id(3491),veil_colorw(201)).
head(id(3492),ring_numbero(201)).
head(id(3493),cap_shapef(459)).
head(id(3494),gill_spacing(459)).
head(id(3495),gill_colorn(459)).
head(id(3496),stalk_rootr(459)).
head(id(3497),stalk_surface_above_rings(459)).
head(id(3498),stalk_color_above_ringw(459)).
head(id(3499),stalk_color_below_ringw(459)).
head(id(3500),veil_colorw(459)).
head(id(3501),ring_numbero(459)).
head(id(3502),cap_shapex(362)).
head(id(3503),cap_surfacef(362)).
head(id(3504),cap_colorn(362)).
head(id(3505),gill_colorp(362)).
head(id(3506),stalk_roote(362)).
head(id(3507),stalk_surface_above_ringf(362)).
head(id(3508),stalk_surface_below_ringf(362)).
head(id(3509),stalk_color_above_ringw(362)).
head(id(3510),stalk_color_below_ringw(362)).
head(id(3511),veil_colorw(362)).
head(id(3512),ring_numbero(362)).
head(id(3513),cap_shapex(204)).
head(id(3514),cap_surfacef(204)).
head(id(3515),cap_colorw(204)).
head(id(3516),gill_colorh(204)).
head(id(3517),stalk_roote(204)).
head(id(3518),stalk_surface_above_ringf(204)).
head(id(3519),stalk_surface_below_rings(204)).
head(id(3520),stalk_color_above_ringw(204)).
head(id(3521),stalk_color_below_ringw(204)).
head(id(3522),veil_colorw(204)).
head(id(3523),ring_numbero(204)).
head(id(3524),cap_shapex(84)).
head(id(3525),cap_surfacef(84)).
head(id(3526),cap_colorg(84)).
head(id(3527),gill_colorn(84)).
head(id(3528),stalk_roote(84)).
head(id(3529),stalk_surface_above_rings(84)).
head(id(3530),stalk_surface_below_rings(84)).
head(id(3531),stalk_color_above_ringw(84)).
head(id(3532),stalk_color_below_ringw(84)).
head(id(3533),veil_colorw(84)).
head(id(3534),ring_numbero(84)).
head(id(3535),cap_shapex(242)).
head(id(3536),cap_surfaces(242)).
head(id(3537),cap_colorw(242)).
head(id(3538),gill_spacing(242)).
head(id(3539),gill_colorw(242)).
head(id(3540),stalk_rootc(242)).
head(id(3541),stalk_surface_above_rings(242)).
head(id(3542),stalk_surface_below_rings(242)).
head(id(3543),stalk_color_above_ringw(242)).
head(id(3544),stalk_color_below_ringw(242)).
head(id(3545),veil_colorw(242)).
head(id(3546),ring_numbero(242)).
head(id(3547),cap_shapex(314)).
head(id(3548),cap_surfacef(314)).
head(id(3549),cap_colorw(314)).
head(id(3550),gill_size(314)).
head(id(3551),gill_colorp(314)).
head(id(3552),stalk_rootb(314)).
head(id(3553),stalk_surface_above_rings(314)).
head(id(3554),stalk_surface_below_rings(314)).
head(id(3555),stalk_color_above_ringw(314)).
head(id(3556),stalk_color_below_ringw(314)).
head(id(3557),veil_colorw(314)).
head(id(3558),ring_numbero(314)).
head(id(3559),cap_shapef(510)).
head(id(3560),cap_surfacef(510)).
head(id(3561),cap_colorg(510)).
head(id(3562),gill_spacing(510)).
head(id(3563),gill_size(510)).
head(id(3564),gill_colorp(510)).
head(id(3565),stalk_roote(510)).
head(id(3566),stalk_surface_above_rings(510)).
head(id(3567),stalk_surface_below_rings(510)).
head(id(3568),stalk_color_above_ringw(510)).
head(id(3569),stalk_color_below_ringw(510)).
head(id(3570),veil_colorw(510)).
head(id(3571),ring_numbero(510)).
head(id(3572),cap_shapes(90)).
head(id(3573),cap_surfacef(90)).
head(id(3574),cap_colorn(90)).
head(id(3575),gill_spacing(90)).
head(id(3576),gill_size(90)).
head(id(3577),gill_colorn(90)).
head(id(3578),stalk_roote(90)).
head(id(3579),stalk_surface_above_rings(90)).
head(id(3580),stalk_surface_below_rings(90)).
head(id(3581),stalk_color_above_ringw(90)).
head(id(3582),stalk_color_below_ringw(90)).
head(id(3583),veil_colorw(90)).
head(id(3584),ring_numbero(90)).
head(id(3585),cap_colorw(150)).
head(id(3586),gill_spacing(150)).
head(id(3587),gill_colorg(150)).
head(id(3588),stalk_rootc(150)).
head(id(3589),stalk_surface_above_rings(150)).
head(id(3590),stalk_surface_below_rings(150)).
head(id(3591),stalk_color_above_ringw(150)).
head(id(3592),stalk_color_below_ringw(150)).
head(id(3593),veil_colorw(150)).
head(id(3594),ring_numbero(150)).
head(id(3595),cap_shapex(385)).
head(id(3596),cap_surfacef(385)).
head(id(3597),cap_colorn(385)).
head(id(3598),gill_spacing(385)).
head(id(3599),gill_colorn(385)).
head(id(3600),stalk_rootb(385)).
head(id(3601),stalk_surface_above_rings(385)).
head(id(3602),stalk_surface_below_rings(385)).
head(id(3603),stalk_color_above_ringg(385)).
head(id(3604),stalk_color_below_ringw(385)).
head(id(3605),veil_colorw(385)).
head(id(3606),ring_numbero(385)).
head(id(3607),cap_shapef(266)).
head(id(3608),cap_surfacef(266)).
head(id(3609),cap_colorg(266)).
head(id(3610),gill_spacing(266)).
head(id(3611),gill_size(266)).
head(id(3612),gill_colorg(266)).
head(id(3613),stalk_roote(266)).
head(id(3614),stalk_surface_above_rings(266)).
head(id(3615),stalk_surface_below_rings(266)).
head(id(3616),stalk_color_above_ringw(266)).
head(id(3617),stalk_color_below_ringw(266)).
head(id(3618),veil_colorw(266)).
head(id(3619),ring_numbero(266)).
head(id(3620),cap_shapex(233)).
head(id(3621),gill_spacing(233)).
head(id(3622),gill_colorn(233)).
head(id(3623),stalk_rootr(233)).
head(id(3624),stalk_surface_above_rings(233)).
head(id(3625),stalk_color_above_ringw(233)).
head(id(3626),stalk_color_below_ringw(233)).
head(id(3627),veil_colorw(233)).
head(id(3628),ring_numbero(233)).
head(id(3629),cap_shapex(190)).
head(id(3630),cap_colorn(190)).
head(id(3631),gill_spacing(190)).
head(id(3632),gill_colorw(190)).
head(id(3633),stalk_rootr(190)).
head(id(3634),stalk_surface_above_rings(190)).
head(id(3635),stalk_color_above_ringw(190)).
head(id(3636),stalk_color_below_ringw(190)).
head(id(3637),veil_colorw(190)).
head(id(3638),ring_numbero(190)).
head(id(3639),cap_shapex(217)).
head(id(3640),cap_surfaces(217)).
head(id(3641),gill_spacing(217)).
head(id(3642),gill_colorg(217)).
head(id(3643),stalk_rootc(217)).
head(id(3644),stalk_surface_above_rings(217)).
head(id(3645),stalk_surface_below_rings(217)).
head(id(3646),stalk_color_above_ringw(217)).
head(id(3647),stalk_color_below_ringw(217)).
head(id(3648),veil_colorw(217)).
head(id(3649),ring_numbero(217)).
head(id(3650),cap_shapex(250)).
head(id(3651),cap_surfaces(250)).
head(id(3652),cap_colorn(250)).
head(id(3653),gill_colorp(250)).
head(id(3654),stalk_roote(250)).
head(id(3655),stalk_surface_above_ringf(250)).
head(id(3656),stalk_surface_below_rings(250)).
head(id(3657),stalk_color_above_ringw(250)).
head(id(3658),stalk_color_below_ringw(250)).
head(id(3659),veil_colorw(250)).
head(id(3660),ring_numbero(250)).
head(id(3661),cap_shapex(49)).
head(id(3662),gill_spacing(49)).
head(id(3663),gill_colorn(49)).
head(id(3664),stalk_rootr(49)).
head(id(3665),stalk_surface_above_rings(49)).
head(id(3666),stalk_color_above_ringw(49)).
head(id(3667),stalk_color_below_ringw(49)).
head(id(3668),veil_colorw(49)).
head(id(3669),ring_numbero(49)).
head(id(3670),gill_spacing(41)).
head(id(3671),gill_colorn(41)).
head(id(3672),stalk_rootc(41)).
head(id(3673),stalk_surface_above_rings(41)).
head(id(3674),stalk_surface_below_rings(41)).
head(id(3675),stalk_color_above_ringw(41)).
head(id(3676),stalk_color_below_ringw(41)).
head(id(3677),veil_colorw(41)).
head(id(3678),ring_numbero(41)).
head(id(3679),cap_colorw(132)).
head(id(3680),gill_spacing(132)).
head(id(3681),gill_colorw(132)).
head(id(3682),stalk_rootc(132)).
head(id(3683),stalk_surface_above_rings(132)).
head(id(3684),stalk_surface_below_rings(132)).
head(id(3685),stalk_color_above_ringw(132)).
head(id(3686),stalk_color_below_ringw(132)).
head(id(3687),veil_colorw(132)).
head(id(3688),ring_numbero(132)).
head(id(3689),gill_spacing(62)).
head(id(3690),gill_colork(62)).
head(id(3691),stalk_rootc(62)).
head(id(3692),stalk_surface_above_rings(62)).
head(id(3693),stalk_surface_below_rings(62)).
head(id(3694),stalk_color_above_ringw(62)).
head(id(3695),stalk_color_below_ringw(62)).
head(id(3696),veil_colorw(62)).
head(id(3697),ring_numbero(62)).
head(id(3698),cap_shapex(114)).
head(id(3699),cap_surfaces(114)).
head(id(3700),gill_spacing(114)).
head(id(3701),gill_colorn(114)).
head(id(3702),stalk_rootc(114)).
head(id(3703),stalk_surface_above_rings(114)).
head(id(3704),stalk_surface_below_rings(114)).
head(id(3705),stalk_color_above_ringw(114)).
head(id(3706),stalk_color_below_ringw(114)).
head(id(3707),veil_colorw(114)).
head(id(3708),ring_numbero(114)).
head(id(3709),cap_shapef(137)).
head(id(3710),cap_surfacef(137)).
head(id(3711),cap_colorw(137)).
head(id(3712),gill_size(137)).
head(id(3713),gill_colorw(137)).
head(id(3714),stalk_rootb(137)).
head(id(3715),stalk_surface_above_rings(137)).
head(id(3716),stalk_surface_below_rings(137)).
head(id(3717),stalk_color_above_ringw(137)).
head(id(3718),stalk_color_below_ringw(137)).
head(id(3719),veil_colorw(137)).
head(id(3720),ring_numbero(137)).
head(id(3721),cap_shapef(344)).
head(id(3722),cap_surfacef(344)).
head(id(3723),gill_size(344)).
head(id(3724),gill_colorp(344)).
head(id(3725),stalk_rootb(344)).
head(id(3726),stalk_surface_above_rings(344)).
head(id(3727),stalk_surface_below_rings(344)).
head(id(3728),stalk_color_above_ringw(344)).
head(id(3729),stalk_color_below_ringw(344)).
head(id(3730),veil_colorw(344)).
head(id(3731),ring_numbero(344)).
head(id(3732),gill_spacing(439)).
head(id(3733),gill_colork(439)).
head(id(3734),stalk_rootc(439)).
head(id(3735),stalk_surface_above_rings(439)).
head(id(3736),stalk_surface_below_rings(439)).
head(id(3737),stalk_color_above_ringw(439)).
head(id(3738),stalk_color_below_ringw(439)).
head(id(3739),veil_colorw(439)).
head(id(3740),ring_numbero(439)).
head(id(3741),cap_shapex(96)).
head(id(3742),cap_surfaces(96)).
head(id(3743),cap_colorw(96)).
head(id(3744),gill_spacing(96)).
head(id(3745),gill_colorg(96)).
head(id(3746),stalk_rootc(96)).
head(id(3747),stalk_surface_above_rings(96)).
head(id(3748),stalk_surface_below_rings(96)).
head(id(3749),stalk_color_above_ringw(96)).
head(id(3750),stalk_color_below_ringw(96)).
head(id(3751),veil_colorw(96)).
head(id(3752),ring_numbero(96)).
head(id(3753),cap_shapef(460)).
head(id(3754),cap_colorn(460)).
head(id(3755),gill_spacing(460)).
head(id(3756),gill_colorw(460)).
head(id(3757),stalk_rootr(460)).
head(id(3758),stalk_surface_above_rings(460)).
head(id(3759),stalk_color_above_ringw(460)).
head(id(3760),stalk_color_below_ringw(460)).
head(id(3761),veil_colorw(460)).
head(id(3762),ring_numbero(460)).
head(id(3763),cap_shapex(173)).
head(id(3764),cap_surfacef(173)).
head(id(3765),gill_size(173)).
head(id(3766),gill_colorn(173)).
head(id(3767),stalk_rootb(173)).
head(id(3768),stalk_surface_above_rings(173)).
head(id(3769),stalk_surface_below_rings(173)).
head(id(3770),stalk_color_above_ringw(173)).
head(id(3771),stalk_color_below_ringw(173)).
head(id(3772),veil_colorw(173)).
head(id(3773),ring_numbero(173)).
head(id(3774),gill_spacing(292)).
head(id(3775),gill_colorn(292)).
head(id(3776),stalk_rootc(292)).
head(id(3777),stalk_surface_above_rings(292)).
head(id(3778),stalk_surface_below_rings(292)).
head(id(3779),stalk_color_above_ringw(292)).
head(id(3780),stalk_color_below_ringw(292)).
head(id(3781),veil_colorw(292)).
head(id(3782),ring_numbero(292)).
head(id(3783),cap_surfaces(58)).
head(id(3784),cap_colorw(58)).
head(id(3785),gill_spacing(58)).
head(id(3786),gill_colorw(58)).
head(id(3787),stalk_rootc(58)).
head(id(3788),stalk_surface_above_rings(58)).
head(id(3789),stalk_surface_below_rings(58)).
head(id(3790),stalk_color_above_ringw(58)).
head(id(3791),stalk_color_below_ringw(58)).
head(id(3792),veil_colorw(58)).
head(id(3793),ring_numbero(58)).
head(id(3794),cap_colorw(176)).
head(id(3795),gill_spacing(176)).
head(id(3796),gill_colorw(176)).
head(id(3797),stalk_rootc(176)).
head(id(3798),stalk_surface_above_rings(176)).
head(id(3799),stalk_surface_below_rings(176)).
head(id(3800),stalk_color_above_ringw(176)).
head(id(3801),stalk_color_below_ringw(176)).
head(id(3802),veil_colorw(176)).
head(id(3803),ring_numbero(176)).
head(id(3804),cap_shapex(303)).
head(id(3805),cap_surfaces(303)).
head(id(3806),gill_size(303)).
head(id(3807),gill_colorw(303)).
head(id(3808),stalk_rootb(303)).
head(id(3809),stalk_surface_above_rings(303)).
head(id(3810),stalk_surface_below_rings(303)).
head(id(3811),stalk_color_above_ringw(303)).
head(id(3812),stalk_color_below_ringw(303)).
head(id(3813),veil_colorw(303)).
head(id(3814),ring_numbero(303)).
head(id(3815),cap_shapef(185)).
head(id(3816),cap_colorn(185)).
head(id(3817),gill_spacing(185)).
head(id(3818),gill_colorp(185)).
head(id(3819),stalk_rootr(185)).
head(id(3820),stalk_surface_above_rings(185)).
head(id(3821),stalk_color_above_ringw(185)).
head(id(3822),stalk_color_below_ringw(185)).
head(id(3823),veil_colorw(185)).
head(id(3824),ring_numbero(185)).
head(id(3825),cap_surfaces(338)).
head(id(3826),gill_spacing(338)).
head(id(3827),gill_colorn(338)).
head(id(3828),stalk_rootc(338)).
head(id(3829),stalk_surface_above_rings(338)).
head(id(3830),stalk_surface_below_rings(338)).
head(id(3831),stalk_color_above_ringw(338)).
head(id(3832),stalk_color_below_ringw(338)).
head(id(3833),veil_colorw(338)).
head(id(3834),ring_numbero(338)).
head(id(3835),cap_shapex(321)).
head(id(3836),gill_spacing(321)).
head(id(3837),gill_colork(321)).
head(id(3838),stalk_rootc(321)).
head(id(3839),stalk_surface_above_rings(321)).
head(id(3840),stalk_surface_below_rings(321)).
head(id(3841),stalk_color_above_ringw(321)).
head(id(3842),stalk_color_below_ringw(321)).
head(id(3843),veil_colorw(321)).
head(id(3844),ring_numbero(321)).
head(id(3845),cap_shapex(359)).
head(id(3846),gill_spacing(359)).
head(id(3847),gill_colorp(359)).
head(id(3848),stalk_rootr(359)).
head(id(3849),stalk_surface_above_rings(359)).
head(id(3850),stalk_color_above_ringw(359)).
head(id(3851),stalk_color_below_ringw(359)).
head(id(3852),veil_colorw(359)).
head(id(3853),ring_numbero(359)).
head(id(3854),cap_shapes(37)).
head(id(3855),cap_surfacef(37)).
head(id(3856),cap_colorg(37)).
head(id(3857),gill_spacing(37)).
head(id(3858),gill_size(37)).
head(id(3859),gill_colork(37)).
head(id(3860),stalk_roote(37)).
head(id(3861),stalk_surface_above_rings(37)).
head(id(3862),stalk_surface_below_rings(37)).
head(id(3863),stalk_color_above_ringw(37)).
head(id(3864),stalk_color_below_ringw(37)).
head(id(3865),veil_colorw(37)).
head(id(3866),ring_numbero(37)).
head(id(3867),cap_surfaces(404)).
head(id(3868),gill_spacing(404)).
head(id(3869),gill_colorw(404)).
head(id(3870),stalk_rootc(404)).
head(id(3871),stalk_surface_above_rings(404)).
head(id(3872),stalk_surface_below_rings(404)).
head(id(3873),stalk_color_above_ringw(404)).
head(id(3874),stalk_color_below_ringw(404)).
head(id(3875),veil_colorw(404)).
head(id(3876),ring_numbero(404)).
head(id(3877),cap_shapef(466)).
head(id(3878),cap_colorn(466)).
head(id(3879),gill_spacing(466)).
head(id(3880),gill_colorp(466)).
head(id(3881),stalk_rootr(466)).
head(id(3882),stalk_surface_above_rings(466)).
head(id(3883),stalk_color_above_ringw(466)).
head(id(3884),stalk_color_below_ringw(466)).
head(id(3885),veil_colorw(466)).
head(id(3886),ring_numbero(466)).
head(id(3887),cap_shapex(46)).
head(id(3888),cap_colorw(46)).
head(id(3889),gill_spacing(46)).
head(id(3890),gill_colorn(46)).
head(id(3891),stalk_rootc(46)).
head(id(3892),stalk_surface_above_rings(46)).
head(id(3893),stalk_surface_below_rings(46)).
head(id(3894),stalk_color_above_ringw(46)).
head(id(3895),stalk_color_below_ringw(46)).
head(id(3896),veil_colorw(46)).
head(id(3897),ring_numbero(46)).
head(id(3898),cap_shapef(144)).
head(id(3899),cap_colorn(144)).
head(id(3900),gill_spacing(144)).
head(id(3901),gill_colorw(144)).
head(id(3902),stalk_rootr(144)).
head(id(3903),stalk_surface_above_rings(144)).
head(id(3904),stalk_color_above_ringw(144)).
head(id(3905),stalk_color_below_ringw(144)).
head(id(3906),veil_colorw(144)).
head(id(3907),ring_numbero(144)).
head(id(3908),cap_surfaces(434)).
head(id(3909),gill_spacing(434)).
head(id(3910),gill_colorw(434)).
head(id(3911),stalk_rootc(434)).
head(id(3912),stalk_surface_above_rings(434)).
head(id(3913),stalk_surface_below_rings(434)).
head(id(3914),stalk_color_above_ringw(434)).
head(id(3915),stalk_color_below_ringw(434)).
head(id(3916),veil_colorw(434)).
head(id(3917),ring_numbero(434)).
head(id(3918),cap_shapex(411)).
head(id(3919),cap_surfaces(411)).
head(id(3920),cap_colorw(411)).
head(id(3921),gill_spacing(411)).
head(id(3922),gill_colorw(411)).
head(id(3923),stalk_rootc(411)).
head(id(3924),stalk_surface_above_rings(411)).
head(id(3925),stalk_surface_below_rings(411)).
head(id(3926),stalk_color_above_ringw(411)).
head(id(3927),stalk_color_below_ringw(411)).
head(id(3928),veil_colorw(411)).
head(id(3929),ring_numbero(411)).
head(id(3930),cap_shapex(74)).
head(id(3931),cap_colorn(74)).
head(id(3932),gill_spacing(74)).
head(id(3933),gill_colorp(74)).
head(id(3934),stalk_rootr(74)).
head(id(3935),stalk_surface_above_rings(74)).
head(id(3936),stalk_color_above_ringw(74)).
head(id(3937),stalk_color_below_ringw(74)).
head(id(3938),veil_colorw(74)).
head(id(3939),ring_numbero(74)).
head(id(3940),gill_spacing(189)).
head(id(3941),gill_colorg(189)).
head(id(3942),stalk_rootc(189)).
head(id(3943),stalk_surface_above_rings(189)).
head(id(3944),stalk_surface_below_rings(189)).
head(id(3945),stalk_color_above_ringw(189)).
head(id(3946),stalk_color_below_ringw(189)).
head(id(3947),veil_colorw(189)).
head(id(3948),ring_numbero(189)).
head(id(3949),cap_shapex(36)).
head(id(3950),cap_surfacef(36)).
head(id(3951),gill_size(36)).
head(id(3952),gill_colorw(36)).
head(id(3953),stalk_rootb(36)).
head(id(3954),stalk_surface_above_rings(36)).
head(id(3955),stalk_surface_below_rings(36)).
head(id(3956),stalk_color_above_ringw(36)).
head(id(3957),stalk_color_below_ringw(36)).
head(id(3958),veil_colorw(36)).
head(id(3959),ring_numbero(36)).
head(id(3960),cap_shapex(529)).
head(id(3961),cap_surfacef(529)).
head(id(3962),cap_colorn(529)).
head(id(3963),gill_spacing(529)).
head(id(3964),gill_size(529)).
head(id(3965),gill_colork(529)).
head(id(3966),stalk_roote(529)).
head(id(3967),stalk_surface_above_rings(529)).
head(id(3968),stalk_surface_below_rings(529)).
head(id(3969),stalk_color_above_ringw(529)).
head(id(3970),stalk_color_below_ringw(529)).
head(id(3971),veil_colorw(529)).
head(id(3972),ring_numbero(529)).
head(id(3973),cap_surfaces(269)).
head(id(3974),cap_colorw(269)).
head(id(3975),gill_spacing(269)).
head(id(3976),gill_colork(269)).
head(id(3977),stalk_rootc(269)).
head(id(3978),stalk_surface_above_rings(269)).
head(id(3979),stalk_surface_below_rings(269)).
head(id(3980),stalk_color_above_ringw(269)).
head(id(3981),stalk_color_below_ringw(269)).
head(id(3982),veil_colorw(269)).
head(id(3983),ring_numbero(269)).
head(id(3984),cap_shapex(379)).
head(id(3985),gill_spacing(379)).
head(id(3986),gill_colork(379)).
head(id(3987),stalk_rootc(379)).
head(id(3988),stalk_surface_above_rings(379)).
head(id(3989),stalk_surface_below_rings(379)).
head(id(3990),stalk_color_above_ringw(379)).
head(id(3991),stalk_color_below_ringw(379)).
head(id(3992),veil_colorw(379)).
head(id(3993),ring_numbero(379)).
head(id(3994),cap_shapex(110)).
head(id(3995),cap_surfaces(110)).
head(id(3996),gill_spacing(110)).
head(id(3997),gill_colork(110)).
head(id(3998),stalk_rootc(110)).
head(id(3999),stalk_surface_above_rings(110)).
head(id(4000),stalk_surface_below_rings(110)).
head(id(4001),stalk_color_above_ringw(110)).
head(id(4002),stalk_color_below_ringw(110)).
head(id(4003),veil_colorw(110)).
head(id(4004),ring_numbero(110)).
head(id(4005),gill_spacing(502)).
head(id(4006),gill_colorg(502)).
head(id(4007),stalk_rootc(502)).
head(id(4008),stalk_surface_above_rings(502)).
head(id(4009),stalk_surface_below_rings(502)).
head(id(4010),stalk_color_above_ringw(502)).
head(id(4011),stalk_color_below_ringw(502)).
head(id(4012),veil_colorw(502)).
head(id(4013),ring_numbero(502)).
head(id(4014),cap_shapef(267)).
head(id(4015),cap_surfaces(267)).
head(id(4016),cap_colorg(267)).
head(id(4017),gill_colorp(267)).
head(id(4018),stalk_roote(267)).
head(id(4019),stalk_surface_above_rings(267)).
head(id(4020),stalk_surface_below_rings(267)).
head(id(4021),stalk_color_above_ringw(267)).
head(id(4022),stalk_color_below_ringw(267)).
head(id(4023),veil_colorw(267)).
head(id(4024),ring_numbero(267)).
head(id(4025),cap_shapef(224)).
head(id(4026),cap_surfacef(224)).
head(id(4027),cap_colorw(224)).
head(id(4028),gill_size(224)).
head(id(4029),gill_colorp(224)).
head(id(4030),stalk_rootb(224)).
head(id(4031),stalk_surface_above_rings(224)).
head(id(4032),stalk_surface_below_rings(224)).
head(id(4033),stalk_color_above_ringw(224)).
head(id(4034),stalk_color_below_ringw(224)).
head(id(4035),veil_colorw(224)).
head(id(4036),ring_numbero(224)).
head(id(4037),cap_colorw(342)).
head(id(4038),gill_spacing(342)).
head(id(4039),gill_colorn(342)).
head(id(4040),stalk_rootc(342)).
head(id(4041),stalk_surface_above_rings(342)).
head(id(4042),stalk_surface_below_rings(342)).
head(id(4043),stalk_color_above_ringw(342)).
head(id(4044),stalk_color_below_ringw(342)).
head(id(4045),veil_colorw(342)).
head(id(4046),ring_numbero(342)).
head(id(4047),cap_shapex(335)).
head(id(4048),cap_colorw(335)).
head(id(4049),gill_spacing(335)).
head(id(4050),gill_colorg(335)).
head(id(4051),stalk_rootc(335)).
head(id(4052),stalk_surface_above_rings(335)).
head(id(4053),stalk_surface_below_rings(335)).
head(id(4054),stalk_color_above_ringw(335)).
head(id(4055),stalk_color_below_ringw(335)).
head(id(4056),veil_colorw(335)).
head(id(4057),ring_numbero(335)).
head(id(4058),cap_shapef(508)).
head(id(4059),cap_surfaces(508)).
head(id(4060),cap_colorn(508)).
head(id(4061),gill_colorp(508)).
head(id(4062),stalk_roote(508)).
head(id(4063),stalk_surface_above_ringf(508)).
head(id(4064),stalk_surface_below_rings(508)).
head(id(4065),stalk_color_above_ringw(508)).
head(id(4066),stalk_color_below_ringw(508)).
head(id(4067),veil_colorw(508)).
head(id(4068),ring_numbero(508)).
head(id(4069),cap_colorw(256)).
head(id(4070),gill_spacing(256)).
head(id(4071),gill_colork(256)).
head(id(4072),stalk_rootc(256)).
head(id(4073),stalk_surface_above_rings(256)).
head(id(4074),stalk_surface_below_rings(256)).
head(id(4075),stalk_color_above_ringw(256)).
head(id(4076),stalk_color_below_ringw(256)).
head(id(4077),veil_colorw(256)).
head(id(4078),ring_numbero(256)).
head(id(4079),cap_shapef(420)).
head(id(4080),cap_surfacef(420)).
head(id(4081),cap_colorg(420)).
head(id(4082),gill_colorh(420)).
head(id(4083),stalk_roote(420)).
head(id(4084),stalk_surface_above_ringf(420)).
head(id(4085),stalk_surface_below_ringf(420)).
head(id(4086),stalk_color_above_ringw(420)).
head(id(4087),stalk_color_below_ringw(420)).
head(id(4088),veil_colorw(420)).
head(id(4089),ring_numbero(420)).
head(id(4090),cap_shapex(319)).
head(id(4091),cap_surfacef(319)).
head(id(4092),cap_colorw(319)).
head(id(4093),gill_size(319)).
head(id(4094),gill_colorn(319)).
head(id(4095),stalk_rootb(319)).
head(id(4096),stalk_surface_above_rings(319)).
head(id(4097),stalk_surface_below_rings(319)).
head(id(4098),stalk_color_above_ringw(319)).
head(id(4099),stalk_color_below_ringw(319)).
head(id(4100),veil_colorw(319)).
head(id(4101),ring_numbero(319)).
head(id(4102),cap_shapes(356)).
head(id(4103),cap_surfacef(356)).
head(id(4104),cap_colorg(356)).
head(id(4105),gill_spacing(356)).
head(id(4106),gill_size(356)).
head(id(4107),gill_colorg(356)).
head(id(4108),stalk_roote(356)).
head(id(4109),stalk_surface_above_rings(356)).
head(id(4110),stalk_surface_below_rings(356)).
head(id(4111),stalk_color_above_ringw(356)).
head(id(4112),stalk_color_below_ringw(356)).
head(id(4113),veil_colorw(356)).
head(id(4114),ring_numbero(356)).
head(id(4115),cap_shapef(275)).
head(id(4116),gill_spacing(275)).
head(id(4117),gill_colorn(275)).
head(id(4118),stalk_rootr(275)).
head(id(4119),stalk_surface_above_rings(275)).
head(id(4120),stalk_color_above_ringw(275)).
head(id(4121),stalk_color_below_ringw(275)).
head(id(4122),veil_colorw(275)).
head(id(4123),ring_numbero(275)).
head(id(4124),cap_surfaces(453)).
head(id(4125),gill_spacing(453)).
head(id(4126),gill_colorg(453)).
head(id(4127),stalk_rootc(453)).
head(id(4128),stalk_surface_above_rings(453)).
head(id(4129),stalk_surface_below_rings(453)).
head(id(4130),stalk_color_above_ringw(453)).
head(id(4131),stalk_color_below_ringw(453)).
head(id(4132),veil_colorw(453)).
head(id(4133),ring_numbero(453)).
head(id(4134),cap_shapef(147)).
head(id(4135),cap_surfacef(147)).
head(id(4136),cap_colorw(147)).
head(id(4137),gill_colork(147)).
head(id(4138),stalk_roote(147)).
head(id(4139),stalk_surface_above_rings(147)).
head(id(4140),stalk_surface_below_ringf(147)).
head(id(4141),stalk_color_above_ringw(147)).
head(id(4142),stalk_color_below_ringw(147)).
head(id(4143),veil_colorw(147)).
head(id(4144),ring_numbero(147)).
head(id(4145),cap_shapex(273)).
head(id(4146),cap_colorw(273)).
head(id(4147),gill_spacing(273)).
head(id(4148),gill_colork(273)).
head(id(4149),stalk_rootc(273)).
head(id(4150),stalk_surface_above_rings(273)).
head(id(4151),stalk_surface_below_rings(273)).
head(id(4152),stalk_color_above_ringw(273)).
head(id(4153),stalk_color_below_ringw(273)).
head(id(4154),veil_colorw(273)).
head(id(4155),ring_numbero(273)).
head(id(4156),cap_surfaces(354)).
head(id(4157),gill_spacing(354)).
head(id(4158),gill_colork(354)).
head(id(4159),stalk_rootc(354)).
head(id(4160),stalk_surface_above_rings(354)).
head(id(4161),stalk_surface_below_rings(354)).
head(id(4162),stalk_color_above_ringw(354)).
head(id(4163),stalk_color_below_ringw(354)).
head(id(4164),veil_colorw(354)).
head(id(4165),ring_numbero(354)).
head(id(4166),cap_shapex(383)).
head(id(4167),cap_colorw(383)).
head(id(4168),gill_spacing(383)).
head(id(4169),gill_colorw(383)).
head(id(4170),stalk_rootc(383)).
head(id(4171),stalk_surface_above_rings(383)).
head(id(4172),stalk_surface_below_rings(383)).
head(id(4173),stalk_color_above_ringw(383)).
head(id(4174),stalk_color_below_ringw(383)).
head(id(4175),veil_colorw(383)).
head(id(4176),ring_numbero(383)).
head(id(4177),cap_shapex(153)).
head(id(4178),cap_colorw(153)).
head(id(4179),gill_spacing(153)).
head(id(4180),gill_colorg(153)).
head(id(4181),stalk_rootc(153)).
head(id(4182),stalk_surface_above_rings(153)).
head(id(4183),stalk_surface_below_rings(153)).
head(id(4184),stalk_color_above_ringw(153)).
head(id(4185),stalk_color_below_ringw(153)).
head(id(4186),veil_colorw(153)).
head(id(4187),ring_numbero(153)).
head(id(4188),cap_shapex(325)).
head(id(4189),cap_colorn(325)).
head(id(4190),gill_spacing(325)).
head(id(4191),gill_colorp(325)).
head(id(4192),stalk_rootr(325)).
head(id(4193),stalk_surface_above_rings(325)).
head(id(4194),stalk_color_above_ringw(325)).
head(id(4195),stalk_color_below_ringw(325)).
head(id(4196),veil_colorw(325)).
head(id(4197),ring_numbero(325)).
head(id(4198),cap_shapex(507)).
head(id(4199),cap_surfaces(507)).
head(id(4200),cap_colorg(507)).
head(id(4201),gill_colorp(507)).
head(id(4202),stalk_roote(507)).
head(id(4203),stalk_surface_above_rings(507)).
head(id(4204),stalk_surface_below_rings(507)).
head(id(4205),stalk_color_above_ringw(507)).
head(id(4206),stalk_color_below_ringw(507)).
head(id(4207),veil_colorw(507)).
head(id(4208),ring_numbero(507)).
head(id(4209),gill_spacing(64)).
head(id(4210),gill_colorg(64)).
head(id(4211),stalk_rootc(64)).
head(id(4212),stalk_surface_above_rings(64)).
head(id(4213),stalk_surface_below_rings(64)).
head(id(4214),stalk_color_above_ringw(64)).
head(id(4215),stalk_color_below_ringw(64)).
head(id(4216),veil_colorw(64)).
head(id(4217),ring_numbero(64)).
head(id(4218),cap_shapex(392)).
head(id(4219),cap_surfaces(392)).
head(id(4220),gill_spacing(392)).
head(id(4221),gill_colorg(392)).
head(id(4222),stalk_rootc(392)).
head(id(4223),stalk_surface_above_rings(392)).
head(id(4224),stalk_surface_below_rings(392)).
head(id(4225),stalk_color_above_ringw(392)).
head(id(4226),stalk_color_below_ringw(392)).
head(id(4227),veil_colorw(392)).
head(id(4228),ring_numbero(392)).
head(id(4229),cap_shapex(148)).
head(id(4230),gill_spacing(148)).
head(id(4231),gill_colorw(148)).
head(id(4232),stalk_rootc(148)).
head(id(4233),stalk_surface_above_rings(148)).
head(id(4234),stalk_surface_below_rings(148)).
head(id(4235),stalk_color_above_ringw(148)).
head(id(4236),stalk_color_below_ringw(148)).
head(id(4237),veil_colorw(148)).
head(id(4238),ring_numbero(148)).
head(id(4239),cap_shapex(271)).
head(id(4240),cap_surfaces(271)).
head(id(4241),cap_colorw(271)).
head(id(4242),gill_spacing(271)).
head(id(4243),gill_colorn(271)).
head(id(4244),stalk_rootc(271)).
head(id(4245),stalk_surface_above_rings(271)).
head(id(4246),stalk_surface_below_rings(271)).
head(id(4247),stalk_color_above_ringw(271)).
head(id(4248),stalk_color_below_ringw(271)).
head(id(4249),veil_colorw(271)).
head(id(4250),ring_numbero(271)).
head(id(4251),cap_shapef(351)).
head(id(4252),cap_surfaces(351)).
head(id(4253),cap_colorg(351)).
head(id(4254),gill_colorh(351)).
head(id(4255),stalk_roote(351)).
head(id(4256),stalk_surface_above_ringf(351)).
head(id(4257),stalk_surface_below_ringf(351)).
head(id(4258),stalk_color_above_ringw(351)).
head(id(4259),stalk_color_below_ringw(351)).
head(id(4260),veil_colorw(351)).
head(id(4261),ring_numbero(351)).
head(id(4262),cap_shapex(479)).
head(id(4263),cap_surfaces(479)).
head(id(4264),cap_colorw(479)).
head(id(4265),gill_size(479)).
head(id(4266),gill_colorp(479)).
head(id(4267),stalk_rootb(479)).
head(id(4268),stalk_surface_above_rings(479)).
head(id(4269),stalk_surface_below_rings(479)).
head(id(4270),stalk_color_above_ringw(479)).
head(id(4271),stalk_color_below_ringw(479)).
head(id(4272),veil_colorw(479)).
head(id(4273),ring_numbero(479)).
head(id(4274),cap_shapex(129)).
head(id(4275),cap_surfaces(129)).
head(id(4276),cap_colorw(129)).
head(id(4277),gill_spacing(129)).
head(id(4278),gill_colorn(129)).
head(id(4279),stalk_rootc(129)).
head(id(4280),stalk_surface_above_rings(129)).
head(id(4281),stalk_surface_below_rings(129)).
head(id(4282),stalk_color_above_ringw(129)).
head(id(4283),stalk_color_below_ringw(129)).
head(id(4284),veil_colorw(129)).
head(id(4285),ring_numbero(129)).
head(id(4286),cap_shapex(134)).
head(id(4287),gill_spacing(134)).
head(id(4288),gill_colorg(134)).
head(id(4289),stalk_rootc(134)).
head(id(4290),stalk_surface_above_rings(134)).
head(id(4291),stalk_surface_below_rings(134)).
head(id(4292),stalk_color_above_ringw(134)).
head(id(4293),stalk_color_below_ringw(134)).
head(id(4294),veil_colorw(134)).
head(id(4295),ring_numbero(134)).
head(id(4296),gill_spacing(389)).
head(id(4297),gill_colorn(389)).
head(id(4298),stalk_rootc(389)).
head(id(4299),stalk_surface_above_rings(389)).
head(id(4300),stalk_surface_below_rings(389)).
head(id(4301),stalk_color_above_ringw(389)).
head(id(4302),stalk_color_below_ringw(389)).
head(id(4303),veil_colorw(389)).
head(id(4304),ring_numbero(389)).
head(id(4305),cap_shapex(48)).
head(id(4306),cap_surfaces(48)).
head(id(4307),cap_colorw(48)).
head(id(4308),gill_spacing(48)).
head(id(4309),gill_colorw(48)).
head(id(4310),stalk_rootc(48)).
head(id(4311),stalk_surface_above_rings(48)).
head(id(4312),stalk_surface_below_rings(48)).
head(id(4313),stalk_color_above_ringw(48)).
head(id(4314),stalk_color_below_ringw(48)).
head(id(4315),veil_colorw(48)).
head(id(4316),ring_numbero(48)).
head(id(4317),cap_shapex(39)).
head(id(4318),cap_surfacef(39)).
head(id(4319),gill_size(39)).
head(id(4320),gill_colorp(39)).
head(id(4321),stalk_rootb(39)).
head(id(4322),stalk_surface_above_rings(39)).
head(id(4323),stalk_surface_below_rings(39)).
head(id(4324),stalk_color_above_ringw(39)).
head(id(4325),stalk_color_below_ringw(39)).
head(id(4326),veil_colorw(39)).
head(id(4327),ring_numbero(39)).
head(id(4328),cap_shapex(146)).
head(id(4329),cap_surfacef(146)).
head(id(4330),cap_colorg(146)).
head(id(4331),gill_colork(146)).
head(id(4332),stalk_roote(146)).
head(id(4333),stalk_surface_above_ringf(146)).
head(id(4334),stalk_surface_below_ringf(146)).
head(id(4335),stalk_color_above_ringw(146)).
head(id(4336),stalk_color_below_ringw(146)).
head(id(4337),veil_colorw(146)).
head(id(4338),ring_numbero(146)).
head(id(4339),cap_shapex(464)).
head(id(4340),gill_spacing(464)).
head(id(4341),gill_colorw(464)).
head(id(4342),stalk_rootc(464)).
head(id(4343),stalk_surface_above_rings(464)).
head(id(4344),stalk_surface_below_rings(464)).
head(id(4345),stalk_color_above_ringw(464)).
head(id(4346),stalk_color_below_ringw(464)).
head(id(4347),veil_colorw(464)).
head(id(4348),ring_numbero(464)).
head(id(4349),cap_shapex(42)).
head(id(4350),gill_spacing(42)).
head(id(4351),gill_colorn(42)).
head(id(4352),stalk_rootr(42)).
head(id(4353),stalk_surface_above_rings(42)).
head(id(4354),stalk_color_above_ringw(42)).
head(id(4355),stalk_color_below_ringw(42)).
head(id(4356),veil_colorw(42)).
head(id(4357),ring_numbero(42)).
head(id(4358),cap_shapef(494)).
head(id(4359),cap_colorn(494)).
head(id(4360),gill_spacing(494)).
head(id(4361),gill_colorw(494)).
head(id(4362),stalk_rootr(494)).
head(id(4363),stalk_surface_above_rings(494)).
head(id(4364),stalk_color_above_ringw(494)).
head(id(4365),stalk_color_below_ringw(494)).
head(id(4366),veil_colorw(494)).
head(id(4367),ring_numbero(494)).
head(id(4368),cap_surfaces(457)).
head(id(4369),cap_colorw(457)).
head(id(4370),gill_spacing(457)).
head(id(4371),gill_colork(457)).
head(id(4372),stalk_rootc(457)).
head(id(4373),stalk_surface_above_rings(457)).
head(id(4374),stalk_surface_below_rings(457)).
head(id(4375),stalk_color_above_ringw(457)).
head(id(4376),stalk_color_below_ringw(457)).
head(id(4377),veil_colorw(457)).
head(id(4378),ring_numbero(457)).
head(id(4379),cap_surfaces(53)).
head(id(4380),cap_colorw(53)).
head(id(4381),gill_spacing(53)).
head(id(4382),gill_colork(53)).
head(id(4383),stalk_rootc(53)).
head(id(4384),stalk_surface_above_rings(53)).
head(id(4385),stalk_surface_below_rings(53)).
head(id(4386),stalk_color_above_ringw(53)).
head(id(4387),stalk_color_below_ringw(53)).
head(id(4388),veil_colorw(53)).
head(id(4389),ring_numbero(53)).
head(id(4390),cap_shapef(483)).
head(id(4391),cap_surfaces(483)).
head(id(4392),cap_colorw(483)).
head(id(4393),gill_size(483)).
head(id(4394),gill_colorp(483)).
head(id(4395),stalk_rootb(483)).
head(id(4396),stalk_surface_above_rings(483)).
head(id(4397),stalk_surface_below_rings(483)).
head(id(4398),stalk_color_above_ringw(483)).
head(id(4399),stalk_color_below_ringw(483)).
head(id(4400),veil_colorw(483)).
head(id(4401),ring_numbero(483)).
head(id(4402),cap_shapex(440)).
head(id(4403),cap_colorn(440)).
head(id(4404),gill_spacing(440)).
head(id(4405),gill_colorp(440)).
head(id(4406),stalk_rootr(440)).
head(id(4407),stalk_surface_above_rings(440)).
head(id(4408),stalk_color_above_ringw(440)).
head(id(4409),stalk_color_below_ringw(440)).
head(id(4410),veil_colorw(440)).
head(id(4411),ring_numbero(440)).
head(id(4412),cap_shapex(532)).
head(id(4413),cap_surfaces(532)).
head(id(4414),cap_colorw(532)).
head(id(4415),gill_spacing(532)).
head(id(4416),gill_colorn(532)).
head(id(4417),stalk_rootc(532)).
head(id(4418),stalk_surface_above_rings(532)).
head(id(4419),stalk_surface_below_rings(532)).
head(id(4420),stalk_color_above_ringw(532)).
head(id(4421),stalk_color_below_ringw(532)).
head(id(4422),veil_colorw(532)).
head(id(4423),ring_numbero(532)).
head(id(4424),cap_shapef(322)).
head(id(4425),cap_surfacef(322)).
head(id(4426),gill_size(322)).
head(id(4427),gill_colorw(322)).
head(id(4428),stalk_rootb(322)).
head(id(4429),stalk_surface_above_rings(322)).
head(id(4430),stalk_surface_below_rings(322)).
head(id(4431),stalk_color_above_ringw(322)).
head(id(4432),stalk_color_below_ringw(322)).
head(id(4433),veil_colorw(322)).
head(id(4434),ring_numbero(322)).
head(id(4435),cap_shapex(317)).
head(id(4436),cap_surfaces(317)).
head(id(4437),gill_size(317)).
head(id(4438),gill_colorw(317)).
head(id(4439),stalk_rootb(317)).
head(id(4440),stalk_surface_above_rings(317)).
head(id(4441),stalk_surface_below_rings(317)).
head(id(4442),stalk_color_above_ringw(317)).
head(id(4443),stalk_color_below_ringw(317)).
head(id(4444),veil_colorw(317)).
head(id(4445),ring_numbero(317)).
head(id(4446),cap_shapef(427)).
head(id(4447),cap_colorn(427)).
head(id(4448),gill_spacing(427)).
head(id(4449),gill_colorn(427)).
head(id(4450),stalk_rootr(427)).
head(id(4451),stalk_surface_above_rings(427)).
head(id(4452),stalk_color_above_ringw(427)).
head(id(4453),stalk_color_below_ringw(427)).
head(id(4454),veil_colorw(427)).
head(id(4455),ring_numbero(427)).
head(id(4456),gill_spacing(407)).
head(id(4457),gill_colorn(407)).
head(id(4458),stalk_rootc(407)).
head(id(4459),stalk_surface_above_rings(407)).
head(id(4460),stalk_surface_below_rings(407)).
head(id(4461),stalk_color_above_ringw(407)).
head(id(4462),stalk_color_below_ringw(407)).
head(id(4463),veil_colorw(407)).
head(id(4464),ring_numbero(407)).
head(id(4465),cap_shapef(66)).
head(id(4466),cap_surfaces(66)).
head(id(4467),cap_colorn(66)).
head(id(4468),gill_colork(66)).
head(id(4469),stalk_roote(66)).
head(id(4470),stalk_surface_above_rings(66)).
head(id(4471),stalk_surface_below_rings(66)).
head(id(4472),stalk_color_above_ringw(66)).
head(id(4473),stalk_color_below_ringw(66)).
head(id(4474),veil_colorw(66)).
head(id(4475),ring_numbero(66)).
head(id(4476),cap_surfaces(296)).
head(id(4477),gill_spacing(296)).
head(id(4478),gill_colorg(296)).
head(id(4479),stalk_rootc(296)).
head(id(4480),stalk_surface_above_rings(296)).
head(id(4481),stalk_surface_below_rings(296)).
head(id(4482),stalk_color_above_ringw(296)).
head(id(4483),stalk_color_below_ringw(296)).
head(id(4484),veil_colorw(296)).
head(id(4485),ring_numbero(296)).
head(id(4486),cap_shapef(475)).
head(id(4487),cap_surfaces(475)).
head(id(4488),gill_size(475)).
head(id(4489),gill_colorn(475)).
head(id(4490),stalk_rootb(475)).
head(id(4491),stalk_surface_above_rings(475)).
head(id(4492),stalk_surface_below_rings(475)).
head(id(4493),stalk_color_above_ringw(475)).
head(id(4494),stalk_color_below_ringw(475)).
head(id(4495),veil_colorw(475)).
head(id(4496),ring_numbero(475)).
head(id(4497),cap_shapex(413)).
head(id(4498),cap_colorn(413)).
head(id(4499),gill_spacing(413)).
head(id(4500),gill_colorn(413)).
head(id(4501),stalk_rootr(413)).
head(id(4502),stalk_surface_above_rings(413)).
head(id(4503),stalk_color_above_ringw(413)).
head(id(4504),stalk_color_below_ringw(413)).
head(id(4505),veil_colorw(413)).
head(id(4506),ring_numbero(413)).
head(id(4507),cap_surfaces(75)).
head(id(4508),gill_spacing(75)).
head(id(4509),gill_colork(75)).
head(id(4510),stalk_rootc(75)).
head(id(4511),stalk_surface_above_rings(75)).
head(id(4512),stalk_surface_below_rings(75)).
head(id(4513),stalk_color_above_ringw(75)).
head(id(4514),stalk_color_below_ringw(75)).
head(id(4515),veil_colorw(75)).
head(id(4516),ring_numbero(75)).
head(id(4517),cap_shapex(98)).
head(id(4518),cap_surfaces(98)).
head(id(4519),gill_spacing(98)).
head(id(4520),gill_colorn(98)).
head(id(4521),stalk_rootc(98)).
head(id(4522),stalk_surface_above_rings(98)).
head(id(4523),stalk_surface_below_rings(98)).
head(id(4524),stalk_color_above_ringw(98)).
head(id(4525),stalk_color_below_ringw(98)).
head(id(4526),veil_colorw(98)).
head(id(4527),ring_numbero(98)).
head(id(4528),cap_shapex(343)).
head(id(4529),cap_surfaces(343)).
head(id(4530),gill_spacing(343)).
head(id(4531),gill_colorg(343)).
head(id(4532),stalk_rootc(343)).
head(id(4533),stalk_surface_above_rings(343)).
head(id(4534),stalk_surface_below_rings(343)).
head(id(4535),stalk_color_above_ringw(343)).
head(id(4536),stalk_color_below_ringw(343)).
head(id(4537),veil_colorw(343)).
head(id(4538),ring_numbero(343)).
head(id(4539),cap_shapex(107)).
head(id(4540),gill_spacing(107)).
head(id(4541),gill_colorw(107)).
head(id(4542),stalk_rootr(107)).
head(id(4543),stalk_surface_above_rings(107)).
head(id(4544),stalk_color_above_ringw(107)).
head(id(4545),stalk_color_below_ringw(107)).
head(id(4546),veil_colorw(107)).
head(id(4547),ring_numbero(107)).
head(id(4548),cap_surfaces(99)).
head(id(4549),cap_colorw(99)).
head(id(4550),gill_spacing(99)).
head(id(4551),gill_colorg(99)).
head(id(4552),stalk_rootc(99)).
head(id(4553),stalk_surface_above_rings(99)).
head(id(4554),stalk_surface_below_rings(99)).
head(id(4555),stalk_color_above_ringw(99)).
head(id(4556),stalk_color_below_ringw(99)).
head(id(4557),veil_colorw(99)).
head(id(4558),ring_numbero(99)).
head(id(4559),cap_shapes(514)).
head(id(4560),cap_surfacef(514)).
head(id(4561),cap_colorg(514)).
head(id(4562),gill_spacing(514)).
head(id(4563),gill_size(514)).
head(id(4564),gill_colorn(514)).
head(id(4565),stalk_roote(514)).
head(id(4566),stalk_surface_above_rings(514)).
head(id(4567),stalk_surface_below_rings(514)).
head(id(4568),stalk_color_above_ringw(514)).
head(id(4569),stalk_color_below_ringw(514)).
head(id(4570),veil_colorw(514)).
head(id(4571),ring_numbero(514)).
head(id(4572),cap_shapex(495)).
head(id(4573),gill_spacing(495)).
head(id(4574),gill_colorw(495)).
head(id(4575),stalk_rootr(495)).
head(id(4576),stalk_surface_above_rings(495)).
head(id(4577),stalk_color_above_ringw(495)).
head(id(4578),stalk_color_below_ringw(495)).
head(id(4579),veil_colorw(495)).
head(id(4580),ring_numbero(495)).
head(id(4581),cap_shapex(280)).
head(id(4582),cap_surfaces(280)).
head(id(4583),gill_spacing(280)).
head(id(4584),gill_colork(280)).
head(id(4585),stalk_rootc(280)).
head(id(4586),stalk_surface_above_rings(280)).
head(id(4587),stalk_surface_below_rings(280)).
head(id(4588),stalk_color_above_ringw(280)).
head(id(4589),stalk_color_below_ringw(280)).
head(id(4590),veil_colorw(280)).
head(id(4591),ring_numbero(280)).
head(id(4592),cap_surfaces(7)).
head(id(4593),cap_colorw(7)).
head(id(4594),gill_spacing(7)).
head(id(4595),gill_colorg(7)).
head(id(4596),stalk_rootc(7)).
head(id(4597),stalk_surface_above_rings(7)).
head(id(4598),stalk_surface_below_rings(7)).
head(id(4599),stalk_color_above_ringw(7)).
head(id(4600),stalk_color_below_ringw(7)).
head(id(4601),veil_colorw(7)).
head(id(4602),ring_numbero(7)).
head(id(4603),cap_shapef(497)).
head(id(4604),cap_surfacef(497)).
head(id(4605),cap_colorw(497)).
head(id(4606),gill_colorh(497)).
head(id(4607),stalk_roote(497)).
head(id(4608),stalk_surface_above_ringf(497)).
head(id(4609),stalk_surface_below_rings(497)).
head(id(4610),stalk_color_above_ringw(497)).
head(id(4611),stalk_color_below_ringw(497)).
head(id(4612),veil_colorw(497)).
head(id(4613),ring_numbero(497)).
head(id(4614),cap_surfaces(172)).
head(id(4615),gill_spacing(172)).
head(id(4616),gill_colork(172)).
head(id(4617),stalk_rootc(172)).
head(id(4618),stalk_surface_above_rings(172)).
head(id(4619),stalk_surface_below_rings(172)).
head(id(4620),stalk_color_above_ringw(172)).
head(id(4621),stalk_color_below_ringw(172)).
head(id(4622),veil_colorw(172)).
head(id(4623),ring_numbero(172)).
head(id(4624),cap_colorw(210)).
head(id(4625),gill_spacing(210)).
head(id(4626),gill_colorw(210)).
head(id(4627),stalk_rootc(210)).
head(id(4628),stalk_surface_above_rings(210)).
head(id(4629),stalk_surface_below_rings(210)).
head(id(4630),stalk_color_above_ringw(210)).
head(id(4631),stalk_color_below_ringw(210)).
head(id(4632),veil_colorw(210)).
head(id(4633),ring_numbero(210)).
head(id(4634),cap_shapef(523)).
head(id(4635),gill_spacing(523)).
head(id(4636),gill_colorp(523)).
head(id(4637),stalk_rootr(523)).
head(id(4638),stalk_surface_above_rings(523)).
head(id(4639),stalk_color_above_ringw(523)).
head(id(4640),stalk_color_below_ringw(523)).
head(id(4641),veil_colorw(523)).
head(id(4642),ring_numbero(523)).
head(id(4643),gill_spacing(334)).
head(id(4644),gill_colorn(334)).
head(id(4645),stalk_rootc(334)).
head(id(4646),stalk_surface_above_rings(334)).
head(id(4647),stalk_surface_below_rings(334)).
head(id(4648),stalk_color_above_ringw(334)).
head(id(4649),stalk_color_below_ringw(334)).
head(id(4650),veil_colorw(334)).
head(id(4651),ring_numbero(334)).
head(id(4652),cap_shapef(372)).
head(id(4653),cap_colorn(372)).
head(id(4654),gill_spacing(372)).
head(id(4655),gill_colorn(372)).
head(id(4656),stalk_rootr(372)).
head(id(4657),stalk_surface_above_rings(372)).
head(id(4658),stalk_color_above_ringw(372)).
head(id(4659),stalk_color_below_ringw(372)).
head(id(4660),veil_colorw(372)).
head(id(4661),ring_numbero(372)).
head(id(4662),cap_shapex(397)).
head(id(4663),cap_surfaces(397)).
head(id(4664),cap_colorw(397)).
head(id(4665),gill_spacing(397)).
head(id(4666),gill_colork(397)).
head(id(4667),stalk_rootc(397)).
head(id(4668),stalk_surface_above_rings(397)).
head(id(4669),stalk_surface_below_rings(397)).
head(id(4670),stalk_color_above_ringw(397)).
head(id(4671),stalk_color_below_ringw(397)).
head(id(4672),veil_colorw(397)).
head(id(4673),ring_numbero(397)).
head(id(4674),cap_colorw(209)).
head(id(4675),gill_spacing(209)).
head(id(4676),gill_colorn(209)).
head(id(4677),stalk_rootc(209)).
head(id(4678),stalk_surface_above_rings(209)).
head(id(4679),stalk_surface_below_rings(209)).
head(id(4680),stalk_color_above_ringw(209)).
head(id(4681),stalk_color_below_ringw(209)).
head(id(4682),veil_colorw(209)).
head(id(4683),ring_numbero(209)).
head(id(4684),cap_shapes(182)).
head(id(4685),cap_surfacef(182)).
head(id(4686),cap_colorn(182)).
head(id(4687),gill_spacing(182)).
head(id(4688),gill_size(182)).
head(id(4689),gill_colorg(182)).
head(id(4690),stalk_roote(182)).
head(id(4691),stalk_surface_above_rings(182)).
head(id(4692),stalk_surface_below_rings(182)).
head(id(4693),stalk_color_above_ringw(182)).
head(id(4694),stalk_color_below_ringw(182)).
head(id(4695),veil_colorw(182)).
head(id(4696),ring_numbero(182)).
head(id(4697),cap_shapef(183)).
head(id(4698),cap_surfacef(183)).
head(id(4699),cap_colorn(183)).
head(id(4700),gill_spacing(183)).
head(id(4701),gill_size(183)).
head(id(4702),gill_colorg(183)).
head(id(4703),stalk_roote(183)).
head(id(4704),stalk_surface_above_rings(183)).
head(id(4705),stalk_surface_below_rings(183)).
head(id(4706),stalk_color_above_ringw(183)).
head(id(4707),stalk_color_below_ringw(183)).
head(id(4708),veil_colorw(183)).
head(id(4709),ring_numbero(183)).
head(id(9506,A),poisoned(A)) :- dom(A).
body(id(9506,A),cap_colorw(A)) :- dom(A).
body(id(9506,A),cap_shapex(A)) :- dom(A).
body(id(9506,A),gill_colork(A)) :- dom(A).
body(id(9506,A),gill_size(A)) :- dom(A).
body(id(9506,A),gill_spacing(A)) :- dom(A).
body(id(9506,A),ring_numbero(A)) :- dom(A).
body(id(9506,A),stalk_color_above_ringw(A)) :- dom(A).
body(id(9506,A),stalk_color_below_ringw(A)) :- dom(A).
body(id(9506,A),stalk_roote(A)) :- dom(A).
body(id(9506,A),stalk_surface_above_rings(A)) :- dom(A).
body(id(9506,A),stalk_surface_below_rings(A)) :- dom(A).
body(id(9506,A),veil_colorw(A)) :- dom(A).
head(id(14264,A),poisoned(A)) :- dom(A).
body(id(14264,A),cap_colorw(A)) :- dom(A).
body(id(14264,A),cap_shapex(A)) :- dom(A).
body(id(14264,A),gill_colorp(A)) :- dom(A).
body(id(14264,A),gill_size(A)) :- dom(A).
body(id(14264,A),gill_spacing(A)) :- dom(A).
body(id(14264,A),ring_numbero(A)) :- dom(A).
body(id(14264,A),stalk_color_above_ringw(A)) :- dom(A).
body(id(14264,A),stalk_color_below_ringw(A)) :- dom(A).
body(id(14264,A),stalk_roote(A)) :- dom(A).
body(id(14264,A),stalk_surface_above_rings(A)) :- dom(A).
body(id(14264,A),stalk_surface_below_rings(A)) :- dom(A).
body(id(14264,A),veil_colorw(A)) :- dom(A).
head(id(23809,A),poisoned(A)) :- dom(A).
body(id(23809,A),alpha_1(A)) :- dom(A).
body(id(23809,A),cap_colorn(A)) :- dom(A).
body(id(23809,A),cap_shapex(A)) :- dom(A).
body(id(23809,A),gill_colorn(A)) :- dom(A).
body(id(23809,A),gill_size(A)) :- dom(A).
body(id(23809,A),gill_spacing(A)) :- dom(A).
body(id(23809,A),ring_numbero(A)) :- dom(A).
body(id(23809,A),stalk_color_above_ringw(A)) :- dom(A).
body(id(23809,A),stalk_color_below_ringw(A)) :- dom(A).
body(id(23809,A),stalk_roote(A)) :- dom(A).
body(id(23809,A),stalk_surface_above_rings(A)) :- dom(A).
body(id(23809,A),stalk_surface_below_rings(A)) :- dom(A).
body(id(23809,A),veil_colorw(A)) :- dom(A).
head(id(28593,A),poisoned(A)) :- dom(A).
body(id(28593,A),cap_colorw(A)) :- dom(A).
body(id(28593,A),cap_shapex(A)) :- dom(A).
body(id(28593,A),gill_colorw(A)) :- dom(A).
body(id(28593,A),gill_size(A)) :- dom(A).
body(id(28593,A),gill_spacing(A)) :- dom(A).
body(id(28593,A),ring_numbero(A)) :- dom(A).
body(id(28593,A),stalk_color_above_ringw(A)) :- dom(A).
body(id(28593,A),stalk_color_below_ringw(A)) :- dom(A).
body(id(28593,A),stalk_roote(A)) :- dom(A).
body(id(28593,A),stalk_surface_above_rings(A)) :- dom(A).
body(id(28593,A),stalk_surface_below_rings(A)) :- dom(A).
body(id(28593,A),veil_colorw(A)) :- dom(A).
head(id(33384,A),poisoned(A)) :- dom(A).
body(id(33384,A),cap_colorn(A)) :- dom(A).
body(id(33384,A),cap_shapex(A)) :- dom(A).
body(id(33384,A),gill_colorw(A)) :- dom(A).
body(id(33384,A),gill_size(A)) :- dom(A).
body(id(33384,A),gill_spacing(A)) :- dom(A).
body(id(33384,A),ring_numbero(A)) :- dom(A).
body(id(33384,A),stalk_color_above_ringw(A)) :- dom(A).
body(id(33384,A),stalk_color_below_ringw(A)) :- dom(A).
body(id(33384,A),stalk_roote(A)) :- dom(A).
body(id(33384,A),stalk_surface_above_rings(A)) :- dom(A).
body(id(33384,A),stalk_surface_below_rings(A)) :- dom(A).
body(id(33384,A),veil_colorw(A)) :- dom(A).
head(id(42989,A),poisoned(A)) :- dom(A).
body(id(42989,A),alpha_2(A)) :- dom(A).
body(id(42989,A),cap_colorn(A)) :- dom(A).
body(id(42989,A),cap_shapex(A)) :- dom(A).
body(id(42989,A),gill_colork(A)) :- dom(A).
body(id(42989,A),gill_size(A)) :- dom(A).
body(id(42989,A),gill_spacing(A)) :- dom(A).
body(id(42989,A),ring_numbero(A)) :- dom(A).
body(id(42989,A),stalk_color_above_ringw(A)) :- dom(A).
body(id(42989,A),stalk_color_below_ringw(A)) :- dom(A).
body(id(42989,A),stalk_roote(A)) :- dom(A).
body(id(42989,A),stalk_surface_above_rings(A)) :- dom(A).
body(id(42989,A),stalk_surface_below_rings(A)) :- dom(A).
body(id(42989,A),veil_colorw(A)) :- dom(A).
head(id(52617,A),poisoned(A)) :- dom(A).
body(id(52617,A),alpha_3(A)) :- dom(A).
body(id(52617,A),cap_colorn(A)) :- dom(A).
body(id(52617,A),cap_shapex(A)) :- dom(A).
body(id(52617,A),gill_colorp(A)) :- dom(A).
body(id(52617,A),gill_size(A)) :- dom(A).
body(id(52617,A),gill_spacing(A)) :- dom(A).
body(id(52617,A),ring_numbero(A)) :- dom(A).
body(id(52617,A),stalk_color_above_ringw(A)) :- dom(A).
body(id(52617,A),stalk_color_below_ringw(A)) :- dom(A).
body(id(52617,A),stalk_roote(A)) :- dom(A).
body(id(52617,A),stalk_surface_above_rings(A)) :- dom(A).
body(id(52617,A),stalk_surface_below_rings(A)) :- dom(A).
body(id(52617,A),veil_colorw(A)) :- dom(A).
head(id(57439,A),poisoned(A)) :- dom(A).
body(id(57439,A),cap_colorn(A)) :- dom(A).
body(id(57439,A),cap_shapef(A)) :- dom(A).
body(id(57439,A),gill_colorw(A)) :- dom(A).
body(id(57439,A),gill_size(A)) :- dom(A).
body(id(57439,A),gill_spacing(A)) :- dom(A).
body(id(57439,A),ring_numbero(A)) :- dom(A).
body(id(57439,A),stalk_color_above_ringw(A)) :- dom(A).
body(id(57439,A),stalk_color_below_ringw(A)) :- dom(A).
body(id(57439,A),stalk_roote(A)) :- dom(A).
body(id(57439,A),stalk_surface_above_rings(A)) :- dom(A).
body(id(57439,A),stalk_surface_below_rings(A)) :- dom(A).
body(id(57439,A),veil_colorw(A)) :- dom(A).
head(id(62269,A),poisoned(A)) :- dom(A).
body(id(62269,A),cap_colorw(A)) :- dom(A).
body(id(62269,A),cap_shapex(A)) :- dom(A).
body(id(62269,A),gill_colorn(A)) :- dom(A).
body(id(62269,A),gill_size(A)) :- dom(A).
body(id(62269,A),gill_spacing(A)) :- dom(A).
body(id(62269,A),ring_numbero(A)) :- dom(A).
body(id(62269,A),stalk_color_above_ringw(A)) :- dom(A).
body(id(62269,A),stalk_color_below_ringw(A)) :- dom(A).
body(id(62269,A),stalk_roote(A)) :- dom(A).
body(id(62269,A),stalk_surface_above_rings(A)) :- dom(A).
body(id(62269,A),stalk_surface_below_rings(A)) :- dom(A).
body(id(62269,A),veil_colorw(A)) :- dom(A).
head(id(67108,A),poisoned(A)) :- dom(A).
body(id(67108,A),cap_colorn(A)) :- dom(A).
body(id(67108,A),cap_shapef(A)) :- dom(A).
body(id(67108,A),cap_surfaces(A)) :- dom(A).
body(id(67108,A),gill_colork(A)) :- dom(A).
body(id(67108,A),gill_size(A)) :- dom(A).
body(id(67108,A),gill_spacing(A)) :- dom(A).
body(id(67108,A),ring_numbero(A)) :- dom(A).
body(id(67108,A),stalk_color_above_ringw(A)) :- dom(A).
body(id(67108,A),stalk_color_below_ringw(A)) :- dom(A).
body(id(67108,A),stalk_roote(A)) :- dom(A).
body(id(67108,A),stalk_surface_above_rings(A)) :- dom(A).
body(id(67108,A),stalk_surface_below_rings(A)) :- dom(A).
body(id(67108,A),veil_colorw(A)) :- dom(A).
head(id(71960,A),poisoned(A)) :- dom(A).
body(id(71960,A),cap_colorn(A)) :- dom(A).
body(id(71960,A),cap_shapef(A)) :- dom(A).
body(id(71960,A),cap_surfaces(A)) :- dom(A).
body(id(71960,A),gill_colorp(A)) :- dom(A).
body(id(71960,A),gill_size(A)) :- dom(A).
body(id(71960,A),gill_spacing(A)) :- dom(A).
body(id(71960,A),ring_numbero(A)) :- dom(A).
body(id(71960,A),stalk_color_above_ringw(A)) :- dom(A).
body(id(71960,A),stalk_color_below_ringw(A)) :- dom(A).
body(id(71960,A),stalk_roote(A)) :- dom(A).
body(id(71960,A),stalk_surface_above_rings(A)) :- dom(A).
body(id(71960,A),stalk_surface_below_rings(A)) :- dom(A).
body(id(71960,A),veil_colorw(A)) :- dom(A).
head(id(76825,A),poisoned(A)) :- dom(A).
body(id(76825,A),cap_colorw(A)) :- dom(A).
body(id(76825,A),cap_shapef(A)) :- dom(A).
body(id(76825,A),cap_surfaces(A)) :- dom(A).
body(id(76825,A),gill_colorn(A)) :- dom(A).
body(id(76825,A),gill_size(A)) :- dom(A).
body(id(76825,A),gill_spacing(A)) :- dom(A).
body(id(76825,A),ring_numbero(A)) :- dom(A).
body(id(76825,A),stalk_color_above_ringw(A)) :- dom(A).
body(id(76825,A),stalk_color_below_ringw(A)) :- dom(A).
body(id(76825,A),stalk_roote(A)) :- dom(A).
body(id(76825,A),stalk_surface_above_rings(A)) :- dom(A).
body(id(76825,A),stalk_surface_below_rings(A)) :- dom(A).
body(id(76825,A),veil_colorw(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).

dom(1).
dom(5).
dom(6).
dom(7).
dom(9).
dom(10).
dom(11).
dom(12).
dom(13).
dom(14).
dom(15).
dom(16).
dom(17).
dom(19).
dom(20).
dom(21).
dom(23).
dom(24).
dom(25).
dom(26).
dom(27).
dom(28).
dom(29).
dom(30).
dom(32).
dom(34).
dom(35).
dom(36).
dom(37).
dom(38).
dom(39).
dom(41).
dom(42).
dom(43).
dom(44).
dom(45).
dom(46).
dom(48).
dom(49).
dom(50).
dom(51).
dom(52).
dom(53).
dom(54).
dom(55).
dom(56).
dom(57).
dom(58).
dom(59).
dom(61).
dom(62).
dom(63).
dom(64).
dom(65).
dom(66).
dom(68).
dom(69).
dom(70).
dom(71).
dom(72).
dom(73).
dom(74).
dom(75).
dom(77).
dom(79).
dom(80).
dom(81).
dom(82).
dom(83).
dom(84).
dom(85).
dom(86).
dom(89).
dom(90).
dom(91).
dom(92).
dom(93).
dom(95).
dom(96).
dom(97).
dom(98).
dom(99).
dom(101).
dom(102).
dom(103).
dom(104).
dom(105).
dom(107).
dom(109).
dom(110).
dom(111).
dom(113).
dom(114).
dom(115).
dom(116).
dom(117).
dom(118).
dom(120).
dom(121).
dom(122).
dom(125).
dom(126).
dom(127).
dom(128).
dom(129).
dom(130).
dom(132).
dom(133).
dom(134).
dom(136).
dom(137).
dom(138).
dom(139).
dom(140).
dom(142).
dom(143).
dom(144).
dom(145).
dom(146).
dom(147).
dom(148).
dom(149).
dom(150).
dom(151).
dom(152).
dom(153).
dom(155).
dom(156).
dom(157).
dom(159).
dom(160).
dom(161).
dom(162).
dom(163).
dom(164).
dom(166).
dom(169).
dom(170).
dom(171).
dom(172).
dom(173).
dom(175).
dom(176).
dom(177).
dom(178).
dom(179).
dom(180).
dom(181).
dom(182).
dom(183).
dom(184).
dom(185).
dom(186).
dom(187).
dom(189).
dom(190).
dom(191).
dom(192).
dom(193).
dom(194).
dom(196).
dom(199).
dom(201).
dom(202).
dom(204).
dom(205).
dom(208).
dom(209).
dom(210).
dom(211).
dom(214).
dom(215).
dom(216).
dom(217).
dom(218).
dom(219).
dom(220).
dom(221).
dom(223).
dom(224).
dom(225).
dom(227).
dom(228).
dom(230).
dom(231).
dom(232).
dom(233).
dom(237).
dom(238).
dom(239).
dom(240).
dom(241).
dom(242).
dom(243).
dom(244).
dom(246).
dom(247).
dom(248).
dom(249).
dom(250).
dom(251).
dom(252).
dom(253).
dom(255).
dom(256).
dom(257).
dom(258).
dom(260).
dom(262).
dom(263).
dom(266).
dom(267).
dom(268).
dom(269).
dom(270).
dom(271).
dom(272).
dom(273).
dom(275).
dom(276).
dom(277).
dom(280).
dom(281).
dom(282).
dom(283).
dom(284).
dom(285).
dom(287).
dom(288).
dom(289).
dom(290).
dom(291).
dom(292).
dom(294).
dom(295).
dom(296).
dom(300).
dom(301).
dom(302).
dom(303).
dom(304).
dom(305).
dom(306).
dom(307).
dom(308).
dom(309).
dom(310).
dom(311).
dom(312).
dom(313).
dom(314).
dom(315).
dom(317).
dom(318).
dom(319).
dom(320).
dom(321).
dom(322).
dom(324).
dom(325).
dom(327).
dom(328).
dom(329).
dom(330).
dom(331).
dom(332).
dom(333).
dom(334).
dom(335).
dom(338).
dom(339).
dom(340).
dom(341).
dom(342).
dom(343).
dom(344).
dom(345).
dom(346).
dom(347).
dom(348).
dom(349).
dom(350).
dom(351).
dom(352).
dom(353).
dom(354).
dom(356).
dom(358).
dom(359).
dom(360).
dom(362).
dom(363).
dom(364).
dom(365).
dom(367).
dom(368).
dom(369).
dom(370).
dom(371).
dom(372).
dom(375).
dom(376).
dom(378).
dom(379).
dom(380).
dom(381).
dom(382).
dom(383).
dom(384).
dom(385).
dom(386).
dom(387).
dom(388).
dom(389).
dom(390).
dom(391).
dom(392).
dom(393).
dom(394).
dom(396).
dom(397).
dom(398).
dom(399).
dom(400).
dom(402).
dom(403).
dom(404).
dom(405).
dom(406).
dom(407).
dom(408).
dom(409).
dom(410).
dom(411).
dom(412).
dom(413).
dom(415).
dom(417).
dom(418).
dom(419).
dom(420).
dom(422).
dom(423).
dom(424).
dom(425).
dom(426).
dom(427).
dom(429).
dom(431).
dom(433).
dom(434).
dom(436).
dom(437).
dom(438).
dom(439).
dom(440).
dom(441).
dom(443).
dom(444).
dom(445).
dom(446).
dom(447).
dom(448).
dom(449).
dom(451).
dom(452).
dom(453).
dom(456).
dom(457).
dom(459).
dom(460).
dom(461).
dom(462).
dom(463).
dom(464).
dom(465).
dom(466).
dom(467).
dom(468).
dom(469).
dom(470).
dom(472).
dom(474).
dom(475).
dom(476).
dom(477).
dom(479).
dom(480).
dom(481).
dom(482).
dom(483).
dom(485).
dom(486).
dom(487).
dom(489).
dom(490).
dom(491).
dom(492).
dom(493).
dom(494).
dom(495).
dom(496).
dom(497).
dom(502).
dom(503).
dom(505).
dom(507).
dom(508).
dom(509).
dom(510).
dom(511).
dom(512).
dom(514).
dom(515).
dom(516).
dom(517).
dom(518).
dom(520).
dom(521).
dom(522).
dom(523).
dom(524).
dom(525).
dom(526).
dom(528).
dom(529).
dom(530).
dom(532).
dom(534).
dom(535).
dom(536).
dom(538).
dom(539).
 :- not supported(poisoned(535)).
 :- not supported(poisoned(14)).
 :- not supported(poisoned(20)).
 :- not supported(poisoned(300)).
 :- not supported(poisoned(252)).
 :- not supported(poisoned(181)).
 :- not supported(poisoned(232)).
 :- not supported(poisoned(1)).
 :- not supported(poisoned(386)).
 :- not supported(poisoned(139)).
 :- not supported(poisoned(121)).
 :- not supported(poisoned(328)).
 :- not supported(poisoned(136)).
 :- not supported(poisoned(55)).
 :- not supported(poisoned(38)).
 :- not supported(poisoned(79)).
 :- not supported(poisoned(244)).
 :- not supported(poisoned(54)).
 :- not supported(poisoned(82)).
 :- not supported(poisoned(492)).
 :- not supported(poisoned(423)).
 :- not supported(poisoned(270)).
 :- not supported(poisoned(415)).
 :- not supported(poisoned(9)).
 :- not supported(poisoned(381)).
 :- not supported(poisoned(312)).
 :- not supported(poisoned(262)).
 :- not supported(poisoned(331)).
 :- not supported(poisoned(281)).
 :- not supported(poisoned(272)).
 :- not supported(poisoned(493)).
 :- not supported(poisoned(115)).
 :- not supported(poisoned(524)).
 :- not supported(poisoned(186)).
 :- not supported(poisoned(403)).
 :- not supported(poisoned(418)).
 :- not supported(poisoned(400)).
 :- not supported(poisoned(26)).
 :- not supported(poisoned(44)).
 :- not supported(poisoned(358)).
 :- not supported(poisoned(32)).
 :- not supported(poisoned(19)).
 :- supported(poisoned(339)).
 :- supported(poisoned(390)).
 :- supported(poisoned(516)).
 :- supported(poisoned(384)).
 :- supported(poisoned(216)).
 :- supported(poisoned(332)).
 :- supported(poisoned(472)).
 :- supported(poisoned(25)).
 :- supported(poisoned(341)).
 :- supported(poisoned(249)).
 :- supported(poisoned(142)).
 :- supported(poisoned(346)).
 :- supported(poisoned(539)).
 :- supported(poisoned(17)).
 :- supported(poisoned(155)).
 :- supported(poisoned(350)).
 :- supported(poisoned(436)).
 :- supported(poisoned(482)).
 :- supported(poisoned(474)).
 :- supported(poisoned(194)).
 :- supported(poisoned(398)).
 :- supported(poisoned(93)).
 :- supported(poisoned(140)).
 :- supported(poisoned(315)).
 :- supported(poisoned(85)).
 :- supported(poisoned(528)).
 :- supported(poisoned(246)).
 :- supported(poisoned(486)).
 :- supported(poisoned(56)).
 :- supported(poisoned(6)).
 :- supported(poisoned(72)).
 :- supported(poisoned(505)).
 :- supported(poisoned(289)).
 :- supported(poisoned(169)).
 :- supported(poisoned(521)).
 :- supported(poisoned(102)).
 :- supported(poisoned(43)).
 :- supported(poisoned(241)).
 :- supported(poisoned(368)).
 :- supported(poisoned(444)).
 :- supported(poisoned(164)).
 :- supported(poisoned(191)).
 :- supported(poisoned(396)).
 :- supported(poisoned(24)).
 :- supported(poisoned(159)).
 :- supported(poisoned(425)).
 :- supported(poisoned(382)).
 :- supported(poisoned(122)).
 :- supported(poisoned(438)).
 :- supported(poisoned(324)).
 :- supported(poisoned(126)).
 :- supported(poisoned(277)).
 :- supported(poisoned(111)).
 :- supported(poisoned(95)).
 :- supported(poisoned(370)).
 :- supported(poisoned(431)).
 :- supported(poisoned(410)).
 :- supported(poisoned(522)).
 :- supported(poisoned(304)).
 :- supported(poisoned(412)).
 :- supported(poisoned(239)).
 :- supported(poisoned(133)).
 :- supported(poisoned(101)).
 :- supported(poisoned(485)).
 :- supported(poisoned(143)).
 :- supported(poisoned(268)).
 :- supported(poisoned(35)).
 :- supported(poisoned(364)).
 :- supported(poisoned(170)).
 :- supported(poisoned(118)).
 :- supported(poisoned(308)).
 :- supported(poisoned(330)).
 :- supported(poisoned(369)).
 :- supported(poisoned(223)).
 :- supported(poisoned(443)).
 :- supported(poisoned(160)).
 :- supported(poisoned(180)).
 :- supported(poisoned(419)).
 :- supported(poisoned(61)).
 :- supported(poisoned(283)).
 :- supported(poisoned(313)).
 :- supported(poisoned(184)).
 :- supported(poisoned(448)).
 :- supported(poisoned(447)).
 :- supported(poisoned(70)).
 :- supported(poisoned(387)).
 :- supported(poisoned(503)).
 :- supported(poisoned(461)).
 :- supported(poisoned(391)).
 :- supported(poisoned(424)).
 :- supported(poisoned(417)).
 :- supported(poisoned(16)).
 :- supported(poisoned(441)).
 :- supported(poisoned(309)).
 :- supported(poisoned(526)).
 :- supported(poisoned(163)).
 :- supported(poisoned(208)).
 :- supported(poisoned(517)).
 :- supported(poisoned(227)).
 :- supported(poisoned(470)).
 :- supported(poisoned(175)).
 :- supported(poisoned(13)).
 :- supported(poisoned(360)).
 :- supported(poisoned(429)).
 :- supported(poisoned(333)).
 :- supported(poisoned(462)).
 :- supported(poisoned(120)).
 :- supported(poisoned(59)).
 :- supported(poisoned(15)).
 :- supported(poisoned(211)).
 :- supported(poisoned(433)).
 :- supported(poisoned(520)).
 :- supported(poisoned(69)).
 :- supported(poisoned(302)).
 :- supported(poisoned(23)).
 :- supported(poisoned(29)).
 :- supported(poisoned(152)).
 :- supported(poisoned(349)).
 :- supported(poisoned(348)).
 :- supported(poisoned(68)).
 :- supported(poisoned(138)).
 :- supported(poisoned(327)).
 :- supported(poisoned(399)).
 :- supported(poisoned(310)).
 :- supported(poisoned(365)).
 :- supported(poisoned(534)).
 :- supported(poisoned(487)).
 :- supported(poisoned(12)).
 :- supported(poisoned(177)).
 :- supported(poisoned(225)).
 :- supported(poisoned(437)).
 :- supported(poisoned(480)).
 :- supported(poisoned(83)).
 :- supported(poisoned(477)).
 :- supported(poisoned(171)).
 :- supported(poisoned(219)).
 :- supported(poisoned(456)).
 :- supported(poisoned(247)).
 :- supported(poisoned(258)).
 :- supported(poisoned(125)).
 :- supported(poisoned(476)).
 :- supported(poisoned(11)).
 :- supported(poisoned(86)).
 :- supported(poisoned(214)).
 :- supported(poisoned(81)).
 :- supported(poisoned(89)).
 :- supported(poisoned(196)).
 :- supported(poisoned(104)).
 :- supported(poisoned(128)).
 :- supported(poisoned(509)).
 :- supported(poisoned(157)).
 :- supported(poisoned(28)).
 :- supported(poisoned(238)).
 :- supported(poisoned(145)).
 :- supported(poisoned(45)).
 :- supported(poisoned(162)).
 :- supported(poisoned(287)).
 :- supported(poisoned(77)).
 :- supported(poisoned(291)).
 :- supported(poisoned(367)).
 :- supported(poisoned(65)).
 :- supported(poisoned(199)).
 :- supported(poisoned(307)).
 :- supported(poisoned(375)).
 :- supported(poisoned(51)).
 :- supported(poisoned(63)).
 :- supported(poisoned(127)).
 :- supported(poisoned(301)).
 :- supported(poisoned(179)).
 :- supported(poisoned(218)).
 :- supported(poisoned(263)).
 :- supported(poisoned(205)).
 :- supported(poisoned(248)).
 :- supported(poisoned(329)).
 :- supported(poisoned(215)).
 :- supported(poisoned(117)).
 :- supported(poisoned(512)).
 :- supported(poisoned(490)).
 :- supported(poisoned(5)).
 :- supported(poisoned(30)).
 :- supported(poisoned(446)).
 :- supported(poisoned(481)).
 :- supported(poisoned(71)).
 :- supported(poisoned(409)).
 :- supported(poisoned(230)).
 :- supported(poisoned(378)).
 :- supported(poisoned(376)).
 :- supported(poisoned(113)).
 :- supported(poisoned(380)).
 :- supported(poisoned(91)).
 :- supported(poisoned(109)).
 :- supported(poisoned(21)).
 :- supported(poisoned(290)).
 :- supported(poisoned(161)).
 :- supported(poisoned(422)).
 :- supported(poisoned(311)).
 :- supported(poisoned(73)).
 :- supported(poisoned(408)).
 :- supported(poisoned(468)).
 :- supported(poisoned(406)).
 :- supported(poisoned(288)).
 :- supported(poisoned(192)).
 :- supported(poisoned(130)).
 :- supported(poisoned(156)).
 :- supported(poisoned(363)).
 :- supported(poisoned(465)).
 :- supported(poisoned(166)).
 :- supported(poisoned(27)).
 :- supported(poisoned(251)).
 :- supported(poisoned(97)).
 :- supported(poisoned(306)).
 :- supported(poisoned(353)).
 :- supported(poisoned(253)).
 :- supported(poisoned(105)).
 :- supported(poisoned(371)).
 :- supported(poisoned(284)).
 :- supported(poisoned(463)).
 :- supported(poisoned(193)).
 :- supported(poisoned(426)).
 :- supported(poisoned(34)).
 :- supported(poisoned(231)).
 :- supported(poisoned(511)).
 :- supported(poisoned(221)).
 :- supported(poisoned(345)).
 :- supported(poisoned(243)).
 :- supported(poisoned(149)).
 :- supported(poisoned(469)).
 :- supported(poisoned(151)).
 :- supported(poisoned(294)).
 :- supported(poisoned(536)).
 :- supported(poisoned(340)).
 :- supported(poisoned(347)).
 :- supported(poisoned(202)).
 :- supported(poisoned(530)).
 :- supported(poisoned(525)).
 :- supported(poisoned(449)).
 :- supported(poisoned(178)).
 :- supported(poisoned(305)).
 :- supported(poisoned(393)).
 :- supported(poisoned(50)).
 :- supported(poisoned(103)).
 :- supported(poisoned(388)).
 :- supported(poisoned(518)).
 :- supported(poisoned(451)).
 :- supported(poisoned(260)).
 :- supported(poisoned(92)).
 :- supported(poisoned(538)).
 :- supported(poisoned(352)).
 :- supported(poisoned(452)).
 :- supported(poisoned(57)).
 :- supported(poisoned(405)).
 :- supported(poisoned(515)).
 :- supported(poisoned(496)).
 :- supported(poisoned(295)).
 :- supported(poisoned(285)).
 :- supported(poisoned(276)).
 :- supported(poisoned(402)).
 :- supported(poisoned(52)).
 :- supported(poisoned(240)).
 :- supported(poisoned(220)).
 :- supported(poisoned(10)).
 :- supported(poisoned(257)).
 :- supported(poisoned(228)).
 :- supported(poisoned(80)).
 :- supported(poisoned(467)).
 :- supported(poisoned(116)).
 :- supported(poisoned(187)).
 :- supported(poisoned(318)).
 :- supported(poisoned(489)).
 :- supported(poisoned(491)).
 :- supported(poisoned(237)).
 :- supported(poisoned(394)).
 :- supported(poisoned(255)).
 :- supported(poisoned(282)).
 :- supported(poisoned(320)).
 :- supported(poisoned(445)).
 :- supported(poisoned(201)).
 :- supported(poisoned(459)).
 :- supported(poisoned(362)).
 :- supported(poisoned(204)).
 :- supported(poisoned(84)).
 :- supported(poisoned(242)).
 :- supported(poisoned(314)).
 :- supported(poisoned(510)).
 :- supported(poisoned(90)).
 :- supported(poisoned(150)).
 :- supported(poisoned(385)).
 :- supported(poisoned(266)).
 :- supported(poisoned(233)).
 :- supported(poisoned(190)).
 :- supported(poisoned(217)).
 :- supported(poisoned(250)).
 :- supported(poisoned(49)).
 :- supported(poisoned(41)).
 :- supported(poisoned(132)).
 :- supported(poisoned(62)).
 :- supported(poisoned(114)).
 :- supported(poisoned(137)).
 :- supported(poisoned(344)).
 :- supported(poisoned(439)).
 :- supported(poisoned(96)).
 :- supported(poisoned(460)).
 :- supported(poisoned(173)).
 :- supported(poisoned(292)).
 :- supported(poisoned(58)).
 :- supported(poisoned(176)).
 :- supported(poisoned(303)).
 :- supported(poisoned(185)).
 :- supported(poisoned(338)).
 :- supported(poisoned(321)).
 :- supported(poisoned(359)).
 :- supported(poisoned(37)).
 :- supported(poisoned(404)).
 :- supported(poisoned(466)).
 :- supported(poisoned(46)).
 :- supported(poisoned(144)).
 :- supported(poisoned(434)).
 :- supported(poisoned(411)).
 :- supported(poisoned(74)).
 :- supported(poisoned(189)).
 :- supported(poisoned(36)).
 :- supported(poisoned(529)).
 :- supported(poisoned(269)).
 :- supported(poisoned(379)).
 :- supported(poisoned(110)).
 :- supported(poisoned(502)).
 :- supported(poisoned(267)).
 :- supported(poisoned(224)).
 :- supported(poisoned(342)).
 :- supported(poisoned(335)).
 :- supported(poisoned(508)).
 :- supported(poisoned(256)).
 :- supported(poisoned(420)).
 :- supported(poisoned(319)).
 :- supported(poisoned(356)).
 :- supported(poisoned(275)).
 :- supported(poisoned(453)).
 :- supported(poisoned(147)).
 :- supported(poisoned(273)).
 :- supported(poisoned(354)).
 :- supported(poisoned(383)).
 :- supported(poisoned(153)).
 :- supported(poisoned(325)).
 :- supported(poisoned(507)).
 :- supported(poisoned(64)).
 :- supported(poisoned(392)).
 :- supported(poisoned(148)).
 :- supported(poisoned(271)).
 :- supported(poisoned(351)).
 :- supported(poisoned(479)).
 :- supported(poisoned(129)).
 :- supported(poisoned(134)).
 :- supported(poisoned(389)).
 :- supported(poisoned(48)).
 :- supported(poisoned(39)).
 :- supported(poisoned(146)).
 :- supported(poisoned(464)).
 :- supported(poisoned(42)).
 :- supported(poisoned(494)).
 :- supported(poisoned(457)).
 :- supported(poisoned(53)).
 :- supported(poisoned(483)).
 :- supported(poisoned(440)).
 :- supported(poisoned(532)).
 :- supported(poisoned(322)).
 :- supported(poisoned(317)).
 :- supported(poisoned(427)).
 :- supported(poisoned(407)).
 :- supported(poisoned(66)).
 :- supported(poisoned(296)).
 :- supported(poisoned(475)).
 :- supported(poisoned(413)).
 :- supported(poisoned(75)).
 :- supported(poisoned(98)).
 :- supported(poisoned(343)).
 :- supported(poisoned(107)).
 :- supported(poisoned(99)).
 :- supported(poisoned(514)).
 :- supported(poisoned(495)).
 :- supported(poisoned(280)).
 :- supported(poisoned(7)).
 :- supported(poisoned(497)).
 :- supported(poisoned(172)).
 :- supported(poisoned(210)).
 :- supported(poisoned(523)).
 :- supported(poisoned(334)).
 :- supported(poisoned(372)).
 :- supported(poisoned(397)).
 :- supported(poisoned(209)).
 :- supported(poisoned(182)).
 :- supported(poisoned(183)).
