head(id(1),lo(59)).
head(id(2),a4(59)).
head(id(3),a5(59)).
head(id(4),a6(59)).
head(id(5),lo(47)).
head(id(6),a4(47)).
head(id(7),a5(47)).
head(id(8),hi(102)).
head(id(9),a2(102)).
head(id(10),a3(102)).
head(id(11),a4(102)).
head(id(12),a5(102)).
head(id(13),a6(102)).
head(id(14),lo(54)).
head(id(15),a4(54)).
head(id(16),a5(54)).
head(id(17),a6(54)).
head(id(18),hi(71)).
head(id(19),a2(71)).
head(id(20),a3(71)).
head(id(21),a4(71)).
head(id(22),a5(71)).
head(id(23),a6(71)).
head(id(24),hi(89)).
head(id(25),a2(89)).
head(id(26),a3(89)).
head(id(27),a4(89)).
head(id(28),a5(89)).
head(id(29),lo(43)).
head(id(30),a4(43)).
head(id(31),a5(43)).
head(id(32),a6(43)).
head(id(33),lo(44)).
head(id(34),a4(44)).
head(id(35),hi(80)).
head(id(36),a2(80)).
head(id(37),a3(80)).
head(id(38),a4(80)).
head(id(39),a5(80)).
head(id(40),a6(80)).
head(id(41),vh(115)).
head(id(42),a2(115)).
head(id(43),a3(115)).
head(id(44),a4(115)).
head(id(45),a5(115)).
head(id(46),hi(100)).
head(id(47),a2(100)).
head(id(48),a3(100)).
head(id(49),a4(100)).
head(id(50),a5(100)).
head(id(51),a4(34)).
head(id(52),lo(48)).
head(id(53),a4(48)).
head(id(54),a5(48)).
head(id(55),a6(48)).
head(id(56),hi(90)).
head(id(57),a2(90)).
head(id(58),a3(90)).
head(id(59),a4(90)).
head(id(60),a5(90)).
head(id(61),a6(90)).
head(id(62),a4(32)).
head(id(63),a5(32)).
head(id(64),a4(27)).
head(id(65),a5(27)).
head(id(66),a6(27)).
head(id(67),a4(7)).
head(id(68),a5(7)).
head(id(69),a6(7)).
head(id(70),lo(52)).
head(id(71),a4(52)).
head(id(72),a4(28)).
head(id(73),hi(79)).
head(id(74),a2(79)).
head(id(75),a3(79)).
head(id(76),a4(79)).
head(id(77),a5(79)).
head(id(78),vh(106)).
head(id(79),a2(106)).
head(id(80),a3(106)).
head(id(81),a4(106)).
head(id(82),a5(106)).
head(id(83),a6(106)).
head(id(84),a4(21)).
head(id(85),a5(21)).
head(id(86),vh(111)).
head(id(87),a2(111)).
head(id(88),a3(111)).
head(id(89),a4(111)).
head(id(90),a5(111)).
head(id(91),a6(111)).
head(id(92),a4(26)).
head(id(93),a5(26)).
head(id(94),a6(26)).
head(id(95),a4(24)).
head(id(96),a5(24)).
head(id(97),a6(24)).
head(id(98),a4(14)).
head(id(99),a5(14)).
head(id(100),a6(14)).
head(id(101),lo(39)).
head(id(102),a4(39)).
head(id(103),lo(40)).
head(id(104),a4(40)).
head(id(105),a5(40)).
head(id(106),a4(4)).
head(id(107),a5(4)).
head(id(108),a6(4)).
head(id(109),hi(99)).
head(id(110),a2(99)).
head(id(111),a3(99)).
head(id(112),a4(99)).
head(id(113),a5(99)).
head(id(114),hi(94)).
head(id(115),a2(94)).
head(id(116),a3(94)).
head(id(117),a4(94)).
head(id(118),a5(94)).
head(id(119),a4(2)).
head(id(120),a5(2)).
head(id(121),a6(2)).
head(id(122),lo(37)).
head(id(123),a4(37)).
head(id(124),a4(31)).
head(id(125),a4(25)).
head(id(126),a5(25)).
head(id(127),a6(25)).
head(id(128),a4(9)).
head(id(129),a5(9)).
head(id(130),a6(9)).
head(id(131),hi(72)).
head(id(132),a2(72)).
head(id(133),a3(72)).
head(id(134),a4(72)).
head(id(135),a5(72)).
head(id(136),a6(72)).
head(id(137),hi(73)).
head(id(138),a2(73)).
head(id(139),a3(73)).
head(id(140),a4(73)).
head(id(141),a5(73)).
head(id(142),a4(30)).
head(id(143),a5(30)).
head(id(144),a6(30)).
head(id(145),hi(84)).
head(id(146),a2(84)).
head(id(147),a3(84)).
head(id(148),a4(84)).
head(id(149),a5(84)).
head(id(150),a6(84)).
head(id(151),lo(55)).
head(id(152),a4(55)).
head(id(153),lo(36)).
head(id(154),a4(36)).
head(id(155),a5(36)).
head(id(156),a6(36)).
head(id(157),vh(107)).
head(id(158),a2(107)).
head(id(159),a3(107)).
head(id(160),a4(107)).
head(id(161),a5(107)).
head(id(162),a4(22)).
head(id(163),a5(22)).
head(id(164),a4(11)).
head(id(165),a5(11)).
head(id(166),a6(11)).
head(id(167),a4(18)).
head(id(168),a5(18)).
head(id(169),a6(18)).
head(id(170),hi(86)).
head(id(171),a2(86)).
head(id(172),a3(86)).
head(id(173),a4(86)).
head(id(174),a5(86)).
head(id(175),lo(56)).
head(id(176),a4(56)).
head(id(177),a5(56)).
head(id(178),hi(91)).
head(id(179),vh(117)).
head(id(180),a3(15)).
head(id(181),hi(78)).
head(id(182),a3(78)).
head(id(183),a4(78)).
head(id(184),a6(78)).
head(id(185),hi(74)).
head(id(186),hi(83)).
head(id(187),a3(83)).
head(id(188),a4(83)).
head(id(189),a6(83)).
head(id(190),a3(1)).
head(id(191),mo(64)).
head(id(192),a3(64)).
head(id(193),a4(64)).
head(id(194),a6(64)).
head(id(195),hi(82)).
head(id(196),a2(82)).
head(id(197),a3(82)).
head(id(198),a5(82)).
head(id(199),vh(110)).
head(id(200),a3(110)).
head(id(201),a4(110)).
head(id(202),a6(110)).
head(id(203),hi(96)).
head(id(204),a2(96)).
head(id(205),a3(96)).
head(id(206),a5(96)).
head(id(207),vh(120)).
head(id(208),a3(120)).
head(id(209),a4(120)).
head(id(210),a6(120)).
head(id(211),hi(76)).
head(id(212),a2(76)).
head(id(213),a3(76)).
head(id(214),a5(76)).
head(id(215),mo(66)).
head(id(216),a3(66)).
head(id(217),a4(66)).
head(id(218),a6(66)).
head(id(219),mo(63)).
head(id(220),a3(63)).
head(id(221),a4(63)).
head(id(222),a6(63)).
head(id(223),a3(29)).
head(id(224),hi(88)).
head(id(225),a2(88)).
head(id(226),a3(88)).
head(id(227),a5(88)).
head(id(228),lo(62)).
head(id(229),a3(62)).
head(id(230),a4(62)).
head(id(231),a6(62)).
head(id(232),hi(70)).
head(id(233),a3(70)).
head(id(234),a4(70)).
head(id(235),a6(70)).
head(id(236),hi(87)).
head(id(237),a3(12)).
head(id(238),hi(104)).
head(id(239),a2(104)).
head(id(240),a3(104)).
head(id(241),a5(104)).
head(id(242),mo(65)).
head(id(243),a3(65)).
head(id(244),a4(65)).
head(id(245),a6(65)).
head(id(246),hi(97)).
head(id(247),a3(97)).
head(id(248),a4(97)).
head(id(249),a6(97)).
head(id(250),vh(118)).
head(id(251),a2(118)).
head(id(252),a3(118)).
head(id(253),a5(118)).
head(id(254),lo(61)).
head(id(255),a3(61)).
head(id(256),a4(61)).
head(id(257),a6(61)).
head(id(258),vh(113)).
head(id(259),a2(113)).
head(id(260),a3(113)).
head(id(261),a5(113)).
head(id(262),hi(103)).
head(id(263),lo(53)).
head(id(264),a3(53)).
head(id(265),mo(68)).
head(id(266),a3(68)).
head(id(267),a4(68)).
head(id(268),a6(68)).
head(id(269),hi(69)).
head(id(270),a3(69)).
head(id(271),a4(69)).
head(id(272),a6(69)).
head(id(273),a3(5)).
head(id(274),a3(3)).
head(id(275),lo(42)).
head(id(276),a3(42)).
head(id(277),a3(33)).
head(id(278),lo(38)).
head(id(279),a3(38)).
head(id(280),vh(116)).
head(id(281),a3(116)).
head(id(282),a4(116)).
head(id(283),a6(116)).
head(id(284),a3(20)).
head(id(285),hi(75)).
head(id(286),hi(92)).
head(id(287),a2(92)).
head(id(288),a3(92)).
head(id(289),a5(92)).
head(id(290),hi(77)).
head(id(291),a2(77)).
head(id(292),a3(77)).
head(id(293),a5(77)).
head(id(294),vh(112)).
head(id(295),lo(35)).
head(id(296),a3(35)).
head(id(297),hi(98)).
head(id(298),a3(98)).
head(id(299),a4(98)).
head(id(300),a6(98)).
head(id(301),a3(16)).
head(id(302),vh(114)).
head(id(303),a3(114)).
head(id(304),a4(114)).
head(id(305),a6(114)).
head(id(306),lo(41)).
head(id(307),a3(41)).
head(id(308),lo(58)).
head(id(309),a3(58)).
head(id(310),a3(8)).
head(id(1033,A),acute(A)) :- dom(A).
body(id(1033,A),alpha_1(A)) :- dom(A).
body(id(1033,A),a4(A)) :- dom(A).
head(id(1386,A),c_alpha_1(A)) :- dom(A).
body(id(1386,A),a3(A)) :- dom(A).
body(id(1386,A),a4(A)) :- dom(A).
body(id(1386,A),a6(A)) :- dom(A).
body(id(1386,A),lo(A)) :- dom(A).
head(id(1722,A),c_alpha_1(A)) :- dom(A).
body(id(1722,A),a3(A)) :- dom(A).
body(id(1722,A),a4(A)) :- dom(A).
body(id(1722,A),a6(A)) :- dom(A).
body(id(1722,A),mo(A)) :- dom(A).
head(id(2393,A),c_alpha_1(A)) :- dom(A).
body(id(2393,A),alpha_2(A)) :- dom(A).
body(id(2393,A),a3(A)) :- dom(A).
body(id(2393,A),a4(A)) :- dom(A).
body(id(2393,A),a6(A)) :- dom(A).
body(id(2393,A),hi(A)) :- dom(A).
head(id(3091,A),c_alpha_1(A)) :- dom(A).
body(id(3091,A),alpha_3(A)) :- dom(A).
body(id(3091,A),a3(A)) :- dom(A).
body(id(3091,A),a4(A)) :- dom(A).
body(id(3091,A),a6(A)) :- dom(A).
body(id(3091,A),vh(A)) :- dom(A).
head(id(3446,A),c_alpha_2(A)) :- dom(A).
body(id(3446,A),a2(A)) :- dom(A).
body(id(3446,A),a3(A)) :- dom(A).
body(id(3446,A),a4(A)) :- dom(A).
body(id(3446,A),a5(A)) :- dom(A).
body(id(3446,A),a6(A)) :- dom(A).
body(id(3446,A),hi(A)) :- dom(A).
head(id(3797,A),c_alpha_3(A)) :- dom(A).
body(id(3797,A),a2(A)) :- dom(A).
body(id(3797,A),a3(A)) :- dom(A).
body(id(3797,A),a4(A)) :- dom(A).
body(id(3797,A),a5(A)) :- dom(A).
body(id(3797,A),a6(A)) :- dom(A).
body(id(3797,A),vh(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).

dom(1).
dom(2).
dom(3).
dom(4).
dom(5).
dom(7).
dom(8).
dom(9).
dom(11).
dom(12).
dom(14).
dom(15).
dom(16).
dom(18).
dom(20).
dom(21).
dom(22).
dom(24).
dom(25).
dom(26).
dom(27).
dom(28).
dom(29).
dom(30).
dom(31).
dom(32).
dom(33).
dom(34).
dom(35).
dom(36).
dom(37).
dom(38).
dom(39).
dom(40).
dom(41).
dom(42).
dom(43).
dom(44).
dom(47).
dom(48).
dom(52).
dom(53).
dom(54).
dom(55).
dom(56).
dom(58).
dom(59).
dom(61).
dom(62).
dom(63).
dom(64).
dom(65).
dom(66).
dom(68).
dom(69).
dom(70).
dom(71).
dom(72).
dom(73).
dom(74).
dom(75).
dom(76).
dom(77).
dom(78).
dom(79).
dom(80).
dom(82).
dom(83).
dom(84).
dom(86).
dom(87).
dom(88).
dom(89).
dom(90).
dom(91).
dom(92).
dom(94).
dom(96).
dom(97).
dom(98).
dom(99).
dom(100).
dom(102).
dom(103).
dom(104).
dom(106).
dom(107).
dom(110).
dom(111).
dom(112).
dom(113).
dom(114).
dom(115).
dom(116).
dom(117).
dom(118).
dom(120).
 :- not supported(acute(59)).
 :- not supported(acute(47)).
 :- not supported(acute(102)).
 :- not supported(acute(54)).
 :- not supported(acute(71)).
 :- not supported(acute(89)).
 :- not supported(acute(43)).
 :- not supported(acute(44)).
 :- not supported(acute(80)).
 :- not supported(acute(115)).
 :- not supported(acute(100)).
 :- not supported(acute(34)).
 :- not supported(acute(48)).
 :- not supported(acute(90)).
 :- not supported(acute(32)).
 :- not supported(acute(27)).
 :- not supported(acute(7)).
 :- not supported(acute(52)).
 :- not supported(acute(28)).
 :- not supported(acute(79)).
 :- not supported(acute(106)).
 :- not supported(acute(21)).
 :- not supported(acute(111)).
 :- not supported(acute(26)).
 :- not supported(acute(24)).
 :- not supported(acute(14)).
 :- not supported(acute(39)).
 :- not supported(acute(40)).
 :- not supported(acute(4)).
 :- not supported(acute(99)).
 :- not supported(acute(94)).
 :- not supported(acute(2)).
 :- not supported(acute(37)).
 :- not supported(acute(31)).
 :- not supported(acute(25)).
 :- not supported(acute(9)).
 :- not supported(acute(72)).
 :- not supported(acute(73)).
 :- not supported(acute(30)).
 :- not supported(acute(84)).
 :- not supported(acute(55)).
 :- not supported(acute(36)).
 :- not supported(acute(107)).
 :- not supported(acute(22)).
 :- not supported(acute(11)).
 :- not supported(acute(18)).
 :- not supported(acute(86)).
 :- not supported(acute(56)).
 :- supported(acute(91)).
 :- supported(acute(117)).
 :- supported(acute(15)).
 :- supported(acute(78)).
 :- supported(acute(74)).
 :- supported(acute(83)).
 :- supported(acute(1)).
 :- supported(acute(64)).
 :- supported(acute(82)).
 :- supported(acute(110)).
 :- supported(acute(96)).
 :- supported(acute(120)).
 :- supported(acute(76)).
 :- supported(acute(66)).
 :- supported(acute(63)).
 :- supported(acute(29)).
 :- supported(acute(88)).
 :- supported(acute(62)).
 :- supported(acute(70)).
 :- supported(acute(87)).
 :- supported(acute(12)).
 :- supported(acute(104)).
 :- supported(acute(65)).
 :- supported(acute(97)).
 :- supported(acute(118)).
 :- supported(acute(61)).
 :- supported(acute(113)).
 :- supported(acute(103)).
 :- supported(acute(53)).
 :- supported(acute(68)).
 :- supported(acute(69)).
 :- supported(acute(5)).
 :- supported(acute(3)).
 :- supported(acute(42)).
 :- supported(acute(33)).
 :- supported(acute(38)).
 :- supported(acute(116)).
 :- supported(acute(20)).
 :- supported(acute(75)).
 :- supported(acute(92)).
 :- supported(acute(77)).
 :- supported(acute(112)).
 :- supported(acute(35)).
 :- supported(acute(98)).
 :- supported(acute(16)).
 :- supported(acute(114)).
 :- supported(acute(41)).
 :- supported(acute(58)).
 :- supported(acute(8)).
