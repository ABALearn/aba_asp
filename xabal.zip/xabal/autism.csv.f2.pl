% training data:
% no. positive ex.: 14
% no. negative ex.: 27
% query: 
train :- aba_asp('./xabal/autism.csv.f2.bk',[autism(434),autism(529),autism(124),autism(521),autism(654),autism(203),autism(224),autism(189),autism(693),autism(472),autism(545),autism(494),autism(638),autism(449)],[autism(304),autism(608),autism(64),autism(294),autism(132),autism(600),autism(295),autism(133),autism(88),autism(205),autism(267),autism(321),autism(286),autism(527),autism(110),autism(342),autism(306),autism(581),autism(617),autism(676),autism(157),autism(44),autism(131),autism(259),autism(470),autism(489),autism(9)]).
% test data:
% no. positive ex.: 3
% no. negative ex.: 6
% query: 
test :- test_abaf('./xabal/autism.csv.f2.bk.sol',[pos(autism(509),[a1(509),a2(509),a3(509),a4(509),a5(509),a6(509),a7(509),a8(509),a9(509),a10(509),age4(509),female(509),white(509),jaundice(509),pdd(509),self(509)]),pos(autism(660),[a1(660),a2(660),a3(660),a4(660),a5(660),a6(660),a9(660),a10(660),age4(660)]),pos(autism(559),[a1(559),a2(559),a3(559),a4(559),a5(559),a6(559),a7(559),a8(559),a10(559),age2(559),female(559),white(559),self(559)])],[neg(autism(215),[a1(215),a2(215),a3(215),a4(215),a10(215),age4(215),white(215),self(215)]),neg(autism(633),[a3(633),a8(633),age2(633),female(633),asian(633),parent(633)]),neg(autism(202),[a1(202),a2(202),a4(202),a5(202),a9(202),a10(202),age2(202),female(202),white(202),self(202)]),neg(autism(113),[a1(113),a5(113),a10(113),age3(113),asian(113),parent(113)]),neg(autism(520),[a3(520),a4(520),a10(520),age3(520),middleeastern(520),self(520)]),neg(autism(160),[a1(160),a7(160),a8(160),age3(160),asian(160),self(160)])]).
