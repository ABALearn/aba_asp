head(id(1),a1(434)).
head(id(2),a2(434)).
head(id(3),a3(434)).
head(id(4),a4(434)).
head(id(5),a5(434)).
head(id(6),a6(434)).
head(id(7),a8(434)).
head(id(8),a9(434)).
head(id(9),age3(434)).
head(id(10),female(434)).
head(id(11),white(434)).
head(id(12),self(434)).
head(id(13),a1(529)).
head(id(14),a2(529)).
head(id(15),a3(529)).
head(id(16),a4(529)).
head(id(17),a5(529)).
head(id(18),a6(529)).
head(id(19),a7(529)).
head(id(20),a8(529)).
head(id(21),a9(529)).
head(id(22),a10(529)).
head(id(23),age4(529)).
head(id(24),female(529)).
head(id(25),white(529)).
head(id(26),jaundice(529)).
head(id(27),pdd(529)).
head(id(28),self(529)).
head(id(29),a1(124)).
head(id(30),a4(124)).
head(id(31),a5(124)).
head(id(32),a6(124)).
head(id(33),a7(124)).
head(id(34),a8(124)).
head(id(35),a10(124)).
head(id(36),age3(124)).
head(id(37),asian(124)).
head(id(38),jaundice(124)).
head(id(39),self(124)).
head(id(40),a1(509)).
head(id(41),a2(509)).
head(id(42),a3(509)).
head(id(43),a4(509)).
head(id(44),a5(509)).
head(id(45),a6(509)).
head(id(46),a7(509)).
head(id(47),a8(509)).
head(id(48),a9(509)).
head(id(49),a10(509)).
head(id(50),age4(509)).
head(id(51),female(509)).
head(id(52),white(509)).
head(id(53),jaundice(509)).
head(id(54),pdd(509)).
head(id(55),self(509)).
head(id(56),a1(660)).
head(id(57),a2(660)).
head(id(58),a3(660)).
head(id(59),a4(660)).
head(id(60),a5(660)).
head(id(61),a6(660)).
head(id(62),a9(660)).
head(id(63),a10(660)).
head(id(64),age4(660)).
head(id(65),a1(559)).
head(id(66),a2(559)).
head(id(67),a3(559)).
head(id(68),a4(559)).
head(id(69),a5(559)).
head(id(70),a6(559)).
head(id(71),a7(559)).
head(id(72),a8(559)).
head(id(73),a10(559)).
head(id(74),age2(559)).
head(id(75),female(559)).
head(id(76),white(559)).
head(id(77),self(559)).
head(id(78),a1(521)).
head(id(79),a2(521)).
head(id(80),a3(521)).
head(id(81),a4(521)).
head(id(82),a5(521)).
head(id(83),a8(521)).
head(id(84),a9(521)).
head(id(85),a10(521)).
head(id(86),age2(521)).
head(id(87),female(521)).
head(id(88),white(521)).
head(id(89),pdd(521)).
head(id(90),self(521)).
head(id(91),a1(654)).
head(id(92),a2(654)).
head(id(93),a3(654)).
head(id(94),a4(654)).
head(id(95),a5(654)).
head(id(96),a6(654)).
head(id(97),a7(654)).
head(id(98),a8(654)).
head(id(99),a9(654)).
head(id(100),a10(654)).
head(id(101),age3(654)).
head(id(102),female(654)).
head(id(103),white(654)).
head(id(104),pdd(654)).
head(id(105),self(654)).
head(id(106),a1(203)).
head(id(107),a2(203)).
head(id(108),a4(203)).
head(id(109),a5(203)).
head(id(110),a8(203)).
head(id(111),a9(203)).
head(id(112),a10(203)).
head(id(113),age2(203)).
head(id(114),female(203)).
head(id(115),white(203)).
head(id(116),self(203)).
head(id(117),a1(224)).
head(id(118),a3(224)).
head(id(119),a4(224)).
head(id(120),a6(224)).
head(id(121),a7(224)).
head(id(122),a8(224)).
head(id(123),a9(224)).
head(id(124),a10(224)).
head(id(125),age2(224)).
head(id(126),white(224)).
head(id(127),self(224)).
head(id(128),a1(189)).
head(id(129),a2(189)).
head(id(130),a4(189)).
head(id(131),a5(189)).
head(id(132),a6(189)).
head(id(133),a8(189)).
head(id(134),a9(189)).
head(id(135),a10(189)).
head(id(136),age5(189)).
head(id(137),female(189)).
head(id(138),white(189)).
head(id(139),pdd(189)).
head(id(140),self(189)).
head(id(141),a1(693)).
head(id(142),a2(693)).
head(id(143),a3(693)).
head(id(144),a5(693)).
head(id(145),a6(693)).
head(id(146),a7(693)).
head(id(147),a8(693)).
head(id(148),a10(693)).
head(id(149),age2(693)).
head(id(150),white(693)).
head(id(151),self(693)).
head(id(152),a1(472)).
head(id(153),a2(472)).
head(id(154),a3(472)).
head(id(155),a4(472)).
head(id(156),a5(472)).
head(id(157),a7(472)).
head(id(158),a8(472)).
head(id(159),age2(472)).
head(id(160),latino(472)).
head(id(161),self(472)).
head(id(162),a8(304)).
head(id(163),a9(304)).
head(id(164),age3(304)).
head(id(165),female(304)).
head(id(166),others(304)).
head(id(167),self(304)).
head(id(168),a8(608)).
head(id(169),age2(608)).
head(id(170),female(608)).
head(id(171),asian(608)).
head(id(172),jaundice(608)).
head(id(173),self(608)).
head(id(174),a1(64)).
head(id(175),a4(64)).
head(id(176),a5(64)).
head(id(177),a8(64)).
head(id(178),a9(64)).
head(id(179),age1(64)).
head(id(180),white(64)).
head(id(181),parent(64)).
head(id(182),a1(294)).
head(id(183),a5(294)).
head(id(184),a7(294)).
head(id(185),a10(294)).
head(id(186),age2(294)).
head(id(187),female(294)).
head(id(188),white(294)).
head(id(189),pdd(294)).
head(id(190),self(294)).
head(id(191),a1(132)).
head(id(192),a8(132)).
head(id(193),a10(132)).
head(id(194),age2(132)).
head(id(195),black(132)).
head(id(196),self(132)).
head(id(197),a1(600)).
head(id(198),a3(600)).
head(id(199),a4(600)).
head(id(200),a8(600)).
head(id(201),a9(600)).
head(id(202),a10(600)).
head(id(203),age3(600)).
head(id(204),female(600)).
head(id(205),asian(600)).
head(id(206),parent(600)).
head(id(207),a1(215)).
head(id(208),a2(215)).
head(id(209),a3(215)).
head(id(210),a4(215)).
head(id(211),a10(215)).
head(id(212),age4(215)).
head(id(213),white(215)).
head(id(214),self(215)).
head(id(215),a3(633)).
head(id(216),a8(633)).
head(id(217),age2(633)).
head(id(218),female(633)).
head(id(219),asian(633)).
head(id(220),parent(633)).
head(id(221),a1(202)).
head(id(222),a2(202)).
head(id(223),a4(202)).
head(id(224),a5(202)).
head(id(225),a9(202)).
head(id(226),a10(202)).
head(id(227),age2(202)).
head(id(228),female(202)).
head(id(229),white(202)).
head(id(230),self(202)).
head(id(231),a1(113)).
head(id(232),a5(113)).
head(id(233),a10(113)).
head(id(234),age3(113)).
head(id(235),asian(113)).
head(id(236),parent(113)).
head(id(237),a3(520)).
head(id(238),a4(520)).
head(id(239),a10(520)).
head(id(240),age3(520)).
head(id(241),middleeastern(520)).
head(id(242),self(520)).
head(id(243),a1(160)).
head(id(244),a7(160)).
head(id(245),a8(160)).
head(id(246),age3(160)).
head(id(247),asian(160)).
head(id(248),self(160)).
head(id(249),age4(295)).
head(id(250),female(295)).
head(id(251),middleeastern(295)).
head(id(252),parent(295)).
head(id(253),a1(133)).
head(id(254),a2(133)).
head(id(255),a8(133)).
head(id(256),age2(133)).
head(id(257),southasian(133)).
head(id(258),self(133)).
head(id(259),a1(88)).
head(id(260),age3(88)).
head(id(261),white(88)).
head(id(262),self(88)).
head(id(263),a1(205)).
head(id(264),a3(205)).
head(id(265),a4(205)).
head(id(266),age3(205)).
head(id(267),white(205)).
head(id(268),pdd(205)).
head(id(269),self(205)).
head(id(270),a1(267)).
head(id(271),a4(267)).
head(id(272),a9(267)).
head(id(273),age2(267)).
head(id(274),asian(267)).
head(id(275),self(267)).
head(id(276),a1(321)).
head(id(277),a2(321)).
head(id(278),age1(321)).
head(id(279),female(321)).
head(id(280),middleeastern(321)).
head(id(281),self(321)).
head(id(282),a4(286)).
head(id(283),a5(286)).
head(id(284),a6(286)).
head(id(285),a7(286)).
head(id(286),a9(286)).
head(id(287),a10(286)).
head(id(288),age3(286)).
head(id(289),female(286)).
head(id(290),a4(527)).
head(id(291),a7(527)).
head(id(292),a8(527)).
head(id(293),a10(527)).
head(id(294),age3(527)).
head(id(295),asian(527)).
head(id(296),self(527)).
head(id(297),a1(110)).
head(id(298),a6(110)).
head(id(299),a7(110)).
head(id(300),age1(110)).
head(id(301),female(110)).
head(id(302),asian(110)).
head(id(303),parent(110)).
head(id(304),a1(342)).
head(id(305),a2(342)).
head(id(306),a3(342)).
head(id(307),a4(342)).
head(id(308),a5(342)).
head(id(309),a8(342)).
head(id(310),age1(342)).
head(id(311),a1(306)).
head(id(312),a2(306)).
head(id(313),a4(306)).
head(id(314),a10(306)).
head(id(315),age3(306)).
head(id(316),female(306)).
head(id(317),white(306)).
head(id(318),self(306)).
head(id(319),a3(581)).
head(id(320),a4(581)).
head(id(321),age4(581)).
head(id(322),black(581)).
head(id(323),self(581)).
head(id(324),a1(617)).
head(id(325),a5(617)).
head(id(326),a7(617)).
head(id(327),age2(617)).
head(id(328),southasian(617)).
head(id(329),self(617)).
head(id(330),a1(676)).
head(id(331),a2(676)).
head(id(332),a3(676)).
head(id(333),a4(676)).
head(id(334),a9(676)).
head(id(335),age2(676)).
head(id(336),female(676)).
head(id(337),white(676)).
head(id(338),jaundice(676)).
head(id(339),self(676)).
head(id(1400,A),autism(A)) :- dom(A).
body(id(1400,A),alpha_1(A)) :- dom(A).
body(id(1400,A),a1(A)) :- dom(A).
head(id(7642,A),c_alpha_1(A)) :- dom(A).
body(id(7642,A),alpha_2(A)) :- dom(A).
body(id(7642,A),a4(A)) :- dom(A).
head(id(9542,A),c_alpha_1(A)) :- dom(A).
body(id(9542,A),alpha_3(A)) :- dom(A).
body(id(9542,A),age3(A)) :- dom(A).
head(id(11477,A),c_alpha_1(A)) :- dom(A).
body(id(11477,A),alpha_4(A)) :- dom(A).
body(id(11477,A),a6(A)) :- dom(A).
head(id(13876,A),c_alpha_1(A)) :- dom(A).
body(id(13876,A),alpha_5(A)) :- dom(A).
body(id(13876,A),a8(A)) :- dom(A).
head(id(18395,A),c_alpha_1(A)) :- dom(A).
body(id(18395,A),alpha_6(A)) :- dom(A).
body(id(18395,A),a5(A)) :- dom(A).
head(id(20944,A),c_alpha_1(A)) :- dom(A).
body(id(20944,A),alpha_7(A)) :- dom(A).
body(id(20944,A),a2(A)) :- dom(A).
head(id(23997,A),c_alpha_2(A)) :- dom(A).
body(id(23997,A),alpha_1(A)) :- dom(A).
body(id(23997,A),a1(A)) :- dom(A).
head(id(30015,A),c_alpha_3(A)) :- dom(A).
body(id(30015,A),alpha_1(A)) :- dom(A).
body(id(30015,A),a1(A)) :- dom(A).
head(id(32145,A),c_alpha_4(A)) :- dom(A).
body(id(32145,A),alpha_1(A)) :- dom(A).
body(id(32145,A),a1(A)) :- dom(A).
head(id(37208,A),c_alpha_5(A)) :- dom(A).
body(id(37208,A),alpha_1(A)) :- dom(A).
body(id(37208,A),a1(A)) :- dom(A).
head(id(43002,A),c_alpha_6(A)) :- dom(A).
body(id(43002,A),alpha_1(A)) :- dom(A).
body(id(43002,A),a1(A)) :- dom(A).
head(id(48670,A),c_alpha_7(A)) :- dom(A).
body(id(48670,A),alpha_1(A)) :- dom(A).
body(id(48670,A),a1(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
assumption(alpha_4(A)) :- dom(A).
assumption(alpha_5(A)) :- dom(A).
assumption(alpha_6(A)) :- dom(A).
assumption(alpha_7(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).
contrary(alpha_4(A),c_alpha_4(A)) :- assumption(alpha_4(A)).
contrary(alpha_5(A),c_alpha_5(A)) :- assumption(alpha_5(A)).
contrary(alpha_6(A),c_alpha_6(A)) :- assumption(alpha_6(A)).
contrary(alpha_7(A),c_alpha_7(A)) :- assumption(alpha_7(A)).

dom(64).
dom(88).
dom(110).
dom(113).
dom(124).
dom(132).
dom(133).
dom(160).
dom(189).
dom(202).
dom(203).
dom(205).
dom(215).
dom(224).
dom(267).
dom(286).
dom(294).
dom(295).
dom(304).
dom(306).
dom(321).
dom(342).
dom(434).
dom(472).
dom(509).
dom(520).
dom(521).
dom(527).
dom(529).
dom(559).
dom(581).
dom(600).
dom(608).
dom(617).
dom(633).
dom(654).
dom(660).
dom(676).
dom(693).
