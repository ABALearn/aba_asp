head(id(1),lo(47)).
head(id(2),a4(47)).
head(id(3),a5(47)).
head(id(4),a4(7)).
head(id(5),a5(7)).
head(id(6),a6(7)).
head(id(7),lo(48)).
head(id(8),a4(48)).
head(id(9),a5(48)).
head(id(10),a6(48)).
head(id(11),lo(59)).
head(id(12),a4(59)).
head(id(13),a5(59)).
head(id(14),a6(59)).
head(id(15),lo(52)).
head(id(16),a4(52)).
head(id(17),a4(19)).
head(id(18),a5(19)).
head(id(19),a6(19)).
head(id(20),a4(14)).
head(id(21),a5(14)).
head(id(22),a6(14)).
head(id(23),hi(89)).
head(id(24),a2(89)).
head(id(25),a3(89)).
head(id(26),a4(89)).
head(id(27),a5(89)).
head(id(28),a4(21)).
head(id(29),a5(21)).
head(id(30),hi(100)).
head(id(31),a2(100)).
head(id(32),a3(100)).
head(id(33),a4(100)).
head(id(34),a5(100)).
head(id(35),hi(71)).
head(id(36),a2(71)).
head(id(37),a3(71)).
head(id(38),a4(71)).
head(id(39),a5(71)).
head(id(40),a6(71)).
head(id(41),a4(9)).
head(id(42),a5(9)).
head(id(43),a6(9)).
head(id(44),hi(85)).
head(id(45),a2(85)).
head(id(46),a3(85)).
head(id(47),a4(85)).
head(id(48),a5(85)).
head(id(49),a4(22)).
head(id(50),a5(22)).
head(id(51),a4(26)).
head(id(52),a5(26)).
head(id(53),a6(26)).
head(id(54),a4(30)).
head(id(55),a5(30)).
head(id(56),a6(30)).
head(id(57),lo(57)).
head(id(58),a4(57)).
head(id(59),a5(57)).
head(id(60),a4(17)).
head(id(61),a5(17)).
head(id(62),a6(17)).
head(id(63),lo(50)).
head(id(64),a4(50)).
head(id(65),a5(50)).
head(id(66),hi(99)).
head(id(67),a2(99)).
head(id(68),a3(99)).
head(id(69),a4(99)).
head(id(70),a5(99)).
head(id(71),hi(90)).
head(id(72),a2(90)).
head(id(73),a3(90)).
head(id(74),a4(90)).
head(id(75),a5(90)).
head(id(76),a6(90)).
head(id(77),lo(49)).
head(id(78),a4(49)).
head(id(79),a5(49)).
head(id(80),lo(44)).
head(id(81),a4(44)).
head(id(82),lo(40)).
head(id(83),a4(40)).
head(id(84),a5(40)).
head(id(85),lo(58)).
head(id(86),a3(58)).
head(id(87),hi(69)).
head(id(88),a3(69)).
head(id(89),a4(69)).
head(id(90),a6(69)).
head(id(91),a3(33)).
head(id(92),hi(74)).
head(id(93),lo(51)).
head(id(94),a3(51)).
head(id(95),a3(20)).
head(id(96),hi(95)).
head(id(97),vh(113)).
head(id(98),a2(113)).
head(id(99),a3(113)).
head(id(100),a5(113)).
head(id(101),hi(88)).
head(id(102),a2(88)).
head(id(103),a3(88)).
head(id(104),a5(88)).
head(id(105),lo(53)).
head(id(106),a3(53)).
head(id(107),a3(23)).
head(id(108),a3(16)).
head(id(109),a3(3)).
head(id(110),mo(68)).
head(id(111),a3(68)).
head(id(112),a4(68)).
head(id(113),a6(68)).
head(id(114),a3(5)).
head(id(115),hi(87)).
head(id(116),hi(75)).
head(id(117),vh(114)).
head(id(118),a3(114)).
head(id(119),a4(114)).
head(id(120),a6(114)).
head(id(121),a3(1)).
head(id(122),lo(38)).
head(id(123),a3(38)).
head(id(124),hi(76)).
head(id(125),a2(76)).
head(id(126),a3(76)).
head(id(127),a5(76)).
head(id(128),a3(8)).
head(id(129),hi(97)).
head(id(130),a3(97)).
head(id(131),a4(97)).
head(id(132),a6(97)).
head(id(133),lo(35)).
head(id(134),a3(35)).
head(id(135),hi(103)).
head(id(617,A),acute(A)) :- dom(A).
body(id(617,A),alpha_1(A)) :- dom(A).
body(id(617,A),lo(A)) :- dom(A).
head(id(1126,A),acute(A)) :- dom(A).
body(id(1126,A),alpha_2(A)) :- dom(A).
body(id(1126,A),a4(A)) :- dom(A).
head(id(5078,A),c_alpha_1(A)) :- dom(A).
body(id(5078,A),lo(A)) :- dom(A).
head(id(5994,A),c_alpha_2(A)) :- dom(A).
body(id(5994,A),mo(A)) :- dom(A).
head(id(6452,A),c_alpha_2(A)) :- dom(A).
body(id(6452,A),alpha_3(A)) :- dom(A).
body(id(6452,A),hi(A)) :- dom(A).
head(id(6939,A),c_alpha_2(A)) :- dom(A).
body(id(6939,A),vh(A)) :- dom(A).
head(id(7592,A),c_alpha_3(A)) :- dom(A).
body(id(7592,A),a2(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).

dom(1).
dom(3).
dom(5).
dom(7).
dom(8).
dom(9).
dom(14).
dom(16).
dom(17).
dom(19).
dom(20).
dom(21).
dom(22).
dom(23).
dom(26).
dom(30).
dom(33).
dom(35).
dom(38).
dom(40).
dom(44).
dom(47).
dom(48).
dom(49).
dom(50).
dom(51).
dom(52).
dom(53).
dom(57).
dom(58).
dom(59).
dom(68).
dom(69).
dom(71).
dom(74).
dom(75).
dom(76).
dom(85).
dom(87).
dom(88).
dom(89).
dom(90).
dom(95).
dom(97).
dom(99).
dom(100).
dom(103).
dom(113).
dom(114).
