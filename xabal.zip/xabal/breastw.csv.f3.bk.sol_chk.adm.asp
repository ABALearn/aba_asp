head(id(1),clump_thickness__5(125)).
head(id(2),cell_size_uniformity__4(125)).
head(id(3),cell_shape_uniformity__6(125)).
head(id(4),marginal_adhesion__7(125)).
head(id(5),single_epi_cell_size__9(125)).
head(id(6),bare_nuclei__7(125)).
head(id(7),bland_chromatin__8(125)).
head(id(8),mitoses__1(125)).
head(id(9),clump_thickness__8(216)).
head(id(10),cell_size_uniformity__7(216)).
head(id(11),cell_shape_uniformity__8(216)).
head(id(12),marginal_adhesion__7(216)).
head(id(13),single_epi_cell_size__5(216)).
head(id(14),bare_nuclei__5(216)).
head(id(15),bland_chromatin__5(216)).
head(id(16),mitoses__2(216)).
head(id(17),clump_thickness__8(301)).
head(id(18),cell_size_uniformity__4(301)).
head(id(19),marginal_adhesion__5(301)).
head(id(20),single_epi_cell_size__4(301)).
head(id(21),bare_nuclei__4(301)).
head(id(22),bland_chromatin__7(301)).
head(id(23),mitoses__1(301)).
head(id(24),clump_thickness__5(54)).
head(id(25),cell_size_uniformity__5(54)).
head(id(26),cell_shape_uniformity__5(54)).
head(id(27),marginal_adhesion__8(54)).
head(id(28),bare_nuclei__8(54)).
head(id(29),bland_chromatin__7(54)).
head(id(30),normal_nucleoli__3(54)).
head(id(31),mitoses__7(54)).
head(id(32),clump_thickness__9(426)).
head(id(33),mitoses__1(426)).
head(id(34),cell_size_uniformity__8(168)).
head(id(35),single_epi_cell_size__6(168)).
head(id(36),bare_nuclei__1(168)).
head(id(37),bland_chromatin__3(168)).
head(id(38),normal_nucleoli__1(168)).
head(id(39),clump_thickness__6(110)).
head(id(40),cell_size_uniformity__5(110)).
head(id(41),cell_shape_uniformity__4(110)).
head(id(42),marginal_adhesion__4(110)).
head(id(43),single_epi_cell_size__3(110)).
head(id(44),bare_nuclei__9(110)).
head(id(45),bland_chromatin__7(110)).
head(id(46),normal_nucleoli__8(110)).
head(id(47),mitoses__3(110)).
head(id(48),clump_thickness__7(321)).
head(id(49),cell_size_uniformity__6(321)).
head(id(50),cell_shape_uniformity__3(321)).
head(id(51),marginal_adhesion__2(321)).
head(id(52),single_epi_cell_size__5(321)).
head(id(53),bland_chromatin__7(321)).
head(id(54),normal_nucleoli__4(321)).
head(id(55),mitoses__6(321)).
head(id(56),cell_size_uniformity__6(467)).
head(id(57),cell_shape_uniformity__6(467)).
head(id(58),marginal_adhesion__2(467)).
head(id(59),single_epi_cell_size__4(467)).
head(id(60),bland_chromatin__9(467)).
head(id(61),normal_nucleoli__7(467)).
head(id(62),mitoses__1(467)).
head(id(63),clump_thickness__8(150)).
head(id(64),cell_size_uniformity__8(150)).
head(id(65),cell_shape_uniformity__7(150)).
head(id(66),marginal_adhesion__4(150)).
head(id(67),bland_chromatin__7(150)).
head(id(68),normal_nucleoli__8(150)).
head(id(69),mitoses__7(150)).
head(id(70),cell_size_uniformity__6(382)).
head(id(71),cell_shape_uniformity__3(382)).
head(id(72),marginal_adhesion__6(382)).
head(id(73),single_epi_cell_size__4(382)).
head(id(74),bland_chromatin__7(382)).
head(id(75),normal_nucleoli__8(382)).
head(id(76),mitoses__4(382)).
head(id(77),cell_size_uniformity__5(280)).
head(id(78),cell_shape_uniformity__7(280)).
head(id(79),marginal_adhesion__3(280)).
head(id(80),single_epi_cell_size__3(280)).
head(id(81),bare_nuclei__7(280)).
head(id(82),bland_chromatin__3(280)).
head(id(83),normal_nucleoli__3(280)).
head(id(84),mitoses__8(280)).
head(id(85),clump_thickness__5(290)).
head(id(86),cell_size_uniformity__6(290)).
head(id(87),cell_shape_uniformity__6(290)).
head(id(88),marginal_adhesion__8(290)).
head(id(89),single_epi_cell_size__6(290)).
head(id(90),bland_chromatin__4(290)).
head(id(91),mitoses__4(290)).
head(id(92),clump_thickness__5(670)).
head(id(93),marginal_adhesion__8(670)).
head(id(94),single_epi_cell_size__5(670)).
head(id(95),bare_nuclei__5(670)).
head(id(96),bland_chromatin__7(670)).
head(id(97),mitoses__1(670)).
head(id(98),clump_thickness__5(189)).
head(id(99),cell_size_uniformity__8(189)).
head(id(100),cell_shape_uniformity__4(189)).
head(id(101),single_epi_cell_size__5(189)).
head(id(102),bare_nuclei__8(189)).
head(id(103),bland_chromatin__9(189)).
head(id(104),mitoses__1(189)).
head(id(105),clump_thickness__1(203)).
head(id(106),cell_size_uniformity__1(203)).
head(id(107),cell_shape_uniformity__1(203)).
head(id(108),marginal_adhesion__1(203)).
head(id(109),single_epi_cell_size__2(203)).
head(id(110),bare_nuclei__1(203)).
head(id(111),bland_chromatin__3(203)).
head(id(112),normal_nucleoli__1(203)).
head(id(113),mitoses__1(203)).
head(id(114),clump_thickness__2(366)).
head(id(115),cell_size_uniformity__1(366)).
head(id(116),cell_shape_uniformity__1(366)).
head(id(117),marginal_adhesion__1(366)).
head(id(118),single_epi_cell_size__2(366)).
head(id(119),bare_nuclei__1(366)).
head(id(120),bland_chromatin__2(366)).
head(id(121),normal_nucleoli__1(366)).
head(id(122),mitoses__1(366)).
head(id(123),clump_thickness__4(371)).
head(id(124),cell_size_uniformity__3(371)).
head(id(125),cell_shape_uniformity__2(371)).
head(id(126),marginal_adhesion__1(371)).
head(id(127),single_epi_cell_size__3(371)).
head(id(128),bare_nuclei__1(371)).
head(id(129),bland_chromatin__2(371)).
head(id(130),normal_nucleoli__1(371)).
head(id(131),mitoses__1(371)).
head(id(132),clump_thickness__3(651)).
head(id(133),cell_size_uniformity__1(651)).
head(id(134),cell_shape_uniformity__1(651)).
head(id(135),marginal_adhesion__2(651)).
head(id(136),single_epi_cell_size__3(651)).
head(id(137),bare_nuclei__4(651)).
head(id(138),bland_chromatin__1(651)).
head(id(139),normal_nucleoli__1(651)).
head(id(140),mitoses__1(651)).
head(id(141),clump_thickness__3(434)).
head(id(142),cell_size_uniformity__2(434)).
head(id(143),cell_shape_uniformity__2(434)).
head(id(144),marginal_adhesion__3(434)).
head(id(145),single_epi_cell_size__2(434)).
head(id(146),bare_nuclei__1(434)).
head(id(147),bland_chromatin__1(434)).
head(id(148),normal_nucleoli__1(434)).
head(id(149),mitoses__1(434)).
head(id(150),clump_thickness__5(683)).
head(id(151),cell_size_uniformity__1(683)).
head(id(152),cell_shape_uniformity__1(683)).
head(id(153),marginal_adhesion__1(683)).
head(id(154),single_epi_cell_size__2(683)).
head(id(155),bare_nuclei__1(683)).
head(id(156),bland_chromatin__3(683)).
head(id(157),normal_nucleoli__2(683)).
head(id(158),mitoses__1(683)).
head(id(159),clump_thickness__3(476)).
head(id(160),cell_size_uniformity__1(476)).
head(id(161),cell_shape_uniformity__1(476)).
head(id(162),marginal_adhesion__1(476)).
head(id(163),single_epi_cell_size__2(476)).
head(id(164),bare_nuclei__1(476)).
head(id(165),bland_chromatin__1(476)).
head(id(166),normal_nucleoli__1(476)).
head(id(167),mitoses__1(476)).
head(id(168),clump_thickness__5(561)).
head(id(169),cell_size_uniformity__1(561)).
head(id(170),cell_shape_uniformity__1(561)).
head(id(171),marginal_adhesion__1(561)).
head(id(172),single_epi_cell_size__2(561)).
head(id(173),bare_nuclei__1(561)).
head(id(174),bland_chromatin__3(561)).
head(id(175),normal_nucleoli__1(561)).
head(id(176),mitoses__1(561)).
head(id(177),clump_thickness__2(409)).
head(id(178),cell_size_uniformity__3(409)).
head(id(179),cell_shape_uniformity__2(409)).
head(id(180),marginal_adhesion__2(409)).
head(id(181),single_epi_cell_size__2(409)).
head(id(182),bare_nuclei__2(409)).
head(id(183),bland_chromatin__3(409)).
head(id(184),normal_nucleoli__1(409)).
head(id(185),mitoses__1(409)).
head(id(186),clump_thickness__4(423)).
head(id(187),cell_size_uniformity__3(423)).
head(id(188),cell_shape_uniformity__3(423)).
head(id(189),marginal_adhesion__1(423)).
head(id(190),single_epi_cell_size__2(423)).
head(id(191),bare_nuclei__1(423)).
head(id(192),bland_chromatin__3(423)).
head(id(193),normal_nucleoli__3(423)).
head(id(194),mitoses__1(423)).
head(id(195),clump_thickness__5(333)).
head(id(196),cell_size_uniformity__2(333)).
head(id(197),cell_shape_uniformity__2(333)).
head(id(198),marginal_adhesion__2(333)).
head(id(199),single_epi_cell_size__2(333)).
head(id(200),bare_nuclei__1(333)).
head(id(201),bland_chromatin__2(333)).
head(id(202),normal_nucleoli__2(333)).
head(id(203),mitoses__1(333)).
head(id(204),clump_thickness__4(249)).
head(id(205),cell_size_uniformity__1(249)).
head(id(206),cell_shape_uniformity__1(249)).
head(id(207),marginal_adhesion__1(249)).
head(id(208),single_epi_cell_size__2(249)).
head(id(209),bare_nuclei__1(249)).
head(id(210),bland_chromatin__3(249)).
head(id(211),normal_nucleoli__6(249)).
head(id(212),mitoses__1(249)).
head(id(213),clump_thickness__1(431)).
head(id(214),cell_size_uniformity__3(431)).
head(id(215),cell_shape_uniformity__1(431)).
head(id(216),marginal_adhesion__1(431)).
head(id(217),single_epi_cell_size__2(431)).
head(id(218),bare_nuclei__1(431)).
head(id(219),bland_chromatin__2(431)).
head(id(220),normal_nucleoli__2(431)).
head(id(221),mitoses__1(431)).
head(id(222),clump_thickness__5(596)).
head(id(223),cell_size_uniformity__1(596)).
head(id(224),cell_shape_uniformity__1(596)).
head(id(225),marginal_adhesion__1(596)).
head(id(226),single_epi_cell_size__2(596)).
head(id(227),bare_nuclei__1(596)).
head(id(228),bland_chromatin__2(596)).
head(id(229),normal_nucleoli__1(596)).
head(id(230),mitoses__1(596)).
head(id(231),clump_thickness__5(414)).
head(id(232),cell_size_uniformity__1(414)).
head(id(233),cell_shape_uniformity__2(414)).
head(id(234),marginal_adhesion__1(414)).
head(id(235),single_epi_cell_size__2(414)).
head(id(236),bare_nuclei__1(414)).
head(id(237),bland_chromatin__3(414)).
head(id(238),normal_nucleoli__1(414)).
head(id(239),mitoses__1(414)).
head(id(240),clump_thickness__1(552)).
head(id(241),cell_size_uniformity__1(552)).
head(id(242),cell_shape_uniformity__1(552)).
head(id(243),marginal_adhesion__1(552)).
head(id(244),single_epi_cell_size__2(552)).
head(id(245),bare_nuclei__1(552)).
head(id(246),bland_chromatin__3(552)).
head(id(247),normal_nucleoli__1(552)).
head(id(248),mitoses__1(552)).
head(id(249),clump_thickness__3(23)).
head(id(250),cell_size_uniformity__1(23)).
head(id(251),cell_shape_uniformity__1(23)).
head(id(252),marginal_adhesion__1(23)).
head(id(253),single_epi_cell_size__2(23)).
head(id(254),bare_nuclei__1(23)).
head(id(255),bland_chromatin__2(23)).
head(id(256),normal_nucleoli__1(23)).
head(id(257),mitoses__1(23)).
head(id(258),clump_thickness__2(95)).
head(id(259),cell_size_uniformity__1(95)).
head(id(260),cell_shape_uniformity__1(95)).
head(id(261),marginal_adhesion__1(95)).
head(id(262),single_epi_cell_size__2(95)).
head(id(263),bare_nuclei__1(95)).
head(id(264),bland_chromatin__3(95)).
head(id(265),normal_nucleoli__1(95)).
head(id(266),mitoses__1(95)).
head(id(267),clump_thickness__6(38)).
head(id(268),cell_size_uniformity__2(38)).
head(id(269),cell_shape_uniformity__1(38)).
head(id(270),marginal_adhesion__1(38)).
head(id(271),single_epi_cell_size__1(38)).
head(id(272),bare_nuclei__1(38)).
head(id(273),bland_chromatin__7(38)).
head(id(274),normal_nucleoli__1(38)).
head(id(275),mitoses__1(38)).
head(id(276),clump_thickness__1(65)).
head(id(277),cell_size_uniformity__1(65)).
head(id(278),cell_shape_uniformity__1(65)).
head(id(279),marginal_adhesion__1(65)).
head(id(280),single_epi_cell_size__2(65)).
head(id(281),bare_nuclei__1(65)).
head(id(282),bland_chromatin__2(65)).
head(id(283),normal_nucleoli__1(65)).
head(id(284),mitoses__1(65)).
head(id(285),clump_thickness__4(67)).
head(id(286),cell_size_uniformity__1(67)).
head(id(287),cell_shape_uniformity__1(67)).
head(id(288),marginal_adhesion__1(67)).
head(id(289),single_epi_cell_size__2(67)).
head(id(290),bare_nuclei__1(67)).
head(id(291),bland_chromatin__3(67)).
head(id(292),normal_nucleoli__1(67)).
head(id(293),mitoses__1(67)).
head(id(294),clump_thickness__5(475)).
head(id(295),cell_size_uniformity__1(475)).
head(id(296),cell_shape_uniformity__1(475)).
head(id(297),marginal_adhesion__1(475)).
head(id(298),single_epi_cell_size__2(475)).
head(id(299),bare_nuclei__1(475)).
head(id(300),bland_chromatin__1(475)).
head(id(301),normal_nucleoli__1(475)).
head(id(302),mitoses__1(475)).
head(id(303),clump_thickness__1(96)).
head(id(304),cell_size_uniformity__1(96)).
head(id(305),cell_shape_uniformity__1(96)).
head(id(306),marginal_adhesion__1(96)).
head(id(307),single_epi_cell_size__2(96)).
head(id(308),bare_nuclei__1(96)).
head(id(309),bland_chromatin__3(96)).
head(id(310),normal_nucleoli__1(96)).
head(id(311),mitoses__1(96)).
head(id(312),clump_thickness__4(18)).
head(id(313),cell_size_uniformity__1(18)).
head(id(314),cell_shape_uniformity__1(18)).
head(id(315),marginal_adhesion__1(18)).
head(id(316),single_epi_cell_size__2(18)).
head(id(317),bare_nuclei__1(18)).
head(id(318),bland_chromatin__3(18)).
head(id(319),normal_nucleoli__1(18)).
head(id(320),mitoses__1(18)).
head(id(321),clump_thickness__1(687)).
head(id(322),cell_size_uniformity__1(687)).
head(id(323),cell_shape_uniformity__1(687)).
head(id(324),marginal_adhesion__1(687)).
head(id(325),single_epi_cell_size__2(687)).
head(id(326),bare_nuclei__1(687)).
head(id(327),bland_chromatin__1(687)).
head(id(328),normal_nucleoli__1(687)).
head(id(329),mitoses__1(687)).
head(id(1366,A),malignant(A)) :- dom(A).
body(id(1366,A),alpha_1(A)) :- dom(A).
body(id(1366,A),clump_thickness__5(A)) :- dom(A).
head(id(2065,A),malignant(A)) :- dom(A).
body(id(2065,A),clump_thickness__8(A)) :- dom(A).
head(id(3456,A),malignant(A)) :- dom(A).
body(id(3456,A),clump_thickness__9(A)) :- dom(A).
head(id(4152,A),malignant(A)) :- dom(A).
body(id(4152,A),cell_size_uniformity__8(A)) :- dom(A).
head(id(5201,A),malignant(A)) :- dom(A).
body(id(5201,A),alpha_2(A)) :- dom(A).
body(id(5201,A),clump_thickness__6(A)) :- dom(A).
head(id(5910,A),malignant(A)) :- dom(A).
body(id(5910,A),clump_thickness__7(A)) :- dom(A).
head(id(6618,A),malignant(A)) :- dom(A).
body(id(6618,A),cell_size_uniformity__6(A)) :- dom(A).
head(id(8033,A),malignant(A)) :- dom(A).
body(id(8033,A),cell_size_uniformity__5(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).

dom(18).
dom(23).
dom(38).
dom(54).
dom(65).
dom(67).
dom(95).
dom(96).
dom(110).
dom(125).
dom(150).
dom(168).
dom(189).
dom(203).
dom(216).
dom(249).
dom(280).
dom(290).
dom(301).
dom(321).
dom(333).
dom(366).
dom(371).
dom(382).
dom(409).
dom(414).
dom(423).
dom(426).
dom(431).
dom(434).
dom(467).
dom(475).
dom(476).
dom(552).
dom(561).
dom(596).
dom(651).
dom(670).
dom(683).
dom(687).
 :- not supported(malignant(125)).
 :- not supported(malignant(216)).
 :- not supported(malignant(301)).
 :- not supported(malignant(54)).
 :- not supported(malignant(426)).
 :- not supported(malignant(168)).
 :- not supported(malignant(110)).
 :- not supported(malignant(321)).
 :- not supported(malignant(467)).
 :- not supported(malignant(150)).
 :- not supported(malignant(382)).
 :- not supported(malignant(280)).
 :- not supported(malignant(290)).
 :- not supported(malignant(670)).
 :- not supported(malignant(189)).
 :- supported(malignant(203)).
 :- supported(malignant(366)).
 :- supported(malignant(371)).
 :- supported(malignant(651)).
 :- supported(malignant(434)).
 :- supported(malignant(683)).
 :- supported(malignant(476)).
 :- supported(malignant(561)).
 :- supported(malignant(409)).
 :- supported(malignant(423)).
 :- supported(malignant(333)).
 :- supported(malignant(249)).
 :- supported(malignant(431)).
 :- supported(malignant(596)).
 :- supported(malignant(414)).
 :- supported(malignant(552)).
 :- supported(malignant(23)).
 :- supported(malignant(95)).
 :- supported(malignant(38)).
 :- supported(malignant(65)).
 :- supported(malignant(67)).
 :- supported(malignant(475)).
 :- supported(malignant(96)).
 :- supported(malignant(18)).
 :- supported(malignant(687)).
