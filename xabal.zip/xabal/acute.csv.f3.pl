% training data:
% no. positive ex.: 23
% no. negative ex.: 25
% query: 
train :- aba_asp('./xabal/acute.csv.f3.bk',[acute(11),acute(54),acute(37),acute(84),acute(80),acute(47),acute(7),acute(48),acute(59),acute(52),acute(19),acute(85),acute(22),acute(26),acute(30),acute(57),acute(17),acute(50),acute(99),acute(90),acute(49),acute(44),acute(40)],[acute(66),acute(64),acute(82),acute(78),acute(96),acute(110),acute(58),acute(69),acute(33),acute(74),acute(51),acute(20),acute(3),acute(68),acute(5),acute(87),acute(75),acute(114),acute(1),acute(38),acute(76),acute(8),acute(97),acute(35),acute(103)]).
% test data:
% no. positive ex.: 6
% no. negative ex.: 6
% query: 
test :- test_abaf('./xabal/acute.csv.f3.bk.sol',[acute(11),acute(54),acute(37),acute(84),acute(80),acute(47),acute(7),acute(48),acute(59),acute(52),acute(19),acute(85),acute(22),acute(26),acute(30),acute(57),acute(17),acute(50),acute(99),acute(90),acute(49),acute(44),acute(40)],[acute(66),acute(64),acute(82),acute(78),acute(96),acute(110),acute(58),acute(69),acute(33),acute(74),acute(51),acute(20),acute(3),acute(68),acute(5),acute(87),acute(75),acute(114),acute(1),acute(38),acute(76),acute(8),acute(97),acute(35),acute(103)],[pos(acute(14),[a4(14),a5(14),a6(14)]),pos(acute(89),[hi(89),a2(89),a3(89),a4(89),a5(89)]),pos(acute(21),[a4(21),a5(21)]),pos(acute(100),[hi(100),a2(100),a3(100),a4(100),a5(100)]),pos(acute(71),[hi(71),a2(71),a3(71),a4(71),a5(71),a6(71)]),pos(acute(9),[a4(9),a5(9),a6(9)])],[neg(acute(95),[hi(95)]),neg(acute(113),[vh(113),a2(113),a3(113),a5(113)]),neg(acute(88),[hi(88),a2(88),a3(88),a5(88)]),neg(acute(53),[lo(53),a3(53)]),neg(acute(23),[a3(23)]),neg(acute(16),[a3(16)])]).
