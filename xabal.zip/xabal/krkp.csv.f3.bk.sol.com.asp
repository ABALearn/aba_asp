head(id(1),a6(2221)).
head(id(2),a9(2221)).
head(id(3),a11(2221)).
head(id(4),a13(2221)).
head(id(5),n(2221)).
head(id(6),a18(2221)).
head(id(7),a20(2221)).
head(id(8),a21(2221)).
head(id(9),a22(2221)).
head(id(10),a26(2221)).
head(id(11),a31(2221)).
head(id(12),a33(2221)).
head(id(13),a34(2221)).
head(id(14),a6(420)).
head(id(15),a9(420)).
head(id(16),a11(420)).
head(id(17),n(420)).
head(id(18),a18(420)).
head(id(19),a22(420)).
head(id(20),a26(420)).
head(id(21),a34(420)).
head(id(22),a35(420)).
head(id(23),a5(296)).
head(id(24),a7(296)).
head(id(25),a8(296)).
head(id(26),a9(296)).
head(id(27),a13(296)).
head(id(28),n(296)).
head(id(29),a18(296)).
head(id(30),a24(296)).
head(id(31),a34(296)).
head(id(32),a35(296)).
head(id(33),a5(2181)).
head(id(34),a11(2181)).
head(id(35),a13(2181)).
head(id(36),w(2181)).
head(id(37),a21(2181)).
head(id(38),a26(2181)).
head(id(39),a31(2181)).
head(id(40),a2(2266)).
head(id(41),a5(2266)).
head(id(42),a9(2266)).
head(id(43),a13(2266)).
head(id(44),n(2266)).
head(id(45),a21(2266)).
head(id(46),a22(2266)).
head(id(47),a35(2266)).
head(id(48),a5(241)).
head(id(49),a6(241)).
head(id(50),a7(241)).
head(id(51),a11(241)).
head(id(52),a13(241)).
head(id(53),w(241)).
head(id(54),a24(241)).
head(id(55),a26(241)).
head(id(56),a34(241)).
head(id(57),a35(241)).
head(id(58),a6(1809)).
head(id(59),a7(1809)).
head(id(60),a11(1809)).
head(id(61),a13(1809)).
head(id(62),w(1809)).
head(id(63),a20(1809)).
head(id(64),a26(1809)).
head(id(65),a31(1809)).
head(id(66),a9(600)).
head(id(67),a13(600)).
head(id(68),n(600)).
head(id(69),a18(600)).
head(id(70),a22(600)).
head(id(71),a34(600)).
head(id(72),a35(600)).
head(id(73),a36(600)).
head(id(74),a2(1918)).
head(id(75),a3(1918)).
head(id(76),a6(1918)).
head(id(77),n(1918)).
head(id(78),a18(1918)).
head(id(79),a24(1918)).
head(id(80),a26(1918)).
head(id(81),a35(1918)).
head(id(82),a36(1918)).
head(id(83),a5(751)).
head(id(84),a6(751)).
head(id(85),a7(751)).
head(id(86),a13(751)).
head(id(87),n(751)).
head(id(88),a21(751)).
head(id(89),a35(751)).
head(id(90),a1(2258)).
head(id(91),a4(2258)).
head(id(92),a6(2258)).
head(id(93),a11(2258)).
head(id(94),a13(2258)).
head(id(95),w(2258)).
head(id(96),a21(2258)).
head(id(97),a24(2258)).
head(id(98),a26(2258)).
head(id(99),a27(2258)).
head(id(100),a31(2258)).
head(id(101),a33(2258)).
head(id(102),a35(2258)).
head(id(103),a13(611)).
head(id(104),n(611)).
head(id(105),a24(611)).
head(id(106),a34(611)).
head(id(107),a35(611)).
head(id(108),a36(611)).
head(id(109),a2(2324)).
head(id(110),a5(2324)).
head(id(111),a9(2324)).
head(id(112),a13(2324)).
head(id(113),n(2324)).
head(id(114),a21(2324)).
head(id(115),a22(2324)).
head(id(116),a30(2324)).
head(id(117),a33(2324)).
head(id(118),a35(2324)).
head(id(119),a36(2324)).
head(id(120),a13(703)).
head(id(121),n(703)).
head(id(122),a18(703)).
head(id(123),a21(703)).
head(id(124),a26(703)).
head(id(125),a34(703)).
head(id(126),a35(703)).
head(id(127),a2(2308)).
head(id(128),a9(2308)).
head(id(129),a13(2308)).
head(id(130),n(2308)).
head(id(131),a21(2308)).
head(id(132),a22(2308)).
head(id(133),a24(2308)).
head(id(134),a33(2308)).
head(id(135),a35(2308)).
head(id(136),a36(2308)).
head(id(137),a5(594)).
head(id(138),a6(594)).
head(id(139),a7(594)).
head(id(140),a8(594)).
head(id(141),a9(594)).
head(id(142),a13(594)).
head(id(143),n(594)).
head(id(144),a18(594)).
head(id(145),a26(594)).
head(id(146),a35(594)).
head(id(147),a36(594)).
head(id(148),a6(259)).
head(id(149),a7(259)).
head(id(150),a8(259)).
head(id(151),a9(259)).
head(id(152),a11(259)).
head(id(153),a13(259)).
head(id(154),w(259)).
head(id(155),a18(259)).
head(id(156),a22(259)).
head(id(157),a26(259)).
head(id(158),a34(259)).
head(id(159),a35(259)).
head(id(160),a7(107)).
head(id(161),a8(107)).
head(id(162),a9(107)).
head(id(163),a11(107)).
head(id(164),a13(107)).
head(id(165),w(107)).
head(id(166),a18(107)).
head(id(167),a20(107)).
head(id(168),a26(107)).
head(id(169),a34(107)).
head(id(170),a35(107)).
head(id(171),a6(339)).
head(id(172),a9(339)).
head(id(173),a13(339)).
head(id(174),n(339)).
head(id(175),a22(339)).
head(id(176),a24(339)).
head(id(177),a35(339)).
head(id(178),a9(671)).
head(id(179),n(671)).
head(id(180),a18(671)).
head(id(181),a22(671)).
head(id(182),a34(671)).
head(id(183),a35(671)).
head(id(184),a36(671)).
head(id(185),a6(591)).
head(id(186),a13(591)).
head(id(187),n(591)).
head(id(188),a24(591)).
head(id(189),a26(591)).
head(id(190),a33(591)).
head(id(191),a35(591)).
head(id(192),a36(591)).
head(id(193),a1(2912)).
head(id(194),a4(2912)).
head(id(195),a6(2912)).
head(id(196),a11(2912)).
head(id(197),a13(2912)).
head(id(198),n(2912)).
head(id(199),a18(2912)).
head(id(200),a24(2912)).
head(id(201),a26(2912)).
head(id(202),a27(2912)).
head(id(203),a31(2912)).
head(id(204),a33(2912)).
head(id(205),a35(2912)).
head(id(206),w(3154)).
head(id(207),a18(3154)).
head(id(208),a20(3154)).
head(id(209),a24(3154)).
head(id(210),a26(3154)).
head(id(211),a29(3154)).
head(id(212),a32(3154)).
head(id(213),a34(3154)).
head(id(214),a6(3121)).
head(id(215),a9(3121)).
head(id(216),a13(3121)).
head(id(217),n(3121)).
head(id(218),a16(3121)).
head(id(219),a22(3121)).
head(id(220),a24(3121)).
head(id(221),a33(3121)).
head(id(222),a35(3121)).
head(id(223),a36(3121)).
head(id(224),a6(1452)).
head(id(225),a7(1452)).
head(id(226),a10(1452)).
head(id(227),a11(1452)).
head(id(228),n(1452)).
head(id(229),a18(1452)).
head(id(230),a26(1452)).
head(id(231),a34(1452)).
head(id(232),a35(1452)).
head(id(233),a10(1408)).
head(id(234),n(1408)).
head(id(235),a18(1408)).
head(id(236),a24(1408)).
head(id(237),a26(1408)).
head(id(238),a34(1408)).
head(id(239),a35(1408)).
head(id(240),a6(1531)).
head(id(241),a10(1531)).
head(id(242),a12(1531)).
head(id(243),n(1531)).
head(id(244),a18(1531)).
head(id(245),a34(1531)).
head(id(246),a35(1531)).
head(id(247),a4(3020)).
head(id(248),a5(3020)).
head(id(249),a6(3020)).
head(id(250),n(3020)).
head(id(251),a24(3020)).
head(id(252),a26(3020)).
head(id(253),a27(3020)).
head(id(254),a33(3020)).
head(id(255),a35(3020)).
head(id(256),a36(3020)).
head(id(257),a7(1250)).
head(id(258),a10(1250)).
head(id(259),a11(1250)).
head(id(260),a13(1250)).
head(id(261),n(1250)).
head(id(262),a18(1250)).
head(id(263),a26(1250)).
head(id(264),a33(1250)).
head(id(265),a34(1250)).
head(id(266),a35(1250)).
head(id(267),a5(1481)).
head(id(268),a6(1481)).
head(id(269),a7(1481)).
head(id(270),a8(1481)).
head(id(271),a9(1481)).
head(id(272),a10(1481)).
head(id(273),a11(1481)).
head(id(274),n(1481)).
head(id(275),a18(1481)).
head(id(276),a26(1481)).
head(id(277),a34(1481)).
head(id(278),a35(1481)).
head(id(279),a1(2494)).
head(id(280),a3(2494)).
head(id(281),a7(2494)).
head(id(282),a8(2494)).
head(id(283),a9(2494)).
head(id(284),a10(2494)).
head(id(285),a11(2494)).
head(id(286),a13(2494)).
head(id(287),b(2494)).
head(id(288),a18(2494)).
head(id(289),a24(2494)).
head(id(290),a26(2494)).
head(id(291),a35(2494)).
head(id(292),a1(2833)).
head(id(293),a2(2833)).
head(id(294),a13(2833)).
head(id(295),b(2833)).
head(id(296),a18(2833)).
head(id(297),a26(2833)).
head(id(298),a32(2833)).
head(id(299),a11(925)).
head(id(300),a13(925)).
head(id(301),n(925)).
head(id(302),a18(925)).
head(id(303),a20(925)).
head(id(304),a26(925)).
head(id(305),a31(925)).
head(id(306),a33(925)).
head(id(307),a34(925)).
head(id(308),a2(1285)).
head(id(309),a10(1285)).
head(id(310),a13(1285)).
head(id(311),n(1285)).
head(id(312),a26(1285)).
head(id(313),a33(1285)).
head(id(314),a34(1285)).
head(id(315),a35(1285)).
head(id(316),a5(1144)).
head(id(317),a6(1144)).
head(id(318),a7(1144)).
head(id(319),n(1144)).
head(id(320),a18(1144)).
head(id(321),a24(1144)).
head(id(322),a33(1144)).
head(id(323),a34(1144)).
head(id(324),a35(1144)).
head(id(325),a7(1305)).
head(id(326),a8(1305)).
head(id(327),a9(1305)).
head(id(328),a10(1305)).
head(id(329),a11(1305)).
head(id(330),a13(1305)).
head(id(331),n(1305)).
head(id(332),a26(1305)).
head(id(333),a33(1305)).
head(id(334),a34(1305)).
head(id(335),a35(1305)).
head(id(336),a5(2855)).
head(id(337),a7(2855)).
head(id(338),a11(2855)).
head(id(339),a13(2855)).
head(id(340),n(2855)).
head(id(341),a20(2855)).
head(id(342),a26(2855)).
head(id(343),a31(2855)).
head(id(344),a33(2855)).
head(id(345),a1(3159)).
head(id(346),a7(3159)).
head(id(347),b(3159)).
head(id(348),a18(3159)).
head(id(349),a23(3159)).
head(id(350),a26(3159)).
head(id(351),a29(3159)).
head(id(352),a32(3159)).
head(id(353),a34(3159)).
head(id(354),a2(2616)).
head(id(355),a6(2616)).
head(id(356),a10(2616)).
head(id(357),a13(2616)).
head(id(358),n(2616)).
head(id(359),a16(2616)).
head(id(360),a18(2616)).
head(id(361),a24(2616)).
head(id(362),a33(2616)).
head(id(363),a34(2616)).
head(id(364),a35(2616)).
head(id(365),a13(3094)).
head(id(366),n(3094)).
head(id(367),a27(3094)).
head(id(368),a30(3094)).
head(id(369),a33(3094)).
head(id(370),a35(3094)).
head(id(371),a36(3094)).
head(id(1552,A),krkp(A)) :- dom(A).
body(id(1552,A),alpha_1(A)) :- dom(A).
body(id(1552,A),a6(A)) :- dom(A).
head(id(3170,A),krkp(A)) :- dom(A).
body(id(3170,A),alpha_2(A)) :- dom(A).
body(id(3170,A),a5(A)) :- dom(A).
head(id(6034,A),krkp(A)) :- dom(A).
body(id(6034,A),alpha_3(A)) :- dom(A).
body(id(6034,A),a9(A)) :- dom(A).
head(id(8517,A),krkp(A)) :- dom(A).
body(id(8517,A),alpha_4(A)) :- dom(A).
body(id(8517,A),a13(A)) :- dom(A).
head(id(13163,A),c_alpha_1(A)) :- dom(A).
body(id(13163,A),a5(A)) :- dom(A).
head(id(14844,A),c_alpha_1(A)) :- dom(A).
body(id(14844,A),a7(A)) :- dom(A).
head(id(16945,A),c_alpha_1(A)) :- dom(A).
body(id(16945,A),a10(A)) :- dom(A).
head(id(18203,A),c_alpha_1(A)) :- dom(A).
body(id(18203,A),a1(A)) :- dom(A).
head(id(20304,A),c_alpha_1(A)) :- dom(A).
body(id(20304,A),a9(A)) :- dom(A).
head(id(21144,A),c_alpha_2(A)) :- dom(A).
body(id(21144,A),a5(A)) :- dom(A).
head(id(23240,A),c_alpha_3(A)) :- dom(A).
body(id(23240,A),a7(A)) :- dom(A).
head(id(26589,A),c_alpha_3(A)) :- dom(A).
body(id(26589,A),a13(A)) :- dom(A).
head(id(27845,A),c_alpha_4(A)) :- dom(A).
body(id(27845,A),alpha_5(A)) :- dom(A).
body(id(27845,A),a11(A)) :- dom(A).
head(id(29563,A),c_alpha_4(A)) :- dom(A).
body(id(29563,A),alpha_6(A)) :- dom(A).
body(id(29563,A),a2(A)) :- dom(A).
head(id(34313,A),c_alpha_4(A)) :- dom(A).
body(id(34313,A),alpha_7(A)) :- dom(A).
body(id(34313,A),n(A)) :- dom(A).
head(id(36091,A),c_alpha_5(A)) :- dom(A).
body(id(36091,A),alpha_8(A)) :- dom(A).
body(id(36091,A),a7(A)) :- dom(A).
head(id(38325,A),c_alpha_5(A)) :- dom(A).
body(id(38325,A),a5(A)) :- dom(A).
head(id(39217,A),c_alpha_5(A)) :- dom(A).
body(id(39217,A),a6(A)) :- dom(A).
head(id(41453,A),c_alpha_6(A)) :- dom(A).
body(id(41453,A),a5(A)) :- dom(A).
head(id(43246,A),c_alpha_6(A)) :- dom(A).
body(id(43246,A),a9(A)) :- dom(A).
head(id(46835,A),c_alpha_7(A)) :- dom(A).
body(id(46835,A),alpha_9(A)) :- dom(A).
body(id(46835,A),a8(A)) :- dom(A).
head(id(50014,A),c_alpha_7(A)) :- dom(A).
body(id(50014,A),alpha_4(A)) :- dom(A).
body(id(50014,A),a13(A)) :- dom(A).
head(id(54954,A),c_alpha_8(A)) :- dom(A).
body(id(54954,A),a1(A)) :- dom(A).
head(id(55846,A),c_alpha_9(A)) :- dom(A).
body(id(55846,A),a7(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
assumption(alpha_4(A)) :- dom(A).
assumption(alpha_5(A)) :- dom(A).
assumption(alpha_6(A)) :- dom(A).
assumption(alpha_7(A)) :- dom(A).
assumption(alpha_8(A)) :- dom(A).
assumption(alpha_9(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).
contrary(alpha_4(A),c_alpha_4(A)) :- assumption(alpha_4(A)).
contrary(alpha_5(A),c_alpha_5(A)) :- assumption(alpha_5(A)).
contrary(alpha_6(A),c_alpha_6(A)) :- assumption(alpha_6(A)).
contrary(alpha_7(A),c_alpha_7(A)) :- assumption(alpha_7(A)).
contrary(alpha_8(A),c_alpha_8(A)) :- assumption(alpha_8(A)).
contrary(alpha_9(A),c_alpha_9(A)) :- assumption(alpha_9(A)).

dom(107).
dom(241).
dom(259).
dom(296).
dom(339).
dom(420).
dom(591).
dom(594).
dom(600).
dom(611).
dom(671).
dom(703).
dom(751).
dom(925).
dom(1144).
dom(1250).
dom(1285).
dom(1305).
dom(1408).
dom(1452).
dom(1481).
dom(1531).
dom(1809).
dom(1918).
dom(2181).
dom(2221).
dom(2258).
dom(2266).
dom(2308).
dom(2324).
dom(2494).
dom(2616).
dom(2833).
dom(2855).
dom(2912).
dom(3020).
dom(3094).
dom(3121).
dom(3154).
dom(3159).
