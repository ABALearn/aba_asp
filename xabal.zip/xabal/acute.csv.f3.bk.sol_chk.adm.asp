head(id(1),a4(11)).
head(id(2),a5(11)).
head(id(3),a6(11)).
head(id(4),lo(54)).
head(id(5),a4(54)).
head(id(6),a5(54)).
head(id(7),a6(54)).
head(id(8),lo(37)).
head(id(9),a4(37)).
head(id(10),hi(84)).
head(id(11),a2(84)).
head(id(12),a3(84)).
head(id(13),a4(84)).
head(id(14),a5(84)).
head(id(15),a6(84)).
head(id(16),hi(80)).
head(id(17),a2(80)).
head(id(18),a3(80)).
head(id(19),a4(80)).
head(id(20),a5(80)).
head(id(21),a6(80)).
head(id(22),lo(47)).
head(id(23),a4(47)).
head(id(24),a5(47)).
head(id(25),a4(7)).
head(id(26),a5(7)).
head(id(27),a6(7)).
head(id(28),lo(48)).
head(id(29),a4(48)).
head(id(30),a5(48)).
head(id(31),a6(48)).
head(id(32),lo(59)).
head(id(33),a4(59)).
head(id(34),a5(59)).
head(id(35),a6(59)).
head(id(36),lo(52)).
head(id(37),a4(52)).
head(id(38),a4(19)).
head(id(39),a5(19)).
head(id(40),a6(19)).
head(id(41),hi(85)).
head(id(42),a2(85)).
head(id(43),a3(85)).
head(id(44),a4(85)).
head(id(45),a5(85)).
head(id(46),a4(22)).
head(id(47),a5(22)).
head(id(48),a4(26)).
head(id(49),a5(26)).
head(id(50),a6(26)).
head(id(51),a4(30)).
head(id(52),a5(30)).
head(id(53),a6(30)).
head(id(54),lo(57)).
head(id(55),a4(57)).
head(id(56),a5(57)).
head(id(57),a4(17)).
head(id(58),a5(17)).
head(id(59),a6(17)).
head(id(60),lo(50)).
head(id(61),a4(50)).
head(id(62),a5(50)).
head(id(63),hi(99)).
head(id(64),a2(99)).
head(id(65),a3(99)).
head(id(66),a4(99)).
head(id(67),a5(99)).
head(id(68),hi(90)).
head(id(69),a2(90)).
head(id(70),a3(90)).
head(id(71),a4(90)).
head(id(72),a5(90)).
head(id(73),a6(90)).
head(id(74),lo(49)).
head(id(75),a4(49)).
head(id(76),a5(49)).
head(id(77),lo(44)).
head(id(78),a4(44)).
head(id(79),lo(40)).
head(id(80),a4(40)).
head(id(81),a5(40)).
head(id(82),mo(66)).
head(id(83),a3(66)).
head(id(84),a4(66)).
head(id(85),a6(66)).
head(id(86),mo(64)).
head(id(87),a3(64)).
head(id(88),a4(64)).
head(id(89),a6(64)).
head(id(90),hi(82)).
head(id(91),a2(82)).
head(id(92),a3(82)).
head(id(93),a5(82)).
head(id(94),hi(78)).
head(id(95),a3(78)).
head(id(96),a4(78)).
head(id(97),a6(78)).
head(id(98),hi(96)).
head(id(99),a2(96)).
head(id(100),a3(96)).
head(id(101),a5(96)).
head(id(102),vh(110)).
head(id(103),a3(110)).
head(id(104),a4(110)).
head(id(105),a6(110)).
head(id(106),lo(58)).
head(id(107),a3(58)).
head(id(108),hi(69)).
head(id(109),a3(69)).
head(id(110),a4(69)).
head(id(111),a6(69)).
head(id(112),a3(33)).
head(id(113),hi(74)).
head(id(114),lo(51)).
head(id(115),a3(51)).
head(id(116),a3(20)).
head(id(117),a3(3)).
head(id(118),mo(68)).
head(id(119),a3(68)).
head(id(120),a4(68)).
head(id(121),a6(68)).
head(id(122),a3(5)).
head(id(123),hi(87)).
head(id(124),hi(75)).
head(id(125),vh(114)).
head(id(126),a3(114)).
head(id(127),a4(114)).
head(id(128),a6(114)).
head(id(129),a3(1)).
head(id(130),lo(38)).
head(id(131),a3(38)).
head(id(132),hi(76)).
head(id(133),a2(76)).
head(id(134),a3(76)).
head(id(135),a5(76)).
head(id(136),a3(8)).
head(id(137),hi(97)).
head(id(138),a3(97)).
head(id(139),a4(97)).
head(id(140),a6(97)).
head(id(141),lo(35)).
head(id(142),a3(35)).
head(id(143),hi(103)).
head(id(646,A),acute(A)) :- dom(A).
body(id(646,A),alpha_1(A)) :- dom(A).
body(id(646,A),a4(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).

dom(1).
dom(3).
dom(5).
dom(7).
dom(8).
dom(11).
dom(17).
dom(19).
dom(20).
dom(22).
dom(26).
dom(30).
dom(33).
dom(35).
dom(37).
dom(38).
dom(40).
dom(44).
dom(47).
dom(48).
dom(49).
dom(50).
dom(51).
dom(52).
dom(54).
dom(57).
dom(58).
dom(59).
dom(64).
dom(66).
dom(68).
dom(69).
dom(74).
dom(75).
dom(76).
dom(78).
dom(80).
dom(82).
dom(84).
dom(85).
dom(87).
dom(90).
dom(96).
dom(97).
dom(99).
dom(103).
dom(110).
dom(114).
 :- not supported(acute(11)).
 :- not supported(acute(54)).
 :- not supported(acute(37)).
 :- not supported(acute(84)).
 :- not supported(acute(80)).
 :- not supported(acute(47)).
 :- not supported(acute(7)).
 :- not supported(acute(48)).
 :- not supported(acute(59)).
 :- not supported(acute(52)).
 :- not supported(acute(19)).
 :- not supported(acute(85)).
 :- not supported(acute(22)).
 :- not supported(acute(26)).
 :- not supported(acute(30)).
 :- not supported(acute(57)).
 :- not supported(acute(17)).
 :- not supported(acute(50)).
 :- not supported(acute(99)).
 :- not supported(acute(90)).
 :- not supported(acute(49)).
 :- not supported(acute(44)).
 :- not supported(acute(40)).
 :- supported(acute(66)).
 :- supported(acute(64)).
 :- supported(acute(82)).
 :- supported(acute(78)).
 :- supported(acute(96)).
 :- supported(acute(110)).
 :- supported(acute(58)).
 :- supported(acute(69)).
 :- supported(acute(33)).
 :- supported(acute(74)).
 :- supported(acute(51)).
 :- supported(acute(20)).
 :- supported(acute(3)).
 :- supported(acute(68)).
 :- supported(acute(5)).
 :- supported(acute(87)).
 :- supported(acute(75)).
 :- supported(acute(114)).
 :- supported(acute(1)).
 :- supported(acute(38)).
 :- supported(acute(76)).
 :- supported(acute(8)).
 :- supported(acute(97)).
 :- supported(acute(35)).
 :- supported(acute(103)).
