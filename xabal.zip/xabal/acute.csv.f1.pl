% training data:
% no. positive ex.: 24
% no. negative ex.: 25
% query: 
train :- aba_asp('./xabal/acute.csv.f1.bk',[acute(47),acute(7),acute(48),acute(59),acute(52),acute(19),acute(14),acute(89),acute(21),acute(100),acute(71),acute(9),acute(85),acute(22),acute(26),acute(30),acute(57),acute(17),acute(50),acute(99),acute(90),acute(49),acute(44),acute(40)],[acute(58),acute(69),acute(33),acute(74),acute(51),acute(20),acute(95),acute(113),acute(88),acute(53),acute(23),acute(16),acute(3),acute(68),acute(5),acute(87),acute(75),acute(114),acute(1),acute(38),acute(76),acute(8),acute(97),acute(35),acute(103)]).
% test data:
% no. positive ex.: 5
% no. negative ex.: 6
% query: 
test :- test_abaf('./xabal/acute.csv.f1.bk.sol',[pos(acute(11),[a4(11),a5(11),a6(11)]),pos(acute(54),[lo(54),a4(54),a5(54),a6(54)]),pos(acute(37),[lo(37),a4(37)]),pos(acute(84),[hi(84),a2(84),a3(84),a4(84),a5(84),a6(84)]),pos(acute(80),[hi(80),a2(80),a3(80),a4(80),a5(80),a6(80)])],[neg(acute(66),[mo(66),a3(66),a4(66),a6(66)]),neg(acute(64),[mo(64),a3(64),a4(64),a6(64)]),neg(acute(82),[hi(82),a2(82),a3(82),a5(82)]),neg(acute(78),[hi(78),a3(78),a4(78),a6(78)]),neg(acute(96),[hi(96),a2(96),a3(96),a5(96)]),neg(acute(110),[vh(110),a3(110),a4(110),a6(110)])]).
