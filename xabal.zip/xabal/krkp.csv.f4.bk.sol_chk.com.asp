head(id(1),a6(2221)).
head(id(2),a9(2221)).
head(id(3),a11(2221)).
head(id(4),a13(2221)).
head(id(5),n(2221)).
head(id(6),a18(2221)).
head(id(7),a20(2221)).
head(id(8),a21(2221)).
head(id(9),a22(2221)).
head(id(10),a26(2221)).
head(id(11),a31(2221)).
head(id(12),a33(2221)).
head(id(13),a34(2221)).
head(id(14),a6(420)).
head(id(15),a9(420)).
head(id(16),a11(420)).
head(id(17),n(420)).
head(id(18),a18(420)).
head(id(19),a22(420)).
head(id(20),a26(420)).
head(id(21),a34(420)).
head(id(22),a35(420)).
head(id(23),a5(296)).
head(id(24),a7(296)).
head(id(25),a8(296)).
head(id(26),a9(296)).
head(id(27),a13(296)).
head(id(28),n(296)).
head(id(29),a18(296)).
head(id(30),a24(296)).
head(id(31),a34(296)).
head(id(32),a35(296)).
head(id(33),a5(2181)).
head(id(34),a11(2181)).
head(id(35),a13(2181)).
head(id(36),w(2181)).
head(id(37),a21(2181)).
head(id(38),a26(2181)).
head(id(39),a31(2181)).
head(id(40),a2(2266)).
head(id(41),a5(2266)).
head(id(42),a9(2266)).
head(id(43),a13(2266)).
head(id(44),n(2266)).
head(id(45),a21(2266)).
head(id(46),a22(2266)).
head(id(47),a35(2266)).
head(id(48),a5(241)).
head(id(49),a6(241)).
head(id(50),a7(241)).
head(id(51),a11(241)).
head(id(52),a13(241)).
head(id(53),w(241)).
head(id(54),a24(241)).
head(id(55),a26(241)).
head(id(56),a34(241)).
head(id(57),a35(241)).
head(id(58),a6(1809)).
head(id(59),a7(1809)).
head(id(60),a11(1809)).
head(id(61),a13(1809)).
head(id(62),w(1809)).
head(id(63),a20(1809)).
head(id(64),a26(1809)).
head(id(65),a31(1809)).
head(id(66),a9(600)).
head(id(67),a13(600)).
head(id(68),n(600)).
head(id(69),a18(600)).
head(id(70),a22(600)).
head(id(71),a34(600)).
head(id(72),a35(600)).
head(id(73),a36(600)).
head(id(74),a2(1918)).
head(id(75),a3(1918)).
head(id(76),a6(1918)).
head(id(77),n(1918)).
head(id(78),a18(1918)).
head(id(79),a24(1918)).
head(id(80),a26(1918)).
head(id(81),a35(1918)).
head(id(82),a36(1918)).
head(id(83),a5(751)).
head(id(84),a6(751)).
head(id(85),a7(751)).
head(id(86),a13(751)).
head(id(87),n(751)).
head(id(88),a21(751)).
head(id(89),a35(751)).
head(id(90),a1(200)).
head(id(91),a6(200)).
head(id(92),a7(200)).
head(id(93),a11(200)).
head(id(94),a13(200)).
head(id(95),b(200)).
head(id(96),a18(200)).
head(id(97),a24(200)).
head(id(98),a26(200)).
head(id(99),a34(200)).
head(id(100),a35(200)).
head(id(101),a2(1702)).
head(id(102),a11(1702)).
head(id(103),a13(1702)).
head(id(104),w(1702)).
head(id(105),a20(1702)).
head(id(106),a26(1702)).
head(id(107),a31(1702)).
head(id(108),a5(68)).
head(id(109),a7(68)).
head(id(110),a13(68)).
head(id(111),n(68)).
head(id(112),a24(68)).
head(id(113),a26(68)).
head(id(114),a34(68)).
head(id(115),a35(68)).
head(id(116),a10(2011)).
head(id(117),a11(2011)).
head(id(118),a13(2011)).
head(id(119),w(2011)).
head(id(120),a18(2011)).
head(id(121),a20(2011)).
head(id(122),a21(2011)).
head(id(123),a24(2011)).
head(id(124),a26(2011)).
head(id(125),a31(2011)).
head(id(126),a33(2011)).
head(id(127),a34(2011)).
head(id(128),a35(2011)).
head(id(129),a1(49)).
head(id(130),a11(49)).
head(id(131),a13(49)).
head(id(132),n(49)).
head(id(133),a18(49)).
head(id(134),a24(49)).
head(id(135),a26(49)).
head(id(136),a31(49)).
head(id(137),a34(49)).
head(id(138),a5(594)).
head(id(139),a6(594)).
head(id(140),a7(594)).
head(id(141),a8(594)).
head(id(142),a9(594)).
head(id(143),a13(594)).
head(id(144),n(594)).
head(id(145),a18(594)).
head(id(146),a26(594)).
head(id(147),a35(594)).
head(id(148),a36(594)).
head(id(149),a6(259)).
head(id(150),a7(259)).
head(id(151),a8(259)).
head(id(152),a9(259)).
head(id(153),a11(259)).
head(id(154),a13(259)).
head(id(155),w(259)).
head(id(156),a18(259)).
head(id(157),a22(259)).
head(id(158),a26(259)).
head(id(159),a34(259)).
head(id(160),a35(259)).
head(id(161),a7(107)).
head(id(162),a8(107)).
head(id(163),a9(107)).
head(id(164),a11(107)).
head(id(165),a13(107)).
head(id(166),w(107)).
head(id(167),a18(107)).
head(id(168),a20(107)).
head(id(169),a26(107)).
head(id(170),a34(107)).
head(id(171),a35(107)).
head(id(172),a6(339)).
head(id(173),a9(339)).
head(id(174),a13(339)).
head(id(175),n(339)).
head(id(176),a22(339)).
head(id(177),a24(339)).
head(id(178),a35(339)).
head(id(179),a9(671)).
head(id(180),n(671)).
head(id(181),a18(671)).
head(id(182),a22(671)).
head(id(183),a34(671)).
head(id(184),a35(671)).
head(id(185),a36(671)).
head(id(186),a6(591)).
head(id(187),a13(591)).
head(id(188),n(591)).
head(id(189),a24(591)).
head(id(190),a26(591)).
head(id(191),a33(591)).
head(id(192),a35(591)).
head(id(193),a36(591)).
head(id(194),a1(2912)).
head(id(195),a4(2912)).
head(id(196),a6(2912)).
head(id(197),a11(2912)).
head(id(198),a13(2912)).
head(id(199),n(2912)).
head(id(200),a18(2912)).
head(id(201),a24(2912)).
head(id(202),a26(2912)).
head(id(203),a27(2912)).
head(id(204),a31(2912)).
head(id(205),a33(2912)).
head(id(206),a35(2912)).
head(id(207),w(3154)).
head(id(208),a18(3154)).
head(id(209),a20(3154)).
head(id(210),a24(3154)).
head(id(211),a26(3154)).
head(id(212),a29(3154)).
head(id(213),a32(3154)).
head(id(214),a34(3154)).
head(id(215),a6(3121)).
head(id(216),a9(3121)).
head(id(217),a13(3121)).
head(id(218),n(3121)).
head(id(219),a16(3121)).
head(id(220),a22(3121)).
head(id(221),a24(3121)).
head(id(222),a33(3121)).
head(id(223),a35(3121)).
head(id(224),a36(3121)).
head(id(225),a6(1452)).
head(id(226),a7(1452)).
head(id(227),a10(1452)).
head(id(228),a11(1452)).
head(id(229),n(1452)).
head(id(230),a18(1452)).
head(id(231),a26(1452)).
head(id(232),a34(1452)).
head(id(233),a35(1452)).
head(id(234),a10(1408)).
head(id(235),n(1408)).
head(id(236),a18(1408)).
head(id(237),a24(1408)).
head(id(238),a26(1408)).
head(id(239),a34(1408)).
head(id(240),a35(1408)).
head(id(241),a6(1531)).
head(id(242),a10(1531)).
head(id(243),a12(1531)).
head(id(244),n(1531)).
head(id(245),a18(1531)).
head(id(246),a34(1531)).
head(id(247),a35(1531)).
head(id(248),a4(3020)).
head(id(249),a5(3020)).
head(id(250),a6(3020)).
head(id(251),n(3020)).
head(id(252),a24(3020)).
head(id(253),a26(3020)).
head(id(254),a27(3020)).
head(id(255),a33(3020)).
head(id(256),a35(3020)).
head(id(257),a36(3020)).
head(id(258),a7(1250)).
head(id(259),a10(1250)).
head(id(260),a11(1250)).
head(id(261),a13(1250)).
head(id(262),n(1250)).
head(id(263),a18(1250)).
head(id(264),a26(1250)).
head(id(265),a33(1250)).
head(id(266),a34(1250)).
head(id(267),a35(1250)).
head(id(268),a5(1481)).
head(id(269),a6(1481)).
head(id(270),a7(1481)).
head(id(271),a8(1481)).
head(id(272),a9(1481)).
head(id(273),a10(1481)).
head(id(274),a11(1481)).
head(id(275),n(1481)).
head(id(276),a18(1481)).
head(id(277),a26(1481)).
head(id(278),a34(1481)).
head(id(279),a35(1481)).
head(id(280),a6(2576)).
head(id(281),a7(2576)).
head(id(282),a10(2576)).
head(id(283),a11(2576)).
head(id(284),a13(2576)).
head(id(285),w(2576)).
head(id(286),a18(2576)).
head(id(287),a20(2576)).
head(id(288),a26(2576)).
head(id(289),a31(2576)).
head(id(290),a33(2576)).
head(id(291),a34(2576)).
head(id(292),a11(2821)).
head(id(293),a13(2821)).
head(id(294),n(2821)).
head(id(295),a18(2821)).
head(id(296),a20(2821)).
head(id(297),a26(2821)).
head(id(298),a27(2821)).
head(id(299),a31(2821)).
head(id(300),a33(2821)).
head(id(301),a34(2821)).
head(id(302),a5(1045)).
head(id(303),a6(1045)).
head(id(304),a7(1045)).
head(id(305),a8(1045)).
head(id(306),a9(1045)).
head(id(307),a13(1045)).
head(id(308),n(1045)).
head(id(309),a18(1045)).
head(id(310),a33(1045)).
head(id(311),a35(1045)).
head(id(312),a10(1494)).
head(id(313),n(1494)).
head(id(314),a18(1494)).
head(id(315),a24(1494)).
head(id(316),a33(1494)).
head(id(317),a34(1494)).
head(id(318),a35(1494)).
head(id(319),a5(2868)).
head(id(320),a9(2868)).
head(id(321),a13(2868)).
head(id(322),n(2868)).
head(id(323),a20(2868)).
head(id(324),a22(2868)).
head(id(325),a26(2868)).
head(id(326),a32(2868)).
head(id(327),a34(2868)).
head(id(328),a7(1305)).
head(id(329),a8(1305)).
head(id(330),a9(1305)).
head(id(331),a10(1305)).
head(id(332),a11(1305)).
head(id(333),a13(1305)).
head(id(334),n(1305)).
head(id(335),a26(1305)).
head(id(336),a33(1305)).
head(id(337),a34(1305)).
head(id(338),a35(1305)).
head(id(339),a5(2855)).
head(id(340),a7(2855)).
head(id(341),a11(2855)).
head(id(342),a13(2855)).
head(id(343),n(2855)).
head(id(344),a20(2855)).
head(id(345),a26(2855)).
head(id(346),a31(2855)).
head(id(347),a33(2855)).
head(id(348),a1(3159)).
head(id(349),a7(3159)).
head(id(350),b(3159)).
head(id(351),a18(3159)).
head(id(352),a23(3159)).
head(id(353),a26(3159)).
head(id(354),a29(3159)).
head(id(355),a32(3159)).
head(id(356),a34(3159)).
head(id(357),a2(2616)).
head(id(358),a6(2616)).
head(id(359),a10(2616)).
head(id(360),a13(2616)).
head(id(361),n(2616)).
head(id(362),a16(2616)).
head(id(363),a18(2616)).
head(id(364),a24(2616)).
head(id(365),a33(2616)).
head(id(366),a34(2616)).
head(id(367),a35(2616)).
head(id(368),a13(3094)).
head(id(369),n(3094)).
head(id(370),a27(3094)).
head(id(371),a30(3094)).
head(id(372),a33(3094)).
head(id(373),a35(3094)).
head(id(374),a36(3094)).
head(id(1564,A),krkp(A)) :- dom(A).
body(id(1564,A),alpha_1(A)) :- dom(A).
body(id(1564,A),a6(A)) :- dom(A).
head(id(3198,A),krkp(A)) :- dom(A).
body(id(3198,A),alpha_2(A)) :- dom(A).
body(id(3198,A),a5(A)) :- dom(A).
head(id(6097,A),krkp(A)) :- dom(A).
body(id(6097,A),alpha_3(A)) :- dom(A).
body(id(6097,A),a9(A)) :- dom(A).
head(id(8616,A),krkp(A)) :- dom(A).
body(id(8616,A),alpha_4(A)) :- dom(A).
body(id(8616,A),a2(A)) :- dom(A).
head(id(10310,A),krkp(A)) :- dom(A).
body(id(10310,A),alpha_5(A)) :- dom(A).
body(id(10310,A),a10(A)) :- dom(A).
head(id(11620,A),krkp(A)) :- dom(A).
body(id(11620,A),alpha_6(A)) :- dom(A).
body(id(11620,A),a1(A)) :- dom(A).
head(id(15124,A),c_alpha_1(A)) :- dom(A).
body(id(15124,A),a5(A)) :- dom(A).
head(id(17311,A),c_alpha_1(A)) :- dom(A).
body(id(17311,A),alpha_7(A)) :- dom(A).
body(id(17311,A),a7(A)) :- dom(A).
head(id(19520,A),c_alpha_1(A)) :- dom(A).
body(id(19520,A),a10(A)) :- dom(A).
head(id(21279,A),c_alpha_1(A)) :- dom(A).
body(id(21279,A),a1(A)) :- dom(A).
head(id(23480,A),c_alpha_1(A)) :- dom(A).
body(id(23480,A),a9(A)) :- dom(A).
head(id(27015,A),c_alpha_2(A)) :- dom(A).
body(id(27015,A),a8(A)) :- dom(A).
head(id(30548,A),c_alpha_2(A)) :- dom(A).
body(id(30548,A),alpha_8(A)) :- dom(A).
body(id(30548,A),a11(A)) :- dom(A).
head(id(32340,A),c_alpha_2(A)) :- dom(A).
body(id(32340,A),a9(A)) :- dom(A).
head(id(33234,A),c_alpha_2(A)) :- dom(A).
body(id(33234,A),a4(A)) :- dom(A).
head(id(37283,A),c_alpha_3(A)) :- dom(A).
body(id(37283,A),alpha_9(A)) :- dom(A).
body(id(37283,A),a8(A)) :- dom(A).
head(id(41387,A),c_alpha_3(A)) :- dom(A).
body(id(41387,A),alpha_10(A)) :- dom(A).
body(id(41387,A),a13(A)) :- dom(A).
head(id(43716,A),c_alpha_4(A)) :- dom(A).
body(id(43716,A),a6(A)) :- dom(A).
head(id(44646,A),c_alpha_5(A)) :- dom(A).
body(id(44646,A),a7(A)) :- dom(A).
head(id(46977,A),c_alpha_5(A)) :- dom(A).
body(id(46977,A),n(A)) :- dom(A).
head(id(51603,A),c_alpha_6(A)) :- dom(A).
body(id(51603,A),a4(A)) :- dom(A).
head(id(54842,A),c_alpha_6(A)) :- dom(A).
body(id(54842,A),alpha_11(A)) :- dom(A).
body(id(54842,A),b(A)) :- dom(A).
head(id(55777,A),c_alpha_7(A)) :- dom(A).
body(id(55777,A),a6(A)) :- dom(A).
head(id(57180,A),c_alpha_8(A)) :- dom(A).
body(id(57180,A),alpha_2(A)) :- dom(A).
body(id(57180,A),a5(A)) :- dom(A).
head(id(59055,A),c_alpha_9(A)) :- dom(A).
body(id(59055,A),alpha_7(A)) :- dom(A).
body(id(59055,A),a7(A)) :- dom(A).
head(id(63302,A),c_alpha_9(A)) :- dom(A).
body(id(63302,A),alpha_3(A)) :- dom(A).
body(id(63302,A),a9(A)) :- dom(A).
head(id(67547,A),c_alpha_10(A)) :- dom(A).
body(id(67547,A),alpha_3(A)) :- dom(A).
body(id(67547,A),a9(A)) :- dom(A).
head(id(71764,A),c_alpha_11(A)) :- dom(A).
body(id(71764,A),alpha_6(A)) :- dom(A).
body(id(71764,A),a1(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
assumption(alpha_4(A)) :- dom(A).
assumption(alpha_5(A)) :- dom(A).
assumption(alpha_6(A)) :- dom(A).
assumption(alpha_7(A)) :- dom(A).
assumption(alpha_8(A)) :- dom(A).
assumption(alpha_9(A)) :- dom(A).
assumption(alpha_10(A)) :- dom(A).
assumption(alpha_11(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).
contrary(alpha_4(A),c_alpha_4(A)) :- assumption(alpha_4(A)).
contrary(alpha_5(A),c_alpha_5(A)) :- assumption(alpha_5(A)).
contrary(alpha_6(A),c_alpha_6(A)) :- assumption(alpha_6(A)).
contrary(alpha_7(A),c_alpha_7(A)) :- assumption(alpha_7(A)).
contrary(alpha_8(A),c_alpha_8(A)) :- assumption(alpha_8(A)).
contrary(alpha_9(A),c_alpha_9(A)) :- assumption(alpha_9(A)).
contrary(alpha_10(A),c_alpha_10(A)) :- assumption(alpha_10(A)).
contrary(alpha_11(A),c_alpha_11(A)) :- assumption(alpha_11(A)).

dom(49).
dom(68).
dom(107).
dom(200).
dom(241).
dom(259).
dom(296).
dom(339).
dom(420).
dom(591).
dom(594).
dom(600).
dom(671).
dom(751).
dom(1045).
dom(1250).
dom(1305).
dom(1408).
dom(1452).
dom(1481).
dom(1494).
dom(1531).
dom(1702).
dom(1809).
dom(1918).
dom(2011).
dom(2181).
dom(2221).
dom(2266).
dom(2576).
dom(2616).
dom(2821).
dom(2855).
dom(2868).
dom(2912).
dom(3020).
dom(3094).
dom(3121).
dom(3154).
dom(3159).
 :- not supported(krkp(2221)).
 :- not supported(krkp(420)).
 :- not supported(krkp(296)).
 :- not supported(krkp(2181)).
 :- not supported(krkp(2266)).
 :- not supported(krkp(241)).
 :- not supported(krkp(1809)).
 :- not supported(krkp(600)).
 :- not supported(krkp(1918)).
 :- not supported(krkp(751)).
 :- not supported(krkp(200)).
 :- not supported(krkp(1702)).
 :- not supported(krkp(68)).
 :- not supported(krkp(2011)).
 :- not supported(krkp(49)).
 :- not supported(krkp(594)).
 :- not supported(krkp(259)).
 :- not supported(krkp(107)).
 :- not supported(krkp(339)).
 :- not supported(krkp(671)).
 :- not supported(krkp(591)).
 :- supported(krkp(2912)).
 :- supported(krkp(3154)).
 :- supported(krkp(3121)).
 :- supported(krkp(1452)).
 :- supported(krkp(1408)).
 :- supported(krkp(1531)).
 :- supported(krkp(3020)).
 :- supported(krkp(1250)).
 :- supported(krkp(1481)).
 :- supported(krkp(2576)).
 :- supported(krkp(2821)).
 :- supported(krkp(1045)).
 :- supported(krkp(1494)).
 :- supported(krkp(2868)).
 :- supported(krkp(1305)).
 :- supported(krkp(2855)).
 :- supported(krkp(3159)).
 :- supported(krkp(2616)).
 :- supported(krkp(3094)).
