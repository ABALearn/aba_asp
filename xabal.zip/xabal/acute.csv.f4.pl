% training data:
% no. positive ex.: 23
% no. negative ex.: 25
% query: 
train :- aba_asp('./xabal/acute.csv.f4.bk',[acute(11),acute(54),acute(37),acute(84),acute(80),acute(47),acute(7),acute(48),acute(59),acute(52),acute(19),acute(14),acute(89),acute(21),acute(100),acute(71),acute(9),acute(50),acute(99),acute(90),acute(49),acute(44),acute(40)],[acute(66),acute(64),acute(82),acute(78),acute(96),acute(110),acute(58),acute(69),acute(33),acute(74),acute(51),acute(20),acute(95),acute(113),acute(88),acute(53),acute(23),acute(16),acute(1),acute(38),acute(76),acute(8),acute(97),acute(35),acute(103)]).
% test data:
% no. positive ex.: 6
% no. negative ex.: 6
% query: 
test :- test_abaf('./xabal/acute.csv.f4.bk.sol',[acute(11),acute(54),acute(37),acute(84),acute(80),acute(47),acute(7),acute(48),acute(59),acute(52),acute(19),acute(14),acute(89),acute(21),acute(100),acute(71),acute(9),acute(50),acute(99),acute(90),acute(49),acute(44),acute(40)],[acute(66),acute(64),acute(82),acute(78),acute(96),acute(110),acute(58),acute(69),acute(33),acute(74),acute(51),acute(20),acute(95),acute(113),acute(88),acute(53),acute(23),acute(16),acute(1),acute(38),acute(76),acute(8),acute(97),acute(35),acute(103)],[pos(acute(85),[hi(85),a2(85),a3(85),a4(85),a5(85)]),pos(acute(22),[a4(22),a5(22)]),pos(acute(26),[a4(26),a5(26),a6(26)]),pos(acute(30),[a4(30),a5(30),a6(30)]),pos(acute(57),[lo(57),a4(57),a5(57)]),pos(acute(17),[a4(17),a5(17),a6(17)])],[neg(acute(3),[a3(3)]),neg(acute(68),[mo(68),a3(68),a4(68),a6(68)]),neg(acute(5),[a3(5)]),neg(acute(87),[hi(87)]),neg(acute(75),[hi(75)]),neg(acute(114),[vh(114),a3(114),a4(114),a6(114)])]).
