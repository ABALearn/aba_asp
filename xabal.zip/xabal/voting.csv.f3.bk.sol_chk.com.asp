head(id(1),physician_fee_freeze(301)).
head(id(2),el_salvador_aid(301)).
head(id(3),anti_satellite_test_ban(301)).
head(id(4),aid_to_nicaraguan_contras(301)).
head(id(5),mx_missile(301)).
head(id(6),immigration(301)).
head(id(7),education_spending(301)).
head(id(8),superfund_right_to_sue(301)).
head(id(9),crime(301)).
head(id(10),export_administration_act_south_africa(301)).
head(id(11),handicapped_infants(405)).
head(id(12),water_project_cost_sharing(405)).
head(id(13),physician_fee_freeze(405)).
head(id(14),el_salvador_aid(405)).
head(id(15),religious_groups_in_schools(405)).
head(id(16),immigration(405)).
head(id(17),education_spending(405)).
head(id(18),superfund_right_to_sue(405)).
head(id(19),crime(405)).
head(id(20),export_administration_act_south_africa(405)).
head(id(21),physician_fee_freeze(143)).
head(id(22),el_salvador_aid(143)).
head(id(23),religious_groups_in_schools(143)).
head(id(24),anti_satellite_test_ban(143)).
head(id(25),aid_to_nicaraguan_contras(143)).
head(id(26),mx_missile(143)).
head(id(27),immigration(143)).
head(id(28),education_spending(143)).
head(id(29),superfund_right_to_sue(143)).
head(id(30),crime(143)).
head(id(31),export_administration_act_south_africa(143)).
head(id(32),physician_fee_freeze(357)).
head(id(33),el_salvador_aid(357)).
head(id(34),religious_groups_in_schools(357)).
head(id(35),education_spending(357)).
head(id(36),superfund_right_to_sue(357)).
head(id(37),crime(357)).
head(id(38),physician_fee_freeze(240)).
head(id(39),el_salvador_aid(240)).
head(id(40),religious_groups_in_schools(240)).
head(id(41),anti_satellite_test_ban(240)).
head(id(42),immigration(240)).
head(id(43),crime(240)).
head(id(44),duty_free_exports(240)).
head(id(45),export_administration_act_south_africa(240)).
head(id(46),physician_fee_freeze(406)).
head(id(47),el_salvador_aid(406)).
head(id(48),religious_groups_in_schools(406)).
head(id(49),education_spending(406)).
head(id(50),superfund_right_to_sue(406)).
head(id(51),crime(406)).
head(id(52),export_administration_act_south_africa(406)).
head(id(53),water_project_cost_sharing(62)).
head(id(54),physician_fee_freeze(62)).
head(id(55),el_salvador_aid(62)).
head(id(56),religious_groups_in_schools(62)).
head(id(57),education_spending(62)).
head(id(58),superfund_right_to_sue(62)).
head(id(59),crime(62)).
head(id(60),water_project_cost_sharing(59)).
head(id(61),physician_fee_freeze(59)).
head(id(62),el_salvador_aid(59)).
head(id(63),religious_groups_in_schools(59)).
head(id(64),immigration(59)).
head(id(65),education_spending(59)).
head(id(66),superfund_right_to_sue(59)).
head(id(67),crime(59)).
head(id(68),export_administration_act_south_africa(59)).
head(id(69),water_project_cost_sharing(34)).
head(id(70),physician_fee_freeze(34)).
head(id(71),el_salvador_aid(34)).
head(id(72),religious_groups_in_schools(34)).
head(id(73),education_spending(34)).
head(id(74),superfund_right_to_sue(34)).
head(id(75),crime(34)).
head(id(76),export_administration_act_south_africa(34)).
head(id(77),water_project_cost_sharing(164)).
head(id(78),physician_fee_freeze(164)).
head(id(79),el_salvador_aid(164)).
head(id(80),religious_groups_in_schools(164)).
head(id(81),anti_satellite_test_ban(164)).
head(id(82),education_spending(164)).
head(id(83),superfund_right_to_sue(164)).
head(id(84),crime(164)).
head(id(85),export_administration_act_south_africa(164)).
head(id(86),physician_fee_freeze(84)).
head(id(87),el_salvador_aid(84)).
head(id(88),religious_groups_in_schools(84)).
head(id(89),education_spending(84)).
head(id(90),superfund_right_to_sue(84)).
head(id(91),crime(84)).
head(id(92),physician_fee_freeze(83)).
head(id(93),el_salvador_aid(83)).
head(id(94),religious_groups_in_schools(83)).
head(id(95),immigration(83)).
head(id(96),education_spending(83)).
head(id(97),superfund_right_to_sue(83)).
head(id(98),crime(83)).
head(id(99),export_administration_act_south_africa(83)).
head(id(100),handicapped_infants(38)).
head(id(101),water_project_cost_sharing(38)).
head(id(102),physician_fee_freeze(38)).
head(id(103),el_salvador_aid(38)).
head(id(104),religious_groups_in_schools(38)).
head(id(105),superfund_right_to_sue(38)).
head(id(106),crime(38)).
head(id(107),export_administration_act_south_africa(38)).
head(id(108),water_project_cost_sharing(57)).
head(id(109),physician_fee_freeze(57)).
head(id(110),el_salvador_aid(57)).
head(id(111),religious_groups_in_schools(57)).
head(id(112),immigration(57)).
head(id(113),synfuels_corporation_cutback(57)).
head(id(114),education_spending(57)).
head(id(115),superfund_right_to_sue(57)).
head(id(116),crime(57)).
head(id(117),export_administration_act_south_africa(57)).
head(id(118),handicapped_infants(118)).
head(id(119),water_project_cost_sharing(118)).
head(id(120),budget_resolution(118)).
head(id(121),physician_fee_freeze(118)).
head(id(122),el_salvador_aid(118)).
head(id(123),anti_satellite_test_ban(118)).
head(id(124),education_spending(118)).
head(id(125),superfund_right_to_sue(118)).
head(id(126),crime(118)).
head(id(127),export_administration_act_south_africa(118)).
head(id(128),handicapped_infants(29)).
head(id(129),physician_fee_freeze(29)).
head(id(130),el_salvador_aid(29)).
head(id(131),anti_satellite_test_ban(29)).
head(id(132),aid_to_nicaraguan_contras(29)).
head(id(133),mx_missile(29)).
head(id(134),education_spending(29)).
head(id(135),superfund_right_to_sue(29)).
head(id(136),crime(29)).
head(id(137),export_administration_act_south_africa(29)).
head(id(138),water_project_cost_sharing(231)).
head(id(139),physician_fee_freeze(231)).
head(id(140),el_salvador_aid(231)).
head(id(141),religious_groups_in_schools(231)).
head(id(142),education_spending(231)).
head(id(143),superfund_right_to_sue(231)).
head(id(144),crime(231)).
head(id(145),export_administration_act_south_africa(231)).
head(id(146),physician_fee_freeze(306)).
head(id(147),el_salvador_aid(306)).
head(id(148),religious_groups_in_schools(306)).
head(id(149),immigration(306)).
head(id(150),education_spending(306)).
head(id(151),superfund_right_to_sue(306)).
head(id(152),crime(306)).
head(id(153),handicapped_infants(393)).
head(id(154),water_project_cost_sharing(393)).
head(id(155),physician_fee_freeze(393)).
head(id(156),el_salvador_aid(393)).
head(id(157),religious_groups_in_schools(393)).
head(id(158),synfuels_corporation_cutback(393)).
head(id(159),education_spending(393)).
head(id(160),superfund_right_to_sue(393)).
head(id(161),crime(393)).
head(id(162),export_administration_act_south_africa(393)).
head(id(163),handicapped_infants(348)).
head(id(164),physician_fee_freeze(348)).
head(id(165),el_salvador_aid(348)).
head(id(166),religious_groups_in_schools(348)).
head(id(167),immigration(348)).
head(id(168),education_spending(348)).
head(id(169),superfund_right_to_sue(348)).
head(id(170),crime(348)).
head(id(171),handicapped_infants(151)).
head(id(172),water_project_cost_sharing(151)).
head(id(173),physician_fee_freeze(151)).
head(id(174),el_salvador_aid(151)).
head(id(175),religious_groups_in_schools(151)).
head(id(176),immigration(151)).
head(id(177),education_spending(151)).
head(id(178),superfund_right_to_sue(151)).
head(id(179),crime(151)).
head(id(180),export_administration_act_south_africa(151)).
head(id(181),physician_fee_freeze(267)).
head(id(182),el_salvador_aid(267)).
head(id(183),religious_groups_in_schools(267)).
head(id(184),immigration(267)).
head(id(185),education_spending(267)).
head(id(186),crime(267)).
head(id(187),export_administration_act_south_africa(267)).
head(id(188),physician_fee_freeze(347)).
head(id(189),el_salvador_aid(347)).
head(id(190),religious_groups_in_schools(347)).
head(id(191),immigration(347)).
head(id(192),education_spending(347)).
head(id(193),superfund_right_to_sue(347)).
head(id(194),crime(347)).
head(id(195),export_administration_act_south_africa(347)).
head(id(196),physician_fee_freeze(134)).
head(id(197),el_salvador_aid(134)).
head(id(198),religious_groups_in_schools(134)).
head(id(199),immigration(134)).
head(id(200),education_spending(134)).
head(id(201),superfund_right_to_sue(134)).
head(id(202),crime(134)).
head(id(203),export_administration_act_south_africa(134)).
head(id(204),budget_resolution(201)).
head(id(205),anti_satellite_test_ban(201)).
head(id(206),aid_to_nicaraguan_contras(201)).
head(id(207),mx_missile(201)).
head(id(208),crime(201)).
head(id(209),duty_free_exports(201)).
head(id(210),export_administration_act_south_africa(201)).
head(id(211),handicapped_infants(420)).
head(id(212),water_project_cost_sharing(420)).
head(id(213),budget_resolution(420)).
head(id(214),anti_satellite_test_ban(420)).
head(id(215),aid_to_nicaraguan_contras(420)).
head(id(216),mx_missile(420)).
head(id(217),export_administration_act_south_africa(420)).
head(id(218),water_project_cost_sharing(153)).
head(id(219),budget_resolution(153)).
head(id(220),religious_groups_in_schools(153)).
head(id(221),aid_to_nicaraguan_contras(153)).
head(id(222),mx_missile(153)).
head(id(223),immigration(153)).
head(id(224),synfuels_corporation_cutback(153)).
head(id(225),superfund_right_to_sue(153)).
head(id(226),duty_free_exports(153)).
head(id(227),export_administration_act_south_africa(153)).
head(id(228),water_project_cost_sharing(366)).
head(id(229),el_salvador_aid(366)).
head(id(230),religious_groups_in_schools(366)).
head(id(231),immigration(366)).
head(id(232),synfuels_corporation_cutback(366)).
head(id(233),superfund_right_to_sue(366)).
head(id(234),crime(366)).
head(id(235),water_project_cost_sharing(89)).
head(id(236),budget_resolution(89)).
head(id(237),el_salvador_aid(89)).
head(id(238),religious_groups_in_schools(89)).
head(id(239),anti_satellite_test_ban(89)).
head(id(240),mx_missile(89)).
head(id(241),immigration(89)).
head(id(242),synfuels_corporation_cutback(89)).
head(id(243),superfund_right_to_sue(89)).
head(id(244),crime(89)).
head(id(245),export_administration_act_south_africa(89)).
head(id(246),budget_resolution(154)).
head(id(247),religious_groups_in_schools(154)).
head(id(248),anti_satellite_test_ban(154)).
head(id(249),aid_to_nicaraguan_contras(154)).
head(id(250),mx_missile(154)).
head(id(251),immigration(154)).
head(id(252),synfuels_corporation_cutback(154)).
head(id(253),superfund_right_to_sue(154)).
head(id(254),crime(154)).
head(id(255),export_administration_act_south_africa(154)).
head(id(256),religious_groups_in_schools(317)).
head(id(257),aid_to_nicaraguan_contras(317)).
head(id(258),mx_missile(317)).
head(id(259),synfuels_corporation_cutback(317)).
head(id(260),education_spending(317)).
head(id(261),superfund_right_to_sue(317)).
head(id(262),crime(317)).
head(id(263),duty_free_exports(317)).
head(id(264),handicapped_infants(203)).
head(id(265),budget_resolution(203)).
head(id(266),religious_groups_in_schools(203)).
head(id(267),anti_satellite_test_ban(203)).
head(id(268),aid_to_nicaraguan_contras(203)).
head(id(269),mx_missile(203)).
head(id(270),immigration(203)).
head(id(271),synfuels_corporation_cutback(203)).
head(id(272),duty_free_exports(203)).
head(id(273),export_administration_act_south_africa(203)).
head(id(274),handicapped_infants(386)).
head(id(275),water_project_cost_sharing(386)).
head(id(276),el_salvador_aid(386)).
head(id(277),religious_groups_in_schools(386)).
head(id(278),synfuels_corporation_cutback(386)).
head(id(279),education_spending(386)).
head(id(280),superfund_right_to_sue(386)).
head(id(281),crime(386)).
head(id(282),duty_free_exports(386)).
head(id(283),handicapped_infants(261)).
head(id(284),budget_resolution(261)).
head(id(285),anti_satellite_test_ban(261)).
head(id(286),aid_to_nicaraguan_contras(261)).
head(id(287),mx_missile(261)).
head(id(288),immigration(261)).
head(id(289),export_administration_act_south_africa(261)).
head(id(290),handicapped_infants(140)).
head(id(291),budget_resolution(140)).
head(id(292),religious_groups_in_schools(140)).
head(id(293),anti_satellite_test_ban(140)).
head(id(294),aid_to_nicaraguan_contras(140)).
head(id(295),mx_missile(140)).
head(id(296),duty_free_exports(140)).
head(id(297),export_administration_act_south_africa(140)).
head(id(298),handicapped_infants(412)).
head(id(299),budget_resolution(412)).
head(id(300),religious_groups_in_schools(412)).
head(id(301),anti_satellite_test_ban(412)).
head(id(302),aid_to_nicaraguan_contras(412)).
head(id(303),mx_missile(412)).
head(id(304),immigration(412)).
head(id(305),synfuels_corporation_cutback(412)).
head(id(306),export_administration_act_south_africa(412)).
head(id(307),water_project_cost_sharing(78)).
head(id(308),budget_resolution(78)).
head(id(309),physician_fee_freeze(78)).
head(id(310),el_salvador_aid(78)).
head(id(311),religious_groups_in_schools(78)).
head(id(312),aid_to_nicaraguan_contras(78)).
head(id(313),mx_missile(78)).
head(id(314),immigration(78)).
head(id(315),synfuels_corporation_cutback(78)).
head(id(316),education_spending(78)).
head(id(317),superfund_right_to_sue(78)).
head(id(318),crime(78)).
head(id(319),export_administration_act_south_africa(78)).
head(id(320),handicapped_infants(190)).
head(id(321),budget_resolution(190)).
head(id(322),anti_satellite_test_ban(190)).
head(id(323),aid_to_nicaraguan_contras(190)).
head(id(324),mx_missile(190)).
head(id(325),duty_free_exports(190)).
head(id(326),export_administration_act_south_africa(190)).
head(id(327),handicapped_infants(242)).
head(id(328),budget_resolution(242)).
head(id(329),anti_satellite_test_ban(242)).
head(id(330),aid_to_nicaraguan_contras(242)).
head(id(331),mx_missile(242)).
head(id(332),immigration(242)).
head(id(333),synfuels_corporation_cutback(242)).
head(id(334),crime(242)).
head(id(335),duty_free_exports(242)).
head(id(336),export_administration_act_south_africa(242)).
head(id(337),handicapped_infants(170)).
head(id(338),budget_resolution(170)).
head(id(339),anti_satellite_test_ban(170)).
head(id(340),aid_to_nicaraguan_contras(170)).
head(id(341),mx_missile(170)).
head(id(342),immigration(170)).
head(id(343),synfuels_corporation_cutback(170)).
head(id(344),crime(170)).
head(id(345),export_administration_act_south_africa(170)).
head(id(346),handicapped_infants(415)).
head(id(347),water_project_cost_sharing(415)).
head(id(348),budget_resolution(415)).
head(id(349),anti_satellite_test_ban(415)).
head(id(350),aid_to_nicaraguan_contras(415)).
head(id(351),mx_missile(415)).
head(id(352),export_administration_act_south_africa(415)).
head(id(353),water_project_cost_sharing(6)).
head(id(354),budget_resolution(6)).
head(id(355),el_salvador_aid(6)).
head(id(356),religious_groups_in_schools(6)).
head(id(357),superfund_right_to_sue(6)).
head(id(358),crime(6)).
head(id(359),duty_free_exports(6)).
head(id(360),export_administration_act_south_africa(6)).
head(id(361),water_project_cost_sharing(163)).
head(id(362),budget_resolution(163)).
head(id(363),el_salvador_aid(163)).
head(id(364),religious_groups_in_schools(163)).
head(id(365),anti_satellite_test_ban(163)).
head(id(366),synfuels_corporation_cutback(163)).
head(id(367),education_spending(163)).
head(id(368),superfund_right_to_sue(163)).
head(id(369),crime(163)).
head(id(370),export_administration_act_south_africa(163)).
head(id(371),water_project_cost_sharing(424)).
head(id(372),budget_resolution(424)).
head(id(373),religious_groups_in_schools(424)).
head(id(374),anti_satellite_test_ban(424)).
head(id(375),aid_to_nicaraguan_contras(424)).
head(id(376),mx_missile(424)).
head(id(377),synfuels_corporation_cutback(424)).
head(id(378),crime(424)).
head(id(379),duty_free_exports(424)).
head(id(380),export_administration_act_south_africa(424)).
head(id(381),handicapped_infants(407)).
head(id(382),budget_resolution(407)).
head(id(383),el_salvador_aid(407)).
head(id(384),religious_groups_in_schools(407)).
head(id(385),mx_missile(407)).
head(id(386),immigration(407)).
head(id(387),superfund_right_to_sue(407)).
head(id(388),crime(407)).
head(id(389),export_administration_act_south_africa(407)).
head(id(390),handicapped_infants(392)).
head(id(391),water_project_cost_sharing(392)).
head(id(392),aid_to_nicaraguan_contras(392)).
head(id(393),mx_missile(392)).
head(id(394),synfuels_corporation_cutback(392)).
head(id(395),duty_free_exports(392)).
head(id(396),handicapped_infants(338)).
head(id(397),budget_resolution(338)).
head(id(398),anti_satellite_test_ban(338)).
head(id(399),aid_to_nicaraguan_contras(338)).
head(id(400),mx_missile(338)).
head(id(401),duty_free_exports(338)).
head(id(402),export_administration_act_south_africa(338)).
head(id(403),handicapped_infants(30)).
head(id(404),water_project_cost_sharing(30)).
head(id(405),budget_resolution(30)).
head(id(406),anti_satellite_test_ban(30)).
head(id(407),aid_to_nicaraguan_contras(30)).
head(id(408),mx_missile(30)).
head(id(409),synfuels_corporation_cutback(30)).
head(id(410),duty_free_exports(30)).
head(id(411),export_administration_act_south_africa(30)).
head(id(1721,A),republican(A)) :- dom(A).
body(id(1721,A),alpha_1(A)) :- dom(A).
body(id(1721,A),physician_fee_freeze(A)) :- dom(A).
head(id(12844,A),c_alpha_1(A)) :- dom(A).
body(id(12844,A),alpha_2(A)) :- dom(A).
body(id(12844,A),water_project_cost_sharing(A)) :- dom(A).
head(id(15014,A),c_alpha_2(A)) :- dom(A).
body(id(15014,A),alpha_1(A)) :- dom(A).
body(id(15014,A),physician_fee_freeze(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).

dom(6).
dom(29).
dom(30).
dom(34).
dom(38).
dom(57).
dom(59).
dom(62).
dom(78).
dom(83).
dom(84).
dom(89).
dom(118).
dom(134).
dom(140).
dom(143).
dom(151).
dom(153).
dom(154).
dom(163).
dom(164).
dom(170).
dom(190).
dom(201).
dom(203).
dom(231).
dom(240).
dom(242).
dom(261).
dom(267).
dom(301).
dom(306).
dom(317).
dom(338).
dom(347).
dom(348).
dom(357).
dom(366).
dom(386).
dom(392).
dom(393).
dom(405).
dom(406).
dom(407).
dom(412).
dom(415).
dom(420).
dom(424).
 :- not supported(republican(301)).
 :- not supported(republican(405)).
 :- not supported(republican(143)).
 :- not supported(republican(357)).
 :- not supported(republican(240)).
 :- not supported(republican(406)).
 :- not supported(republican(62)).
 :- not supported(republican(59)).
 :- not supported(republican(34)).
 :- not supported(republican(164)).
 :- not supported(republican(84)).
 :- not supported(republican(83)).
 :- not supported(republican(38)).
 :- not supported(republican(57)).
 :- not supported(republican(118)).
 :- not supported(republican(29)).
 :- not supported(republican(231)).
 :- not supported(republican(306)).
 :- not supported(republican(393)).
 :- not supported(republican(348)).
 :- not supported(republican(151)).
 :- not supported(republican(267)).
 :- not supported(republican(347)).
 :- not supported(republican(134)).
 :- supported(republican(201)).
 :- supported(republican(420)).
 :- supported(republican(153)).
 :- supported(republican(366)).
 :- supported(republican(89)).
 :- supported(republican(154)).
 :- supported(republican(317)).
 :- supported(republican(203)).
 :- supported(republican(386)).
 :- supported(republican(261)).
 :- supported(republican(140)).
 :- supported(republican(412)).
 :- supported(republican(78)).
 :- supported(republican(190)).
 :- supported(republican(242)).
 :- supported(republican(170)).
 :- supported(republican(415)).
 :- supported(republican(6)).
 :- supported(republican(163)).
 :- supported(republican(424)).
 :- supported(republican(407)).
 :- supported(republican(392)).
 :- supported(republican(338)).
 :- supported(republican(30)).
