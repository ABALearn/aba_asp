head(id(1),a5(241)).
head(id(2),a6(241)).
head(id(3),a7(241)).
head(id(4),a11(241)).
head(id(5),a13(241)).
head(id(6),w(241)).
head(id(7),a24(241)).
head(id(8),a26(241)).
head(id(9),a34(241)).
head(id(10),a35(241)).
head(id(11),a6(1809)).
head(id(12),a7(1809)).
head(id(13),a11(1809)).
head(id(14),a13(1809)).
head(id(15),w(1809)).
head(id(16),a20(1809)).
head(id(17),a26(1809)).
head(id(18),a31(1809)).
head(id(19),a9(600)).
head(id(20),a13(600)).
head(id(21),n(600)).
head(id(22),a18(600)).
head(id(23),a22(600)).
head(id(24),a34(600)).
head(id(25),a35(600)).
head(id(26),a36(600)).
head(id(27),a2(1918)).
head(id(28),a3(1918)).
head(id(29),a6(1918)).
head(id(30),n(1918)).
head(id(31),a18(1918)).
head(id(32),a24(1918)).
head(id(33),a26(1918)).
head(id(34),a35(1918)).
head(id(35),a36(1918)).
head(id(36),a5(751)).
head(id(37),a6(751)).
head(id(38),a7(751)).
head(id(39),a13(751)).
head(id(40),n(751)).
head(id(41),a21(751)).
head(id(42),a35(751)).
head(id(43),a1(200)).
head(id(44),a6(200)).
head(id(45),a7(200)).
head(id(46),a11(200)).
head(id(47),a13(200)).
head(id(48),b(200)).
head(id(49),a18(200)).
head(id(50),a24(200)).
head(id(51),a26(200)).
head(id(52),a34(200)).
head(id(53),a35(200)).
head(id(54),a2(1702)).
head(id(55),a11(1702)).
head(id(56),a13(1702)).
head(id(57),w(1702)).
head(id(58),a20(1702)).
head(id(59),a26(1702)).
head(id(60),a31(1702)).
head(id(61),a5(68)).
head(id(62),a7(68)).
head(id(63),a13(68)).
head(id(64),n(68)).
head(id(65),a24(68)).
head(id(66),a26(68)).
head(id(67),a34(68)).
head(id(68),a35(68)).
head(id(69),a10(2011)).
head(id(70),a11(2011)).
head(id(71),a13(2011)).
head(id(72),w(2011)).
head(id(73),a18(2011)).
head(id(74),a20(2011)).
head(id(75),a21(2011)).
head(id(76),a24(2011)).
head(id(77),a26(2011)).
head(id(78),a31(2011)).
head(id(79),a33(2011)).
head(id(80),a34(2011)).
head(id(81),a35(2011)).
head(id(82),a1(49)).
head(id(83),a11(49)).
head(id(84),a13(49)).
head(id(85),n(49)).
head(id(86),a18(49)).
head(id(87),a24(49)).
head(id(88),a26(49)).
head(id(89),a31(49)).
head(id(90),a34(49)).
head(id(91),a1(2258)).
head(id(92),a4(2258)).
head(id(93),a6(2258)).
head(id(94),a11(2258)).
head(id(95),a13(2258)).
head(id(96),w(2258)).
head(id(97),a21(2258)).
head(id(98),a24(2258)).
head(id(99),a26(2258)).
head(id(100),a27(2258)).
head(id(101),a31(2258)).
head(id(102),a33(2258)).
head(id(103),a35(2258)).
head(id(104),a13(611)).
head(id(105),n(611)).
head(id(106),a24(611)).
head(id(107),a34(611)).
head(id(108),a35(611)).
head(id(109),a36(611)).
head(id(110),a2(2324)).
head(id(111),a5(2324)).
head(id(112),a9(2324)).
head(id(113),a13(2324)).
head(id(114),n(2324)).
head(id(115),a21(2324)).
head(id(116),a22(2324)).
head(id(117),a30(2324)).
head(id(118),a33(2324)).
head(id(119),a35(2324)).
head(id(120),a36(2324)).
head(id(121),a13(703)).
head(id(122),n(703)).
head(id(123),a18(703)).
head(id(124),a21(703)).
head(id(125),a26(703)).
head(id(126),a34(703)).
head(id(127),a35(703)).
head(id(128),a2(2308)).
head(id(129),a9(2308)).
head(id(130),a13(2308)).
head(id(131),n(2308)).
head(id(132),a21(2308)).
head(id(133),a22(2308)).
head(id(134),a24(2308)).
head(id(135),a33(2308)).
head(id(136),a35(2308)).
head(id(137),a36(2308)).
head(id(138),a5(594)).
head(id(139),a6(594)).
head(id(140),a7(594)).
head(id(141),a8(594)).
head(id(142),a9(594)).
head(id(143),a13(594)).
head(id(144),n(594)).
head(id(145),a18(594)).
head(id(146),a26(594)).
head(id(147),a35(594)).
head(id(148),a36(594)).
head(id(149),a6(259)).
head(id(150),a7(259)).
head(id(151),a8(259)).
head(id(152),a9(259)).
head(id(153),a11(259)).
head(id(154),a13(259)).
head(id(155),w(259)).
head(id(156),a18(259)).
head(id(157),a22(259)).
head(id(158),a26(259)).
head(id(159),a34(259)).
head(id(160),a35(259)).
head(id(161),a7(107)).
head(id(162),a8(107)).
head(id(163),a9(107)).
head(id(164),a11(107)).
head(id(165),a13(107)).
head(id(166),w(107)).
head(id(167),a18(107)).
head(id(168),a20(107)).
head(id(169),a26(107)).
head(id(170),a34(107)).
head(id(171),a35(107)).
head(id(172),a6(339)).
head(id(173),a9(339)).
head(id(174),a13(339)).
head(id(175),n(339)).
head(id(176),a22(339)).
head(id(177),a24(339)).
head(id(178),a35(339)).
head(id(179),a9(671)).
head(id(180),n(671)).
head(id(181),a18(671)).
head(id(182),a22(671)).
head(id(183),a34(671)).
head(id(184),a35(671)).
head(id(185),a36(671)).
head(id(186),a6(591)).
head(id(187),a13(591)).
head(id(188),n(591)).
head(id(189),a24(591)).
head(id(190),a26(591)).
head(id(191),a33(591)).
head(id(192),a35(591)).
head(id(193),a36(591)).
head(id(194),a10(1408)).
head(id(195),n(1408)).
head(id(196),a18(1408)).
head(id(197),a24(1408)).
head(id(198),a26(1408)).
head(id(199),a34(1408)).
head(id(200),a35(1408)).
head(id(201),a6(1531)).
head(id(202),a10(1531)).
head(id(203),a12(1531)).
head(id(204),n(1531)).
head(id(205),a18(1531)).
head(id(206),a34(1531)).
head(id(207),a35(1531)).
head(id(208),a4(3020)).
head(id(209),a5(3020)).
head(id(210),a6(3020)).
head(id(211),n(3020)).
head(id(212),a24(3020)).
head(id(213),a26(3020)).
head(id(214),a27(3020)).
head(id(215),a33(3020)).
head(id(216),a35(3020)).
head(id(217),a36(3020)).
head(id(218),a7(1250)).
head(id(219),a10(1250)).
head(id(220),a11(1250)).
head(id(221),a13(1250)).
head(id(222),n(1250)).
head(id(223),a18(1250)).
head(id(224),a26(1250)).
head(id(225),a33(1250)).
head(id(226),a34(1250)).
head(id(227),a35(1250)).
head(id(228),a5(1481)).
head(id(229),a6(1481)).
head(id(230),a7(1481)).
head(id(231),a8(1481)).
head(id(232),a9(1481)).
head(id(233),a10(1481)).
head(id(234),a11(1481)).
head(id(235),n(1481)).
head(id(236),a18(1481)).
head(id(237),a26(1481)).
head(id(238),a34(1481)).
head(id(239),a35(1481)).
head(id(240),a6(2576)).
head(id(241),a7(2576)).
head(id(242),a10(2576)).
head(id(243),a11(2576)).
head(id(244),a13(2576)).
head(id(245),w(2576)).
head(id(246),a18(2576)).
head(id(247),a20(2576)).
head(id(248),a26(2576)).
head(id(249),a31(2576)).
head(id(250),a33(2576)).
head(id(251),a34(2576)).
head(id(252),a11(2821)).
head(id(253),a13(2821)).
head(id(254),n(2821)).
head(id(255),a18(2821)).
head(id(256),a20(2821)).
head(id(257),a26(2821)).
head(id(258),a27(2821)).
head(id(259),a31(2821)).
head(id(260),a33(2821)).
head(id(261),a34(2821)).
head(id(262),a5(1045)).
head(id(263),a6(1045)).
head(id(264),a7(1045)).
head(id(265),a8(1045)).
head(id(266),a9(1045)).
head(id(267),a13(1045)).
head(id(268),n(1045)).
head(id(269),a18(1045)).
head(id(270),a33(1045)).
head(id(271),a35(1045)).
head(id(272),a10(1494)).
head(id(273),n(1494)).
head(id(274),a18(1494)).
head(id(275),a24(1494)).
head(id(276),a33(1494)).
head(id(277),a34(1494)).
head(id(278),a35(1494)).
head(id(279),a5(2868)).
head(id(280),a9(2868)).
head(id(281),a13(2868)).
head(id(282),n(2868)).
head(id(283),a20(2868)).
head(id(284),a22(2868)).
head(id(285),a26(2868)).
head(id(286),a32(2868)).
head(id(287),a34(2868)).
head(id(288),a1(2494)).
head(id(289),a3(2494)).
head(id(290),a7(2494)).
head(id(291),a8(2494)).
head(id(292),a9(2494)).
head(id(293),a10(2494)).
head(id(294),a11(2494)).
head(id(295),a13(2494)).
head(id(296),b(2494)).
head(id(297),a18(2494)).
head(id(298),a24(2494)).
head(id(299),a26(2494)).
head(id(300),a35(2494)).
head(id(301),a1(2833)).
head(id(302),a2(2833)).
head(id(303),a13(2833)).
head(id(304),b(2833)).
head(id(305),a18(2833)).
head(id(306),a26(2833)).
head(id(307),a32(2833)).
head(id(308),a11(925)).
head(id(309),a13(925)).
head(id(310),n(925)).
head(id(311),a18(925)).
head(id(312),a20(925)).
head(id(313),a26(925)).
head(id(314),a31(925)).
head(id(315),a33(925)).
head(id(316),a34(925)).
head(id(317),a2(1285)).
head(id(318),a10(1285)).
head(id(319),a13(1285)).
head(id(320),n(1285)).
head(id(321),a26(1285)).
head(id(322),a33(1285)).
head(id(323),a34(1285)).
head(id(324),a35(1285)).
head(id(325),a5(1144)).
head(id(326),a6(1144)).
head(id(327),a7(1144)).
head(id(328),n(1144)).
head(id(329),a18(1144)).
head(id(330),a24(1144)).
head(id(331),a33(1144)).
head(id(332),a34(1144)).
head(id(333),a35(1144)).
head(id(334),a7(1305)).
head(id(335),a8(1305)).
head(id(336),a9(1305)).
head(id(337),a10(1305)).
head(id(338),a11(1305)).
head(id(339),a13(1305)).
head(id(340),n(1305)).
head(id(341),a26(1305)).
head(id(342),a33(1305)).
head(id(343),a34(1305)).
head(id(344),a35(1305)).
head(id(345),a5(2855)).
head(id(346),a7(2855)).
head(id(347),a11(2855)).
head(id(348),a13(2855)).
head(id(349),n(2855)).
head(id(350),a20(2855)).
head(id(351),a26(2855)).
head(id(352),a31(2855)).
head(id(353),a33(2855)).
head(id(354),a1(3159)).
head(id(355),a7(3159)).
head(id(356),b(3159)).
head(id(357),a18(3159)).
head(id(358),a23(3159)).
head(id(359),a26(3159)).
head(id(360),a29(3159)).
head(id(361),a32(3159)).
head(id(362),a34(3159)).
head(id(363),a2(2616)).
head(id(364),a6(2616)).
head(id(365),a10(2616)).
head(id(366),a13(2616)).
head(id(367),n(2616)).
head(id(368),a16(2616)).
head(id(369),a18(2616)).
head(id(370),a24(2616)).
head(id(371),a33(2616)).
head(id(372),a34(2616)).
head(id(373),a35(2616)).
head(id(374),a13(3094)).
head(id(375),n(3094)).
head(id(376),a27(3094)).
head(id(377),a30(3094)).
head(id(378),a33(3094)).
head(id(379),a35(3094)).
head(id(380),a36(3094)).
head(id(1588,A),krkp(A)) :- dom(A).
body(id(1588,A),alpha_1(A)) :- dom(A).
body(id(1588,A),a5(A)) :- dom(A).
head(id(2808,A),krkp(A)) :- dom(A).
body(id(2808,A),alpha_2(A)) :- dom(A).
body(id(2808,A),a6(A)) :- dom(A).
head(id(4040,A),krkp(A)) :- dom(A).
body(id(4040,A),alpha_3(A)) :- dom(A).
body(id(4040,A),a9(A)) :- dom(A).
head(id(6511,A),krkp(A)) :- dom(A).
body(id(6511,A),alpha_4(A)) :- dom(A).
body(id(6511,A),a2(A)) :- dom(A).
head(id(8169,A),krkp(A)) :- dom(A).
body(id(8169,A),alpha_5(A)) :- dom(A).
body(id(8169,A),a10(A)) :- dom(A).
head(id(9425,A),krkp(A)) :- dom(A).
body(id(9425,A),alpha_6(A)) :- dom(A).
body(id(9425,A),a1(A)) :- dom(A).
head(id(11111,A),krkp(A)) :- dom(A).
body(id(11111,A),alpha_7(A)) :- dom(A).
body(id(11111,A),a13(A)) :- dom(A).
assumption(alpha_1(A)) :- dom(A).
assumption(alpha_2(A)) :- dom(A).
assumption(alpha_3(A)) :- dom(A).
assumption(alpha_4(A)) :- dom(A).
assumption(alpha_5(A)) :- dom(A).
assumption(alpha_6(A)) :- dom(A).
assumption(alpha_7(A)) :- dom(A).
contrary(alpha_1(A),c_alpha_1(A)) :- assumption(alpha_1(A)).
contrary(alpha_2(A),c_alpha_2(A)) :- assumption(alpha_2(A)).
contrary(alpha_3(A),c_alpha_3(A)) :- assumption(alpha_3(A)).
contrary(alpha_4(A),c_alpha_4(A)) :- assumption(alpha_4(A)).
contrary(alpha_5(A),c_alpha_5(A)) :- assumption(alpha_5(A)).
contrary(alpha_6(A),c_alpha_6(A)) :- assumption(alpha_6(A)).
contrary(alpha_7(A),c_alpha_7(A)) :- assumption(alpha_7(A)).

dom(49).
dom(68).
dom(107).
dom(200).
dom(241).
dom(259).
dom(339).
dom(591).
dom(594).
dom(600).
dom(611).
dom(671).
dom(703).
dom(751).
dom(925).
dom(1045).
dom(1144).
dom(1250).
dom(1285).
dom(1305).
dom(1408).
dom(1481).
dom(1494).
dom(1531).
dom(1702).
dom(1809).
dom(1918).
dom(2011).
dom(2258).
dom(2308).
dom(2324).
dom(2494).
dom(2576).
dom(2616).
dom(2821).
dom(2833).
dom(2855).
dom(2868).
dom(3020).
dom(3094).
dom(3159).
 :- not supported(krkp(241)).
 :- not supported(krkp(1809)).
 :- not supported(krkp(600)).
 :- not supported(krkp(1918)).
 :- not supported(krkp(751)).
 :- not supported(krkp(200)).
 :- not supported(krkp(1702)).
 :- not supported(krkp(68)).
 :- not supported(krkp(2011)).
 :- not supported(krkp(49)).
 :- not supported(krkp(2258)).
 :- not supported(krkp(611)).
 :- not supported(krkp(2324)).
 :- not supported(krkp(703)).
 :- not supported(krkp(2308)).
 :- not supported(krkp(594)).
 :- not supported(krkp(259)).
 :- not supported(krkp(107)).
 :- not supported(krkp(339)).
 :- not supported(krkp(671)).
 :- not supported(krkp(591)).
 :- supported(krkp(1408)).
 :- supported(krkp(1531)).
 :- supported(krkp(3020)).
 :- supported(krkp(1250)).
 :- supported(krkp(1481)).
 :- supported(krkp(2576)).
 :- supported(krkp(2821)).
 :- supported(krkp(1045)).
 :- supported(krkp(1494)).
 :- supported(krkp(2868)).
 :- supported(krkp(2494)).
 :- supported(krkp(2833)).
 :- supported(krkp(925)).
 :- supported(krkp(1285)).
 :- supported(krkp(1144)).
 :- supported(krkp(1305)).
 :- supported(krkp(2855)).
 :- supported(krkp(3159)).
 :- supported(krkp(2616)).
 :- supported(krkp(3094)).
